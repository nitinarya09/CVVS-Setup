import re
# gui/tabs_qt/validation_results_tab.py
# PySide6 GUI tab for viewing Live Validation Results and opening Audit Reports

import os
import sys
import subprocess
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFrame,
    QPushButton, QLabel, QTableView, QHeaderView, QAbstractItemView,
    QComboBox, QLineEdit, QDialog, QTextEdit, QDialogButtonBox
)
from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex, QSortFilterProxyModel
from PySide6.QtGui import QFont, QColor

def open_voucher_folder(app, voucher_no: str, treasury: str = "", mh: str = "", amount: str = ""):
    import re, subprocess
    """Find and open the exact matching downloaded voucher folder on disk using token-smart metric scoring."""
    base_dir = getattr(app, "download_dir", None) or os.path.join(getattr(app, "APP_DIR", os.getcwd()), "downloads")

    # If base_dir does not exist, fallback to workspace base_path or cwd
    if not os.path.exists(base_dir):
        base_dir = getattr(app, "base_path", os.getcwd())

    target_vno = str(voucher_no).strip().lstrip("0") or str(voucher_no).strip()
    target_trs = str(treasury).strip().lstrip("0") or str(treasury).strip()
    target_mh = str(mh).strip().lstrip("0") or str(mh).strip()
    
    amt_clean = str(amount).strip().replace("₹", "").replace(",", "").strip()
    target_amt = amt_clean.split(".")[0] if amt_clean else ""

    best_folder = None
    best_score = 0

    # Walk base_dir to score matching voucher subfolders
    for root, dirs, files in os.walk(base_dir):
        for d in dirs:
            d_name = d.strip()
            # Clean tokens split by underscore
            parts = [p.strip().lstrip("0") for p in d_name.split("_")]
            score = 0

            # 1. Exact token matching for Voucher No
            if target_vno and target_vno in parts:
                score += 1000
            elif target_vno and re.search(r'(?:^|[_\-\s])0*' + re.escape(target_vno) + r'(?:[_\-\s]|$)', d_name):
                score += 800

            # 2. Exact token matching for Treasury
            if target_trs and target_trs in parts:
                score += 500
            elif target_trs and re.search(r'(?:^|[_\-\s])0*' + re.escape(target_trs) + r'(?:[_\-\s]|$)', d_name):
                score += 300

            # 3. Exact token matching for Major Head
            if target_mh and target_mh in parts:
                score += 300
            elif target_mh and target_mh in d_name:
                score += 100

            # 4. Exact matching for Amount
            if target_amt and any(target_amt in p for p in parts):
                score += 200

            if score > best_score:
                best_score = score
                best_folder = os.path.join(root, d)

    # Use best folder if score >= 400, else fallback to base_dir so Explorer always opens
    if best_folder and os.path.exists(best_folder) and best_score >= 400:
        target_folder = best_folder
    else:
        target_folder = base_dir if os.path.exists(base_dir) else os.getcwd()
        if hasattr(app, "log"):
            app.log(f"⚠️ Specific folder not found for Voucher #{voucher_no} (Treasury: {treasury}, MH: {mh}). Opening downloads directory...")

    try:
        if sys.platform == "win32":
            os.startfile(target_folder)
        else:
            subprocess.Popen(["xdg-open", target_folder])
        if hasattr(app, "log"):
            app.log(f"📂 Opened voucher folder (Score {best_score}): {target_folder}")
    except Exception as e:
        if hasattr(app, "log"):
            app.log(f"⚠️ Failed to open folder: {e}")

class AuditFindingDetailsDialog(QDialog):
    """Modal dialog to view complete unabbreviated finding messages and details."""
    def __init__(self, entry: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"📋 Audit Finding Details — Voucher #{entry.get('voucher_no', '')}")
        self.resize(650, 420)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)
        
        # Header Info Card - Theme Adaptive
        info_frame = QFrame()
        info_frame.setProperty("cssClass", "card")
        info_frame.setStyleSheet("QFrame { border: 1px solid rgba(148, 163, 184, 0.25); border-radius: 8px; padding: 10px; }")
        info_lay = QVBoxLayout(info_frame)
        
        chk_lbl = QLabel(f"<b>Check Name:</b> {entry.get('check_name', '')}")
        chk_lbl.setFont(QFont("Segoe UI", 11))
        info_lay.addWidget(chk_lbl)
        
        meta_str = f"<b>Voucher No:</b> {entry.get('voucher_no', '')} | <b>Treasury:</b> {entry.get('treasury', '')} | <b>Major Head:</b> {entry.get('mh', '')} | <b>Amount:</b> ₹{entry.get('amount', '')}"
        meta_lbl = QLabel(meta_str)
        meta_lbl.setFont(QFont("Segoe UI", 10))
        info_lay.addWidget(meta_lbl)
        
        st = str(entry.get('status', '')).upper()
        st_lbl = QLabel(f"<b>Status:</b> {st}")
        st_lbl.setFont(QFont("Segoe UI", 11, QFont.Bold))
        if st in ("PASS", "MATCHED"):
            st_lbl.setStyleSheet("color: #10b981;")
        elif st in ("WARNING", "SUSPICIOUS", "MISMATCH"):
            st_lbl.setStyleSheet("color: #d97706;")
        elif st in ("FAIL", "ERROR"):
            st_lbl.setStyleSheet("color: #ef4444;")
        info_lay.addWidget(st_lbl)
        
        layout.addWidget(info_frame)
        
        # Text Area for Full Un-truncated Message - Theme Adaptive
        msg_title = QLabel("📄 Complete Message / Audit Findings:")
        msg_title.setFont(QFont("Segoe UI", 10, QFont.Bold))
        layout.addWidget(msg_title)
        
        txt_box = QTextEdit()
        txt_box.setReadOnly(True)
        txt_box.setFont(QFont("Segoe UI", 10))
        txt_box.setText(str(entry.get("message", "")))
        txt_box.setStyleSheet("QTextEdit { border: 1px solid rgba(148, 163, 184, 0.3); border-radius: 6px; padding: 8px; }")
        layout.addWidget(txt_box, 1)
        
        # Action Buttons
        btn_box = QHBoxLayout()
        btn_box.addStretch(1)
        
        btn_open_folder = QPushButton("📂 Open Voucher Folder")
        btn_open_folder.setProperty("cssClass", "secondary")
        btn_open_folder.clicked.connect(lambda: open_voucher_folder(parent, entry.get('voucher_no', ''), entry.get('treasury', ''), entry.get('mh', ''), entry.get('amount', '')))
        btn_box.addWidget(btn_open_folder)
        
        btn_close = QPushButton("Close")
        btn_close.setProperty("cssClass", "primary")
        btn_close.clicked.connect(self.accept)
        btn_box.addWidget(btn_close)
        
        layout.addLayout(btn_box)


class ValidationResultsModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.headers = ["📂", "Voucher No", "Treasury", "Major Head", "Amount", "Check Name", "Status", "Message / Findings"]
        self._data = []

    def rowCount(self, parent=QModelIndex()):
        return len(self._data)

    def columnCount(self, parent=QModelIndex()):
        return len(self.headers)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None

        row = index.row()
        col = index.column()
        entry = self._data[row]

        if role == Qt.DisplayRole:
            if col == 0:
                return "📂"
            elif col == 1:
                v_str = str(entry.get("voucher_no", "")).strip()
                if v_str.startswith('="') and v_str.endswith('"'): v_str = v_str[2:-1].strip()
                elif v_str.startswith('='): v_str = v_str[1:].strip().strip('"')
                return v_str
            elif col == 2:
                t_str = str(entry.get("treasury", "")).strip()
                if t_str.startswith('="') and t_str.endswith('"'): t_str = t_str[2:-1].strip()
                elif t_str.startswith('='): t_str = t_str[1:].strip().strip('"')
                return t_str
            elif col == 3:
                m_str = str(entry.get("mh", "")).strip()
                if m_str.startswith('="') and m_str.endswith('"'): m_str = m_str[2:-1].strip()
                elif m_str.startswith('='): m_str = m_str[1:].strip().strip('"')
                return m_str
            elif col == 4:
                amt = entry.get("amount", "")
                return f"₹{amt}" if amt else ""
            elif col == 5:
                return str(entry.get("check_name", ""))
            elif col == 6:
                return str(entry.get("status", "")).upper()
            elif col == 7:
                return str(entry.get("message", ""))

        elif role == Qt.ToolTipRole:
            v_no = str(entry.get("voucher_no", ""))
            trs = str(entry.get("treasury", ""))
            chk = str(entry.get("check_name", ""))
            st = str(entry.get("status", "")).upper()
            msg = str(entry.get("message", ""))
            return f"Voucher #{v_no} (Treasury {trs})\nCheck: {chk}\nStatus: {st}\n\nFindings:\n{msg}"

        elif role == Qt.ForegroundRole:
            if col == 6:
                st = str(entry.get("status", "")).upper()
                if st in ("PASS", "MATCHED"):
                    return QColor("#22c55e")
                elif st in ("WARNING", "SUSPICIOUS", "MISMATCH"):
                    return QColor("#eab308")
                elif st in ("FAIL", "ERROR"):
                    return QColor("#ef4444")

        elif role == Qt.TextAlignmentRole:
            if col in (0, 1, 2, 3, 4, 6):
                return Qt.AlignCenter

        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole and orientation == Qt.Horizontal:
            return self.headers[section]
        return None

    def add_result(self, entry):
        self.beginInsertRows(QModelIndex(), len(self._data), len(self._data))
        self._data.append(entry)
        self.endInsertRows()

    def add_results_batch(self, entries_list):
        if not entries_list:
            return
        self.beginInsertRows(QModelIndex(), len(self._data), len(self._data) + len(entries_list) - 1)
        self._data.extend(entries_list)
        self.endInsertRows()

    def set_results(self, entries_list):
        self.beginResetModel()
        self._data = list(entries_list)
        self.endResetModel()

    def clear(self):
        self.beginResetModel()
        self._data.clear()
        self.endResetModel()

    def get_row_data(self, row):
        if 0 <= row < len(self._data):
            return self._data[row]
        return None


class ValidationResultsFilterProxyModel(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.status_filter = "⚠️ Errors & Warnings Only"
        self.search_text = ""

    def filterAcceptsRow(self, source_row, source_parent):
        model = self.sourceModel()
        entry = model.get_row_data(source_row)
        if not entry:
            return False

        st = str(entry.get("status", "")).upper()
        status_match = False

        if self.status_filter == "⚠️ Errors & Warnings Only":
            status_match = st in ("WARNING", "SUSPICIOUS", "MISMATCH", "FAIL", "ERROR")
        elif self.status_filter == "📋 All Results":
            status_match = True
        elif self.status_filter == "✅ Passed Only":
            status_match = st in ("PASS", "MATCHED")
        elif self.status_filter == "❌ Errors Only":
            status_match = st in ("FAIL", "ERROR")
        elif self.status_filter == "⚠️ Warnings Only":
            status_match = st in ("WARNING", "SUSPICIOUS", "MISMATCH")
        else:
            status_match = True

        if not status_match:
            return False

        if self.search_text:
            s = self.search_text.lower()
            v_no = str(entry.get("voucher_no", "")).lower()
            trs = str(entry.get("treasury", "")).lower()
            chk = str(entry.get("check_name", "")).lower()
            msg = str(entry.get("message", "")).lower()
            if s not in v_no and s not in trs and s not in chk and s not in msg:
                return False

        return True

    def set_status_filter(self, text):
        self.status_filter = text
        self.invalidateFilter()

    def set_search_text(self, text):
        self.search_text = text
        self.invalidateFilter()


def build_validation_results_tab(app, tab):
    """Build the Validation Results Tab showing realtime check findings and report links."""
    layout = QVBoxLayout(tab)
    layout.setContentsMargins(10, 5, 10, 5)
    layout.setSpacing(8)

    # Info Header
    app.lbl_results_info = QLabel(
        "📊 Live Validation Results & Audit Reports Dashboard\n"
        "Real-time alerts, tally verification flags, and consolidated audit reports generated during downloading."
    )
    app.lbl_results_info.setFont(QFont("Segoe UI", 11))
    font = app.lbl_results_info.font()
    font.setItalic(True)
    app.lbl_results_info.setFont(font)
    app.lbl_results_info.setAlignment(Qt.AlignCenter)
    app.lbl_results_info.setWordWrap(True)
    app.lbl_results_info.setProperty("cssClass", "muted")
    layout.addWidget(app.lbl_results_info)

    # Metric Cards Row
    metrics_frame = QFrame()
    metrics_layout = QHBoxLayout(metrics_frame)
    metrics_layout.setContentsMargins(0, 0, 0, 0)
    metrics_layout.setSpacing(10)

    card_total = QFrame()
    card_total.setProperty("cssClass", "card")
    c1_lay = QVBoxLayout(card_total)
    c1_lay.setContentsMargins(10, 8, 10, 8)
    lbl_c1_title = QLabel("Total Checks Run")
    lbl_c1_title.setFont(QFont("Segoe UI", 9))
    lbl_c1_title.setProperty("cssClass", "muted")
    c1_lay.addWidget(lbl_c1_title)
    app.lbl_val_total_checks = QLabel("0")
    app.lbl_val_total_checks.setFont(QFont("Segoe UI", 18, QFont.Bold))
    app.lbl_val_total_checks.setStyleSheet("color: #38bdf8;")
    c1_lay.addWidget(app.lbl_val_total_checks)
    metrics_layout.addWidget(card_total)

    card_passed = QFrame()
    card_passed.setProperty("cssClass", "card")
    c2_lay = QVBoxLayout(card_passed)
    c2_lay.setContentsMargins(10, 8, 10, 8)
    lbl_c2_title = QLabel("Passed Validations")
    lbl_c2_title.setFont(QFont("Segoe UI", 9))
    lbl_c2_title.setProperty("cssClass", "muted")
    c2_lay.addWidget(lbl_c2_title)
    app.lbl_val_passed_checks = QLabel("0")
    app.lbl_val_passed_checks.setFont(QFont("Segoe UI", 18, QFont.Bold))
    app.lbl_val_passed_checks.setStyleSheet("color: #22c55e;")
    c2_lay.addWidget(app.lbl_val_passed_checks)
    metrics_layout.addWidget(card_passed)

    card_alerts = QFrame()
    card_alerts.setProperty("cssClass", "card")
    c3_lay = QVBoxLayout(card_alerts)
    c3_lay.setContentsMargins(10, 8, 10, 8)
    lbl_c3_title = QLabel("Flagged Discrepancies")
    lbl_c3_title.setFont(QFont("Segoe UI", 9))
    lbl_c3_title.setProperty("cssClass", "muted")
    c3_lay.addWidget(lbl_c3_title)
    app.lbl_val_flagged_checks = QLabel("0")
    app.lbl_val_flagged_checks.setFont(QFont("Segoe UI", 18, QFont.Bold))
    app.lbl_val_flagged_checks.setStyleSheet("color: #eab308;")
    c3_lay.addWidget(app.lbl_val_flagged_checks)
    metrics_layout.addWidget(card_alerts)

    layout.addWidget(metrics_frame)

    # Action Toolbar for opening reports
    report_tool_frame = QFrame()
    rt_layout = QHBoxLayout(report_tool_frame)
    rt_layout.setContentsMargins(0, 0, 0, 0)
    rt_layout.setSpacing(10)

    btn_open_excel = QPushButton("📊 Open Consolidated Excel Report")
    btn_open_excel.setProperty("cssClass", "primary")
    btn_open_excel.setFixedHeight(32)

    def _open_last_excel():
        out_dir = app.download_dir or os.path.join(getattr(app, "APP_DIR", os.getcwd()), "downloads")
        if hasattr(app, "last_excel_report") and app.last_excel_report and os.path.exists(app.last_excel_report):
            target = app.last_excel_report
        else:
            target = None
            if os.path.exists(out_dir):
                files = [os.path.join(out_dir, f) for f in os.listdir(out_dir) if f.startswith("Centralized_Validation_Report_") and f.endswith(".xlsx")]
                if files:
                    files.sort(key=os.path.getmtime, reverse=True)
                    target = files[0]

        if not target and hasattr(app, "trigger_post_download_checks"):
            app.log("📊 Generating Consolidated Excel Report on demand...")
            rows = getattr(app, "excel_rows", []) or []
            summary = app.trigger_post_download_checks(rows, out_dir)
            if summary:
                target = summary.get("excel_path")

        if target and os.path.exists(target):
            try:
                if sys.platform == "win32":
                    os.startfile(target)
                else:
                    subprocess.Popen(["xdg-open", target])
            except Exception as e:
                app.log(f"⚠️ Failed to open Excel report: {e}")
        else:
            app.log("⚠️ No Consolidated Excel Report found yet. Start downloading vouchers to generate one.")

    btn_open_excel.clicked.connect(_open_last_excel)
    rt_layout.addWidget(btn_open_excel)

    btn_open_html = QPushButton("🌐 Open HTML Summary Dashboard")
    btn_open_html.setProperty("cssClass", "secondary")
    btn_open_html.setFixedHeight(32)

    def _open_last_html():
        out_dir = app.download_dir or os.path.join(getattr(app, "APP_DIR", os.getcwd()), "downloads")
        if hasattr(app, "last_html_report") and app.last_html_report and os.path.exists(app.last_html_report):
            target = app.last_html_report
        else:
            target = None
            if os.path.exists(out_dir):
                files = [os.path.join(out_dir, f) for f in os.listdir(out_dir) if f.startswith("Centralized_Validation_Dashboard_") and f.endswith(".html")]
                if files:
                    files.sort(key=os.path.getmtime, reverse=True)
                    target = files[0]

        if not target and hasattr(app, "trigger_post_download_checks"):
            app.log("🌐 Generating HTML Summary Dashboard on demand...")
            rows = getattr(app, "excel_rows", []) or []
            summary = app.trigger_post_download_checks(rows, out_dir)
            if summary:
                target = summary.get("html_path")

        if target and os.path.exists(target):
            try:
                if sys.platform == "win32":
                    os.startfile(target)
                else:
                    subprocess.Popen(["xdg-open", target])
            except Exception as e:
                app.log(f"⚠️ Failed to open HTML dashboard: {e}")
        else:
            app.log("⚠️ No HTML Summary Dashboard found yet. Start downloading vouchers to generate one.")

    btn_open_html.clicked.connect(_open_last_html)
    rt_layout.addWidget(btn_open_html)

    btn_clear_table = QPushButton("🧹 Clear Results")
    btn_clear_table.setProperty("cssClass", "outline")
    btn_clear_table.setFixedHeight(32)
    rt_layout.addWidget(btn_clear_table)

    layout.addWidget(report_tool_frame)

    # Filter Toolbar Frame
    filter_frame = QFrame()
    filter_layout = QHBoxLayout(filter_frame)
    filter_layout.setContentsMargins(0, 0, 0, 0)
    filter_layout.setSpacing(10)

    app.cmb_val_filter = QComboBox()
    app.cmb_val_filter.addItems([
        "⚠️ Errors & Warnings Only",
        "📋 All Results",
        "✅ Passed Only",
        "❌ Errors Only",
        "⚠️ Warnings Only"
    ])
    filter_layout.addWidget(app.cmb_val_filter)

    app.entry_val_search = QLineEdit()
    app.entry_val_search.setPlaceholderText("🔍 Search voucher, treasury, check...")
    filter_layout.addWidget(app.entry_val_search)

    app.lbl_val_filter_count = QLabel("Showing 0 of 0 results")
    app.lbl_val_filter_count.setProperty("cssClass", "muted")
    filter_layout.addWidget(app.lbl_val_filter_count)

    layout.addWidget(filter_frame)

    # Initialize MVC for Validation Results
    app.val_results_table = QTableView()
    app.val_results_model = ValidationResultsModel()
    app.val_results_proxy = ValidationResultsFilterProxyModel()
    app.val_results_proxy.setSourceModel(app.val_results_model)
    app.val_results_table.setModel(app.val_results_proxy)

    app.val_results_table.setSelectionBehavior(QAbstractItemView.SelectRows)
    app.val_results_table.setSelectionMode(QAbstractItemView.SingleSelection)
    app.val_results_table.setAlternatingRowColors(True)
    app.val_results_table.setShowGrid(True)
    app.val_results_table.setWordWrap(True)
    app.val_results_table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
    
    header = app.val_results_table.horizontalHeader()
    header.setSectionResizeMode(0, QHeaderView.Fixed)
    app.val_results_table.setColumnWidth(0, 40)
    header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
    header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
    header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
    header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
    header.setSectionResizeMode(5, QHeaderView.ResizeToContents)
    header.setSectionResizeMode(6, QHeaderView.ResizeToContents)
    header.setSectionResizeMode(7, QHeaderView.Stretch)
    
    # Connect signals
    def update_filter_count():
        app.lbl_val_filter_count.setText(f"Showing {app.val_results_proxy.rowCount()} of {app.val_results_model.rowCount()} results")
        
    def _on_filter_changed():
        app.val_results_proxy.set_status_filter(app.cmb_val_filter.currentText())
        update_filter_count()
        
    def _on_search_changed():
        app.val_results_proxy.set_search_text(app.entry_val_search.text())
        update_filter_count()

    app.cmb_val_filter.currentIndexChanged.connect(_on_filter_changed)
    app.entry_val_search.textChanged.connect(_on_search_changed)
    
    def _on_table_clicked(index):
        if index.column() == 0:
            source_index = app.val_results_proxy.mapToSource(index)
            entry = app.val_results_model.get_row_data(source_index.row())
            if entry:
                v_no = str(entry.get("voucher_no", ""))
                t_str = str(entry.get("treasury", ""))
                mh_str = str(entry.get("mh", ""))
                amt_str = str(entry.get("amount", ""))
                open_voucher_folder(app, v_no, t_str, mh_str, amt_str)
                
    def _on_table_double_clicked(index):
        source_index = app.val_results_proxy.mapToSource(index)
        entry = app.val_results_model.get_row_data(source_index.row())
        if entry:
            dlg = AuditFindingDetailsDialog(entry, parent=app)
            dlg.exec()

    app.val_results_table.clicked.connect(_on_table_clicked)
    app.val_results_table.doubleClicked.connect(_on_table_double_clicked)
    
    def _clear_results():
        app.val_results_model.clear()
        if hasattr(app, "check_registry"):
            app.check_registry.realtime_results.clear()
        app._val_total_count = 0
        app._val_passed_count = 0
        app._val_flagged_count = 0
        app.lbl_val_total_checks.setText("0")
        app.lbl_val_passed_checks.setText("0")
        app.lbl_val_flagged_checks.setText("0")
        update_filter_count()
        
    btn_clear_table.clicked.connect(_clear_results)
    layout.addWidget(app.val_results_table, 1)

    # Set counters
    app._val_total_count = 0
    app._val_passed_count = 0
    app._val_flagged_count = 0

def add_realtime_result_to_table(app, result_entry: dict):
    """Utility method to append a realtime result to the table and update metrics."""
    if not hasattr(app, "val_results_model"):
        return

    app.val_results_model.add_result(result_entry)
    
    # Update metrics
    st = str(result_entry.get("status", "")).upper()
    if not hasattr(app, "_val_total_count"):
        app._val_total_count = 0
        app._val_passed_count = 0
        app._val_flagged_count = 0

    app._val_total_count += 1
    if st in ("PASS", "MATCHED"):
        app._val_passed_count += 1
    elif st in ("WARNING", "SUSPICIOUS", "MISMATCH", "FAIL", "ERROR"):
        app._val_flagged_count += 1

    app.lbl_val_total_checks.setText(str(app._val_total_count))
    app.lbl_val_passed_checks.setText(str(app._val_passed_count))
    app.lbl_val_flagged_checks.setText(str(app._val_flagged_count))

    app.lbl_val_filter_count.setText(f"Showing {app.val_results_proxy.rowCount()} of {app.val_results_model.rowCount()} results")
    app.val_results_table.scrollToBottom()
