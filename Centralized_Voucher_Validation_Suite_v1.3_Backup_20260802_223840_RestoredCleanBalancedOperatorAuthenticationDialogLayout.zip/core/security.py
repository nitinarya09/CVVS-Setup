import re
import time
# core/security.py
# Centralized Voucher Validation Suite v3.1.3 — License verification and hardware ID utilities

import os
import sys
import hashlib
import base64
import json
import subprocess
import datetime
if sys.platform == "win32":
    import winreg
from core.constants import APP_DIR

PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0qxkAIHGUzKlMgbucEfP
ul2dYvPzAPOf+09rKzXMTmxLITPqrOaXiDZ5HxpWF5pvrobwIz+TZ8lGtd6kp9ic
aMDC5OBVFA/oXnQR6wq5Eb23JXiSIisEW72REqbhocbgTT0RepcKJBbg2vgksoQZ
uj1E+GUTCP+Vd3vJdXvij5eRPlJWrCzp2HJptMqZdcrAez20qauhCMs0LBTQQBCb
1dqblIAPHth+18HyOSdvyrdkoPH3LIJzZqHPLUF1hT1mDHSAFTxKDMVKASeW2Lpi
NcxGw7CwWZA4HPZutX0ZQVk6uotcvuW5TnbQkcJanYDwbwGxpZ1AFr+jCDDZsN/i
5wIDAQAB
-----END PUBLIC KEY-----"""

def get_machine_id():
    try:
        output = subprocess.check_output('wmic csproduct get uuid', creationflags=0x08000000).decode('utf-8').strip()
        lines = [line.strip() for line in output.split('\n') if line.strip() != '']
        if len(lines) > 1 and len(lines[1]) > 10: return lines[1]
    except Exception: pass

    try:
        cmd = ['powershell', '-NoProfile', '-Command', '(Get-CimInstance -Class Win32_ComputerSystemProduct).UUID']
        output = subprocess.check_output(cmd, creationflags=0x08000000).decode('utf-8').strip()
        if output and len(output) > 10: return output
    except Exception: pass

    try:
        registry = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
        key = winreg.OpenKey(registry, r"SOFTWARE\Microsoft\Cryptography")
        machine_guid, _ = winreg.QueryValueEx(key, "MachineGuid")
        if machine_guid: return machine_guid
    except Exception: pass

    return "UNKNOWN_MACHINE"

def verify_key(key_str, current_machine_id):
    if not key_str:
        return False, "No key provided."
    try:
        decoded = base64.b64decode(key_str.encode('utf-8')).decode('utf-8')
        parts = decoded.split('|')
        if len(parts) != 3:
            return False, "Invalid license key format."
        
        expiry_str, hwid, sig_hex = parts
        
        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.serialization import load_pem_public_key
        
        public_key = load_pem_public_key(PUBLIC_KEY_PEM.encode('utf-8'))
        raw_data = f"{expiry_str}|{hwid}"
        
        try:
            public_key.verify(
                bytes.fromhex(sig_hex),
                raw_data.encode('utf-8'),
                padding.PKCS1v15(),
                hashes.SHA256()
            )
        except Exception:
            return False, "License signature mismatch."
            
        if hwid != current_machine_id:
            return False, "License key is for a different machine ID."
            
        if expiry_str != "NEVER":
            try:
                exp_date = datetime.datetime.strptime(expiry_str, "%Y-%m-%d").date()
                if datetime.date.today() > exp_date:
                    return False, f"License expired on {expiry_str}."
            except Exception:
                return False, "Invalid expiry date in license key."
        return True, expiry_str
    except Exception as e:
        return False, f"Failed to decode key: {e}"

def save_license_key(key):
    if sys.platform == "win32":
        try:
            key_reg = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\IFMIS_Suite")
            winreg.SetValueEx(key_reg, "LicenseKey", 0, winreg.REG_SZ, key)
            winreg.CloseKey(key_reg)
        except Exception as e:
            print(f"Registry write failed: {e}")
        
    try:
        with open(os.path.join(APP_DIR, "license.key"), "w", encoding="utf-8") as f:
            f.write(key.strip())
    except Exception as e:
        print(f"License file write failed: {e}")

def read_license_key():
    if sys.platform == "win32":
        try:
            key_reg = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\IFMIS_Suite")
            value, _ = winreg.QueryValueEx(key_reg, "LicenseKey")
            winreg.CloseKey(key_reg)
            if value:
                return value.strip()
        except Exception:
            pass
        
    try:
        key_path = os.path.join(APP_DIR, "license.key")
        if os.path.exists(key_path):
            with open(key_path, "r", encoding="utf-8") as f:
                return f.read().strip()
    except Exception:
        pass
    return None
