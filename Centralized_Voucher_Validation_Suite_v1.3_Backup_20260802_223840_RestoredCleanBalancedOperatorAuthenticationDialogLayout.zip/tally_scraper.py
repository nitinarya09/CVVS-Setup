import os
import re
import time
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

class TallyScraper:
    """Scrapes IFMIS Bill Details + FVC Bill pages for tally verification."""

    def __init__(self, logger=None):
        self.logger = logger or (lambda msg, level="info": print(f"[{level.upper()}] {msg}"))

    def log(self, msg, level="info"):
        if self.logger:
            self.logger(msg, level)

    def scrape_bill_details(self, bill_page):
        """
        On Bill Details tab, extract:
        1. Expenditure Details (table#tblbillDetailHeadExp)
        2. Deduction/Receipt Details (table#tblbillDetailHeadRecp) - TDS, GST, etc.
        3. Bill Amount Summary (fieldset#billAmtDtlGrp)
        """
        data = {
            "expenditure_heads": [],
            "deductions": [],
            "tds_amount": 0.0,
            "gst_amount": 0.0,
            "other_deductions_amount": 0.0,
            "total_deductions": 0.0,
            "expenditure_amount": 0.0,
            "receipt_amount": 0.0,
            "net_amount": 0.0,
            "gross_amount": 0.0,
        }

        try:
            # 1. Expenditure Details
            exp_table = bill_page.locator("table#tblbillDetailHeadExp")
            if exp_table.count() > 0:
                rows = exp_table.locator("tbody tr").all()
                for r in rows:
                    try:
                        sel = r.locator("select[name='cmbExpDetailHead']")
                        amt_input = r.locator("input[name='txtExpAmount']")
                        if sel.count() > 0 and amt_input.count() > 0:
                            head_text = sel.evaluate("el => el.options[el.selectedIndex] ? el.options[el.selectedIndex].text : ''")
                            amt_val = self.parse_amount(amt_input.input_value())
                            if amt_val > 0 or head_text:
                                data["expenditure_heads"].append({"head": head_text.strip(), "amount": amt_val})
                    except Exception:
                        pass

            # 2. Receipt (Deduction) Details
            rec_table = bill_page.locator("table#tblbillDetailHeadRecp")
            if rec_table.count() > 0:
                rows = rec_table.locator("tbody tr").all()
                for r in rows:
                    try:
                        code_input = r.locator("input[name='txtDetailCode']")
                        desc_input = r.locator("input[name='detailCodeValue']")
                        type_input = r.locator("input[name='txtDetailCodeType']")
                        amt_input = r.locator("input[name='txtRecAmount']")

                        if code_input.count() > 0 and amt_input.count() > 0:
                            code = code_input.input_value().strip()
                            desc = desc_input.input_value().strip() if desc_input.count() > 0 else ""
                            ded_type = type_input.input_value().strip() if type_input.count() > 0 else ""
                            amt = self.parse_amount(amt_input.input_value())

                            if code or amt > 0:
                                ded_entry = {
                                    "code": code,
                                    "description": desc,
                                    "type": ded_type,
                                    "amount": amt
                                }
                                data["deductions"].append(ded_entry)
                                data["total_deductions"] += amt

                                desc_upper = desc.upper()
                                if "TDS" in desc_upper and "GST" not in desc_upper:
                                    data["tds_amount"] += amt
                                elif "GST" in desc_upper:
                                    data["gst_amount"] += amt
                                else:
                                    data["other_deductions_amount"] += amt
                    except Exception:
                        pass

            # 3. Bill Amount Summary & Explicit Deduction Amount Field
            try:
                exp_amt_elem = bill_page.locator("#txtBillExpAmt, input[name='txtBillExpAmt']").first
                if exp_amt_elem.count() > 0:
                    data["expenditure_amount"] = self.parse_amount(exp_amt_elem.input_value())

                rec_amt_elem = bill_page.locator("#txtBillReceiptAmt, input[name='txtBillReceiptAmt']").first
                if rec_amt_elem.count() > 0:
                    data["receipt_amount"] = self.parse_amount(rec_amt_elem.input_value())

                # Explicit Deduction Amount Summary Field (e.g. 536.00)
                ded_amt_elem = bill_page.locator("#txtBillDeductionAmt, input[name='txtBillDeductionAmt'], #txtDeductionAmt, input[name='txtDeductionAmt'], #lblDeductionAmt").first
                if ded_amt_elem.count() > 0:
                    try:
                        val_ded = ded_amt_elem.input_value()
                    except Exception:
                        val_ded = ded_amt_elem.inner_text()
                    parsed_ded = self.parse_amount(val_ded)
                    if parsed_ded > 0:
                        data["deduction_amount_field"] = parsed_ded
                        data["total_deductions"] = parsed_ded

                if data["total_deductions"] == 0.0 and data["receipt_amount"] > 0:
                    data["total_deductions"] = data["receipt_amount"]

                net_elem = bill_page.locator("#txtNetTotal, input[name='txtNetTotal']").first
                if net_elem.count() > 0:
                    data["net_amount"] = self.parse_amount(net_elem.input_value())
                else:
                    lbl_net = bill_page.locator("#lblNetTotal")
                    if lbl_net.count() > 0:
                        data["net_amount"] = self.parse_amount(lbl_net.inner_text())

                gross_elem = bill_page.locator("#txtGrossTotal, input[name='txtGrossTotal']").first
                if gross_elem.count() > 0:
                    data["gross_amount"] = self.parse_amount(gross_elem.input_value())
                else:
                    lbl_gross = bill_page.locator("#lblGrossTotal")
                    if lbl_gross.count() > 0:
                        data["gross_amount"] = self.parse_amount(lbl_gross.inner_text())
            except Exception:
                pass


        except Exception as e:
            self.log(f"Error scraping bill details: {e}", "warning")

        return data

    def scrape_fvc_bill(self, bill_page):
        """
        Click FVC Bill tab (#tab2 or text='FVC Bill') -> wait for content -> scrape entries + total.
        Target input#txtTotalAmt specifically for total sum.
        """
        data = {
            "entries": [],
            "portal_total": 0.0,
            "entry_count": 0,
            "computed_sum": 0.0,
            "fvc_tab_opened": False
        }

        try:
            tab_clicked = False
            # Multi-strategy retry loop (up to 3 attempts) to guarantee Tab 2 opens for any bill type
            for attempt in range(3):
                try:
                    fvc_tab = bill_page.locator("#tab2, a[href*='tab2'], td[id*='tab2'], .tab2, #tabHeader2, ul.tabs li:nth-child(2), a:has-text('FVC Bill'), td:has-text('FVC Bill'), a:has-text('Sub Voucher'), a:has-text('Beneficiary'), a:has-text('Payee')").first
                    if fvc_tab.count() > 0:
                        try:
                            fvc_tab.click(timeout=3000, force=True)
                            tab_clicked = True
                        except Exception:
                            # Fallback: JavaScript event dispatch
                            fvc_tab.evaluate("el => { el.dispatchEvent(new Event('click', {bubbles:true})); if (typeof el.click === 'function') el.click(); }")
                            tab_clicked = True

                    if not tab_clicked:
                        for frame in bill_page.frames:
                            t = frame.locator("#tab2, a[href*='tab2'], td[id*='tab2'], .tab2, a:has-text('FVC Bill'), td:has-text('FVC Bill')").first
                            if t.count() > 0:
                                t.click(timeout=3000, force=True)
                                tab_clicked = True
                                break


                    # Direct JavaScript Function Invocation Fallback
                    if not tab_clicked:
                        try:
                            bill_page.evaluate("""() => {
                                if (typeof showFVCDtl === 'function') showFVCDtl('tab2');
                                else if (typeof switchTab === 'function') switchTab(2);
                                else if (typeof showTab === 'function') showTab(2);
                            }""")
                            tab_clicked = True
                        except Exception: pass

                    # Verify tab 2 input elements loaded
                    time.sleep(0.4)
                    tot_chk = bill_page.locator("#txtTotalAmt, input[name='txtTotalAmt'], input[name='txtFvcAmount']").first
                    if tot_chk.count() > 0:
                        data["fvc_tab_opened"] = True
                        break
                except Exception:
                    time.sleep(0.5)

            if tab_clicked:
                data["fvc_tab_opened"] = True
                try:
                    bill_page.wait_for_load_state("domcontentloaded", timeout=3000)
                except Exception:
                    pass
                time.sleep(0.3)


            # 1. Scrape Total Amount from #txtTotalAmt
            tot_found = False
            tot_elem = bill_page.locator("#txtTotalAmt, input[name='txtTotalAmt']").first
            if tot_elem.count() > 0:
                val_str = tot_elem.input_value() or tot_elem.get_attribute("value") or ""
                parsed = self.parse_amount(val_str)
                if parsed > 0:
                    data["portal_total"] = parsed
                    tot_found = True

            if not tot_found:
                for frame in bill_page.frames:
                    tot_elem = frame.locator("#txtTotalAmt, input[name='txtTotalAmt']").first
                    if tot_elem.count() > 0:
                        val_str = tot_elem.input_value() or tot_elem.get_attribute("value") or ""
                        parsed = self.parse_amount(val_str)
                        if parsed > 0:
                            data["portal_total"] = parsed
                            tot_found = True
                            break

            # 2. Scrape cash memo sub-voucher rows
            target_context = bill_page
            amt_inputs = bill_page.locator("input[name='txtFvcAmount']").all()
            if not amt_inputs:
                for frame in bill_page.frames:
                    frame_inputs = frame.locator("input[name='txtFvcAmount']").all()
                    if frame_inputs:
                        amt_inputs = frame_inputs
                        target_context = frame
                        break

            memo_inputs = target_context.locator("input[name='txtCashMemoNo']").all()
            date_inputs = target_context.locator("input[name='txtCashMemoDate']").all()
            subv_inputs = target_context.locator("input[name='txtNoSubVoucher']").all()
            desc_inputs = target_context.locator("input[name='txtDesc']").all()

            count = len(amt_inputs)
            data["entry_count"] = count

            for i in range(count):
                memo_no = memo_inputs[i].input_value().strip() if i < len(memo_inputs) else ""
                memo_date = date_inputs[i].input_value().strip() if i < len(date_inputs) else ""
                subv = subv_inputs[i].input_value().strip() if i < len(subv_inputs) else ""
                desc = desc_inputs[i].input_value().strip() if i < len(desc_inputs) else ""
                amt_str = amt_inputs[i].input_value().strip() if i < len(amt_inputs) else "0"
                amt_val = self.parse_amount(amt_str)

                data["computed_sum"] += amt_val
                data["entries"].append({
                    "cash_memo_no": memo_no,
                    "cash_memo_date": memo_date,
                    "no_sub_voucher": subv,
                    "description": desc,
                    "amount": amt_val
                })

            if data["portal_total"] == 0.0 and data["computed_sum"] > 0:
                data["portal_total"] = data["computed_sum"]

        except Exception as e:
            self.log(f"Error scraping FVC bill page: {e}", "warning")

        return data

    @staticmethod
    def parse_amount(val_str):
        if not val_str:
            return 0.0
        cleaned = re.sub(r'[^\d\.]', '', str(val_str).strip())
        if not cleaned:
            return 0.0
        try:
            return float(cleaned)
        except ValueError:
            return 0.0
