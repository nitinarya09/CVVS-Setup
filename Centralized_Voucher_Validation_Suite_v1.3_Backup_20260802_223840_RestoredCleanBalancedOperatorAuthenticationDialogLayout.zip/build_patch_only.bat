@echo off
setlocal EnableDelayedExpansion
title IFMIS 365 Suite v3.5 - Compile Patch Setup Only
echo ========================================================
echo IFMIS 365 Suite v3.5 - Compile Patch Setup Only
echo ========================================================
echo.
echo Running pre-build backup...
py -3 backup.py
echo.

:: 1. Verify environment
py -3 --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python launcher [py] was not found in your PATH!
    pause
    exit /b 1
)

py -3 -m pip show pyinstaller >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] PyInstaller is not installed!
    py -3 -m pip install pyinstaller
)

set "ISCC_PATH=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if not exist "%ISCC_PATH%" (
    echo [ERROR] Inno Setup 6 Compiler [ISCC.exe] was not found at:
    echo "%ISCC_PATH%"
    pause
    exit /b 1
)

:: 2. Compile portable executable
echo [1/3] Running PyInstaller to compile combined ifmis_suite.py...
py -3 -m PyInstaller --noconsole --onefile --icon="cag_logo.ico" --paths "TI Studio Pro" --paths "TI Studio Pro/POL Downloader" --paths "TI Studio Pro/POL Analyser" --paths "Treasury Downloader" --add-data "ddo.txt;." --add-data "terms.txt;." --add-data "index.html;." --add-data "unified_audit_suite.html;." --add-data "standalone_audit_suite.html;." --add-data "unified_audit_suite_my working.html;." --add-data "web_dist;web_dist" --add-data "cag_logo.png;." --add-data "cag_logo.ico;." --add-data "TI Studio Pro;TI Studio Pro" --add-data "Treasury Downloader;Treasury Downloader" --hidden-import polars --hidden-import fastexcel --exclude-module torch --exclude-module torchvision --exclude-module scipy --name ifmis_365_suite ifmis_suite.py --clean --noconfirm

if %errorlevel% neq 0 (
    echo [ERROR] PyInstaller compilation failed!
    pause
    exit /b %errorlevel%
)

:: 3. Copy compiled binary to root
echo Terminating any running ifmis_suite or ti_studio or epay_verifier instances to release file locks...
taskkill /f /im ifmis_365_suite.exe >nul 2>&1
taskkill /f /im ti_studio.exe >nul 2>&1
taskkill /f /im epay_verifier.exe >nul 2>&1
if exist "dist\ifmis_365_suite.exe" (
    copy /y "dist\ifmis_365_suite.exe" "ifmis_365_suite.exe"
)

:: Clean PyInstaller build residues
echo Cleaning build directories...
rmdir /s /q "build"
rmdir /s /q "dist"

:: 4. Copy Playwright browsers to local pw-browsers folder for Inno Setup bundling
:: Only copies: chromium, firefox, ffmpeg, winldd, .links (skips webkit ~166MB and chromium_headless_shell ~267MB)
echo [2/4] Preparing Playwright browsers bundle (pw-browsers)...
if exist "pw-browsers" rmdir /s /q "pw-browsers"
mkdir "pw-browsers"
set "PW_SRC=%LOCALAPPDATA%\ms-playwright"
if not exist "%PW_SRC%" (
    echo [INFO] Primary path not found. Checking fallback...
    set "PW_SRC=!USERPROFILE!\.cache\ms-playwright"
)
if exist "!PW_SRC!" (
    echo Copying required Playwright browsers from !PW_SRC!...
    for /d %%D in ("!PW_SRC!\chromium-*") do (
        echo   + %%~nxD
        xcopy /s /e /y /q "%%D" "pw-browsers\%%~nxD\"
    )
    for /d %%D in ("!PW_SRC!\firefox-*") do (
        echo   + %%~nxD
        xcopy /s /e /y /q "%%D" "pw-browsers\%%~nxD\"
    )
    for /d %%D in ("!PW_SRC!\ffmpeg-*") do (
        echo   + %%~nxD
        xcopy /s /e /y /q "%%D" "pw-browsers\%%~nxD\"
    )
    for /d %%D in ("!PW_SRC!\winldd-*") do (
        echo   + %%~nxD
        xcopy /s /e /y /q "%%D" "pw-browsers\%%~nxD\"
    )
    if exist "!PW_SRC!\.links" (
        echo   + .links
        xcopy /s /e /y /q "!PW_SRC!\.links" "pw-browsers\.links\"
    )
    echo   - SKIPPED: webkit ^(not used by tool^)
    echo   - SKIPPED: chromium_headless_shell ^(not used by tool^)
    echo Playwright browsers bundle prepared successfully.
) else (
    echo [WARNING] No Playwright browser cache found! pw-browsers folder will be empty.
)

:: 5. Compile Inno Setup patch script
echo [3/4] Compiling Lightweight Patch Updater (IFMIS_365_Suite_Patch_Setup.exe)...
"%ISCC_PATH%" setup_patch.iss

if %errorlevel% neq 0 (
    echo [ERROR] Inno Setup compiler failed on setup_patch.iss!
    pause
    exit /b %errorlevel%
)

:: 6. Sync output files to staging folder
set "STAGING_DIR=D:\BUILDING AND TESTING\IFMIS Downloader and Analyzer Setup"
if exist "%STAGING_DIR%" (
    echo [4/4] Syncing generated files to staging directory...
    copy /y "output\IFMIS_365_Suite_Patch_Setup.exe" "%STAGING_DIR%\"
    copy /y "ifmis_365_suite.exe" "%STAGING_DIR%\"
    if exist "output\IFMIS_365_Suite_Portable" (
        copy /y "ifmis_365_suite.exe" "output\IFMIS_365_Suite_Portable\"
    )
    if exist "%STAGING_DIR%\IFMIS_365_Suite_Portable_30" (
        copy /y "ifmis_365_suite.exe" "%STAGING_DIR%\IFMIS_365_Suite_Portable_30\"
    )
)

echo.
echo ========================================================
echo [SUCCESS] PATCH COMPILATION COMPLETED SUCCESSFULLY!
echo ========================================================
echo.
