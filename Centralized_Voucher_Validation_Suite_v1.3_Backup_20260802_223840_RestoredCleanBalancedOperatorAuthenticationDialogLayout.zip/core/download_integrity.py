# core/download_integrity.py
# Centralized Voucher Validation Suite v3.1.3 — Post-download file integrity validation

import os

def validate_pdf_integrity(filepath):
    """Validate that a PDF file is complete and not corrupt.
    
    Returns:
        tuple: (is_valid: bool, reason: str)
    """
    if not os.path.exists(filepath):
        return False, "File does not exist"
    
    size = os.path.getsize(filepath)
    if size < 100:
        return False, f"File too small ({size} bytes)"
    
    # Check PDF header
    try:
        with open(filepath, "rb") as f:
            header = f.read(5)
        if not header.startswith(b"%PDF"):
            return False, f"Invalid PDF header: {header[:10]}"
    except Exception as e:
        return False, f"Cannot read file: {e}"
    
    # Check for error page content saved as PDF
    if _contains_error_page_content(filepath):
        return False, "File contains error/login page content"
    
    # Try parsing with pypdf if available
    try:
        from pypdf import PdfReader
        reader = PdfReader(filepath)
        page_count = len(reader.pages)
        if page_count == 0:
            return False, "PDF has 0 pages"
    except ImportError:
        pass  # pypdf not available, skip deep validation
    except Exception as e:
        return False, f"PDF is corrupt: {str(e)[:80]}"
    
    return True, "OK"

def validate_xls_integrity(filepath):
    """Validate that an Excel file has valid headers and minimum size.
    
    Returns:
        tuple: (is_valid: bool, reason: str)
    """
    if not os.path.exists(filepath):
        return False, "File does not exist"
    
    size = os.path.getsize(filepath)
    if size < 100:
        return False, f"File too small ({size} bytes)"
    
    try:
        with open(filepath, "rb") as f:
            header = f.read(1024)
        
        # OLE header (xls), ZIP header (xlsx), or HTML table
        valid_headers = [
            header.startswith(b"\xd0\xcf\x11\xe0"),  # OLE/XLS
            header.startswith(b"PK\x03\x04"),          # ZIP/XLSX
            b"<html" in header.lower(),                 # HTML table
            b"<!doc" in header.lower(),
            b"<table" in header.lower(),
        ]
        if not any(valid_headers):
            return False, "Unrecognized file format"
    except Exception as e:
        return False, f"Cannot read file: {e}"
    
    return True, "OK"

def validate_folder_completeness(folder_path):
    """Verify a voucher download folder has minimum required files.
    At minimum, the MPTC PDF should be present.
    
    Returns:
        tuple: (is_complete: bool, missing_items: list[str])
    """
    if not os.path.isdir(folder_path):
        return False, ["Folder does not exist"]
    
    files = os.listdir(folder_path)
    missing = []
    
    # Check for MPTC PDF (required)
    has_mptc = any(
        ('show_mptc' in f.lower() or 'mptc' in f.lower()) and f.lower().endswith('.pdf')
        for f in files
    )
    if not has_mptc:
        missing.append("MPTC PDF")
    
    # Check MPTC PDF integrity if it exists
    if has_mptc:
        for f in files:
            if ('show_mptc' in f.lower() or 'mptc' in f.lower()) and f.lower().endswith('.pdf'):
                pdf_path = os.path.join(folder_path, f)
                is_valid, reason = validate_pdf_integrity(pdf_path)
                if not is_valid:
                    missing.append(f"MPTC PDF corrupt: {reason}")
                break
    
    return len(missing) == 0, missing

def _contains_error_page_content(filepath):
    """Check if a file contains error page / login page content."""
    try:
        with open(filepath, "rb") as f:
            content = f.read(2048).lower()
        
        error_indicators = [
            b"session expired",
            b"session has expired",
            b"session timeout",
            b"please login again",
            b"re-login",
            b"j_username",
            b"j_password",
        ]
        return any(indicator in content for indicator in error_indicators)
    except Exception:
        return False
