import os
import re
import glob
from checks.base_check import BaseValidationCheck
from parsers.mptc_parser import parse_mptc_pdf


class GpfScheduleCheck(BaseValidationCheck):
    check_id = "check_realtime_gpf_schedule"
    name = "GPF Schedule & Deduction Verification Check"
    description = "Checks GPF schedule data for GPF bills (Form 63) or deduction columns for Pay Bills (Form 24)."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            mptc_file = os.path.join(download_folder, "Show_MPTC.pdf")
            if not os.path.exists(mptc_file):
                return {"status": "SKIPPED", "message": "No MPTC PDF found", "details": {}}

            mptc = parse_mptc_pdf(mptc_file)
            form_number = mptc.form_number.strip()
            raw_text = mptc.raw_text

            if form_number == "63":
                # GPF Bill - extract GPF account number, subscriber name, amount
                gpf_account = ""
                subscriber = ""
                amount = mptc.total_amount

                # GPF account: pattern like "1400204004D0672"
                acct_m = re.search(r'Account\s+No[.\s]*(\w+)', raw_text, re.IGNORECASE)
                if not acct_m:
                    acct_m = re.search(r'(\d{4,}[A-Z]\d+)', raw_text)
                if acct_m:
                    gpf_account = acct_m.group(1).strip()

                # Subscriber name: after "Shri" or "Smt."
                name_m = re.search(r'(?:Shri|Smt\.?)\s+([A-Z][A-Z\s]+)', raw_text)
                if name_m:
                    subscriber = name_m.group(1).strip()

                # Check certificate block
                has_certificate = "CERTIFICATE" in raw_text.upper()

                details = {
                    "gpf_account": gpf_account,
                    "subscriber": subscriber,
                    "amount": amount,
                    "has_certificate": has_certificate,
                }

                if gpf_account and subscriber and amount > 0:
                    return {"status": "PASS",
                            "message": "GPF schedule: %s, A/C %s, Rs.%.2f" % (subscriber, gpf_account, amount),
                            "details": details}
                else:
                    missing = []
                    if not gpf_account: missing.append("GPF account no")
                    if not subscriber: missing.append("subscriber name")
                    if not amount: missing.append("withdrawal amount")
                    return {"status": "WARNING",
                            "message": "Missing GPF fields: %s" % ", ".join(missing),
                            "details": details}

            elif form_number == "24":
                # Pay Bill - check for deduction-related Excel files
                excel_files = glob.glob(os.path.join(download_folder, "*.xlsx")) + glob.glob(os.path.join(download_folder, "*.xls"))
                pay_files = [f for f in excel_files if any(kw in os.path.basename(f).lower() for kw in ["epay", "paybill"])]

                if pay_files:
                    return {"status": "PASS",
                            "message": "Pay Bill Excel schedule found (%d file(s))" % len(pay_files),
                            "details": {"pay_files": [os.path.basename(f) for f in pay_files]}}
                else:
                    return {"status": "WARNING",
                            "message": "No e-payment/deduction schedule Excel found for Pay Bill",
                            "details": {"files_in_folder": [os.path.basename(f) for f in excel_files]}}
            else:
                return {"status": "SKIPPED", "message": "Not a GPF (Form 63) or Pay Bill (Form 24)", "details": {"form_number": form_number}}

        except Exception as e:
            return {"status": "FAIL", "message": "Error during check: %s" % str(e), "details": {}}
