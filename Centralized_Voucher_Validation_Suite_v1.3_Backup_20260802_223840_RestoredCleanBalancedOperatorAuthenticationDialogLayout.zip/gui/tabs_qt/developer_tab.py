from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QFrame,
    QPushButton, QLabel, QCheckBox, QLineEdit, QComboBox, QGridLayout,
    QScrollArea, QSizePolicy)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from gui.toggle_switch import ToggleSwitch


def build_developer_tab(app, tab):
    """Build the Developer tab - exact 1:1 clone of CTk version.
    Wrapped in a QScrollArea internally.
    """
    outer_layout = QVBoxLayout(tab)
    outer_layout.setContentsMargins(0, 0, 0, 0)

    scroll_area = QScrollArea()
    scroll_area.setWidgetResizable(True)
    scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    scroll_area.setFrameShape(QFrame.NoFrame)

    scroll_content = QWidget()
    content_grid = QGridLayout(scroll_content)
    content_grid.setContentsMargins(10, 10, 10, 10)
    content_grid.setColumnStretch(0, 1)
    content_grid.setColumnStretch(1, 1)

    # Title
    lbl_title = QLabel("🛠️ DEVELOPER CONTROL PANEL")
    lbl_title.setFont(QFont("Segoe UI", 14, QFont.Bold))
    lbl_title.setAlignment(Qt.AlignCenter)
    lbl_title.setProperty("cssClass", "highlight")
    content_grid.addWidget(lbl_title, 0, 0, 1, 2)

    # ── Section 0: Security Overrides (Dev Only) ────────────────────────
    sec_box = QFrame()
    sec_box.setProperty("cssClass", "card")
    sec_grid = QGridLayout(sec_box)
    sec_grid.setContentsMargins(15, 10, 15, 10)
    sec_grid.setColumnStretch(0, 1)
    sec_grid.setColumnStretch(1, 1)

    lbl_sec_title = QLabel("🔓 Security Overrides (Dev Only)")
    lbl_sec_title.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_sec_title.setAlignment(Qt.AlignCenter)
    lbl_sec_title.setProperty("cssClass", "highlight")
    sec_grid.addWidget(lbl_sec_title, 0, 0, 1, 2)

    lbl_sec_warn = QLabel(
        "⚠️ These features are disabled by default for security compliance. "
        "Enable only for development/testing. They reset to OFF on app restart "
        "and when Developer Mode is deactivated."
    )
    lbl_sec_warn.setFont(QFont("Segoe UI", 10))
    lbl_sec_warn.setStyleSheet("color: #f59e0b;")
    lbl_sec_warn.setWordWrap(True)
    sec_grid.addWidget(lbl_sec_warn, 1, 0, 1, 2)

    # Toggle: Auto-Solve CAPTCHA
    lbl_captcha = QLabel("Auto-Solve CAPTCHA")
    lbl_captcha.setFont(QFont("Segoe UI", 11))
    lbl_captcha.setToolTip("Attempts to solve IFMS CAPTCHA images automatically\nusing AI/OCR engine (requires model file).")
    sec_grid.addWidget(lbl_captcha, 2, 0)

    app.sw_dev_auto_captcha = ToggleSwitch(variant="warning")
    app.sw_dev_auto_captcha.setToolTip("Enable automatic CAPTCHA solving")
    if hasattr(app, 'var_auto_solve_captcha'):
        app.var_auto_solve_captcha.bind_to_widget(app.sw_dev_auto_captcha)
    sec_grid.addWidget(app.sw_dev_auto_captcha, 2, 1, Qt.AlignRight)

    # Toggle: Direct Dashboard Mode (Bypass OTP)
    lbl_dashboard = QLabel("Direct Dashboard Mode (Bypass OTP)")
    lbl_dashboard.setFont(QFont("Segoe UI", 11))
    lbl_dashboard.setToolTip("Skips OTP verification wait and directly polls for\ndashboard access. Use when session is pre-authenticated.")
    sec_grid.addWidget(lbl_dashboard, 3, 0)

    app.sw_dev_direct_dashboard = ToggleSwitch(variant="warning")
    app.sw_dev_direct_dashboard.setToolTip("Enable direct dashboard polling mode (bypass OTP)")
    if hasattr(app, 'var_direct_dashboard'):
        app.var_direct_dashboard.bind_to_widget(app.sw_dev_direct_dashboard)
    sec_grid.addWidget(app.sw_dev_direct_dashboard, 3, 1, Qt.AlignRight)

    # Toggle: Detailed Debug Logging
    lbl_detailed_logs = QLabel("Detailed Debug Logging")
    lbl_detailed_logs.setFont(QFont("Segoe UI", 11))
    lbl_detailed_logs.setToolTip("Displays detailed technical debug logs (CDP URLs, engine details).\nDisabled by default for clean user-friendly logs.")
    sec_grid.addWidget(lbl_detailed_logs, 4, 0)

    app.sw_dev_detailed_logs = ToggleSwitch(variant="warning")
    app.sw_dev_detailed_logs.setToolTip("Enable detailed technical debug logging")
    if hasattr(app, 'var_detailed_logs'):
        app.var_detailed_logs.bind_to_widget(app.sw_dev_detailed_logs)
    sec_grid.addWidget(app.sw_dev_detailed_logs, 4, 1, Qt.AlignRight)

    content_grid.addWidget(sec_box, 1, 0, 1, 2)

    # ── Section 1: Batch Slicing & Filters ──────────────────────────────
    filter_box = QFrame()
    filter_box.setProperty("cssClass", "card")
    filter_grid = QGridLayout(filter_box)
    filter_grid.setContentsMargins(15, 10, 15, 10)
    filter_grid.setColumnStretch(1, 1)

    lbl_filter_title = QLabel("📋 Batch Slicing & Filters")
    lbl_filter_title.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_filter_title.setAlignment(Qt.AlignCenter)
    lbl_filter_title.setProperty("cssClass", "highlight")
    filter_grid.addWidget(lbl_filter_title, 0, 0, 1, 2)

    # Limit rows switch + entry
    app.sw_limit = ToggleSwitch("Limit run to first N rows")
    app.sw_limit.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_dev_limit_rows'):
        app.var_dev_limit_rows.bind_to_widget(app.sw_limit)
    filter_grid.addWidget(app.sw_limit, 1, 0)

    app.ent_limit = QLineEdit()
    app.ent_limit.setFixedSize(80, 30)
    if hasattr(app, 'var_dev_limit_rows_val'):
        app.var_dev_limit_rows_val.bind_to_widget(app.ent_limit)
    filter_grid.addWidget(app.ent_limit, 1, 1, Qt.AlignLeft)

    # Filter range switch + entry
    app.sw_range = ToggleSwitch("Filter to specific row range")
    app.sw_range.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_dev_filter_range'):
        app.var_dev_filter_range.bind_to_widget(app.sw_range)
    filter_grid.addWidget(app.sw_range, 2, 0)

    app.ent_range = QLineEdit()
    app.ent_range.setPlaceholderText("e.g. 134-150, 200")
    app.ent_range.setFixedHeight(30)
    if hasattr(app, 'var_dev_filter_range_val'):
        app.var_dev_filter_range_val.bind_to_widget(app.ent_range)
    filter_grid.addWidget(app.ent_range, 2, 1)

    content_grid.addWidget(filter_box, 2, 0, 1, 2)

    # ── Section 2: Scraper Retry Configuration ──────────────────────────
    retry_box = QFrame()
    retry_box.setProperty("cssClass", "card")
    retry_grid = QGridLayout(retry_box)
    retry_grid.setContentsMargins(15, 10, 15, 10)
    retry_grid.setColumnStretch(1, 1)

    lbl_retry_title = QLabel("🔄 Scraper Retry Configuration")
    lbl_retry_title.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_retry_title.setAlignment(Qt.AlignCenter)
    lbl_retry_title.setProperty("cssClass", "highlight")
    retry_grid.addWidget(lbl_retry_title, 0, 0, 1, 2)

    lbl_retry = QLabel("Max Worker Scrape Retries:")
    lbl_retry.setFont(QFont("Segoe UI", 11))
    retry_grid.addWidget(lbl_retry, 1, 0)

    app.opt_retry = QComboBox()
    app.opt_retry.setFixedSize(80, 30)
    app.opt_retry.setFont(QFont("Segoe UI", 11))
    app.opt_retry.addItems(["0", "1", "2", "3"])
    if hasattr(app, 'var_dev_retry_count'):
        app.var_dev_retry_count.bind_to_widget(app.opt_retry)
    retry_grid.addWidget(app.opt_retry, 1, 1, Qt.AlignLeft)

    content_grid.addWidget(retry_box, 3, 0, 1, 2)

    # ── Section 3: Workspace & Cache Actions ────────────────────────────
    actions_box = QFrame()
    actions_box.setProperty("cssClass", "card")
    actions_grid = QGridLayout(actions_box)
    actions_grid.setContentsMargins(15, 10, 15, 10)
    actions_grid.setColumnStretch(0, 1)
    actions_grid.setColumnStretch(1, 1)

    lbl_actions_title = QLabel("🧹 Workspace & Cache Actions")
    lbl_actions_title.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_actions_title.setAlignment(Qt.AlignCenter)
    lbl_actions_title.setProperty("cssClass", "highlight")
    actions_grid.addWidget(lbl_actions_title, 0, 0, 1, 2)

    # Row 1, Col 0: Hard Cache & Session Reset
    btn_reset = QPushButton("🧹 Hard Cache && Session Reset")
    btn_reset.setProperty("cssClass", "danger")
    btn_reset.setFont(QFont("Segoe UI", 11, QFont.Bold))
    def run_full_reset():
        app.dev_reset_folder_and_db_cache()
        app.dev_wipe_browser_profiles()
    btn_reset.clicked.connect(run_full_reset)
    actions_grid.addWidget(btn_reset, 1, 0)

    # Row 1, Col 1: Open Target Downloads Folder
    btn_open = QPushButton("📁 Open Downloads Folder")
    btn_open.setProperty("cssClass", "outline")
    btn_open.setFont(QFont("Segoe UI", 11, QFont.Bold))
    btn_open.clicked.connect(app.dev_open_active_folder)
    actions_grid.addWidget(btn_open, 1, 1)

    # Row 2, Col 0: Run System Diagnostics
    btn_diag = QPushButton("📊 Run System Diagnostics")
    btn_diag.setProperty("cssClass", "outline")
    btn_diag.setFont(QFont("Segoe UI", 11, QFont.Bold))
    btn_diag.clicked.connect(app.dev_run_diagnostics)
    actions_grid.addWidget(btn_diag, 2, 0)

    # Row 2, Col 1: Open Chrome DevTools Inspector
    btn_devtools = QPushButton("🌐 Open Chrome DevTools Inspector")
    btn_devtools.setProperty("cssClass", "primary")
    btn_devtools.setFont(QFont("Segoe UI", 11, QFont.Bold))
    btn_devtools.clicked.connect(app.open_cdp_devtools)
    actions_grid.addWidget(btn_devtools, 2, 1)

    content_grid.addWidget(actions_box, 4, 0, 1, 2)

    # Bottom stretch
    content_grid.setRowStretch(5, 1)

    scroll_area.setWidget(scroll_content)
    outer_layout.addWidget(scroll_area)
