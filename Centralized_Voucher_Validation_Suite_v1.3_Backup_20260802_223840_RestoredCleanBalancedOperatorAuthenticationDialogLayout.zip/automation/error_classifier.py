# =========================================================
# Centralized Voucher Validation Suite — Centralized Error Classifier
# Replaces ad-hoc string matching with structured categories
# =========================================================

class ErrorCategory:
    """Enumeration of all recognized error categories for self-healing."""
    SESSION_EXPIRED = "session_expired"
    BROWSER_CRASH = "browser_crash"
    TIMEOUT = "timeout"
    NETWORK = "network"
    RATE_LIMITED = "rate_limited"
    FILE_CORRUPT = "file_corrupt"
    DOM_STALE = "dom_stale"
    NAVIGATION_INTERRUPTED = "navigation_interrupted"
    UNKNOWN = "unknown"


# Keywords for each error category (all lowercase)
_SESSION_KEYWORDS = [
    'session', 'login.jsp', 'sessionexpired', 'expired', 'logged out',
    'j_username', 'unauthorized', '401', 'redirect to login',
    'authentication', 'not authenticated', 'access denied'
]

_BROWSER_CRASH_KEYWORDS = [
    'target closed', 'browser has been closed', 'connection closed',
    'target page, context or browser has been closed',
    'page crashed', 'browser disconnected', 'websocket',
    'cdp session', 'detached', 'protocol error',
    'browser.close', 'context.close'
]

_TIMEOUT_KEYWORDS = [
    'timeout', 'exceeded', 'timed out', 'waiting for',
    'locator.select_option', 'locator.click', 'locator.fill',
    'page.wait_for', 'wait_for_selector', 'wait_for_load_state'
]

_NETWORK_KEYWORDS = [
    'net::err_', 'network', 'dns', 'refused', 'reset',
    'err_connection', 'err_name_not_resolved', 'err_internet',
    'err_tunnel', 'err_proxy', 'socket hang up', 'econnrefused',
    'econnreset', 'epipe', 'ehostunreach', 'enetunreach',
    'fetch failed', 'failed to fetch'
]

_RATE_LIMIT_KEYWORDS = [
    '429', '503', '502', 'too many requests', 'service unavailable',
    'bad gateway', 'server overloaded', 'rate limit', 'throttl'
]

_FILE_CORRUPT_KEYWORDS = [
    '0 bytes', '0 kb', 'invalid pdf', 'corrupt', 'validation failed',
    'empty file', 'incomplete download', 'truncated',
    'failed to verify', 'file size'
]

_DOM_STALE_KEYWORDS = [
    'stale', 'not found', 'detached from dom', 'element not found',
    'no such element', 'element is not attached',
    'element handle', 'node is detached'
]

_NAVIGATION_KEYWORDS = [
    'interrupted by another navigation', 'navigation failed',
    'navigating to', 'page.goto', 'err_aborted',
    'frame was detached', 'execution context was destroyed'
]


def classify_error(exception):
    """
    Classify an exception into a recoverable error category.
    
    Args:
        exception: The exception instance or error string.
    
    Returns:
        str: One of the ErrorCategory constants.
    """
    msg = str(exception).lower()

    # Order matters: check most specific categories first
    if any(k in msg for k in _SESSION_KEYWORDS):
        return ErrorCategory.SESSION_EXPIRED

    if any(k in msg for k in _BROWSER_CRASH_KEYWORDS):
        return ErrorCategory.BROWSER_CRASH

    if any(k in msg for k in _RATE_LIMIT_KEYWORDS):
        return ErrorCategory.RATE_LIMITED

    if any(k in msg for k in _NAVIGATION_KEYWORDS):
        return ErrorCategory.NAVIGATION_INTERRUPTED

    if any(k in msg for k in _TIMEOUT_KEYWORDS):
        return ErrorCategory.TIMEOUT

    if any(k in msg for k in _NETWORK_KEYWORDS):
        return ErrorCategory.NETWORK

    if any(k in msg for k in _FILE_CORRUPT_KEYWORDS):
        return ErrorCategory.FILE_CORRUPT

    if any(k in msg for k in _DOM_STALE_KEYWORDS):
        return ErrorCategory.DOM_STALE

    return ErrorCategory.UNKNOWN


def is_retryable(category):
    """
    Determine if an error category is worth retrying.
    
    Returns:
        bool: True if the error is transient and retrying may succeed.
    """
    return category in {
        ErrorCategory.SESSION_EXPIRED,
        ErrorCategory.BROWSER_CRASH,
        ErrorCategory.TIMEOUT,
        ErrorCategory.NETWORK,
        ErrorCategory.RATE_LIMITED,
        ErrorCategory.FILE_CORRUPT,
        ErrorCategory.DOM_STALE,
        ErrorCategory.NAVIGATION_INTERRUPTED,
    }


def is_session_level(category):
    """
    Determine if an error requires session-level recovery (re-authentication).
    
    Returns:
        bool: True if all workers should pause for re-authentication.
    """
    return category in {
        ErrorCategory.SESSION_EXPIRED,
    }


def is_browser_level(category):
    """
    Determine if an error requires browser-level recovery (context respawn).
    
    Returns:
        bool: True if the browser context should be torn down and recreated.
    """
    return category in {
        ErrorCategory.BROWSER_CRASH,
    }


def get_backoff_seconds(category, attempt):
    """
    Get the recommended backoff delay (in seconds) for a given error category
    and attempt number (1-indexed).
    
    Args:
        category: ErrorCategory constant.
        attempt: The retry attempt number (1, 2, 3, ...).
    
    Returns:
        float: Recommended delay in seconds before retrying.
    """
    base_delays = {
        ErrorCategory.SESSION_EXPIRED: 5.0,      # Quick retry after re-auth
        ErrorCategory.BROWSER_CRASH: 3.0,         # Quick retry after respawn
        ErrorCategory.TIMEOUT: 2.0,               # Standard exponential
        ErrorCategory.NETWORK: 3.0,               # Slightly longer
        ErrorCategory.RATE_LIMITED: 10.0,          # Much longer
        ErrorCategory.FILE_CORRUPT: 2.0,           # Quick retry
        ErrorCategory.DOM_STALE: 1.5,              # Quick retry with reload
        ErrorCategory.NAVIGATION_INTERRUPTED: 2.0, # Standard
        ErrorCategory.UNKNOWN: 5.0,                # Conservative
    }
    base = base_delays.get(category, 5.0)
    # Exponential backoff: base * 2^(attempt-1), capped at 120 seconds
    delay = base * (2 ** (attempt - 1))
    return min(delay, 120.0)


# Recovery action hints per category — used by the supervisor to decide
# what corrective action to take before retrying a failed task
RECOVERY_ACTIONS = {
    ErrorCategory.SESSION_EXPIRED: "reauthenticate",       # Pause all workers, re-login, resume
    ErrorCategory.BROWSER_CRASH: "respawn_context",         # Tear down context, create new one
    ErrorCategory.TIMEOUT: "retry_with_backoff",            # Exponential backoff, retry same task
    ErrorCategory.NETWORK: "retry_with_backoff",            # Wait and retry
    ErrorCategory.RATE_LIMITED: "cooldown_and_retry",        # Longer cooldown, reduce concurrency
    ErrorCategory.FILE_CORRUPT: "delete_and_retry",          # Delete corrupt file, retry download
    ErrorCategory.DOM_STALE: "reload_and_retry",             # Reload page, retry
    ErrorCategory.NAVIGATION_INTERRUPTED: "retry_with_backoff",
    ErrorCategory.UNKNOWN: "retry_with_backoff",
}


def get_recovery_action(category):
    """
    Get the recommended recovery action for a given error category.
    
    Args:
        category: ErrorCategory constant.
    
    Returns:
        str: Recovery action identifier.
    """
    return RECOVERY_ACTIONS.get(category, "retry_with_backoff")
