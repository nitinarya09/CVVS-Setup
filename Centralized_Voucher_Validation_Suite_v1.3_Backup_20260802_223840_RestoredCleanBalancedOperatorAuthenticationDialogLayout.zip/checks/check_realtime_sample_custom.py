import time
# checks/check_realtime_sample_custom.py
# Sample Custom Realtime Check Script for Centralized Voucher Validation Suite
# Users can duplicate and edit this file to add new custom realtime check rules!

from checks.base_check import BaseValidationCheck

class CheckRealtimeSampleCustom(BaseValidationCheck):
    check_id = "check_realtime_sample_custom"
    name = "High-Value Voucher Realtime Alert Check"
    description = "Sample custom realtime check that flags high-value vouchers (> ₹1,00,000) for enhanced audit scrutiny."
    check_type = "realtime"
    enabled = False

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        amt_str = str(voucher_data.get("amount", "")).strip().replace(",", "")
        try:
            amt = float(amt_str) if amt_str else 0.0
        except ValueError:
            amt = 0.0

        threshold = 100000.0  # ₹1 Lakh
        if amt >= threshold:
            return {
                "status": "WARNING",
                "message": f"High-Value Claim Flagged: Voucher amount ₹{amt:,.2f} exceeds threshold ₹{threshold:,.2f}",
                "details": {"amount": amt, "threshold": threshold}
            }

        return {
            "status": "PASS",
            "message": f"Voucher amount ₹{amt:,.2f} is within normal threshold.",
            "details": {"amount": amt}
        }
