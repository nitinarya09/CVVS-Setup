# -*- mode: python ; coding: utf-8 -*-

a = Analysis(
    ['ifmis_suite.py'],
    pathex=['.'],
    binaries=[],
    datas=[
        ('ddo.txt', '.'),
        ('terms.txt', '.'),
        ('cag_logo.png', '.'),
        ('cag_logo.ico', '.'),
        ('data', 'data'),
        ('checks', 'checks'),
        ('parsers', 'parsers'),
        ('core', 'core'),
        ('gui', 'gui'),
        ('automation', 'automation')
    ],
    hiddenimports=[
        'polars', 'fastexcel', 'openpyxl', 'fitz', 'PySide6', 'playwright', 'docx'
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['torch', 'torchvision', 'scipy', 'sympy'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='Centralized_Voucher_Validation_Suite',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['cag_logo.ico'],
)
