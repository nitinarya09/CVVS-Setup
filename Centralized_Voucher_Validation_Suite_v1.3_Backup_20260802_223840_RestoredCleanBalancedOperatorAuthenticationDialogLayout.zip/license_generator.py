import re
import time
# =========================================================
# Centralized Voucher Validation Suite - License Key Generator Utility
# Midnight/Teal Design Edition
# =========================================================

import os
import sys
import base64
import datetime
import subprocess
import customtkinter as ctk
from tkinter import messagebox

PRIVATE_KEY_PEM = """-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDSrGQAgcZTMqUy
Bu5wR8+6XZ1i8/MA85/7T2srNcxObEshM+qs5peINnkfGlYXmm+uhvAjP5NnyUa1
3qSn2JxowMLk4FUUD+hedBHrCrkRvbcleJIiKwRbvZESpuGhxuBNPRF6lwokFuDa
+CSyhBm6PUT4ZRMI/5V3e8l1e+KPl5E+UlasLOnYcmm0ypl1ysB7PbSpq6EIyzQs
FNBAEJvV2puUgA8e2H7XwfI5J2/Kt2Sg8fcsgnNmoc8tQXWFPWYMdIAVPEoMxUoB
J5bYumI1zEbDsLBZkDgc9m61fRlBWTq6i1y+5blOdtCRwlqdgPBvAbGlnUAWv6MI
MNmw3+LnAgMBAAECggEAAMDkS/Q+MJJm804oIrA3hAmhyk2MRF0mxu7kJE8jiKl6
h8ODEtmJt27LMrXKGg5qTzM+gF0+eBST2giYN4/hNAJoaMs6RHt6nHgZA2cUjCUJ
PW2dtBwb/ndTRd0IB3vs7gNzd6DVfs9Ix4n5qeOsnEJr8+EQqmHuk3fwARFIRL57
e6BfcQ30a/CVSg9oN+D1SiT0GdqpGFwFxfLcZC+3upEXuEQ2WrMZar1nzQvqnqWy
5Y0lFyTeHAnLqguCRfKIEvDEJMnxZ3+Hg5qTeuSo2SIZn1yNenLxo1IVDCUOetxp
VJEMfBJjGWrtM1ICJQ4qhRu2u8BdZir/PkNDEKTfsQKBgQDyw2CHz8qJbJDgjoFx
wp3cFagp6jm/Lcxlg0rslMKNl/HMQ+RO6s6ihFglrrpB6idBXWmDgs9YGa3AmRfv
8g6w0qXOpD/NuyLllvtm4V3Axv1jCHHN3b380wpgYQvntkc6SOXBGOaZPF/LY1R7
ec4obQz0OdUtDfszmHGTYrPp3wKBgQDeKRYlatG7T2WfkWHDxhXVp2exBNdyiRk0
PeNMGDzb6wmx018rIDa9KInpWaD1QHhcYYMNcjBt1MY46iwEnOqETfh+vV0rI+sP
PrzcCW0HFibcCRJ8nyzJWkKIZ53d/V870N6iHGZdV5wv6xrafsAqak0xZ2iaVaGd
JcCV+K23+QKBgDAwKiwrSgfnXgbFItrDB/TU87GGRfo2DBmmayv1B311yNCENYCY
yXWnEZxBR8Wnxi0KbtRlFeVmC4BsozzE7reYyMLxBZ0/5VhvlO3CFIsctNWAqp5z
wq+58JhbCzLuksr2B21CFRwbyOQljnKIJi0OIIEmLbOoz9FZFEpuUEo/AoGAQgcI
E/rZdsg0NeapndwDpUpp4QzFU783hHVYVsdlXx9N9FIUGOcsHbAsvPPsiLeujhZV
MuvbROlWOJgwmPZiJQxfbJuvUyELva4xx1vt0Ytd5Uu0+OD+GKIA4DWbj9y8LzT2
1kuGiPt+6icABixhxLlvU92eEzCcJe6QfII6b1ECgYEAoSYTq8uyUfzq594GSmhi
Xx9OGS6AbKpMTkhxrjdD7kKdMLr2D/iFDkrvcD7ATzzKM/p8PWV4bitLCqItNDhc
iXPrrQlDehNcjrkATevANKrdliYiCF6dCf5orE7x43mCIIyWqzYJ+q6Xo09GDR3v
cpjO6tfZWyqCtrt6EYlbcJo=
-----END PRIVATE KEY-----"""

def load_private_key():
    try:
        from cryptography.hazmat.primitives.serialization import load_pem_private_key
        return load_pem_private_key(PRIVATE_KEY_PEM.encode('utf-8'), password=None)
    except Exception as e:
        print(f"Error loading embedded private key: {e}")
    return None

# Set up style
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class KeyGeneratorApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Centralized Voucher Validation Suite - Licensing Key Generator")
        self.geometry("540x440")
        self.configure(fg_color="#0d1117")
        self.resizable(False, False)
        
        # Center the window
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        x = (screen_width - 540) // 2
        y = (screen_height - 440) // 2
        self.geometry(f"540x440+{x}+{y}")
        
        self._build_gui()

    def _build_gui(self):
        # Header
        title_label = ctk.CTkLabel(
            self, text="🔑 License Key Generator", 
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"), text_color="#00c9a7"
        )
        title_label.pack(pady=(30, 5))
        
        sub_label = ctk.CTkLabel(
            self, text="Generate secure offline activation keys for Centralized Voucher Validation Suite client installations.", 
            font=ctk.CTkFont(family="Segoe UI", size=11), text_color="#8b949e"
        )
        sub_label.pack(pady=(0, 25))
        
        # Form Box
        form_frame = ctk.CTkFrame(self, fg_color="#161b22", border_width=1, border_color="#30363d", corner_radius=12)
        form_frame.pack(fill="x", padx=40, pady=10)
        
        # Hardware ID Entry
        ctk.CTkLabel(form_frame, text="Client Hardware ID (HWID):", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#f8fafc").grid(row=0, column=0, padx=15, pady=(15, 5), sticky="w")
        
        hwid_container = ctk.CTkFrame(form_frame, fg_color="transparent")
        hwid_container.grid(row=0, column=1, padx=15, pady=(15, 5), sticky="ew")
        
        self.entry_hwid = ctk.CTkEntry(
            hwid_container, placeholder_text="e.g. UUID from client screen", height=30,
            fg_color="#0d1117", border_color="#30363d", text_color="#f8fafc",
            font=ctk.CTkFont(family="Consolas", size=11), corner_radius=8
        )
        self.entry_hwid.pack(side="left", fill="x", expand=True, padx=(0, 10))
        
        self.btn_fetch_hwid = ctk.CTkButton(
            hwid_container, text="Get Local", width=80, height=30,
            fg_color="transparent", border_width=1, border_color="#00c9a7", text_color="#00c9a7",
            hover_color="#0c362d", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"), corner_radius=8,
            command=self.fetch_local_hwid
        )
        self.btn_fetch_hwid.pack(side="right")
        
        # Expiry Duration Combobox
        ctk.CTkLabel(form_frame, text="License Expiry:", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#f8fafc").grid(row=1, column=0, padx=15, pady=(5, 15), sticky="w")
        self.combo_expiry = ctk.CTkComboBox(
            form_frame, values=["1 Month", "3 Months", "6 Months", "1 Year", "Permanent"], width=280, height=30,
            fg_color="#0d1117", border_color="#30363d", button_color="#00c9a7", button_hover_color="#00e5bf",
            dropdown_fg_color="#161b22", dropdown_hover_color="#0c362d", dropdown_text_color="#f8fafc",
            font=ctk.CTkFont(family="Segoe UI", size=11), corner_radius=8
        )
        self.combo_expiry.set("1 Year")
        self.combo_expiry.grid(row=1, column=1, padx=15, pady=(5, 15), sticky="ew")
        
        form_frame.grid_columnconfigure(1, weight=1)
        
        # Action Buttons
        self.btn_generate = ctk.CTkButton(
            self, text="⚡ Generate Key", height=38, width=220,
            fg_color="#00c9a7", hover_color="#00e5bf", text_color="#0d1117",
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"), corner_radius=8,
            command=self.generate_activation_key
        )
        self.btn_generate.pack(pady=15)
        
        # Output Key Box
        out_frame = ctk.CTkFrame(self, fg_color="transparent")
        out_frame.pack(fill="x", padx=40, pady=5)
        
        ctk.CTkLabel(out_frame, text="Generated Activation Key Block:", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color="#f8fafc").pack(anchor="w", pady=2)
        
        self.txt_key = ctk.CTkEntry(
            out_frame, height=36, fg_color="#161b22", border_color="#30363d", text_color="#00c9a7",
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"), corner_radius=8
        )
        self.txt_key.pack(fill="x", pady=2)
        
        self.btn_copy = ctk.CTkButton(
            out_frame, text="📋 Copy Key Block to Clipboard", height=32, fg_color="transparent", border_width=1, border_color="#00c9a7", text_color="#00c9a7",
            hover_color="#0c362d", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"), corner_radius=8,
            command=self.copy_key
        )
        self.btn_copy.pack(fill="x", pady=8)
        self.btn_copy.configure(state="disabled")

    def generate_activation_key(self):
        hwid = self.entry_hwid.get().strip()
        if not hwid:
            messagebox.showerror("Error", "Please specify the Client Hardware ID.")
            return
            
        expiry_type = self.combo_expiry.get()
        today = datetime.date.today()
        
        if expiry_type == "1 Month":
            expiry_date = today + datetime.timedelta(days=30)
            exp_str = expiry_date.strftime("%Y-%m-%d")
        elif expiry_type == "3 Months":
            expiry_date = today + datetime.timedelta(days=90)
            exp_str = expiry_date.strftime("%Y-%m-%d")
        elif expiry_type == "6 Months":
            expiry_date = today + datetime.timedelta(days=180)
            exp_str = expiry_date.strftime("%Y-%m-%d")
        elif expiry_type == "1 Year":
            expiry_date = today + datetime.timedelta(days=365)
            exp_str = expiry_date.strftime("%Y-%m-%d")
        else:
            exp_str = "NEVER"
            
        try:
            private_key = load_private_key()
            if not private_key:
                messagebox.showerror("Error", "Private key (private_key.pem) not found!\nPlease place it in the same directory.")
                return
                
            # Generate offline signature using RSA private key
            raw_data = f"{exp_str}|{hwid}"
            
            from cryptography.hazmat.primitives.asymmetric import padding
            from cryptography.hazmat.primitives import hashes
            
            signature = private_key.sign(
                raw_data.encode('utf-8'),
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            
            # Combine raw data and signature hex
            combined = f"{raw_data}|{signature.hex()}"
            
            # Encode Base64
            key_block = base64.b64encode(combined.encode('utf-8')).decode('utf-8')
            
            self.txt_key.delete(0, "end")
            self.txt_key.insert(0, key_block)
            
            self.btn_copy.configure(state="normal")
            
        except Exception as e:
            messagebox.showerror("Generation Error", f"An error occurred:\n{e}")

    def copy_key(self):
        key = self.txt_key.get().strip()
        if key:
            self.clipboard_clear()
            self.clipboard_append(key)
            self.update()
            messagebox.showinfo("Success", "Activation key block copied successfully!")

    def fetch_local_hwid(self):
        hwid = get_machine_id()
        self.entry_hwid.delete(0, "end")
        self.entry_hwid.insert(0, hwid)

def get_machine_id():
    try:
        output = subprocess.check_output('wmic csproduct get uuid', creationflags=0x08000000).decode('utf-8').strip()
        lines = [line.strip() for line in output.split('\n') if line.strip() != '']
        if len(lines) > 1 and len(lines[1]) > 10: return lines[1]
    except Exception: pass

    try:
        cmd = ['powershell', '-NoProfile', '-Command', '(Get-CimInstance -Class Win32_ComputerSystemProduct).UUID']
        output = subprocess.check_output(cmd, creationflags=0x08000000).decode('utf-8').strip()
        if output and len(output) > 10: return output
    except Exception: pass

    try:
        import winreg
        registry = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
        key = winreg.OpenKey(registry, r"SOFTWARE\Microsoft\Cryptography")
        machine_guid, _ = winreg.QueryValueEx(key, "MachineGuid")
        if machine_guid: return machine_guid
    except Exception: pass

    return "UNKNOWN_MACHINE"

if __name__ == "__main__":
    app = KeyGeneratorApp()
    app.mainloop()
