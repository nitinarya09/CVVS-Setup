#!/usr/bin/env python3
# Centralized Voucher Validation Suite Entry Point
import os
import sys
import multiprocessing

if __name__ == "__main__":
    multiprocessing.freeze_support()

    # Delegate to ifmis_suite.py
    script_dir = os.path.dirname(os.path.abspath(__file__))
    entry_script = os.path.join(script_dir, "ifmis_suite.py")

    with open(entry_script, "r", encoding="utf-8") as f:
        code = compile(f.read(), entry_script, 'exec')
        exec(code, {'__name__': '__main__', '__file__': entry_script})
