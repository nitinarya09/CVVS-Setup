"""
voucher_http_pool.py — High-Throughput Direct HTTP Connection Pool for v1.3

Extracts authenticated portal session cookies from Playwright context and executes
concurrent HTTP GET binary streams for attachment files, Paybills, and document details,
reducing DOM click overhead per voucher from ~40s down to 4-8s.
"""

import os
import re
import sys
import time
import hashlib
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class VoucherHttpPool:
    def __init__(self, playwright_context, max_workers=5, log_fn=None):
        self.context = playwright_context
        self.max_workers = max_workers
        self.log = log_fn or print
        self.session = requests.Session()
        self.session.verify = False
        self._sync_cookies()

    def _sync_cookies(self):
        """Extract cookies from Playwright context into the requests session."""
        try:
            pw_cookies = self.context.cookies()
            for c in pw_cookies:
                self.session.cookies.set(c['name'], c['value'], domain=c.get('domain', ''), path=c.get('path', '/'))
        except Exception as e:
            self.log(f"⚠️ Notice: Cookie sync exception: {e}")

    def download_file_direct(self, url, output_path, headers=None):
        """
        Download a file directly over HTTP binary stream, computing MD5 in RAM.
        Returns dict with (filename, size, md5, path, success).
        """
        req_headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Accept": "*/*"
        }
        if headers:
            req_headers.update(headers)

        md5_hasher = hashlib.md5()
        bytes_total = 0

        try:
            resp = self.session.get(url, headers=req_headers, stream=True, timeout=25)
            resp.raise_for_status()

            # Ensure parent folder exists
            os.makedirs(os.path.dirname(output_path), exist_ok=True)

            with open(output_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=32768):
                    if chunk:
                        f.write(chunk)
                        md5_hasher.update(chunk)
                        bytes_total += len(chunk)

            if bytes_total < 100:
                if os.path.exists(output_path):
                    try: os.remove(output_path)
                    except Exception: pass
                return {"success": False, "error": "File too small (<100 bytes)"}

            filename = os.path.basename(output_path)
            md5_hex = md5_hasher.hexdigest()

            return {
                "success": True,
                "filename": filename,
                "size": bytes_total,
                "md5": md5_hex,
                "path": output_path
            }

        except Exception as err:
            if os.path.exists(output_path):
                try: os.remove(output_path)
                except Exception: pass
            return {"success": False, "error": str(err)}

    def batch_download_attachments(self, attachment_requests, target_folder):
        """
        Download a batch of attachment request dicts in parallel using ThreadPoolExecutor.
        attachment_requests: list of dicts with keys ('url', 'filename', 'headers')
        Returns list of result dicts.
        """
        self._sync_cookies()
        results = []
        if not attachment_requests:
            return results

        def _worker(req):
            url = req.get('url')
            fname = req.get('filename', f"attachment_{int(time.time()*1000)}.pdf")
            out_path = os.path.join(target_folder, fname)
            headers = req.get('headers')
            return self.download_file_direct(url, out_path, headers)

        with ThreadPoolExecutor(max_workers=min(self.max_workers, len(attachment_requests))) as executor:
            future_to_req = {executor.submit(_worker, req): req for req in attachment_requests}
            for future in as_completed(future_to_req):
                try:
                    res = future.result()
                    results.append(res)
                except Exception as ex:
                    results.append({"success": False, "error": str(ex)})

        return results
