def validate_mptc_pdf(filepath):
    """
    Safety Feature: Validates that Show_MPTC.pdf is not blank.
    Returns True if valid non-blank PDF, False if blank/corrupt.
    """
    if not os.path.exists(filepath):
        return False
    size = os.path.getsize(filepath)
    if size < 4000:
        return False
    try:
        from pypdf import PdfReader
        reader = PdfReader(filepath)
        if len(reader.pages) == 0:
            return False
        text = (reader.pages[0].extract_text() or "").strip()
        if len(text) < 15:
            return False
        return True
    except Exception:
        return size >= 5000

import os
import re
import time
import base64
import calendar
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

# Import helper functions
from parsers.pdf_paybill import clean_and_save_flat_paybill
from parsers.excel_mapper import clean_amount_string


def compress_pdf_file(filepath):
    try:
        import pypdf
    except ImportError:
        return False

    try:
        if not os.path.exists(filepath):
            return False
        
        reader = pypdf.PdfReader(filepath)
        writer = pypdf.PdfWriter()
        
        for page in reader.pages:
            try:
                page.compress_content_streams()
            except Exception:
                pass
            
            try:
                for img in page.images:
                    try:
                        img.replace(img.image, quality=60)
                    except Exception:
                        pass
            except Exception:
                pass
                
            writer.add_page(page)
            
        try:
            writer.compress_identical_objects(remove_duplicates=True, remove_unreferenced=True)
        except Exception:
            pass
            
        temp_filepath = filepath + ".tmp"
        with open(temp_filepath, "wb") as f:
            writer.write(f)
            
        if os.path.exists(temp_filepath):
            # Verify the compressed PDF is not corrupted
            is_valid = False
            try:
                test_reader = pypdf.PdfReader(temp_filepath)
                if len(test_reader.pages) > 0:
                    is_valid = True
            except Exception:
                is_valid = False
                
            orig_size = os.path.getsize(filepath)
            new_size = os.path.getsize(temp_filepath)
            if is_valid and new_size < orig_size and new_size > 0:
                os.replace(temp_filepath, filepath)
                return True
            else:
                try: os.remove(temp_filepath)
                except Exception: pass
        return False
    except Exception:
        return False


def save_landscape_pdf(page, pdf_path):
    """
    Renders active tab DOM state to PDF using exact IFMIS 365 v3.5 print engine logic:
    1. Set viewport to 1920x1080.
    2. Expand all hidden/overflow elements to visible.
    3. Inject @page { size: landscape; margin: 5mm; } & @media print zoom rules.
    4. Render PDF with format=A4, landscape=True, scale=0.80, print_background=True.
    5. Compress PDF with pypdf to keep file size lightweight (~300KB-400KB).
    """
    try:
        # 1. Expand viewport size
        try:
            page.set_viewport_size({"width": 1920, "height": 1080})
        except Exception: pass

        # 2. Force all overflow elements visible
        try:
            page.evaluate("""() => {
                document.querySelectorAll('*').forEach(el => {
                    const style = window.getComputedStyle(el);
                    if (style.overflow === 'hidden' || style.overflowX === 'hidden') {
                        el.style.overflow = 'visible';
                        el.style.overflowX = 'visible';
                    }
                });
                document.body.style.width = '100%';
                document.body.style.overflow = 'visible';
            }""")
        except Exception: pass

        # 3. Inject @page landscape and @media print scaling rules
        try:
            page.add_style_tag(content="""
                @page { size: landscape; margin: 5mm; }
                @media print {
                    html, body { width: 100% !important; overflow: visible !important; zoom: 80% !important; }
                    table { width: 100% !important; max-width: 100% !important; font-size: 9px !important; }
                }
            """)
        except Exception: pass

        # 4. Render PDF using Playwright native .pdf() with CDP fallback
        rendered = False
        try:
            page.pdf(
                path=pdf_path,
                format="A4",
                landscape=True,
                scale=0.80,
                print_background=True,
                margin={"top": "5mm", "bottom": "5mm", "left": "5mm", "right": "5mm"}
            )
            rendered = True
        except Exception:
            try:
                client = page.context.new_cdp_session(page)
                pdf_data = client.send("Page.printToPDF", {
                    "landscape": True,
                    "printBackground": True,
                    "scale": 0.80,
                    "paperWidth": 11.69,
                    "paperHeight": 8.27,
                    "marginTop": 0.2,
                    "marginBottom": 0.2,
                    "marginLeft": 0.2,
                    "marginRight": 0.2,
                    "preferCSSPageSize": True
                })
                with open(pdf_path, "wb") as f:
                    f.write(base64.b64decode(pdf_data['data']))
                rendered = True
            except Exception: pass

        if rendered and os.path.exists(pdf_path):
            compress_pdf_file(pdf_path)
            return True
    except Exception:
        pass
    return False


def _inject_tab_style(page, show_id: str, hide_id: str):
    """Inject CSS overrides that force one tab content visible and the other hidden for PDF rendering."""
    try:
        page.evaluate(f"""() => {{
            const old = document.getElementById('__agy_print_override__');
            if (old) old.remove();

            const show = document.getElementById('{show_id}');
            const hide = document.getElementById('{hide_id}');
            if (show) {{
                show.style.cssText += '; display:block !important; visibility:visible !important; height:auto !important; overflow:visible !important; position:relative !important; opacity:1 !important;';
            }}
            if (hide) {{
                hide.style.cssText += '; display:none !important; visibility:hidden !important; height:0 !important; overflow:hidden !important; position:absolute !important; opacity:0 !important;';
            }}

            const s = document.createElement('style');
            s.id = '__agy_print_override__';
            s.textContent = `
                #{hide_id} {{ display:none !important; visibility:hidden !important; height:0 !important; overflow:hidden !important; }}
                #{show_id} {{ display:block !important; visibility:visible !important; height:auto !important; overflow:visible !important; }}
                @media print {{
                    #{hide_id} {{ display:none !important; visibility:hidden !important; height:0 !important; overflow:hidden !important; }}
                    #{show_id} {{ display:block !important; visibility:visible !important; height:auto !important; overflow:visible !important; }}
                }}`;
            document.head.appendChild(s);
        }}""")
    except Exception:
        pass


def is_network_error_page(page):
    """
    Detects if the browser page is showing a network error / timeout page
    (Firefox 'Problem loading page', 'The connection has timed out',
     Chrome 'This site can't be reached', 'ERR_CONNECTION_TIMED_OUT',
     502 Bad Gateway, 504 Gateway Timeout, etc.)
    """
    try:
        if page is None:
            return True

        try:
            if page.is_closed():
                return True
        except Exception:
            return True

        try:
            url_low = page.url.lower()
            if "about:neterror" in url_low or "chrome-error://" in url_low:
                return True
        except Exception:
            pass

        try:
            title_low = page.title().lower()
            if any(term in title_low for term in [
                "problem loading page", "server not found", "connection timed out",
                "can’t be reached", "cant be reached", "this site can’t be reached",
                "this site can't be reached", "502 bad gateway", "504 gateway time-out",
                "504 gateway timeout", "503 service unavailable", "service unavailable"
            ]):
                return True
        except Exception:
            pass

        try:
            if page.locator("#reload-button").count() > 0 or page.locator("#netErrorButton").count() > 0 or page.locator("button:has-text('Try Again')").count() > 0 or page.locator("#errorTitleText").count() > 0:
                return True
        except Exception:
            pass

        try:
            body_text = page.inner_text("body").lower()
            error_keywords = [
                "the connection has timed out",
                "taking too long to respond",
                "server at ifmisprod.mptreasury.gov.in is taking too long to respond",
                "server at ifmiscommonreports.mptreasury.gov.in is taking too long to respond",
                "err_connection_timed_out",
                "err_connection_reset",
                "err_name_not_resolved",
                "err_timed_out",
                "dns_probe_finished",
                "site can’t be reached",
                "site can't be reached",
                "server ip address could not be found",
                "ip address could not be found",
                "unable to connect",
                "502 bad gateway",
                "504 gateway time-out",
                "504 gateway timeout",
                "503 service unavailable"
            ]
            if any(kw in body_text for kw in error_keywords):
                return True
        except Exception:
            pass

    except Exception:
        pass
    return False


def handle_ifmis_page_error(page):
    """
    Checks if IFMIS technical error modal (#okbutton or 'Your request cannot be currently processed')
    is visible on page. If visible, automatically clicks OK to clear the error and returns True.
    """
    try:
        if page and not page.is_closed():
            if page.locator("#okbutton").count() > 0 and page.locator("#okbutton").is_visible():
                page.locator("#okbutton").click()
                page.wait_for_timeout(1000)
                return True
            content_low = page.content().lower()
            if "your request cannot be currently processed" in content_low or "an unexpected error occurred" in content_low:
                if page.locator("#okbutton").count() > 0:
                    try:
                        page.locator("#okbutton").click()
                        page.wait_for_timeout(1000)
                    except Exception: pass
                return True
    except Exception:
        pass
    return False


class SessionExpiredError(Exception):
    pass

class BrowserConnectionDeadError(Exception):
    pass

class UserAlreadyLoggedInError(Exception):
    pass

def is_session_expired(page):
    try:
        url = page.url.lower()
        
        # Explicit check for logout.jsp or logout redirect
        if "logout.jsp" in url or "logout" in url:
            return True

        # Check for standard login page and session expiry/logout keywords in URL
        login_url_indicators = [
            "login.jsp", "logout.jsp", "sessionexpired", "session_expired", "sessiontimeout", 
            "logout", "getuseridforotp", "login", "timeout", "signout", "expired"
        ]
        if any(indicator in url for indicator in login_url_indicators):
            # Ensure we don't treat the active validateLogin or ifms htm as expired/login
            if "validatelogin" in url or "ifms.htm" in url:
                # Unless it specifically has an error message or logout keyword
                if "logout" not in url and "expired" not in url and "timeout" not in url:
                    return False
            return True
            
        # Check input elements indicating login/expired page
        if page.locator("input[name='j_username']").count() > 0: return True
        if page.locator("input[name='j_password']").count() > 0: return True
        if page.locator("input[id*='username']").count() > 0: return True
        if page.locator("input[id*='password']").count() > 0: return True
        
        # Check for body text indicating session expiration or logout
        try:
            page_text = page.inner_text("body").lower()
            expired_indicators = [
                "session expired", "session has expired", "session timeout", 
                "logged out", "please login again", "re-login", "login again",
                "always make proper logout", "proper logout"
            ]
            if any(ind in page_text for ind in expired_indicators):
                return True

        except Exception:
            pass
            
        return False
    except Exception:
        return False

def is_browser_connection_dead(err):
    err_str = str(err).lower()
    return any(x in err_str for x in [
        "connection closed",
        "target closed",
        "browser has been closed",
        "channel closed",
        "disconnected",
        "not opened",
        "closed"
    ])

def get_scaled_timeout(self, base_ms):
    if hasattr(self, "TIMEOUT_MULTIPLIER"):
        return int(base_ms * self.TIMEOUT_MULTIPLIER)
    is_parallel = getattr(self, "var_parallel", None) and self.var_parallel.get()
    workers = getattr(self, "var_parallel_workers", None) and self.var_parallel_workers.get() or 1
    if not is_parallel:
        workers = 1
    multiplier = 1.0 + max(0, workers - 1) * 0.25
    return int(base_ms * multiplier)

def resilient_click(self, page_or_frame, locator, max_retries=3, base_timeout=4000):
    current_timeout = base_timeout
    for attempt in range(1, max_retries + 1):
        try:
            loc = page_or_frame.locator(locator) if isinstance(locator, str) else locator
            loc.first.wait_for(state="visible", timeout=get_scaled_timeout(self, current_timeout))
            loc.first.click(timeout=get_scaled_timeout(self, current_timeout))
            return True
        except Exception as e:
            if attempt == max_retries:
                raise e
            sleep_time = 2 ** attempt
            self.log(f"⚠️ Click failed: {e}. Retrying in {sleep_time}s (Attempt {attempt + 1}/{max_retries})...")
            time.sleep(sleep_time)
            current_timeout *= 1.5
    return False

def resilient_goto(self, page, url, max_retries=3, base_timeout=20000):
    current_timeout = base_timeout
    for attempt in range(1, max_retries + 1):
        try:
            nav_timeout = min(90000, get_scaled_timeout(self, current_timeout))
            page.goto(url, wait_until="domcontentloaded", timeout=nav_timeout)

            if is_network_error_page(page):
                raise Exception("Browser network error / connection timeout page loaded")

            return True
        except Exception as e:
            if is_network_error_page(page):
                if hasattr(self, "log"):
                    self.log(f"⚠️ Connection timeout detected on browser. Attempting automatic reload ({attempt}/{max_retries})...")
                try:
                    if page.locator("button:has-text('Try Again')").count() > 0:
                        page.locator("button:has-text('Try Again')").click()
                    elif page.locator("#netErrorButton").count() > 0:
                        page.locator("#netErrorButton").click()
                    elif page.locator("#reload-button").count() > 0:
                        page.locator("#reload-button").click()
                    else:
                        page.reload(wait_until="domcontentloaded", timeout=30000)
                    time.sleep(2.5)
                    if not is_network_error_page(page):
                        if hasattr(self, "log"):
                            self.log("✅ Network connection recovered after reload!")
                        return True
                except Exception as r_err:
                    if hasattr(self, "log"):
                        self.log(f"⚠️ Reload attempt notice: {r_err}")

            if attempt == max_retries:
                if is_network_error_page(page):
                    if hasattr(self, "log"):
                        self.log("❌ Connection timeout persisted after 3 reload attempts. Triggering session reset & re-login...")
                    try:
                        page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/", wait_until="domcontentloaded", timeout=30000)
                    except Exception:
                        pass
                    raise SessionExpiredError("Network connection timeout persisted after multiple reload attempts. Session reset required.")
                raise e

            sleep_time = 2 ** attempt
            if hasattr(self, "log"):
                self.log(f"⚠️ Navigation failed: {e}. Retrying in {sleep_time}s (Attempt {attempt + 1}/{max_retries})...")
            time.sleep(sleep_time)
            current_timeout *= 1.5
    return False

def resilient_wait_for(self, page_or_frame, locator_or_str, state="visible", max_retries=3, base_timeout=4000):
    current_timeout = base_timeout
    for attempt in range(1, max_retries + 1):
        try:
            loc = page_or_frame.locator(locator_or_str) if isinstance(locator_or_str, str) else locator_or_str
            loc.first.wait_for(state=state, timeout=get_scaled_timeout(self, current_timeout))
            return True
        except Exception as e:
            if attempt == max_retries:
                raise e
            sleep_time = 2 ** attempt
            self.log(f"⚠️ Wait failed: {e}. Retrying in {sleep_time}s (Attempt {attempt + 1}/{max_retries})...")
            time.sleep(sleep_time)
            current_timeout *= 1.5
    return False

def wait_for_selector_with_retry(self, page_or_frame, selector, state="visible", max_retries=3, base_timeout=4000):
    current_timeout = base_timeout
    for attempt in range(1, max_retries + 1):
        try:
            page_or_frame.wait_for_selector(selector, state=state, timeout=get_scaled_timeout(self, current_timeout))
            return True
        except Exception as e:
            if attempt == max_retries:
                raise e
            sleep_time = 2 ** attempt
            self.log(f"⚠️ Wait for selector '{selector}' failed: {e}. Retrying in {sleep_time}s (Attempt {attempt + 1}/{max_retries})...")
            time.sleep(sleep_time)
            current_timeout *= 1.5
    return False

def validate_downloaded_file(filepath):
    if not os.path.exists(filepath):
        return False
    size = os.path.getsize(filepath)
    if size < 100:
        try:
            with open(filepath, "rb") as f:
                content = f.read(100)
            print(f"⚠️ Debug: File too small ({size} bytes). Content: {content}")
        except Exception:
            pass
        return False
    if filepath.lower().endswith(".pdf"):
        try:
            with open(filepath, "rb") as f:
                header = f.read(4)
            if header == b"%PDF":
                return True
            print(f"⚠️ Debug: PDF validation failed. Header: {header}")
            return False
        except Exception:
            return False
    elif filepath.lower().endswith((".xls", ".xlsx")):
        try:
            with open(filepath, "rb") as f:
                header = f.read(1024)
            # Check OLE header, Zip header, or HTML container
            if header.startswith(b"\xd0\xcf\x11\xe0") or header.startswith(b"PK\x03\x04") or b"<html" in header.lower() or b"<!doc" in header.lower() or b"<table" in header.lower():
                return True
            print(f"⚠️ Debug: Excel validation failed. Size: {size} bytes. Header snippet: {header[:100]}")
            return False
        except Exception:
            return False
    return True

def _select_bill_type_paybill(self, page):
    # Bill Type auto-selection disabled per user request.
    try:
        dd = page.locator("#cmbBillType")
        if dd.count() > 0:
            self.log("⚠️ Bill Type auto-selection disabled; leaving existing selection unchanged.")
        else:
            self.log("⚠️ Bill Type dropdown not present; no action taken.")
    except Exception as e:
        self.log(f"⚠️ Bill Type selection check failed: {str(e)[:80]}")
    return True

def _click_bill_ref_no_link(self, page):
    primary = page.locator("a[onclick*='retrievePayrollBillEmpDetails']")
    if primary.count() > 0 and primary.first.is_visible(): return primary.first
    secondary = page.locator("a[onclick*='payrollBillId']")
    if secondary.count() > 0 and secondary.first.is_visible(): return secondary.first
    tertiary = page.locator("a:has-text('Pay Bill/')")
    if tertiary.count() > 0 and tertiary.first.is_visible(): return tertiary.first
    all_links = page.locator("#tblSrchRslt a, table a").all()
    visible_links = [lnk for lnk in all_links if lnk.is_visible()]
    if len(visible_links) >= 2: return visible_links[1]
    return None

def _download_paybill_for_voucher(self, context, bill_page, folder, s_no, treasury, vou, year, month, mh):
    try:
        # Check if the Excel file is already downloaded and is valid
        safe_vou = self.clean_folder_name(str(vou))
        save_name_xls = f"PayBill_{s_no}_{treasury}_{safe_vou}_{year}{month:02d}.xls"
        save_name_xlsx = f"PayBill_{s_no}_{treasury}_{safe_vou}_{year}{month:02d}.xlsx"
        path_xls = os.path.join(folder, save_name_xls)
        path_xlsx = os.path.join(folder, save_name_xlsx)
        
        if (os.path.exists(path_xls) and validate_downloaded_file(path_xls)) or (os.path.exists(path_xlsx) and validate_downloaded_file(path_xlsx)):
            self.log("⏭ Paybill Excel already downloaded and is valid. Skipping download.")
            return

        # Check if Paybill/NPS tab exists
        tab_btn = self.get_locator_in_frames(bill_page, "a:has-text('Paybill'), a:has-text('NPS'), a:has-text('Pay Bill')")
        if tab_btn.count() == 0:
            return
            
        self.log("⏳ Paybill tab detected inside voucher details. Triggering Paybill download...")
        tab_btn.click(timeout=get_scaled_timeout(self, 25000))
        try: bill_page.wait_for_load_state("networkidle", timeout=get_scaled_timeout(self, 5000))
        except PlaywrightTimeoutError: pass

        # Locate and click 'Employee Wise Bill Details Report' inside the Paybill tab
        emp_report_btn = self.get_locator_in_frames(bill_page, "text='Employee Wise Bill Details Report'")
        if emp_report_btn.count() == 0:
            emp_report_btn = self.get_locator_in_frames(bill_page, "a[onclick*='retrievePayrollBillEmpDetails']")
            
        if emp_report_btn.count() == 0:
            self.log("⚠️ 'Employee Wise Bill Details Report' button not found inside Paybill tab.")
            return

        self.log("⏳ Opening Employee Details popup for Paybill...")
        with context.expect_page(timeout=get_scaled_timeout(self, 25000)) as p2_info:
            emp_report_btn.first.click(timeout=get_scaled_timeout(self, 25000))
        emp_page = p2_info.value
        emp_page.wait_for_load_state("load", timeout=get_scaled_timeout(self, 35000))
        try: emp_page.wait_for_load_state("networkidle", timeout=get_scaled_timeout(self, 10000))
        except PlaywrightTimeoutError: pass

        # Move to 2nd tab of the 2nd popup (Bill Detail)
        emp_tab2 = self.get_locator_in_frames(emp_page, "a:has-text('Bill Detail')")
        if emp_tab2.count() == 0:
            emp_tab2 = self.get_locator_in_frames(emp_page, "a[rel='tabContent1']")
        if emp_tab2.count() == 0:
            emp_tab2 = self.get_locator_in_frames(emp_page, "#tabmenu li a")
            if emp_tab2.count() >= 2:
                emp_tab2 = emp_tab2.nth(1)
        if emp_tab2.count() == 0:
            emp_tab2 = self.get_locator_in_frames(emp_page, "#tab2, a:has-text('Report')")
            
        if emp_tab2.count() > 0:
            emp_tab2.first.click(timeout=get_scaled_timeout(self, 25000))
            try: emp_page.wait_for_load_state("networkidle", timeout=get_scaled_timeout(self, 5000))
            except PlaywrightTimeoutError: pass

        # Excel download selectors
        excel_selectors = [
            "a[href*='ExportFormat=4']",
            "a[onclick*='takeAction'][href*='ExportReport']",
            "a:has-text('Excel')",
            "a[href*='excel' i]"
        ]

        excel_btn = None
        for selector in excel_selectors:
            loc = self.get_locator_in_frames(emp_page, selector)
            if loc.count() > 0 and loc.first.is_visible():
                excel_btn = loc.first
                break
            
        if excel_btn is None:
            for frame in emp_page.frames:
                for selector in excel_selectors:
                    try:
                        floc = frame.locator(selector)
                        if floc.count() > 0 and floc.first.is_visible():
                            excel_btn = floc.first
                            break
                    except Exception: pass
                if excel_btn: break

        if excel_btn is None:
            self.log("⚠️ Excel export button not found in Employee Details page.")
            emp_page.close()
            return

        self.log("📥 Exporting Pay Bill Excel...")
        with emp_page.expect_download(timeout=self.TIMEOUT_DOWNLOAD_ATTACHMENT) as dl_info:
            excel_btn.click(timeout=get_scaled_timeout(self, 25000))
        download = dl_info.value

        suggested = download.suggested_filename or "PayBill.xls"
        safe_vou  = self.clean_folder_name(str(vou))
        ext = os.path.splitext(suggested)[1]
        save_name = f"PayBill_{s_no}_{treasury}_{safe_vou}_{year}{month:02d}{ext}"
        save_path = os.path.join(folder, save_name)
        download.save_as(save_path)
        if not validate_downloaded_file(save_path):
            if os.path.exists(save_path):
                try: os.remove(save_path)
                except Exception: pass
            raise Exception("Downloaded Pay Bill Excel file failed integrity validation.")
            
        self.log(f"✅ Saved Pay Bill Excel: {save_name} ({os.path.getsize(save_path)/1024:.1f} KB)")
        emp_page.close()

        # Clean and keep cleaned xlsx file in the respective voucher folder
        try:
            base_name = save_name[:-5] if save_name.lower().endswith(".xlsx") else (save_name[:-4] if save_name.lower().endswith(".xls") else save_name)
            cleaned_name = base_name + "_Cleaned.xlsx" if not base_name.lower().endswith("_cleaned") else base_name + ".xlsx"
            cleaned_path = os.path.join(folder, cleaned_name)
            clean_and_save_flat_paybill(self, save_path, cleaned_path, year, month, vou, treasury, mh)
        except Exception as ex:
            self.log(f"⚠️ Failed to clean/export flat Pay Bill Excel: {ex}")

    except Exception as e:
        self.log(f"⚠️ Paybill download from voucher skipped: {e}")

def process_voucher_vch(self, page, context, row_data, failed_rows):
    if self.stop_requested: return
    if is_session_expired(page):
        raise SessionExpiredError("Session expired before starting voucher download")
    def _clean_val(val):
        s = str(val or "").strip()
        if s.startswith('="') and s.endswith('"'):
            s = s[2:-1].strip()
        elif s.startswith("='") and s.endswith("'"):
            s = s[2:-1].strip()
        elif s.startswith('='):
            s = s[1:].strip().strip('"').strip("'")
        return s.strip('"').strip("'").strip()

    s_no = _clean_val(row_data["s_no"])
    mh = _clean_val(row_data["mh"])
    treasury = _clean_val(row_data["treasury"])
    vou = _clean_val(row_data["voucher"])
    amount = _clean_val(row_data["amount"])
    folder_name = row_data.get("folder_name", "")

    month = 1
    year = 2026
    if "from_date" in row_data and "to_date" in row_data:
        from_date = row_data["from_date"]
        to_date = row_data["to_date"]
        try:
            parts = from_date.split("/")
            if len(parts) == 3:
                month = int(parts[1])
                year = int(parts[2])
            elif "month" in row_data and "year" in row_data:
                month = int(row_data["month"])
                year = int(row_data["year"])
        except Exception:
            if "month" in row_data and "year" in row_data:
                try:
                    month = int(row_data["month"])
                    year = int(row_data["year"])
                except Exception:
                    pass
    else:
        month = int(row_data["month"])
        year = int(row_data["year"])
        from_date = f"01/{month:02d}/{year}"
        to_date = f"{calendar.monthrange(year, month)[1]:02d}/{month:02d}/{year}"

    folder = self.resolve_download_path(row_data, "Voucher")
    success_marker = os.path.join(folder, "SUCCESS.marker")

    if "search_type" not in row_data and os.path.exists(success_marker):
        with self._counter_lock: self.skip_count += 1
        self.update_stats(current=vou)
        return

    # Dry Run Mode Handling
    if getattr(self, "dry_run", False) or (hasattr(self, "var_dryrun") and self.var_dryrun.get()) or getattr(self, "config_dict", {}).get("dry_run", False):
        self.log(f"🧪 [DRY RUN] Simulating download for Voucher: MH={mh} Try={treasury} Vou={vou}")
        os.makedirs(folder, exist_ok=True)
        with open(success_marker, "w", encoding="utf-8") as f:
            f.write(f"DRY RUN SUCCESS - Simulated at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        with self._counter_lock: self.success_count += 1
        self.update_stats(current=vou)
        time.sleep(0.05)
        return

    os.makedirs(folder, exist_ok=True)
    self.update_stats(current=vou)
    self.log(f"🔍 [{s_no}] Voucher: MH={mh} Try={treasury} Vou={vou}")

    # Strict tab hygiene: close leftover popup/secondary tabs from previous voucher before starting search
    try:
        if hasattr(context, "pages") and len(context.pages) > 1:
            for p in context.pages:
                if p != page:
                    try: p.close()
                    except Exception: pass
    except Exception: pass

    dialog_caught = {"message": None}
    def handle_dialog(dialog):
        dialog_caught["message"] = dialog.message
        dialog.accept()
    page.on("dialog", handle_dialog)

    try:
        try:
            resilient_goto(self, page, "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", base_timeout=60000)
        except Exception as goto_err:
            err_msg = str(goto_err).lower()
            if any(x in err_msg for x in ["redirect", "expired", "session", "auth", "login", "net::err_too_many_redirects"]):
                raise SessionExpiredError(f"IFMS connection/session redirect loop: {goto_err}")
            raise goto_err
        
        # Robust check for login redirection
        if is_session_expired(page):
            raise SessionExpiredError("IFMS Session expired - login screen detected.")

        # Wait for the treasury dropdown selector to be attached/visible
        try:
            wait_for_selector_with_retry(self, page, "#cmbTreasuryCodeName", state="visible", base_timeout=15000)
        except Exception:
            # Check if we were redirected to login page during wait
            if is_session_expired(page):
                raise SessionExpiredError("IFMS Session expired - login screen detected during wait.")
            # Save timeout debug screenshot
            try:
                page.screenshot(path=os.path.join(folder, f"debug_timeout_{vou}.png"))
                self.log(f"📸 Saved timeout debug screenshot for voucher {vou}.")
            except Exception: pass
            raise Exception("Search page elements failed to load.")

        if not self.select_dropdown(page, "cmbTreasuryCodeName", treasury):
            raise Exception("Treasury Code not found in dropdown.")

        self.safe_fill(page, "#txtFrmBillDate", from_date)
        self.safe_fill(page, "#txtToBillDate", to_date)
        self.safe_fill(page, "#txtMajorHead", mh)
        
        search_type = row_data.get("search_type", "voucher_number")
        if search_type == "voucher_number" or not search_type:
            self.safe_fill(page, "#txtSerialNo", vou)
        elif search_type == "bill_ref":
            self.safe_fill(page, "#txtBillRefNo", row_data.get("bill_ref", ""))
        elif search_type == "bill_control":
            self.safe_fill(page, "#txtBillCntrlNo", row_data.get("bill_control", ""))
        elif search_type == "amount":
            self.safe_fill(page, "#txtNetAmt", row_data.get("amount", ""))
            
        page.locator("#btnSearch").click()
        
        try: page.wait_for_load_state("networkidle", timeout=get_scaled_timeout(self, 10000))
        except: pass

        if dialog_caught["message"] and "no" in dialog_caught["message"].lower():
            raise Exception("No Results Found")

        # Fail fast if page content indicates no records found
        content = page.content().lower()
        if "no record found" in content or "no records found" in content:
            raise Exception("No Results Found")

        bill_link = page.locator("a[onclick*='showBillDtlByCtrlNo']").first
        
        # Wait up to 10 seconds for the bill link to be visible, or check if a dialog was caught
        try:
            resilient_wait_for(self, page, bill_link, state="visible", base_timeout=10000)
        except Exception as wait_err:
            if dialog_caught["message"] and any(x in dialog_caught["message"].lower() for x in ["no", "not found"]):
                raise Exception("No Results Found")
            # If no dialog but not visible, take a debug screenshot as requested!
            try:
                page.screenshot(path=os.path.join(folder, f"debug_fail_{vou}.png"))
                self.log(f"📸 Saved debug screenshot for voucher {vou} failure.")
            except Exception:
                pass
            raise Exception("Voucher Details Link not visible.")

        opened_new_tab = False
        try:
            self.log("⏳ Opening voucher details...")
            with context.expect_page(timeout=get_scaled_timeout(self, 15000)) as new_page_info:
                bill_link.click()
            bill_page = new_page_info.value
            bill_page.wait_for_load_state("load")
            opened_new_tab = True
        except PlaywrightTimeoutError:
            page.wait_for_load_state("networkidle")
            bill_page = page

        if folder not in self.downloaded_folders_this_run:
            self.downloaded_folders_this_run.append(folder)

        # Real-time Portal Tally Scraping: Tab 1 (Bill Details)
        portal_scraped_amt = 0.0
        try:
            from tally_scraper import TallyScraper
            _ts = TallyScraper(logger=self.log)

            # 1. Scrape Tab 1 (Bill Details / Abstract)
            _t1_data = _ts.scrape_bill_details(bill_page)
            net_amt = float(_t1_data.get("net_amount", 0.0) if _t1_data else 0.0)
            exp_amt = float(_t1_data.get("expenditure_amount", 0.0) if _t1_data else 0.0)
            gross_amt = float(_t1_data.get("gross_amount", 0.0) if _t1_data else 0.0)
            port_tot = float(_t1_data.get("portal_total", 0.0) if _t1_data else 0.0)

            input_amt = 0.0
            try: input_amt = float(str(amount).replace(",", "").strip())
            except Exception: pass

            # Multi-candidate match check across net, expenditure, portal total, and gross amount
            matched_candidate = None
            for cand in (net_amt, exp_amt, port_tot, gross_amt):
                if cand > 0 and abs(input_amt - cand) <= 0.01:
                    matched_candidate = cand
                    break

            if matched_candidate is not None:
                portal_scraped_amt = input_amt
            else:
                portal_scraped_amt = net_amt or exp_amt or port_tot or gross_amt

            # 2. Print & Save Tab 1 PDF in Landscape mode with CSS isolation (if mismatch detected or if save_all enabled)
            try:
                save_all_tally = getattr(self, "var_tally_pdf_all", False) or getattr(self, "config_dict", {}).get("tally_pdf_all", False)
                is_mismatch = (portal_scraped_amt > 0 and abs(input_amt - portal_scraped_amt) > 0.01)

                if save_all_tally or is_mismatch:
                    t1_pdf_path = os.path.join(folder, "Tally_Tab1_BillDetails.pdf")
                    if not os.path.exists(t1_pdf_path) or os.path.getsize(t1_pdf_path) == 0:
                        _inject_tab_style(bill_page, show_id="tcontent0", hide_id="tcontent1")
                        time.sleep(0.3)
                        if save_landscape_pdf(bill_page, t1_pdf_path):
                            self.log(f"⚠️ [Tally Mismatch Proof] Tab 1 (Bill Details) PDF Saved ({os.path.getsize(t1_pdf_path)/1024:.1f} KB).")
            except Exception as _pdf1_err:
                pass
        except Exception as _tally_err:
            try: self.log(f"⚠️ Realtime tally scraping notice: {_tally_err}")
            except Exception: pass

        # MPTC PDF
        if not (hasattr(self, "var_paybill_only") and self.var_paybill_only.get()):
            try:
                mptc_path = os.path.join(folder, "Show_MPTC.pdf")
                if os.path.exists(mptc_path) and validate_downloaded_file(mptc_path):
                    self.log("⏭ Show_MPTC.pdf already exists and is valid. Skipping download.")
                else:
                    mptc_btn = self.get_locator_in_frames(bill_page, "text='Show MPTC'")
                    with context.expect_page(timeout=get_scaled_timeout(self, 35000)) as mptc_page_info:
                        mptc_btn.click(timeout=get_scaled_timeout(self, 30000))
                    mptc_page = mptc_page_info.value
                    mptc_page.wait_for_load_state("networkidle")
                    
                    # 🛡️ Safety Feature: Wait for Print MPTC button / report element to be visible on MPTC page before printing to PDF
                    try:
                        print_selectors = [
                            "input[value*='Print' i]", "input[value*='PRINT']", "button:has-text('Print')",
                            "input[type='button']", "[onclick*='print' i]", "td:has-text('MPTC')", "table"
                        ]
                        print_visible = False
                        for p_sel in print_selectors:
                            try:
                                loc = mptc_page.locator(p_sel)
                                if loc.count() > 0:
                                    loc.first.wait_for(state="visible", timeout=get_scaled_timeout(self, 8000))
                                    print_visible = True
                                    break
                            except Exception:
                                pass
                        if not print_visible:
                            try: mptc_page.wait_for_selector("text=/Print|MPTC|Treasury|Voucher/i", timeout=get_scaled_timeout(self, 10000))
                            except Exception: pass
                    except Exception as print_wait_err:
                        self.log(f"⚠️ MPTC Print button wait notice: {print_wait_err}")

                    # Buffer 400ms to guarantee complete visual font & table layout rendering
                    time.sleep(0.4)

                    client = mptc_page.context.new_cdp_session(mptc_page)
                    pdf_data = client.send("Page.printToPDF", {"printBackground": True})
                    with open(mptc_path, "wb") as f:
                        f.write(base64.b64decode(pdf_data['data']))
                    mptc_page.close()
                    
                    # 🛡️ Safety Feature: Validate downloaded MPTC PDF is not blank (file size > 4KB and contains extracted text)
                    if not (validate_downloaded_file(mptc_path) and validate_mptc_pdf(mptc_path)):
                        if os.path.exists(mptc_path):
                            try: os.remove(mptc_path)
                            except: pass
                        raise Exception("Show_MPTC.pdf failed blank/integrity validation check.")
                    self.log("✅ MPTC PDF Saved.")
                    compress_pdf_file(mptc_path)
            except Exception as e:
                if "integrity check" in str(e):
                    raise e
                if is_browser_connection_dead(e):
                    raise BrowserConnectionDeadError(str(e)) from e
                if "CDP session is only available" in str(e) or "cdp" in str(e).lower():
                    self.log("⚠️ MPTC PDF skipped: MPTC PDF download requires Google Chrome / Chromium. Please select Google Chrome in Settings.")
                else:
                    self.log(f"⚠️ MPTC skipped: {str(e)[:60]}")
        else:
            self.log("⏭ Show_MPTC.pdf skipped (Paybill XLS Only mode).")

        if self.stop_requested: return

        # Party Details
        if not (hasattr(self, "var_paybill_only") and self.var_paybill_only.get()):
            try:
                has_valid_party = False
                try:
                    for f in os.listdir(folder):
                        if "party" in f.lower() and f.lower().endswith(".pdf"):
                            if validate_downloaded_file(os.path.join(folder, f)):
                                has_valid_party = True
                                break
                except Exception:
                    pass
                    
                if has_valid_party:
                    self.log("⏭ Party Details PDF already exists and is valid. Skipping download.")
                else:
                    party_btn = self.get_locator_in_frames(bill_page, "text='Download Party Details PDF'")
                    with bill_page.expect_download(timeout=self.TIMEOUT_DOWNLOAD_PDF) as download_info: party_btn.click()
                    download = download_info.value
                    party_path = os.path.join(folder, download.suggested_filename)
                    download.save_as(party_path)
                    if not validate_downloaded_file(party_path):
                        if os.path.exists(party_path):
                            try: os.remove(party_path)
                            except: pass
                        raise Exception("Party Details PDF failed integrity check.")
                    self.log("✅ Party Details Saved.")
                    compress_pdf_file(party_path)
            except PlaywrightTimeoutError: self.log("⚠️ Party Details PDF timed out.")
            except Exception as e:
                if "integrity check" in str(e):
                    raise e
                if is_browser_connection_dead(e):
                    raise BrowserConnectionDeadError(str(e)) from e
                self.log(f"⚠️ Party Details skipped: {str(e)[:60]}")
        else:
            self.log("⏭ Party Details PDF skipped (Paybill XLS Only mode).")

        if self.stop_requested: return

        # Attachments Tab
        if not (hasattr(self, "var_paybill_only") and self.var_paybill_only.get()):
            try:
                # Robust switch & delay to guarantee Tab 2 DOM content is active
                tab2_clicked = False
                try:
                    tab2_btn = self.get_locator_in_frames(bill_page, "#tab2")
                    tab2_btn.click(timeout=get_scaled_timeout(self, 15000))
                    tab2_clicked = True
                except Exception:
                    try:
                        t2_elem = bill_page.locator("#tab2, a[href*='tab2'], td[id*='tab2'], .tab2, a:has-text('FVC Bill'), a:has-text('Sub Voucher'), a:has-text('Attachment Details')").first
                        if t2_elem.count() > 0:
                            t2_elem.evaluate("el => { el.dispatchEvent(new Event('click', {bubbles:true})); if (typeof el.click === 'function') el.click(); }")
                            tab2_clicked = True
                    except Exception: pass

                if not tab2_clicked:
                    try:
                        bill_page.evaluate("""() => {
                            if (typeof showFVCDtl === 'function') showFVCDtl('tab2');
                            else if (typeof switchTab === 'function') switchTab(2);
                            else if (typeof showTab === 'function') showTab(2);
                        }""")
                    except Exception: pass

                time.sleep(0.5)
                try: bill_page.wait_for_load_state("domcontentloaded", timeout=5000)
                except PlaywrightTimeoutError: pass 

                # Real-time Portal Tally Scraping: Tab 2 (FVC Bill / Sub-Voucher / Schedule Details)
                try:
                    from tally_scraper import TallyScraper
                    _ts = TallyScraper(logger=self.log)
                    _t2_data = _ts.scrape_fvc_bill(bill_page)
                    if _t2_data and _t2_data.get("portal_total", 0.0) > 0:
                        portal_scraped_amt = float(_t2_data.get("portal_total", 0.0))

                    # 4. Print & Save Tab 2 PDF in Landscape mode with CSS isolation (if mismatch detected or if save_all enabled)
                    input_amt = 0.0
                    try: input_amt = float(str(amount).replace(",", "").strip())
                    except Exception: pass

                    save_all_tally = getattr(self, "var_tally_pdf_all", False) or getattr(self, "config_dict", {}).get("tally_pdf_all", False)
                    is_mismatch = (portal_scraped_amt > 0 and abs(input_amt - portal_scraped_amt) > 0.01)

                    if save_all_tally or is_mismatch:
                        t2_pdf_path = os.path.join(folder, "Tally_Tab2_SubVouchers.pdf")
                        if not os.path.exists(t2_pdf_path) or os.path.getsize(t2_pdf_path) == 0:
                            _inject_tab_style(bill_page, show_id="tcontent1", hide_id="tcontent0")
                            time.sleep(0.3)
                            if save_landscape_pdf(bill_page, t2_pdf_path):
                                self.log(f"⚠️ [Tally Mismatch Proof] Tab 2 (Sub-Vouchers) PDF Saved ({os.path.getsize(t2_pdf_path)/1024:.1f} KB).")
                            # Remove injected style
                            try: bill_page.evaluate("() => { const s = document.getElementById('__agy_print_override__'); if (s) s.remove(); }")
                            except Exception: pass
                except Exception as _pdf2_err:
                    pass 

                target_frame = bill_page
                for frame in bill_page.frames:
                    if frame.locator("a[onclick*='openDocumentOnClick']").count() > 0:
                        target_frame = frame
                        break

                links = target_frame.locator("a[onclick*='openDocumentOnClick']").all()
                if links:
                    for idx, link in enumerate(links):
                        if self.stop_requested: break
                        try:
                            # Fuzzy match in folder to avoid redundant downloads
                            link_text = (link.text_content() or "").strip()
                            clean_text = "".join(c for c in link_text if c.isalnum() or c in "._- ")
                            found_valid = False
                            clean_lower = clean_text.lower().replace(" ", "").replace("_", "").replace("-", "")
                            
                            if clean_lower:
                                try:
                                    for existing_file in os.listdir(folder):
                                        existing_lower = existing_file.lower().replace(" ", "").replace("_", "").replace("-", "")
                                        if clean_lower in existing_lower or existing_lower in clean_lower:
                                            test_path = os.path.join(folder, existing_file)
                                            if validate_downloaded_file(test_path):
                                                self.log(f"⏭ Attachment {idx + 1} ({existing_file}) matches existing valid file. Skipping download.")
                                                found_valid = True
                                                break
                                except Exception:
                                    pass
                                    
                            if found_valid:
                                continue

                            with bill_page.expect_download(timeout=self.TIMEOUT_DOWNLOAD_ATTACHMENT) as download_info:
                                link.scroll_into_view_if_needed()
                                link.click(timeout=get_scaled_timeout(self, 25000))
                            download = download_info.value
                            attach_path = os.path.join(folder, download.suggested_filename)
                            download.save_as(attach_path)
                            if not validate_downloaded_file(attach_path):
                                if os.path.exists(attach_path):
                                    try: os.remove(attach_path)
                                    except: pass
                                raise Exception("Attachment PDF failed integrity check.")
                            self.log(f"✅ Attachment {idx + 1} Saved.")
                            if attach_path.lower().endswith(".pdf"):
                                compress_pdf_file(attach_path)
                        except Exception as e:
                            if "integrity check" in str(e):
                                raise e
                            if is_browser_connection_dead(e):
                                raise BrowserConnectionDeadError(str(e)) from e
                            self.log(f"⚠️ Attachment {idx + 1} skipped: {str(e)[:60]}")
            except Exception as e:
                if is_browser_connection_dead(e):
                    raise BrowserConnectionDeadError(str(e)) from e
                self.log(f"⚠️ Attachments tab error: {str(e)[:60]}")
        else:
            self.log("⏭ PDF Attachments skipped (Paybill XLS Only mode).")

        # Paybill Excel Download (if this voucher is a Paybill)
        if self.var_voucher_download_paybills.get() or (hasattr(self, "var_paybill_only") and self.var_paybill_only.get()):
            _download_paybill_for_voucher(self, context, bill_page, folder, s_no, treasury, vou, year, month, mh)
        else:
            self.log("⏭ Paybill download disabled by user settings for Voucher.")

        if opened_new_tab: bill_page.close()

        # F1: Post-download integrity check (D1)
        from core.download_integrity import validate_folder_completeness
        is_complete, missing = validate_folder_completeness(folder)
        if not is_complete:
            self.log(f"⚠️ [Worker] Incomplete download for voucher {vou}: {', '.join(missing)}")
            failed_rows.append(row_data)
            return

        with open(success_marker, "w") as f: f.write("DONE")
        with self._counter_lock: self.success_count += 1

        # --- Centralized Voucher Validation Suite: Realtime Checks Hook ---
        try:
            if hasattr(self, "trigger_realtime_checks"):
                _v_meta = {
                    'voucher_no': vou, 'treasury': treasury, 'mh': mh,
                    'month': month, 'year': year, 'amount': amount,
                    'ddo': ddo_code if 'ddo_code' in dir() else '',
                    'folder_path': folder,
                    'scraped_amount': portal_scraped_amt if 'portal_scraped_amt' in locals() else 0.0,
                    'total_deductions': _t1_data.get('total_deductions', 0.0) if '_t1_data' in locals() and _t1_data else 0.0,
                    'net_amount': _t1_data.get('net_amount', 0.0) if '_t1_data' in locals() and _t1_data else 0.0,
                    'gross_amount': _t1_data.get('gross_amount', 0.0) if '_t1_data' in locals() and _t1_data else 0.0,
                    'expenditure_amount': _t1_data.get('expenditure_amount', 0.0) if '_t1_data' in locals() and _t1_data else 0.0,
                }
                self.trigger_realtime_checks(_v_meta, folder)
        except Exception as _check_err:
            try: self.log(f"⚠️ Realtime check notice: {_check_err}")
            except Exception: pass

        # --- v3.1: Duplicate Payment Detection — Catalog & Real-time Check ---
        try:
            from automation.duplicate_detector import catalog_voucher_attachments, check_realtime_duplicates
            _dup_meta = {
                'treasury': treasury, 'mh': mh, 'month': month, 'year': year,
                'voucher_no': vou, 'amount': amount, 'ddo': ddo_code if 'ddo_code' in dir() else '',
                'folder_path': folder
            }
            _dup_db = getattr(self, 'db_path', None)
            _dup_attachments = catalog_voucher_attachments(folder, _dup_meta, db_path=_dup_db)
            if _dup_attachments and _dup_db:
                _dup_matches = check_realtime_duplicates(_dup_meta, _dup_attachments, _dup_db)
                for _dm in _dup_matches:
                    v_b_no = str(_dm.voucher_b.get('voucher_no','')) if str(_dm.voucher_a.get('voucher_no','')) == str(vou) else str(_dm.voucher_a.get('voucher_no',''))
                    v_b_trs = str(_dm.voucher_b.get('treasury','')) if str(_dm.voucher_a.get('voucher_no','')) == str(vou) else str(_dm.voucher_a.get('treasury',''))
                    try:
                        f_amt = float(amount)
                        amt_str = f"₹{f_amt:,.2f}"
                    except Exception:
                        amt_str = f"₹{amount}"

                    self.log(f"⚠️🔴 DUPLICATE PAYMENT ALERT: Voucher {vou} shares {_dm.match_count} attachment(s) "
                             f"with Voucher {v_b_no} ({amt_str}) — Confidence: {_dm.confidence}")

                    dup_finding = {
                        "voucher_no": str(vou).lstrip('="').rstrip('"').strip(),
                        "treasury": str(treasury).lstrip('="').rstrip('"').strip(),
                        "mh": str(mh).lstrip('="').rstrip('"').strip(),
                        "month": str(month),
                        "year": str(year),
                        "amount": amt_str,
                        "check_name": "Duplicate Payment & Double Claim Check",
                        "status": "SUSPICIOUS",
                        "message": f"🚨 DOUBLE PAYMENT ALERT! Shares {_dm.match_count} identical attachment MD5 hash(es) with Voucher #{v_b_no} (Treasury: {v_b_trs}, Amount: {amt_str}) — Confidence: {_dm.confidence}"
                    }

                    # Put finding in result queue for live UI table & reports
                    if hasattr(self, "result_queue") and self.result_queue:
                        self.result_queue.put(("task_audit_finding", dup_finding))

                    # Save finding into SQLite cache
                    if _dup_db:
                        try:
                            from database.db_manager import save_audit_results_batch
                            save_audit_results_batch(_dup_db, [dup_finding])
                        except Exception:
                            pass
        except Exception as _dup_err:
            try: self.log(f"⚠️ Duplicate detection skipped: {str(_dup_err)[:60]}")
            except Exception: pass

        with open(self.voucher_master_report, "a", encoding="utf-8") as report:
            report.write(f"\n[S.NO: {s_no}] Voucher: {vou} | Folder: {folder_name} | Completed: {time.strftime('%H:%M:%S')}\n")

    except SessionExpiredError:
        page.remove_listener("dialog", handle_dialog)
        raise 
    except Exception as e:
        page.remove_listener("dialog", handle_dialog)
        if is_browser_connection_dead(e):
            raise BrowserConnectionDeadError(str(e)) from e
        with self._counter_lock: self.fail_count += 1
        failed_rows.append(row_data)
        self.log(f"❌ FAILED: {vou} - {str(e)[:100]}")
        try:
            screenshot_name = f"fail_{vou}_{int(time.time())}.png"
            page.screenshot(path=os.path.join(folder, screenshot_name))
            self.log(f"📸 Saved failure screenshot to {screenshot_name}")
        except Exception:
            pass
        try:
            with open(self.voucher_failed_file, "a", encoding="utf-8") as failed_file:
                failed_file.write(f"{s_no}|{mh}|{treasury}|{vou}|{amount}|{month}|{year}\n")
        except Exception: pass
    finally:
        page.remove_listener("dialog", handle_dialog)
        try:
            for p in context.pages:
                if p != page: p.close()
        except Exception: pass

def extract_row_amount(r):
    if not isinstance(r, dict): return 0.0
    for k in ('amount', 'Amount_Paid', 'Amount Paid', 'Amount', 'amount_paid', 'paid_amount', 'Paid Amount', 'Paid_Amount', 'sop_vch_amt', 'gross', 'net', 'claim'):
        if k in r and r[k] is not None and str(r[k]).strip() not in ('', '0', '0.0', '0.00'):
            try:
                val = float(clean_amount_string(r[k]))
                if val > 0: return val
            except Exception: pass
    for k, v in r.items():
        if any(term in str(k).lower() for term in ('amount', 'paid', 'amt', 'claim')) and v is not None:
            try:
                val = float(clean_amount_string(v))
                if val > 0: return val
            except Exception: pass
    return 0.0

def process_voucher_tally(self, page, context, row_data, failed_rows):
    if self.stop_requested: return
    if is_session_expired(page):
        raise SessionExpiredError("Session expired before starting voucher tally")

    s_no = row_data.get("s_no", "")
    mh = str(row_data.get("mh", "")).strip()
    treasury = str(row_data.get("treasury", "")).strip()
    vou = str(row_data.get("voucher", "")).strip()
    
    excel_amt = extract_row_amount(row_data)

    month = 1
    year = 2026
    if "from_date" in row_data and "to_date" in row_data:
        from_date = str(row_data["from_date"]).strip()
        to_date = str(row_data["to_date"]).strip()
    elif "month" in row_data and "year" in row_data:
        try:
            month = int(row_data["month"])
            year = int(row_data["year"])
        except Exception: pass
        from_date = f"01/{month:02d}/{year}"
        to_date = f"{calendar.monthrange(year, month)[1]:02d}/{month:02d}/{year}"
    else:
        from_date = f"01/01/{year}"
        to_date = f"31/01/{year}"

    self.update_stats(current=vou)
    self.log(f"🔍 [{s_no}] Voucher Tally: MH={mh} Try={treasury} Vou={vou} | Excel Amt=₹{excel_amt:,.2f}")

    dialog_caught = {"message": None}
    def handle_dialog(dialog):
        dialog_caught["message"] = dialog.message
        dialog.accept()
    page.on("dialog", handle_dialog)

    try:
        resilient_goto(self, page, "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", base_timeout=30000)

        if is_session_expired(page):
            raise SessionExpiredError("Session expired during navigation")

        if treasury:
            self.select_dropdown(page, "cmbTreasuryCodeName", treasury)



        page.fill("#txtFrmBillDate", from_date)
        page.fill("#txtToBillDate", to_date)
        if mh: page.fill("#txtMajorHead", mh)
        if vou: page.fill("#txtSerialNo", vou)

        page.click("#btnSearch")
        try: page.wait_for_load_state("networkidle", timeout=5000)
        except: pass

        if dialog_caught["message"] and "no" in dialog_caught["message"].lower():
            self.log(f"⚠️ Voucher {vou} not found on portal.")
            failed_rows.append(row_data)
            return

        content = page.content().lower()
        if "no record found" in content or "no records found" in content:
            self.log(f"⚠️ Voucher {vou} not found on portal.")
            failed_rows.append(row_data)
            return

        bill_link = page.locator("a[onclick*='showBillDtlByCtrlNo']").first
        if bill_link.count() == 0:
            self.log(f"⚠️ Voucher {vou} details link not found.")
            failed_rows.append(row_data)
            return

        # Multi-attempt popup retry loop (up to 3 attempts with 25s timeout each to handle portal lag)
        bill_page = None
        opened_new_tab = False
        for popup_attempt in range(1, 4):
            try:
                # Close any stale extra pages before opening popup
                for p in list(context.pages):
                    if p != page and not p.is_closed():
                        try: p.close(run_before_unload=False)
                        except Exception: pass

                with context.expect_page(timeout=25000) as new_page_info:
                    if popup_attempt == 1:
                        bill_link.click(force=True)
                    else:
                        bill_link.evaluate("el => { el.dispatchEvent(new Event('click', {bubbles:true})); if (typeof el.click === 'function') el.click(); }")
                
                bill_page = new_page_info.value
                opened_new_tab = True
                try: bill_page.wait_for_load_state("domcontentloaded", timeout=12000)
                except Exception: pass
                break
            except Exception as ex_open:
                self.log(f"⚠️ Popup open attempt {popup_attempt}/3 timed out/failed due to IFMIS portal slowdown ({ex_open}). Retrying...")
                time.sleep(1.5)

        if not bill_page or bill_page == page:
            self.log(f"❌ Voucher {vou}: Details popup window failed to open after 3 attempts due to IFMIS portal slowdown. Marked for Retry.")
            failed_rows.append(row_data)
            return

        # Ensure portal bill detail elements are fully rendered before scraping
        try:
            bill_page.wait_for_selector("#txtGrossTotal, #txtBillExpAmt, #lblGrossTotal, table#tblbillDetailHeadExp, input[name='txtExpAmount']", timeout=12000)
        except Exception: pass


        details_data = {}
        fvc_data = {}
        try:
            from tally_scraper import TallyScraper
            scraper = TallyScraper(logger=self.log)

            target_dir = self.resolve_download_path(row_data, "Tally")
            os.makedirs(target_dir, exist_ok=True)

            # 1. Expand viewport & inject print scaling CSS
            try:
                bill_page.set_viewport_size({"width": 1920, "height": 1080})
            except Exception: pass

            try:
                bill_page.evaluate("""() => {
                    document.querySelectorAll('*').forEach(el => {
                        const style = window.getComputedStyle(el);
                        if (style.overflow === 'hidden' || style.overflowX === 'hidden') {
                            el.style.overflow = 'visible';
                            el.style.overflowX = 'visible';
                        }
                    });
                    document.body.style.width = '100%';
                    document.body.style.overflow = 'visible';
                }""")
            except Exception: pass

            try:
                bill_page.add_style_tag(content="""
                    @page { size: landscape; margin: 5mm; }
                    @media print {
                        html, body { width: 100% !important; overflow: visible !important; zoom: 80% !important; }
                        table { width: 100% !important; max-width: 100% !important; font-size: 9px !important; }
                    }
                """)
            except Exception: pass

            # 2. Scrape Tab 1 (Bill Details / Expenditure & Deductions)
            details_data = scraper.scrape_bill_details(bill_page)

            # ── PDF 1: Show ONLY Tab 1 (tcontent0), hide Tab 2 (tcontent1) ──────
            def _inject_tab_style(page, show_id: str, hide_id: str):
                """Inject CSS overrides that force one tab content visible and the other hidden,
                both in the live DOM and via @media print rules, covering all possible style properties."""
                page.evaluate(f"""() => {{
                    const old = document.getElementById('__agy_print_override__');
                    if (old) old.remove();

                    // Live-DOM forced visibility
                    const show = document.getElementById('{show_id}');
                    const hide = document.getElementById('{hide_id}');
                    if (show) {{
                        show.style.cssText += '; display:block !important; visibility:visible !important; height:auto !important; overflow:visible !important; position:relative !important; opacity:1 !important;';
                    }}
                    if (hide) {{
                        hide.style.cssText += '; display:none !important; visibility:hidden !important; height:0 !important; overflow:hidden !important; position:absolute !important; opacity:0 !important;';
                    }}

                    // @media print rules (Playwright PDF respects these)
                    const s = document.createElement('style');
                    s.id = '__agy_print_override__';
                    s.textContent = `
                        #{hide_id} {{ display:none !important; visibility:hidden !important; height:0 !important; overflow:hidden !important; }}
                        #{show_id} {{ display:block !important; visibility:visible !important; height:auto !important; overflow:visible !important; }}
                        @media print {{
                            #{hide_id} {{ display:none !important; visibility:hidden !important; height:0 !important; overflow:hidden !important; }}
                            #{show_id} {{ display:block !important; visibility:visible !important; height:auto !important; overflow:visible !important; }}
                        }}`;
                    document.head.appendChild(s);
                }}""")

            try:
                _inject_tab_style(bill_page, show_id="tcontent0", hide_id="tcontent1")
                time.sleep(0.4)
                pdf1_path = os.path.join(target_dir, f"Portal_Bill_Details_Tab1_{vou}.pdf")
                bill_page.pdf(
                    path=pdf1_path,
                    format="A4",
                    landscape=True,
                    scale=0.80,
                    print_background=True,
                    margin={"top": "5mm", "bottom": "5mm", "left": "5mm", "right": "5mm"}
                )
                self.log(f"📄 Saved Tab 1 PDF: {os.path.basename(pdf1_path)}")
            except Exception as ex1:
                self.log(f"⚠️ Warning saving Tab 1 PDF: {ex1}")

            # 4. Switch to Tab 2 & Scrape Tab 2
            fvc_data = scraper.scrape_fvc_bill(bill_page)

            # ── PDF 2: Show ONLY Tab 2 (tcontent1), hide Tab 1 (tcontent0) ──────
            try:
                _inject_tab_style(bill_page, show_id="tcontent1", hide_id="tcontent0")
                time.sleep(0.4)
                pdf2_path = os.path.join(target_dir, f"Portal_Bill_Details_Tab2_{vou}.pdf")
                bill_page.pdf(
                    path=pdf2_path,
                    format="A4",
                    landscape=True,
                    scale=0.80,
                    print_background=True,
                    margin={"top": "5mm", "bottom": "5mm", "left": "5mm", "right": "5mm"}
                )
                self.log(f"📄 Saved Tab 2 PDF: {os.path.basename(pdf2_path)}")
            except Exception as ex2:
                self.log(f"⚠️ Warning saving Tab 2 PDF: {ex2}")

            # Clean up injected style
            try:
                bill_page.evaluate("() => { const s = document.getElementById('__agy_print_override__'); if (s) s.remove(); }")
            except Exception: pass








            # Save SUCCESS.marker to preserve skip status across application restarts
            marker_path = os.path.join(target_dir, "SUCCESS.marker")
            with open(marker_path, "w", encoding="utf-8") as mf:
                mf.write(f"TALLY_VERIFIED|VOUCHER={vou}|EXCEL_AMT={excel_amt}|DATE={time.strftime('%Y-%m-%d %H:%M:%S')}\n")

            # Register download to SQLite history database
            try:
                from database.db_manager import save_download_record
                db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
                save_download_record(
                    db_path=db_path,
                    mode="tally",
                    treasury=treasury,
                    major_head=mh,
                    month=str(month),
                    year=str(year),
                    voucher_no=vou,
                    amount=excel_amt,
                    ddo_code=row_data.get('ddo', ''),
                    file_path=target_dir
                )
            except Exception: pass

        except Exception as artifact_ex:
            self.log(f"⚠️ Warning saving voucher page artifacts: {artifact_ex}")
        finally:
            # Always close any popup tabs in context so no popup window is left open on screen
            for p in list(context.pages):
                if p != page and not p.is_closed():
                    try:
                        p.close(run_before_unload=False)
                    except Exception:
                        pass


        scraped = {**details_data, **fvc_data}



        deviation_enabled = getattr(self, "var_tally_deviation", None) and self.var_tally_deviation.get()

        portal_total = scraped.get("portal_total", 0.0)
        # Fallback to Bill Details total if FVC tab total is 0.0 (non-FVC or un-bifurcated bills)
        if portal_total == 0.0:
            portal_total = scraped.get("gross_amount", 0.0) or scraped.get("expenditure_amount", 0.0) or scraped.get("net_amount", 0.0)

        # Safety Guard: If portal_total is 0.0 for a non-zero Excel voucher because the page failed to load fields
        if portal_total == 0.0 and excel_amt > 0:
            has_scraped_fields = bool(scraped.get("expenditure_heads") or scraped.get("deductions") or scraped.get("entries"))
            if not has_scraped_fields:
                self.log(f"❌ Voucher {vou}: IFMIS portal page failed to load bill form fields (portal lag/network slowdown). Marked for Retry.")
                failed_rows.append(row_data)
                return


        tot_deductions = scraped.get("total_deductions", 0.0)
        net_amount = portal_total - tot_deductions
        if scraped.get("net_amount", 0.0) > 0:
            net_amount = scraped.get("net_amount", 0.0)

        gross_dev = abs(excel_amt - portal_total)
        gross_dev_pct = (gross_dev / portal_total * 100.0) if portal_total > 0 else (100.0 if excel_amt != 0 else 0.0)
        net_dev = abs(excel_amt - net_amount)
        net_dev_pct = (net_dev / net_amount * 100.0) if net_amount > 0 else (100.0 if excel_amt != 0 else 0.0)

        # Check if difference between Excel amount and Portal Gross equals Receipts/Deductions
        ded_diff = abs(gross_dev - tot_deductions)
        is_deduction_matched = (tot_deductions > 0) and (abs(net_dev) < 0.01 or ded_diff < 0.01)

        if abs(gross_dev) < 0.01:
            gross_flag = "GREEN"
            effective_dev = 0.0
            effective_dev_pct = 0.0
            remarks = "Exact Gross Match"
        elif is_deduction_matched:
            gross_flag = "GREEN"
            effective_dev = 0.0
            effective_dev_pct = 0.0
            remarks = f"Matched Net Paid Amount (Deductions: ₹{tot_deductions:,.2f})"
        elif (abs(gross_dev) <= (portal_total * 0.02) or abs(net_dev) <= (net_amount * 0.02)):
            gross_flag = "GREEN"
            effective_dev = min(gross_dev, net_dev)
            effective_dev_pct = min(gross_dev_pct, net_dev_pct)
            remarks = f"Matched within 2% tolerance (Dev: ₹{effective_dev:,.2f})"

        else:
            gross_flag = "RED"
            effective_dev = min(gross_dev, net_dev)
            effective_dev_pct = min(gross_dev_pct, net_dev_pct)
            if tot_deductions > 0:
                remarks = f"Mismatch: Dev=₹{gross_dev:,.2f} (Receipts/Deductions: ₹{tot_deductions:,.2f})"
            else:
                remarks = f"Gross Mismatch (Dev: ₹{gross_dev:,.2f})"

        tally_result = {
            "excel_amount": excel_amt,
            "portal_total": portal_total,
            "gross_dev": effective_dev,
            "gross_dev_pct": effective_dev_pct,
            "raw_gross_dev": gross_dev,
            "net_dev": net_dev,
            "net_dev_pct": net_dev_pct,
            "gross_flag": gross_flag,
            "overall_flag": gross_flag,
            "remarks": remarks,
            "scraped_data": scraped
        }


        if hasattr(self, "tally_writer") and self.tally_writer:
            self.tally_writer.add_result(row_data=row_data, scraped_data=scraped, tally_result=tally_result)

        with self._counter_lock: self.success_count += 1

        if gross_flag == "GREEN":
            self.log(f"  ✅ MATCHED: Excel=₹{excel_amt:,.2f} | IFMIS Amt=₹{portal_total:,.2f} | Dev=0.00%", "success")
        else:
            self.log(f"  ❌ MISMATCH: Excel=₹{excel_amt:,.2f} | IFMIS Amt=₹{portal_total:,.2f} | Dev=₹{gross_dev:,.2f} ({gross_dev_pct:.2f}%)", "warning")


    except SessionExpiredError:
        page.remove_listener("dialog", handle_dialog)
        raise
    except Exception as e:
        page.remove_listener("dialog", handle_dialog)
        if is_browser_connection_dead(e):
            raise BrowserConnectionDeadError(str(e)) from e
        self.log(f"⚠️ Error processing tally for voucher {vou}: {str(e)[:80]}")
        failed_rows.append(row_data)

def _get_paybill_folder(self, treasury, mh, year, month, s_no, vou):
    tr_code = str(treasury).strip()
    short_name = tr_code
    if hasattr(self, "TREASURY_MAP"):
        for k, v in self.TREASURY_MAP.items():
            if v == tr_code:
                short_name = k
                break
    treasury_clean = self.clean_folder_name(short_name)
    month_label    = f"{year}-{month:02d}"
    folder = os.path.join(self.download_dir, "PAYBILL", treasury_clean, mh, month_label)
    return folder

def process_voucher_pb(self, page, context, row_data, failed_rows):
    if self.stop_requested: return
    if is_session_expired(page):
        raise SessionExpiredError("Session expired before starting voucher download")
    s_no    = row_data["s_no"]
    mh      = row_data["mh"]
    treasury= row_data["treasury"]
    vou     = row_data["voucher"]
    amount  = row_data["amount"]
    month   = int(row_data["month"])
    year    = int(row_data["year"])

    from_date = f"01/{month:02d}/{year}"
    to_date   = f"{calendar.monthrange(year, month)[1]:02d}/{month:02d}/{year}"

    folder         = self.resolve_download_path(row_data, "Paybill")
    success_marker = os.path.join(folder, "SUCCESS.marker")

    if os.path.exists(success_marker):
        with self._counter_lock: self.skip_count += 1
        self.update_stats(current=vou)
        self.log(f"⏭ [{s_no}] Already downloaded - skipping {vou}")
        return

    os.makedirs(folder, exist_ok=True)
    self.update_stats(current=vou)
    self.log(f"🔍 [{s_no}] Paybill: MH={mh} Try={treasury} Vou={vou}")

    dialog_caught = {"message": None}
    def handle_dialog(dialog):
        dialog_caught["message"] = dialog.message
        dialog.accept()
    page.on("dialog", handle_dialog)

    paybill_page = None
    bill_page = None
    emp_page = None
    try:
        try:
            resilient_goto(self, page, "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", base_timeout=60000)
        except Exception as goto_err:
            err_msg = str(goto_err).lower()
            if any(x in err_msg for x in ["redirect", "expired", "session", "auth", "login", "net::err_too_many_redirects"]):
                raise SessionExpiredError(f"IFMS connection/session redirect loop: {goto_err}")
            raise goto_err
        
        # Robust check for login redirection
        if is_session_expired(page):
            raise SessionExpiredError("IFMS Session expired - login screen detected.")

        # Wait for the treasury dropdown selector to be attached/visible
        try:
            wait_for_selector_with_retry(self, page, "#cmbTreasuryCodeName", state="visible", base_timeout=15000)
        except Exception:
            # Check if we were redirected to login page during wait
            if is_session_expired(page):
                raise SessionExpiredError("IFMS Session expired - login screen detected during wait.")
            try:
                page.screenshot(path=os.path.join(folder, f"debug_timeout_{vou}.png"))
                self.log(f"📸 Saved timeout debug screenshot for paybill {vou}.")
            except Exception: pass
            raise Exception("Search page elements failed to load.")

        if not self.select_dropdown(page, "cmbTreasuryCodeName", treasury):
            raise Exception(f"Treasury code '{treasury}' not found in dropdown.")

        self.safe_fill(page, "#txtFrmBillDate", from_date)
        self.safe_fill(page, "#txtToBillDate", to_date)
        self.safe_fill(page, "#txtMajorHead", mh)
        self.safe_fill(page, "#txtSerialNo", vou)

        if not _select_bill_type_paybill(self, page):
            self.log("⚠️ Bill Type could not be set - proceeding anyway.")

        page.locator("#btnSearch").click()
        try: page.wait_for_load_state("networkidle", timeout=get_scaled_timeout(self, 10000))
        except: pass

        if dialog_caught["message"] and "no" in dialog_caught["message"].lower():
            raise Exception("No Records Found")

        # Fail fast if page content indicates no records found
        content = page.content().lower()
        if "no record found" in content or "no records found" in content:
            raise Exception("No Records Found")

        page.wait_for_timeout(1000)
        
        # Click the control link to open 1st pop-up
        bill_link = page.locator("a[onclick*='showBillDtlByCtrlNo']").first
        
        # Wait for the link to become visible
        try:
            resilient_wait_for(self, page, bill_link, state="visible", base_timeout=10000)
        except Exception:
            # Try secondary selector
            secondary_link = _click_bill_ref_no_link(self, page)
            if secondary_link and secondary_link.is_visible():
                bill_link = secondary_link
            else:
                if dialog_caught["message"] and any(x in dialog_caught["message"].lower() for x in ["no", "not found"]):
                    raise Exception("No Records Found")
                try:
                    page.screenshot(path=os.path.join(folder, f"debug_fail_{vou}.png"))
                    self.log(f"📸 Saved debug screenshot for paybill {vou} failure.")
                except Exception:
                    pass
                raise Exception("Bill Control/Ref Link not found or not visible in results table.")

        self.log("⏳ Opening bill details first popup...")
        with context.expect_page(timeout=get_scaled_timeout(self, 20000)) as new_page_info:
            bill_link.click()
        bill_page = new_page_info.value
        bill_page.wait_for_load_state("load", timeout=get_scaled_timeout(self, 30000))
        try: bill_page.wait_for_load_state("networkidle", timeout=get_scaled_timeout(self, 10000))
        except PlaywrightTimeoutError: pass
        self.log("✅ Bill Details popup loaded.")

        if folder not in self.downloaded_folders_this_run:
            self.downloaded_folders_this_run.append(folder)

        if self.stop_requested: return

        # Move to 2nd tab inside 1st popup
        self.log("⏳ Navigating to the 2nd tab in the first popup...")
        tab2_btn = self.get_locator_in_frames(bill_page, "#tab2")
        if tab2_btn.count() == 0:
            tab2_btn = bill_page.locator("a:has-text('Paybill'), a:has-text('NPS'), #tab2")
        tab2_btn.first.click()
        try: bill_page.wait_for_load_state("networkidle", timeout=get_scaled_timeout(self, 5000))
        except PlaywrightTimeoutError: pass

        # Locate and click 'Employee Wise Bill Details Report' inside the 2nd tab
        self.log("⏳ Locating 'Employee Wise Bill Details Report' button...")
        emp_report_btn = self.get_locator_in_frames(bill_page, "text='Employee Wise Bill Details Report'")
        if emp_report_btn.count() == 0:
            emp_report_btn = self.get_locator_in_frames(bill_page, "a[onclick*='retrievePayrollBillEmpDetails']")
        if emp_report_btn.count() == 0:
            raise Exception("'Employee Wise Bill Details Report' button not found inside 2nd tab of first popup.")

        if self.stop_requested: return

        self.log("⏳ Opening Employee Wise Bill Details Report second popup...")
        with context.expect_page(timeout=get_scaled_timeout(self, 25000)) as p2_info:
            emp_report_btn.first.click()
        emp_page = p2_info.value
        emp_page.wait_for_load_state("load", timeout=get_scaled_timeout(self, 35000))
        try: emp_page.wait_for_load_state("networkidle", timeout=get_scaled_timeout(self, 10000))
        except PlaywrightTimeoutError: pass
        self.log("✅ Employee Wise Bill Details Report popup loaded.")

        if self.stop_requested: return

        # Move to 2nd tab of the 2nd popup (Bill Detail)
        self.log("⏳ Navigating to the 2nd tab in the second popup (Bill Detail)...")
        emp_tab2 = self.get_locator_in_frames(emp_page, "a:has-text('Bill Detail')")
        if emp_tab2.count() == 0:
            emp_tab2 = self.get_locator_in_frames(emp_page, "a[rel='tabContent1']")
        if emp_tab2.count() == 0:
            emp_tab2 = self.get_locator_in_frames(emp_page, "#tabmenu li a")
            if emp_tab2.count() >= 2:
                emp_tab2 = emp_tab2.nth(1)
        if emp_tab2.count() == 0:
            emp_tab2 = emp_page.locator("#tab2, a:has-text('Report')")
        emp_tab2.first.click()
        try: emp_page.wait_for_load_state("networkidle", timeout=get_scaled_timeout(self, 5000))
        except PlaywrightTimeoutError: pass

        excel_downloaded = False
        excel_selectors = [
            "a[href*='ExportFormat=4']",
            "a[onclick*='takeAction'][href*='ExportReport']",
            "a:has-text('Excel')",
            "a[href*='excel' i]"
        ]

        excel_btn = None
        for selector in excel_selectors:
            loc = self.get_locator_in_frames(emp_page, selector)
            if loc.count() > 0 and loc.first.is_visible():
                excel_btn = loc.first
                break
                
        if excel_btn is None:
            # Deep search across frames in case of nested frame structure inside second popup
            for frame in emp_page.frames:
                for selector in excel_selectors:
                    try:
                        floc = frame.locator(selector)
                        if floc.count() > 0 and floc.first.is_visible():
                            excel_btn = floc.first
                            break
                    except Exception: pass
                if excel_btn: break

        if excel_btn is None:
            raise Exception("Excel export button not found in the employee details report page (second popup, second tab).")

        self.log("📥 Exporting Pay Bill to Excel...")
        with emp_page.expect_download(timeout=self.TIMEOUT_DOWNLOAD_ATTACHMENT) as dl_info:
            excel_btn.click()
        download = dl_info.value

        suggested = download.suggested_filename or "PayBill.xls"
        safe_vou  = self.clean_folder_name(str(vou))
        ext = os.path.splitext(suggested)[1]
        save_name = f"PayBill_{s_no}_{treasury}_{safe_vou}_{year}{month:02d}{ext}"
        save_path = os.path.join(folder, save_name)
        download.save_as(save_path)
        if not validate_downloaded_file(save_path):
            if os.path.exists(save_path):
                try: os.remove(save_path)
                except: pass
            raise Exception("Downloaded Pay Bill Excel file failed integrity validation.")
        
        self.log(f"✅ Saved Pay Bill Excel: {save_name} ({os.path.getsize(save_path)/1024:.1f} KB)")
        
        # Inject metadata columns directly into the downloaded Paybill Excel file
        try:
            import pandas as pd
            try:
                df_list = pd.read_html(save_path)
                df = df_list[0] if df_list else pd.read_excel(save_path)
            except Exception:
                df = pd.read_excel(save_path)

            # Insert metadata columns at the beginning of the dataframe
            df.insert(0, "Year", year)
            df.insert(0, "Month", month)
            df.insert(0, "Voucher_No", vou)
            df.insert(0, "Major_Head", mh)
            df.insert(0, "Treasury_Name", treasury)
            df.insert(0, "S_No", s_no)

            df.to_excel(save_path, index=False)
            self.log(f"✅ Injected Excel metadata columns (S_No, Treasury_Name, Major_Head, Voucher_No, Month, Year)")
        except Exception as e:
            self.log(f"⚠️ Could not inject Excel metadata: {e}")

        excel_downloaded = True

        # F1: Validate downloaded Excel file integrity
        from core.download_integrity import validate_xls_integrity
        is_valid_xls, xls_reason = validate_xls_integrity(save_path)
        if not is_valid_xls:
            self.log(f"⚠️ [Worker] Excel validation failed for voucher {vou}: {xls_reason}")
            failed_rows.append(row_data)
            return

        with open(success_marker, "w") as f:
            f.write(f"DONE\nVoucher: {vou}\nSaved: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        with self._counter_lock: self.success_count += 1
        with open(self.paybill_master_report, "a", encoding="utf-8") as report:
            report.write(f"[{time.strftime('%H:%M:%S')}] S.No:{s_no} Voucher:{vou} Try:{treasury} MH:{mh} -> {folder}\n")

    except SessionExpiredError:
        page.remove_listener("dialog", handle_dialog)
        raise
    except Exception as e:
        page.remove_listener("dialog", handle_dialog)
        if is_browser_connection_dead(e):
            raise BrowserConnectionDeadError(str(e)) from e
        with self._counter_lock: self.fail_count += 1
        failed_rows.append(row_data)
        self.log(f"❌ FAILED Paybill [{s_no}]: {vou} - {str(e)[:100]}")
        try:
            screenshot_name = f"fail_pb_{vou}_{int(time.time())}.png"
            page.screenshot(path=os.path.join(folder, screenshot_name))
            self.log(f"📸 Saved failure screenshot to {screenshot_name}")
        except Exception:
            pass
        try:
            with open(self.paybill_failed_file, "a", encoding="utf-8") as ff:
                ff.write(f"{s_no}|{mh}|{treasury}|{vou}|{amount}|{month}|{year}\n")
        except Exception: pass
    finally:
        page.remove_listener("dialog", handle_dialog)
        if bill_page:
            try: bill_page.close()
            except Exception: pass
        if emp_page:
            try: emp_page.close()
            except Exception: pass
        if paybill_page and paybill_page != page:
            try: paybill_page.close()
            except Exception: pass
        try:
            for p in context.pages:
                if p != page: p.close()
        except Exception: pass


def merge_and_rename_pdfs(self, folder, mh, vou):
    return None


def download_voucher_browserless(self, row_data, mode, config_dict, template_path, state_file, page, context):
    return False


def extract_voucher_no(self, voucher_text):
    numbers = re.findall(r"\d+", str(voucher_text))
    if numbers:
        return numbers[0]
    text = str(voucher_text).strip()
    text = re.sub(r"[^\w\-]+", "_", text)
    text = re.sub(r"_+", "_", text)
    return text.strip("_")


def get_xpath_locator_in_frames(self, p_page, xpath):
    loc = p_page.locator(f"xpath={xpath}")
    if loc.count() > 0: 
        return loc.first
    for frame in p_page.frames:
        loc = frame.locator(f"xpath={xpath}")
        if loc.count() > 0: 
            return loc.first
    return p_page.locator(f"xpath={xpath}").first


def wait_and_get_xpath_locator_in_frames(self, p_page, xpath, timeout_ms=15000):
    start_time = time.time()
    while (time.time() - start_time) * 1000 < timeout_ms:
        try:
            loc = p_page.locator(f"xpath={xpath}")
            if loc.count() > 0 and loc.first.is_visible():
                return loc.first
        except:
            pass
        for frame in p_page.frames:
            try:
                loc = frame.locator(f"xpath={xpath}")
                if loc.count() > 0 and loc.first.is_visible():
                    return loc.first
            except:
                pass
        time.sleep(0.5)
    return p_page.locator(f"xpath={xpath}").first


def open_report_page(self, page):
    self.log("Opening Salary Voucher Report Page...")
    module_btn = self.wait_and_get_xpath_locator_in_frames(page, "//a[contains(@onclick,'moduleCode=1000147')]")
    module_btn.click()
    
    element_btn = self.wait_and_get_xpath_locator_in_frames(page, "//a[contains(@href,'elementId=7052054')]")
    element_btn.click()
    time.sleep(3)


def wait_for_all_vouchers_loaded_playwright(self, page, timeout=180, stable_rounds_required=5, check_interval=2):
    voucher_dropdown = self.wait_and_get_xpath_locator_in_frames(page, "//*[@id='voucherNumber']")
    last_count = -1
    stable_rounds = 0
    final_vouchers = []
    
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            options = voucher_dropdown.locator("option")
            count = options.count()
            
            vouchers = []
            for idx in range(count):
                opt_text = options.nth(idx).inner_text().strip()
                if opt_text and "SELECT" not in opt_text.upper() and "--" not in opt_text:
                    vouchers.append(opt_text)
            
            current_count = len(vouchers)
            self.log(f"Voucher dropdown check → Count: {current_count}")
            
            if current_count == last_count:
                stable_rounds += 1
            else:
                stable_rounds = 0
                last_count = current_count
            
            final_vouchers = vouchers
            
            if current_count > 0 and stable_rounds >= stable_rounds_required:
                self.log(f"Voucher dropdown loading completed. Final Count = {current_count}")
                return final_vouchers
                
            time.sleep(check_interval)
        except Exception as e:
            self.log(f"Waiting for voucher dropdown options: {e}")
            time.sleep(check_interval)
            
    if final_vouchers:
        self.log(f"⚠️ Voucher count did not stabilize fully, using latest count = {len(final_vouchers)}")
        return final_vouchers
        
    raise Exception("Voucher dropdown did not load any voucher within timeout.")


def read_excel_first_logical_text_playwright(self, file_path):
    import openpyxl
    import xlrd
    
    full_text = ""
    if file_path.lower().endswith(".xlsx"):
        wb = openpyxl.load_workbook(file_path, data_only=True)
        ws = wb.active
        max_r = min(ws.max_row, 25)
        max_c = min(ws.max_column, 25)
        for r in range(1, max_r + 1):
            row_values = []
            for c in range(1, max_c + 1):
                val = ws.cell(r, c).value
                if val is not None:
                    row_values.append(str(val))
            if row_values:
                full_text += " ".join(row_values) + " "
    else:
        wb = xlrd.open_workbook(file_path)
        ws = wb.sheet_by_index(0)
        max_r = min(ws.nrows, 25)
        max_c = min(ws.ncols, 25)
        for r in range(max_r):
            row_values = []
            for c in range(max_c):
                val = ws.cell_value(r, c)
                if val is not None and str(val).strip():
                    row_values.append(str(val))
            if row_values:
                full_text += " ".join(row_values) + " "
    return full_text.upper()


def extract_ddo_code_playwright(self, full_text):
    patterns = [
        r"DDO\s*CODE\s*[:\-]?\s*(\d+)",
        r"DDOCODE\s*[:\-]?\s*(\d+)",
        r"D\.D\.O\.?\s*CODE\s*[:\-]?\s*(\d+)",
        r"DDO\s*[:\-]?\s*(\d+)"
    ]
    for pattern in patterns:
        match = re.search(pattern, full_text, re.IGNORECASE)
        if match:
            ddo_code = match.group(1).strip()
            if len(ddo_code) == 9:
                ddo_code = ddo_code.zfill(10)
            return ddo_code
    return "UNKNOWNDDO"


def create_blank_excel_file(self, voucher_text, month, year, ddo_code, message_text, download_dir):
    import openpyxl
    voucher_no = self.extract_voucher_no(voucher_text)
    file_name = f"blankdata_{voucher_no}_{month}_{year}_{ddo_code}.xlsx"
    file_path = os.path.join(download_dir, file_name)
    
    counter = 1
    while os.path.exists(file_path):
        file_name = f"blankdata_{voucher_no}_{month}_{year}_{ddo_code}_{counter}.xlsx"
        file_path = os.path.join(download_dir, file_name)
        counter += 1
        
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Blank Data"
    ws.append(["Voucher Number", "Month", "Year", "DDO Code", "Message"])
    ws.append([voucher_text, month, year, ddo_code, message_text])
    wb.save(file_path)
    self.log(f"BLANK DATA FILE CREATED → {file_name}")
    return file_path


def create_small_file_log(self, voucher_text, month, year, ddo_code, size_kb, remarks, download_dir):
    import openpyxl
    voucher_no = self.extract_voucher_no(voucher_text)
    file_name = f"smallfile_{voucher_no}_{month}_{year}_{ddo_code}.xlsx"
    file_path = os.path.join(download_dir, file_name)
    
    counter = 1
    while os.path.exists(file_path):
        file_name = f"smallfile_{voucher_no}_{month}_{year}_{ddo_code}_{counter}.xlsx"
        file_path = os.path.join(download_dir, file_name)
        counter += 1
        
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Small File Log"
    ws.append(["Voucher Number", "Month", "Year", "DDO Code", "File Size KB", "Remarks"])
    ws.append([voucher_text, month, year, ddo_code, round(size_kb, 2), remarks])
    wb.save(file_path)
    self.log(f"SMALL FILE LOG CREATED → {file_name}")
    return file_path


def move_to_different_department(self, latest_file, voucher_text, month, year, ddo_code, diff_dept_folder):
    extension = os.path.splitext(latest_file)[1]
    voucher_no = self.extract_voucher_no(voucher_text)
    new_name = f"different_department_{voucher_no}_{month}_{year}_{ddo_code}{extension}"
    new_path = os.path.join(diff_dept_folder, new_name)
    
    counter = 1
    while os.path.exists(new_path):
        new_name = f"different_department_{voucher_no}_{month}_{year}_{ddo_code}_{counter}{extension}"
        new_path = os.path.join(diff_dept_folder, new_name)
        counter += 1
        
    os.rename(latest_file, new_path)
    self.log(f"MOVED TO DIFFERENT DEPARTMENT FOLDER → {new_name}")
    return new_path


def rename_downloaded_file_playwright(self, latest_file, voucher_text, month, year, ddo_code, download_dir):
    extension = os.path.splitext(latest_file)[1]
    voucher_no = self.extract_voucher_no(voucher_text)
    new_name = f"{voucher_no}_{month}_{year}_{ddo_code}{extension}"
    new_path = os.path.join(download_dir, new_name)
    
    counter = 1
    while os.path.exists(new_path):
        new_name = f"{voucher_no}_{month}_{year}_{ddo_code}_{counter}{extension}"
        new_path = os.path.join(download_dir, new_name)
        counter += 1
        
    os.rename(latest_file, new_path)
    self.log(f"RENAMED FILE → {new_name}")
    return new_path


def download_salary_voucher_excel(self, page, context, voucher_text, year, month, treasury_code, dept_code, download_dir):
    retry = 0
    small_file_retry = 0
    dept_validation_retry = 0
    diff_dept_folder = os.path.join(download_dir, "different department")
    os.makedirs(diff_dept_folder, exist_ok=True)
    
    while retry < 5:
        if self.stop_requested:
            self.log(f"🛑 Download canceled for voucher {voucher_text} due to Stop request.")
            return
        try:
            submit_btn = self.wait_and_get_xpath_locator_in_frames(page, "//*[@id='btnSubmit']")
            with context.expect_page(timeout=25000) as new_page_info:
                submit_btn.click()
            new_tab = new_page_info.value
            new_tab.wait_for_load_state("load", timeout=30000)
        except Exception as e:
            self.log(f"⚠️ Failed to open voucher page: {e}. Retrying {retry+1}/5...")
            retry += 1
            continue
            
        blank_keywords = [
            "data not available", "no data available", "data not found",
            "no data found", "no record found", "no records found",
            "record not found", "records not found", "no records available"
        ]
        
        excel_xpaths = [
            "//a[contains(text(),'Excel')]",
            "//img[contains(@src,'excel')]",
            "//img[contains(@src,'xls')]",
            "//a[contains(@href,'xls')]",
            "//a[contains(@href,'excel')]",
            "//*[contains(text(),'Excel')]"
        ]
        
        excel_btn = None
        is_blank = False
        blank_body_text = ""
        
        start_wait = time.time()
        while time.time() - start_wait < 15:
            if self.stop_requested:
                self.log(f"🛑 Download canceled for voucher {voucher_text} due to Stop request.")
                return
            
            try:
                body_text = new_tab.locator("body").inner_text().strip()
                body_text_lower = body_text.lower()
                if any(kw in body_text_lower for kw in blank_keywords):
                    is_blank = True
                    blank_body_text = body_text
                    break
            except: pass
            
            for xpath in excel_xpaths:
                try:
                    loc = new_tab.locator(f"xpath={xpath}")
                    if loc.count() > 0 and loc.first.is_visible():
                        excel_btn = loc.first
                        break
                except: pass
            
            if excel_btn:
                break
                
            time.sleep(0.5)
        
        if is_blank:
            self.log(f"📝 Blank data message found for voucher {voucher_text}")
            self.create_blank_excel_file(voucher_text, month, year, "UNKNOWNDDO", blank_body_text, download_dir)
            try: new_tab.close()
            except: pass
            self._last_extracted_ddo = "UNKNOWNDDO"
            return
            
        if not excel_btn:
            self.log(f"⚠️ Excel download button not found for voucher {voucher_text}. Retrying...")
            try: new_tab.close()
            except: pass
            retry += 1
            continue
            
        try:
            with new_tab.expect_download(timeout=30000) as download_info:
                excel_btn.click(no_wait_after=True)
            download = download_info.value
            suggested_filename = download.suggested_filename or "report.xls"
            latest_file = os.path.join(download_dir, suggested_filename)
            download.save_as(latest_file)
            try: new_tab.close()
            except: pass
        except Exception as de:
            self.log(f"⚠️ Download failed/timed out: {de}. Retrying...")
            try: new_tab.close()
            except: pass
            retry += 1
            continue
            
        size_kb = os.path.getsize(latest_file) / 1024
        self.log(f"File size → {size_kb:.2f} KB")
        
        if size_kb <= 1:
            small_file_retry += 1
            self.log(f"⚠️ File size <= 1 KB (attempt {small_file_retry}/2)")
            try: os.remove(latest_file)
            except: pass
            
            if small_file_retry < 2:
                retry += 1
                continue
            else:
                self.create_small_file_log(
                    voucher_text=voucher_text, month=month, year=year, ddo_code="UNKNOWNDDO",
                    size_kb=size_kb, remarks="Downloaded Excel size was <= 1 KB after 2 attempts.",
                    download_dir=download_dir
                )
                self._last_extracted_ddo = "UNKNOWNDDO"
                return
                
        try:
            full_text = self.read_excel_first_logical_text_playwright(latest_file)
        except Exception as re:
            self.log(f"⚠️ Excel read error: {re}. Retrying...")
            try: os.remove(latest_file)
            except: pass
            retry += 1
            continue
            
        ddo_code = self.extract_ddo_code_playwright(full_text)
        self.log(f"Extracted DDO Code: {ddo_code}")
        self._last_extracted_ddo = ddo_code
        
        if size_kb >= 5:
            ddo_code_clean = str(ddo_code).strip()
            treasury_from_ddo = ddo_code_clean[:3]
            dept_from_ddo = ddo_code_clean[3:5]
            treasury_ok = (treasury_from_ddo == treasury_code)
            dept_ok = (dept_from_ddo == dept_code)
            
            if not (treasury_ok and dept_ok):
                dept_validation_retry += 1
                self.log(f"⚠️ Different Treasury/Dept found: Try={treasury_from_ddo}, Dept={dept_from_ddo} (attempt {dept_validation_retry}/2)")
                if dept_validation_retry < 2:
                    try: os.remove(latest_file)
                    except: pass
                    retry += 1
                    continue
                else:
                    self.move_to_different_department(
                        latest_file=latest_file, voucher_text=voucher_text, month=month, year=year,
                        ddo_code=ddo_code_clean, diff_dept_folder=diff_dept_folder
                    )
                    return
                    
        self.rename_downloaded_file_playwright(
            latest_file=latest_file, voucher_text=voucher_text, month=month, year=year,
            ddo_code=ddo_code, download_dir=download_dir
        )
        return
        
    raise Exception(f"Failed to download/process voucher {voucher_text} after retries.")


def process_salary_voucher_dropdown_loop(self, page, context, months_to_process, treasury_code, dept_code, mhcd, gpf_idx):
    total_months = len(months_to_process)
    total_month_vouchers = 0
    
    # Calculate simulated/estimated stats total if needed, or dynamically adjust
    # Since we don't know total vouchers, we start with total months and scale as we discover counts
    with self._counter_lock:
        self.stats_total = total_months
        self.update_stats()
        
    processed_months_count = 0
    
    for m_idx, (year, month) in enumerate(months_to_process, 1):
        if self.stop_requested: break
        self.log(f"Starting month {m_idx}/{total_months} → {month}/{year}")
        
        try:
            page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm", timeout=20000)
            page.wait_for_load_state("networkidle")
        except:
            pass
            
        try:
            self.open_report_page(page)
            
            self.log(f"FILLING FORM → {month}/{year}")
            
            report_dropdown = self.wait_and_get_xpath_locator_in_frames(page, "//*[@id='report']")
            
            report_select_loc = report_dropdown.locator("option")
            selected_option_value = None
            for idx in range(report_select_loc.count()):
                opt = report_select_loc.nth(idx)
                opt_text = opt.inner_text().strip()
                if "Treasury Wise Salary Voucher Details" in opt_text:
                    selected_option_value = opt.get_attribute("value")
                    break
            if selected_option_value:
                report_dropdown.select_option(value=selected_option_value)
            else:
                self.log("⚠️ Option 'Treasury Wise Salary Voucher Details' not found in report dropdown.")
                continue
            time.sleep(5)
            
            treasury_dropdown = self.wait_and_get_xpath_locator_in_frames(page, "//*[@id='treasuryCode']")
            treasury_options = treasury_dropdown.locator("option")
            selected_tr_value = None
            for idx in range(treasury_options.count()):
                opt = treasury_options.nth(idx)
                opt_text = opt.inner_text().strip()
                if opt_text.startswith(treasury_code):
                    selected_tr_value = opt.get_attribute("value")
                    break
            if selected_tr_value:
                treasury_dropdown.select_option(value=selected_tr_value)
            else:
                self.log(f"⚠️ Treasury code {treasury_code} not found in dropdown.")
                continue
            time.sleep(5)
            
            fin_year_dropdown = self.wait_and_get_xpath_locator_in_frames(page, "//*[@id='FinYear']")
            fin_year_dropdown.select_option(value=str(year))
            time.sleep(2)
            
            month_dropdown = self.wait_and_get_xpath_locator_in_frames(page, "//*[@id='Month']")
            month_dropdown.select_option(value=str(month))
            time.sleep(2)
            
            time.sleep(2)
            
            # Wait for Head of Account dropdown to populate
            self.log("⏳ Waiting for Head of Account dropdown to populate...")
            hoa_dropdown = self.wait_and_get_xpath_locator_in_frames(page, "//*[@id='HoA']")
            for idx in range(30):
                if hoa_dropdown.locator("option").count() > 1:
                    break
                time.sleep(0.5)
            
            hoa_options = hoa_dropdown.locator("option")
            selected_hoa_value = None
            for idx in range(hoa_options.count()):
                opt = hoa_options.nth(idx)
                opt_val = opt.get_attribute("value")
                opt_text = opt.inner_text().strip()
                if opt_val == str(mhcd) or str(mhcd) in opt_text:
                    selected_hoa_value = opt_val
                    break
            
            if selected_hoa_value:
                hoa_dropdown.select_option(value=selected_hoa_value)
                self.log(f"✅ Selected Head of Account value: {selected_hoa_value}")
            else:
                self.log(f"⚠️ Major Head {mhcd} not found in options list. Attempting direct select fallback...")
                hoa_dropdown.select_option(value=str(mhcd))
                self.log(f"✅ Selected Head of Account directly: {mhcd}")
            time.sleep(5)
            
            voucher_dropdown = self.wait_and_get_xpath_locator_in_frames(page, "//*[@id='voucherNumber']")
            voucher_texts = self.wait_for_all_vouchers_loaded_playwright(page, timeout=180)
            self.log(f"TOTAL VOUCHERS FOUND → {len(voucher_texts)}")
            
            total_month_vouchers = len(voucher_texts)
            
            # Update stats total dynamically
            with self._counter_lock:
                # Approximate total count based on current month's count
                self.stats_total = max(self.stats_total, total_month_vouchers * total_months)
                self.update_stats()
            
            for v_idx, voucher_text in enumerate(voucher_texts):
                if self.stop_requested: break
                
                voucher_no = self.extract_voucher_no(voucher_text)
                
                row_data = {
                    "s_no": str(v_idx + 1),
                    "mh": mhcd,
                    "treasury": treasury_code,
                    "voucher": voucher_no,
                    "amount": "",
                    "month": int(month),
                    "year": int(year)
                }
                
                v_download_dir = self.resolve_download_path(row_data, "Salary Bill")
                marker_file = os.path.join(v_download_dir, f"{voucher_no}_SUCCESS.marker")
                skipped_marker = os.path.join(v_download_dir, f"{voucher_no}_skipped.marker")
                
                if os.path.exists(marker_file) or os.path.exists(skipped_marker):
                    self.log(f"⏭️ Skipping {v_idx + 1}/{total_month_vouchers} → {voucher_text} (already processed)")
                    with self._counter_lock:
                        self.skip_count += 1
                    self.update_stats(current=voucher_text, progress=((m_idx - 1) / total_months) + (v_idx / (total_month_vouchers * total_months)))
                    continue
                    
                self.log(f"PROCESSING {v_idx + 1}/{total_month_vouchers} → {voucher_text}")
                self.update_stats(current=voucher_text, progress=((m_idx - 1) / total_months) + (v_idx / (total_month_vouchers * total_months)))
                
                if "login.jsp" in page.url.lower():
                    raise SessionExpiredError("Session expired during dropdown loop.")
                    
                voucher_dropdown.select_option(label=voucher_text)
                time.sleep(0.5)
                
                try:
                    self.download_salary_voucher_excel(
                        page=page, context=context, voucher_text=voucher_text,
                        year=year, month=month, treasury_code=treasury_code,
                        dept_code=dept_code, download_dir=v_download_dir
                    )
                    
                    with open(marker_file, "w") as f:
                        f.write("DONE")
                    if v_download_dir not in self.downloaded_folders_this_run:
                        self.downloaded_folders_this_run.append(v_download_dir)
                    with self._counter_lock:
                        self.success_count += 1
                    
                    # Cache download to SQLite DB
                    try:
                        from database.db_manager import save_download_record
                        db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
                        save_download_record(
                            db_path=db_path,
                            mode="voucher",
                            treasury=treasury_code,
                            major_head=mhcd,
                            month=int(month),
                            year=int(year),
                            voucher_no=voucher_no,
                            amount="",
                            ddo_code=getattr(self, "_last_extracted_ddo", "UNKNOWNDDO"),
                            file_path=v_download_dir
                        )
                    except Exception as dbe:
                        self.log(f"⚠️ Failed to cache download: {dbe}")
                        
                except Exception as ve:
                    self.log(f"❌ Voucher Error for {voucher_text}: {ve}")
                    with self._counter_lock:
                        self.fail_count += 1
                    try:
                        with open(self.voucher_failed_file, "a", encoding="utf-8") as f:
                            f.write(f"{v_idx+1}|{mhcd}|{treasury_code}|{voucher_no}||{month}|{year} - Error: {ve}\n")
                    except Exception: pass
                    
        except Exception as e:
            self.log(f"❌ Error processing month {month}/{year}: {e}")
            continue

