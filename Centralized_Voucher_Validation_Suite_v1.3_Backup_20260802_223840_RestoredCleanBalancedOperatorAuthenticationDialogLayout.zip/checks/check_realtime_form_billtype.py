import os
import glob
from checks.base_check import BaseValidationCheck
from parsers.mptc_parser import parse_mptc_pdf
from parsers.party_details_parser import parse_party_details_pdf
from parsers.classification_data import FORM_BILL_TYPE_MAP


class FormBilltypeCheck(BaseValidationCheck):
    check_id = "check_realtime_form_billtype"
    name = "Form Number vs Bill Type Agreement Check"
    description = "Extracts form_number from MPTC and bill_type from Party Details to verify agreement."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            mptc_file = os.path.join(download_folder, "Show_MPTC.pdf")
            party_file = os.path.join(download_folder, "Party_Details.pdf")

            if not os.path.exists(party_file):
                party_pdfs = glob.glob(os.path.join(download_folder, "bill_party_*.pdf"))
                if party_pdfs:
                    party_file = party_pdfs[0]

            if not os.path.exists(mptc_file) or not os.path.exists(party_file):
                return {"status": "SKIPPED", "message": "Cannot determine form number or bill type (files missing)", "details": {}}

            mptc = parse_mptc_pdf(mptc_file)
            party = parse_party_details_pdf(party_file)

            form_number = mptc.form_number.strip()  # e.g., "24", "34", "63"
            actual_bill_type = party.bill_type.strip()  # e.g., "Pay Bill", "FVC Bill"

            if not form_number or not actual_bill_type:
                return {"status": "SKIPPED", "message": "Cannot determine form number or bill type from parsed data",
                        "details": {"form_number": form_number, "bill_type": actual_bill_type}}

            form_info = FORM_BILL_TYPE_MAP.get(form_number)
            if not form_info:
                return {"status": "WARNING", "message": "Form number '%s' not in mapping table" % form_number,
                        "details": {"form_number": form_number, "bill_type": actual_bill_type}}

            expected_bill_type = form_info["bill_type"]

            # Normalize for comparison
            actual_clean = actual_bill_type.lower().replace(" bill", "").strip()
            expected_clean = expected_bill_type.lower().replace(" bill", "").strip()

            # Bill type synonym alias sets
            gia_aliases = {"gia", "grant", "grant in aid", "grant-in-aid", "grant in aid bill", "gia bill"}
            gpf_aliases = {"dpf", "gpf", "gpf withdrawal", "provident fund"}
            pay_aliases = {"pay", "pay bill", "establishment pay bill", "salary", "salaries"}
            fvc_aliases = {"fvc", "fvc bill", "fully vouched contingent", "contingent"}
            med_aliases = {"medical", "medical bill", "medical reimbursement"}
            ta_aliases = {"ta", "ta bill", "travelling allowance", "travel"}

            is_matched = (
                actual_clean == expected_clean or
                actual_clean.startswith(expected_clean) or
                expected_clean.startswith(actual_clean) or
                (actual_clean in gia_aliases and expected_clean in gia_aliases) or
                (actual_clean in gpf_aliases and any(k in expected_clean for k in ("gpf", "dpf"))) or
                (actual_clean in pay_aliases and expected_clean in pay_aliases) or
                (actual_clean in fvc_aliases and expected_clean in fvc_aliases) or
                (actual_clean in med_aliases and expected_clean in med_aliases) or
                (actual_clean in ta_aliases and expected_clean in ta_aliases)
            )

            if is_matched:
                return {"status": "PASS", "message": "Form MPTC %s matches %s (%s)" % (form_number, actual_bill_type, form_info["description"]),
                        "details": {"form_number": form_number, "bill_type": actual_bill_type, "expected": expected_bill_type}}
            else:
                return {"status": "MISMATCH",
                        "message": "Form MPTC %s expects '%s' but bill type is '%s'" % (form_number, expected_bill_type, actual_bill_type),
                        "details": {"form_number": form_number, "bill_type": actual_bill_type, "expected": expected_bill_type}}

        except Exception as e:
            return {"status": "FAIL", "message": "Error during check: %s" % str(e), "details": {}}
