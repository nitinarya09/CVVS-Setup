# Centralized Voucher Validation Suite - Compiler Kit & Publishing Guide

This compiler kit contains all the necessary scripts, configuration files, and assets to compile your updated client scripts (`ifmis_suite.py`) into three distributions:
1. **Portable Version** (Folder containing the single executable and bundled assets)
2. **Full Installation Wizard** (Installs the app with Playwright browsers bundled)
3. **Lightweight Patch Setup** (Overwrites only the main code, frontend assets, and database)

---

## Directory Structure

```text
IFMIS_Suite_Compiler_Kit/
├── ifmis_suite.py        # Place your updated Python source script here
├── build_all_setups.bat  # Automated batch script to compile everything
├── setup.iss             # Inno Setup config for the Complete Installation Wizard
├── setup_patch.iss       # Inno Setup config for the Lightweight Update Patch
├── ddo.txt               # Embeddable SQLite database file
├── keygen.exe            # Keygen tool copied into the portable distribution
├── unified_audit_suite.html # UI container file copied into the portable distribution
├── web_dist/             # Frontend web assets folder
├── pw-browsers/          # Bundled Playwright browser engines (for Full Setup)
└── output/               # [GENERATED] Directory containing build outputs
    ├── IFMIS_Suite_Setup.exe        # Complete setup installer
    ├── IFMIS_Suite_Patch_Setup.exe  # Lightweight update patch installer
    └── IFMIS_Suite_Portable/        # Portable distribution directory
```

---

## Prerequisites & Setup

Ensure the compiling machine has the following tools installed:

1. **Python 3.12+**: Download from [python.org](https://www.python.org/downloads/). Ensure **"Add Python to PATH"** is checked during installation.
2. **PyInstaller**: Open Command Prompt and install PyInstaller:
   ```cmd
   pip install pyinstaller
   ```
3. **Inno Setup 6**: Download and install Inno Setup 6 from [jrsoftware.org](https://jrsoftware.org/isdl.php). It must be installed in its default location:
   `C:\Program Files (x86)\Inno Setup 6\ISCC.exe`

---

## How to Compile

1. Open/modify the **`ifmis_suite.py`** script in this folder to apply your changes.
2. Double-click **`build_all_setups.bat`**.
3. The script will:
   - Compile the python code into a frozen executable (`ifmis_suite.exe`) using PyInstaller.
   - Assemble the local self-contained portable folder inside `output\IFMIS_Suite_Portable`.
   - Compile Inno Setup scripts to create the installers inside `output\`.
   - Automatically sync the outputs to your staging directory (`D:\BUILDING AND TESTING\IFMIS Downloader and Analyzer Setup`) for testing.
4. Once completed, your generated files will be ready in the **`output\`** directory!

---

## Step-by-Step Guide: Publishing a New Update

Follow these steps when you want to deploy a new version to your users:

### Step 1: Update the Version in Code
In `ifmis_suite.py`, locate the `TOOL_VERSION` variable (near the top) and increment it:
```python
TOOL_VERSION = "1.1" # Change from "1.0" to "1.1"
```

### Step 2: Compile the Build
Double-click `build_all_setups.bat` to rebuild the executable and installers with your updated code. 

### Step 3: Create a GitHub Release
1. Open your repository in a web browser: `https://github.com/nitinarya09/ifmis-suite-releases`.
2. Click on **Releases** -> **Draft a new release**.
3. Create a new release tag matching your version exactly (e.g., `1.1`).
4. Title the release (e.g., `Centralized Voucher Validation Suite v1.1 - Hotfix Update`).
5. Under **Attach binaries by dropping them here**, upload the compiled lightweight patch installer:
   - File to upload: `output\IFMIS_Suite_Patch_Setup.exe`
   *(Optional: You can also upload `IFMIS_Suite_Setup.exe` for new users).*
6. Click **Publish release**.

### Step 4: Update the Pastebin Configuration
The active clients query a Pastebin URL on startup to check for updates. You must update this JSON configuration to point to your new release.

1. Go to your Pastebin account and edit the paste pointing to: `https://pastebin.com/raw/sUxsMvyJ`
2. Update the JSON to specify the new version details and the download URL from your GitHub Release. Make sure to use the exact keys (`update_url` and `latest_version`):
   ```json
   {
     "global_enabled": true,
     "min_version": "1.0",
     "latest_version": "1.2",
     "update_url": "https://github.com/nitinarya09/ifmis-suite-releases/releases/download/1.2/IFMIS_Suite_Patch_Setup.exe",
     "blocked_hardware_ids": []
   }
   ```
3. Save the paste.

> [!WARNING]
> **Troubleshooting: "Failed to load Python DLL"**
> If you test the "online update" using the old client and it downloads the old `IFMIS_Suite_Patch_Setup.exe` from your GitHub `1.0` release, it will still crash with the Python DLL error.
> This is because the old installer on GitHub does not contain the `SetEnvironmentVariable` DLL-clearing fix.
> To fix this immediately:
> 1. Go to your GitHub Releases tab for version `1.0`.
> 2. Delete the old `IFMIS_Suite_Patch_Setup.exe` file.
> 3. Upload the newly compiled file from `D:\BUILDING AND TESTING\IFMIS Downloader and Analyzer Setup\IFMIS_Suite_Patch_Setup.exe` in its place.
> 4. Once the new installer is hosted on GitHub, the online update will download the fixed version and complete without any DLL crashes!

---

## How the Auto-Updater Works

When an end-user launches their app:
1. The app fetches the JSON config from `https://pastebin.com/raw/sUxsMvyJ`.
2. It parses the version numbers. If `latest_version` (e.g. `1.1`) is greater than their local version (e.g. `1.0`), it triggers a prompt asking the user if they wish to install the update.
3. If they accept, a progress dialog downloads the setup file showing live download statistics.
4. Once downloaded, the application spawns the installer silently (`/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /LOG`) with a 1-second delay and exits immediately.
5. The installer starts. The first thing it does is execute `taskkill /f /im ifmis_suite.exe` in the background to forcefully close any hanging client instances and unlock files.
6. The installer copies the new files, overwriting the old ones.
7. Finally, because the installer ran silently, it restarts the application automatically by running `ifmis_suite.exe --updated` in background mode.
8. On restart, the app detects the `--updated` flag and displays an "Update Successful" confirmation popup to the user.
