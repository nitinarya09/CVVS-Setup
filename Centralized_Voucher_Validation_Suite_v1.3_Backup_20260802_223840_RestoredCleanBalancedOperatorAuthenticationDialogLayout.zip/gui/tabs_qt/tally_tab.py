import os
import sys
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QFrame,
    QPushButton, QLabel, QLineEdit, QFileDialog)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from gui.toggle_switch import ToggleSwitch

def build_tally_tab(app, tab):
    """Build the Voucher Total Tally Verification tab."""
    layout = QVBoxLayout(tab)
    layout.setContentsMargins(10, 5, 10, 5)

    # Info label
    app.lbl_tally_info = QLabel(
        "📊 Voucher Total Tally Verification\n"
        "Scrapes FVC Bill totals & TDS/GST deductions from IFMIS portal and tallies against Excel input amounts."
    )
    app.lbl_tally_info.setFont(QFont("Segoe UI", 11))
    font = app.lbl_tally_info.font()
    font.setItalic(True)
    app.lbl_tally_info.setFont(font)
    app.lbl_tally_info.setAlignment(Qt.AlignCenter)
    app.lbl_tally_info.setWordWrap(True)
    app.lbl_tally_info.setProperty("cssClass", "muted")
    layout.addWidget(app.lbl_tally_info)

    # File selection card
    app.tally_file_box = QFrame()
    app.tally_file_box.setProperty("cssClass", "card")
    file_layout = QVBoxLayout(app.tally_file_box)
    file_layout.setContentsMargins(15, 10, 15, 10)

    app.btn_tally_excel = QPushButton("📂 Select Voucher Excel List")
    app.btn_tally_excel.setProperty("cssClass", "outline")
    app.btn_tally_excel.setFixedHeight(30)
    app.btn_tally_excel.clicked.connect(lambda: app.pick_excel_file("tally"))
    file_layout.addWidget(app.btn_tally_excel)

    app.lbl_tally_excel = QLabel("No Excel Selected")
    app.lbl_tally_excel.setStyleSheet("color: #ef4444;")
    app.lbl_tally_excel.setAlignment(Qt.AlignCenter)
    file_layout.addWidget(app.lbl_tally_excel)

    layout.addWidget(app.tally_file_box)

    # Output folder row
    output_frame = QFrame()
    output_layout = QHBoxLayout(output_frame)
    output_layout.setContentsMargins(0, 0, 0, 0)

    app.entry_tally_output = QLineEdit()
    app.entry_tally_output.setPlaceholderText("Output folder for tally results")
    app.entry_tally_output.setFixedHeight(30)
    
    def _on_tally_output_changed(text):
        path = text.strip()
        app.tally_output_dir = os.path.normpath(path) if path else None

    app.entry_tally_output.textChanged.connect(_on_tally_output_changed)
    output_layout.addWidget(app.entry_tally_output, 1)

    btn_output_browse = QPushButton("Browse...")
    btn_output_browse.setProperty("cssClass", "outline")
    btn_output_browse.setFixedSize(85, 30)
    
    def _browse_tally_output():
        directory = QFileDialog.getExistingDirectory(app, "Select Output Directory")
        if directory:
            directory = os.path.normpath(directory)
            app.entry_tally_output.setText(directory)
            app.tally_output_dir = directory

    btn_output_browse.clicked.connect(_browse_tally_output)
    output_layout.addWidget(btn_output_browse)

    layout.addWidget(output_frame)

    # Action buttons

    btn_frame = QFrame()
    btn_layout = QHBoxLayout(btn_frame)
    btn_layout.setContentsMargins(0, 0, 0, 0)

    app.btn_tally_start = QPushButton("▶ Start Tally Verification")
    app.btn_tally_start.setProperty("cssClass", "primary")
    app.btn_tally_start.setFixedHeight(30)
    app.btn_tally_start.clicked.connect(lambda: app.start_thread("tally", run_failed=False))
    btn_layout.addWidget(app.btn_tally_start)

    app.btn_tally_open_folder = QPushButton("📂 Open Results Folder")
    app.btn_tally_open_folder.setProperty("cssClass", "outline")
    app.btn_tally_open_folder.setFixedHeight(30)

    def _open_tally_results():
        folder = app.get_tally_output_dir() if hasattr(app, "get_tally_output_dir") else (getattr(app, "tally_output_dir", None) or os.path.join(app.download_dir, "Tally_Results"))
        os.makedirs(folder, exist_ok=True)
        try:
            if sys.platform == "win32":
                os.startfile(folder)
            else:
                import subprocess
                subprocess.Popen(["xdg-open", folder])
        except Exception as err:
            app.log(f"⚠️ Failed to open results folder: {err}")

    app.btn_tally_open_folder.clicked.connect(_open_tally_results)
    btn_layout.addWidget(app.btn_tally_open_folder)

    app.btn_tally_rerun_mismatched = QPushButton("🔁 Re-verify Mismatches")
    app.btn_tally_rerun_mismatched.setProperty("cssClass", "warning")
    app.btn_tally_rerun_mismatched.setFixedHeight(30)
    app.btn_tally_rerun_mismatched.setToolTip("Select and re-verify a previously generated Tally_MISMATCHED Excel file")
    app.btn_tally_rerun_mismatched.clicked.connect(lambda: app.pick_excel_file("tally"))
    btn_layout.addWidget(app.btn_tally_rerun_mismatched)

    app.btn_tally_stop = QPushButton("🛑 Stop Safely")
    app.btn_tally_stop.setProperty("cssClass", "danger")
    app.btn_tally_stop.setFixedHeight(30)
    app.btn_tally_stop.clicked.connect(app.request_stop)
    btn_layout.addWidget(app.btn_tally_stop)

    layout.addWidget(btn_frame)


