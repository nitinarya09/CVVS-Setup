import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC

# --- CONFIGURATION ---
# Enter your portal credentials here
USERNAME = "YOUR_USERNAME"
PASSWORD = "YOUR_PASSWORD"

# List of Main Treasuries (Extracted from rep.html, excluding Sub-Treasuries)
TREASURIES = {
    "010-BALAGHAT TREASURY": "18312~010~BALAGHAT TREASURY",
    "020-Barwani District Treasury": "18071~020~Barwani District Treasury",
    "030-Betul District Treasury": "17863~030~Betul District Treasury",
    "040-Bhind Treasury": "17575~040~Bhind Treasury",
    "050-District Treasury Office Bhopal": "17472~050~District Treasury Office Bhopal",
    "051-Vindhyachal Treasury": "17465~051~Vindhyachal Treasury",
    "052-Vallabh Bhawan Treasury, Bhopal": "17470~052~Vallabh Bhawan Treasury, Bhopal",
    "054-Principal Treasury Officer Centre Treasury Bhopal": "50027814~054~Principal Treasury Officer Centre Treasury Bhopal",
    "060-Chhatarpur Treasury": "17081~060~Chhatarpur Treasury",
    "070-Chhindwara Treasury": "16858~070~Chhindwara Treasury",
    "080-Damoh Treasury": "16573~080~Damoh Treasury",
    "090-Datia Treasury": "16419~090~Datia Treasury",
    "100-Dewas Treasury": "16304~100~Dewas Treasury",
    "110-Dhar Treasury": "16117~110~Dhar Treasury",
    "120-Dindori Treasury": "15743~120~Dindori Treasury",
    "130-Guna Treasury": "15710~130~Guna Treasury",
    "140-Gwalior Gorkhi Treasury": "15549~140~Gwalior Gorkhi Treasury",
    "141-Motimahal Gwalior Treasury": "15547~141~Motimahal Gwalior Treasury",
    "150-Harda Treasury": "15292~150~Harda Treasury",
    "160-Hoshangabad Treasury": "15182~160~Hoshangabad Treasury",
    "170-Indore District Treasury": "14925~170~Indore District Treasury",
    "171-Indore City Treasury": "14929~171~Indore City Treasury",
    "180-Jabalpur District Treasury": "14605~180~Jabalpur District Treasury",
    "181-Jabalpur City Treasury": "14593~181~Jabalpur City Treasury",
    "190-Jhabua Treasury": "14278~190~Jhabua Treasury",
    "200-Katni Treasury": "14080~200~Katni Treasury",
    "210-Khandva Treasury": "13880~210~Khandva Treasury",
    "220-Khargaun Treasury": "13688~220~Khargaun Treasury",
    "230-Mandla Treasury": "13412~230~Mandla Treasury",
    "240-Mandsaur Treasury": "13136~240~Mandsaur Treasury",
    "250-Morena Treasury": "12959~250~Morena Treasury",
    "260-Narsinghpur Treasury": "12775~260~Narsinghpur Treasury",
    "270-Neemuch District Treasury": "12605~270~Neemuch District Treasury",
    "280-Panna Treasury": "12473~280~Panna Treasury",
    "290-Raisen Treasury": "12326~290~Raisen Treasury",
    "300-Rajgarh Treasury": "12147~300~Rajgarh Treasury",
    "310-Ratlam Treasury": "11969~310~Ratlam Treasury",
    "320-Rewa Treasury": "11741~320~Rewa Treasury",
    "330-Sagar Treasury": "11416~330~Sagar Treasury",
    "340-Satna Treasury": "11125~340~Satna Treasury",
    "350-Sehore Treasury": "10878~350~Sehore Treasury",
    "360-Seoni Treasury": "10703~360~Seoni Treasury",
    "370-Shahdol Treasury": "10460~370~Shahdol Treasury",
    "380-Shajapur Treasury": "10266~380~Shajapur Treasury",
    "390-Shivpuri Treasury": "10120~390~Shivpuri Treasury",
    "400-Sheopur Treasury": "9963~400~Sheopur Treasury",
    "410-Seedhi Treasury": "9855~410~Seedhi Treasury",
    "420-Tikamgarh Treasury": "9660~420~Tikamgarh Treasury",
    "430-Ujjain Treasury": "9491~430~Ujjain Treasury",
    "440-Umaria Treasury": "9242~440~Umaria Treasury",
    "450-Vidisha Treasury": "9123~450~Vidisha Treasury",
    "460-Anupur Treasury": "18665~460~Anupur Treasury",
    "470-Ashoknagar Treasury": "18483~470~Ashoknagar Treasury",
    "480-Burhanpur Treasury": "18393~480~Burhanpur Treasury",
    "490-Alirajpur Treasury": "8950~490~Alirajpur Treasury",
    "500-Singrauli Treasury": "8833~500~Singrauli Treasury",
    "510-Agar Malwa Treasury": "18736~510~Agar Malwa Treasury",
    "520-District Treasury Office Niwari": "50027813~520~District Treasury Office Niwari"
}

def fetch_and_save_ddos():
    driver = webdriver.Chrome()
    driver.get("https://ifmisprod.mptreasury.gov.in/IFMS/")
    wait = WebDriverWait(driver, 120)

    print("👉 Action Required: Login with Captcha in the browser window.")
    
    # Handle the initial login popup
    time.sleep(5)
    if len(driver.window_handles) > 1:
        driver.switch_to.window(driver.window_handles[1])

    # Wait for the user to login manually and reach the dashboard
    wait.until(EC.presence_of_element_located((By.LINK_TEXT, "Receipt & Disbursement")))
    print("✅ Login Successful. Starting DDO extraction...")

    # Navigate directly to the report parameters page
    driver.get("https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-paymentOrderListForAG&elementId=10072358")
    
    with open("ddo.txt", "w", encoding="utf-8") as f:
        # Loop through each main treasury
        for t_name, t_val in TREASURIES.items():
            print(f"🔎 Fetching DDOs for: {t_name}")
            
            try:
                # Select the Treasury Name dropdown
                tsry_sel = Select(wait.until(EC.visibility_of_element_located((By.ID, "tsryList"))))
                tsry_sel.select_by_value(t_val)
                
                # Wait for the DDO Name list to load via server request (AJAX)
                time.sleep(3)
                
                # Extract all options from the DDO Name dropdown
                ddo_sel = Select(driver.find_element(By.ID, "ddoCode"))
                # Filter out the default "-- Select --" option (value="-1")
                ddo_list = [opt.text for opt in ddo_sel.options if opt.get_attribute("value") != "-1"]
                
                # Write results to the text file
                f.write(f"=== {t_name} ===\n")
                if not ddo_list:
                    f.write("No DDOs found or failed to load.\n")
                else:
                    for ddo in ddo_list:
                        f.write(f"{ddo}\n")
                f.write("\n") # Add a blank line between treasuries
                
                print(f"  Successfully found {len(ddo_list)} DDOs.")
                
            except Exception as e:
                print(f"  ❌ Error fetching {t_name}: {str(e)}")

    driver.quit()
    print("🎯 Extraction complete. Check 'ddo.txt' for results.")

if __name__ == "__main__":
    fetch_and_save_ddos()