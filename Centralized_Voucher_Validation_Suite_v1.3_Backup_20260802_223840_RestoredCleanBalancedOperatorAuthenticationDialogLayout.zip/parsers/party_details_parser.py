import os
import re
import time
import pypdf

class PartyData:
    def __init__(self):
        self.bill_ref_no = ""    # e.g., "Pay Bill/Arrear/200017328452"
        self.bill_type = ""      # e.g., "Pay Bill", "FVC Bill"
        self.parties = []        # List of dicts

def parse_party_details_pdf(pdf_path):
    """Parse a Party Details PDF and return PartyData."""
    data = PartyData()
    try:
        with open(pdf_path, 'rb') as f:
            reader = pypdf.PdfReader(f)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
            
            # Bill Ref No
            bill_ref_match = re.search(r'Bill Ref No\s*:\s*(.+)', text, re.IGNORECASE)
            if bill_ref_match:
                data.bill_ref_no = bill_ref_match.group(1).strip()
                type_match = data.bill_ref_no.split('/')
                if type_match:
                    data.bill_type = type_match[0].strip()
            
            # Party Details
            # Expected format per line:
            # SR No Party Name Party Code Party Amount Account No IFSC Code Aadhaar No Account Mapped Payment Mode
            # Ex: 1 RAMVEER SINGH TOMAR 500244484 693391 6007572900 IDIB000G025 Account
            lines = text.split('\n')
            for line in lines:
                # Match starting digit, party name, code, amount, account, IFSC
                match = re.match(r'^(\d+)\s+([A-Za-z\s\.]+?)\s+(\d+)\s+(\d+)\s+([A-Za-z0-9]+)\s+([A-Z]{4}0[A-Z0-9]{6})', line.strip())
                if match:
                    try:
                        data.parties.append({
                            'sr_no': match.group(1),
                            'party_name': match.group(2).strip(),
                            'party_code': match.group(3),
                            'amount': float(match.group(4)),
                            'account_no': match.group(5),
                            'ifsc_code': match.group(6)
                        })
                    except ValueError:
                        pass
                        
    except Exception as e:
        print(f"Error parsing party details from {pdf_path}: {e}")
        
    return data
