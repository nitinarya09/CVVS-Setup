# checks/check_realtime_fvc_labour.py
# Check 32: FVC Labour Payments Verification Check
# Centralized Voucher Validation Suite v1.2

import os
from checks.base_check import BaseValidationCheck
from parsers.vlc_mapper import VLCMapper

class CheckRealtimeFVCLabour(BaseValidationCheck):
    check_id = "check_realtime_fvc_labour"
    name = "Check 32: FVC Labour & Wages Classification Check"
    description = "Verifies FVC Labour and Mazdoor payments using VLC data mapping and classification rules."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            narration = voucher_data.get("narration", "")
            detail_head = voucher_data.get("detail_head", "")
            object_head = voucher_data.get("object_head", "")
            vlc_mapped = voucher_data.get("vlc_mapped", False)

            # Check if narration or classification indicates labour/mazdoor payment
            is_labour = VLCMapper.is_labour_payment(narration, detail_head, object_head)

            details = {
                "narration": narration,
                "detail_head": detail_head,
                "object_head": object_head,
                "vlc_mapped": vlc_mapped,
                "is_labour_flagged": is_labour
            }

            if is_labour:
                # Validate if object head is 12 (Wages) or Detail Head 012
                if str(object_head).strip() in ("12", "012") or str(detail_head).strip() in ("012", "12"):
                    return {
                        "status": "PASS",
                        "message": "FVC Labour Payment correctly classified under Wages Head (OH 12 / DH 012)",
                        "details": details
                    }
                else:
                    return {
                        "status": "WARNING",
                        "message": f"FVC Labour Payment detected in narration ('{narration[:40]}...'), but misclassified under Head OH={object_head} / DH={detail_head} instead of Wages (OH 12 / DH 012)",
                        "details": details
                    }

            return {
                "status": "PASS",
                "message": "Standard voucher expenditure (no labour/mazdoor keywords flagged)",
                "details": details
            }

        except Exception as e:
            return {
                "status": "FAIL",
                "message": f"Error in FVC Labour Check: {str(e)}",
                "details": {}
            }
