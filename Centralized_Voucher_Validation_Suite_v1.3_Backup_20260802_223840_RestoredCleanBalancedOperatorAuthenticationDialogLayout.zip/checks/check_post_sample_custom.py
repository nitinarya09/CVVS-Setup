# checks/check_post_sample_custom.py
# Sample Custom Post-Download Check Script for Centralized Voucher Validation Suite

from checks.base_check import BaseValidationCheck

class CheckPostSampleCustom(BaseValidationCheck):
    check_id = "check_post_sample_custom"
    name = "Post-Download High Risk Treasury Concentration Check"
    description = "Sample custom post-download check that flags treasuries where more than 50% of vouchers exceed ₹50,000."
    check_type = "post_download"
    enabled = True

    def run_post_download(self, all_vouchers_data: list, output_dir: str, context: dict) -> dict:
        treasury_counts = {}
        high_val_counts = {}

        for v in all_vouchers_data:
            trs = str(v.get("treasury", "Unknown"))
            amt_str = str(v.get("amount", "0")).replace(",", "")
            try:
                amt = float(amt_str)
            except ValueError:
                amt = 0.0

            treasury_counts[trs] = treasury_counts.get(trs, 0) + 1
            if amt > 50000.0:
                high_val_counts[trs] = high_val_counts.get(trs, 0) + 1

        rows = []
        flagged_trs = []

        for trs, total in treasury_counts.items():
            high_cnt = high_val_counts.get(trs, 0)
            ratio = (high_cnt / total) * 100.0 if total > 0 else 0.0
            is_high_risk = ratio > 50.0
            if is_high_risk:
                flagged_trs.append(trs)

            rows.append({
                "Treasury": trs,
                "Total_Vouchers": total,
                "High_Value_Vouchers": high_cnt,
                "High_Value_Ratio_Pct": f"{ratio:.1f}%",
                "Risk_Level": "HIGH RISK" if is_high_risk else "NORMAL"
            })

        msg = f"Post-Download Risk Analysis: {len(flagged_trs)} high-risk treasuries identified ({', '.join(flagged_trs) if flagged_trs else 'None'})."
        return {
            "status": "COMPLETED",
            "message": msg,
            "rows": rows,
            "summary_stats": {"flagged_treasuries_count": len(flagged_trs)}
        }
