import os
import re
import time
import pypdf

class MPTCVoucherData:
    """Structured data extracted from an MPTC voucher PDF."""
    def __init__(self):
        self.form_number = ""        # e.g., "24", "34", "63"
        self.form_title = ""         # e.g., "ESTABLISHMENT PAY BILL"
        self.voucher_no = ""         # e.g., "140/2071/012023-24/0107"
        self.ddo_code = ""           # e.g., "1400204001"
        self.ddo_name = ""           # e.g., "SUPDT. OF POLICE GWALIOR"
        self.tan_no = ""             # e.g., "BPLS08812G"
        self.head_of_account = ""    # Full classification string (clean)
        self.major_head = ""         # e.g., "2071"
        self.object_head = ""        # e.g., "13"
        self.total_amount = 0.0      # Parsed total
        self.sub_vouchers = []       # List of dicts: {description, amount}
        self.digital_signatures = [] # List of dicts: {signer, role, date}
        self.bill_ref_no = ""        # e.g., "Pay Bill/Arrear/200017328452"
        self.month = ""
        self.year = ""
        self.raw_text = ""           # Full raw text for further analysis

def parse_mptc_pdf(pdf_path):
    """Parse a Show_MPTC.pdf and return MPTCVoucherData."""
    data = MPTCVoucherData()
    try:
        with open(pdf_path, 'rb') as f:
            reader = pypdf.PdfReader(f)
            text = ""
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
            
            data.raw_text = text
            
            # ── Form Number ──────────────────────────────────────────────
            # Matches: "FORM M.P.T.C. 34", "M.P.T.C. 24", "FORM MPTC 63"
            form_match = re.search(
                r'(?:FORM\s+)?M\.?P\.?\s*T\.?C\.?\s*(\d+[A-Z]?)',
                text, re.IGNORECASE
            )
            if form_match:
                data.form_number = form_match.group(1).strip()
            
            # ── Form Title ───────────────────────────────────────────────
            title_patterns = [
                r'ESTABLISHMENT\s+PAY\s+BILL',
                r'FULLY\s+VOUCH(?:ER)?ED?\s+CONTINGENT\s+BILL',
                r'Bill\s+for\s+withdrawing\s+Final\s+Payment.*?(?:General\s+)?Provident\s+Fund',
                r'GRANT[- ]IN[- ]AID\s+BILL',
                r'PENSION\s+BILL',
                r'REFUND\s+BILL',
                r'MEDICAL\s+(?:REIMBURSEMENT\s+)?BILL',
                r'TRAVELLING\s+ALLOWANCE\s+BILL',
            ]
            for pat in title_patterns:
                title_m = re.search(pat, text, re.IGNORECASE)
                if title_m:
                    data.form_title = title_m.group(0).strip()
                    break
            
            # ── Voucher No ───────────────────────────────────────────────
            voucher_match = re.search(r'Voucher\s+No\s*:?\s*([\w/\-]+)', text)
            if voucher_match:
                data.voucher_no = voucher_match.group(1).strip()
            
            # ── DDO Code and Name ────────────────────────────────────────
            # Pattern: "DDO Code : 1401003004 - D F O (T) GWALIOR"
            # Stop capturing DDO name at "TAN" or newline
            ddo_match = re.search(
                r'DDO\s+Code\s*:\s*(\d+)\s*-\s*(.+?)(?=\s*TAN|\n|$)',
                text, re.IGNORECASE
            )
            if ddo_match:
                data.ddo_code = ddo_match.group(1).strip()
                data.ddo_name = ddo_match.group(2).strip()
            
            # ── TAN No ───────────────────────────────────────────────────
            tan_match = re.search(r'TAN\s+No\s*:?\s*([A-Z0-9]{10})', text, re.IGNORECASE)
            if tan_match:
                data.tan_no = tan_match.group(1).strip()
            
            # ── Head of Account ──────────────────────────────────────────
            # Pattern: "006 - 2071 - 01 - 115 - 9999 - 9999 - 00000000 - V - 13"
            # or:      "010 - 4406 - 01 - 070 - 0101 - 4342 - 00000000 - V - 34 - 009"
            hoa_match = re.search(
                r'(\d{3}\s*-\s*\d{4}\s*-\s*\d{2}\s*-\s*\d{3}'
                r'(?:\s*-\s*[\w]+)*)',
                text
            )
            if hoa_match:
                raw_hoa = hoa_match.group(1).strip()
                # Clean: split on " - ", keep only the classification parts
                # Stop at first non-classification token (letters other than V/single digit groups)
                parts = [p.strip() for p in raw_hoa.split('-')]
                clean_parts = []
                for p in parts:
                    p_clean = p.strip()
                    if not p_clean:
                        continue
                    # Classification parts: digits, 'V', or short alphanumeric codes
                    if re.match(r'^[\d]+$', p_clean) or re.match(r'^[A-Z]$', p_clean):
                        clean_parts.append(p_clean)
                    else:
                        break  # Stop at non-classification content
                
                data.head_of_account = ' - '.join(clean_parts)
                
                # Extract major head (2nd part) and object head (9th part or last numeric)
                if len(clean_parts) >= 2:
                    data.major_head = clean_parts[1]
                if len(clean_parts) >= 9:
                    data.object_head = clean_parts[8]
                elif len(clean_parts) >= 2:
                    # Find the last numeric part as object head
                    for p in reversed(clean_parts):
                        if re.match(r'^\d+$', p) and p != clean_parts[1]:
                            data.object_head = p
                            break

            # ── Total Amount ─────────────────────────────────────────────
            # Strategy: Try multiple patterns in order of specificity
            # For FVC bills, prefer gross amount from "Pay to" line (Rs.3,28,359.00)
            # over the net/deducted amount from "UNDER RUPEES" line
            amount_patterns = [
                # Pattern 1: "TOTAL......... 6,93,391.00"
                (r'TOTAL[.\s]+\s*([\d,]+\.\d{2})', 0),
                # Pattern 2: "Pay to ... Rs.3,28,359.00" (gross amount)
                (r'Pay\s+to\s+.*?Rs\.?\s*([\d,]+\.\d{2})', re.DOTALL),
                # Pattern 3: "Total (in words) Rs. ... Only 3,28,359.00"
                (r'Total\s*\(in\s*words\).*?([\d,]+\.\d{2})', re.DOTALL | re.IGNORECASE),
                # Pattern 4: "Pay Rs 1,50,000.00" (GPF bills)
                (r'Pay\s+Rs\s*([\d,]+\.\d{2})', 0),
                # Pattern 5: "UNDER RUPEES Rs. 1,50,001.00" (fallback)
                (r'UNDER\s+RUPEES\s+Rs\.?\s*([\d,]+\.\d{2})', re.IGNORECASE),
            ]
            for pat, flags in amount_patterns:
                amt_m = re.search(pat, text, flags)
                if amt_m:
                    amount_str = amt_m.group(1).replace(',', '')
                    try:
                        data.total_amount = float(amount_str)
                        if data.total_amount > 0:
                            break
                    except ValueError:
                        continue
            
            # ── Digital Signatures ───────────────────────────────────────
            # Pattern: "Signed by : NAME\nValidity DDO/TO Sign date:DATE"
            # Some PDFs have on same line, others on separate lines
            sig_blocks = re.finditer(
                r'Signed\s+by\s*:\s*(.+?)'
                r'\s*(?:Validity|validity)\s+'
                r'(DDO|TO)\s+'
                r'Sign\s+[Dd]ate\s*:\s*'
                r'([\d\-: .]+)',
                text,
                re.DOTALL
            )
            for m in sig_blocks:
                signer = m.group(1).strip()
                # Clean signer name: take only the first line, strip noise
                signer = signer.split('\n')[0].strip()
                signer = re.sub(r'\s*Print\s+Mptc.*', '', signer, flags=re.IGNORECASE).strip()
                role = m.group(2).strip()
                date_str = m.group(3).strip()
                # Avoid duplicate entries
                if not any(s['signer'] == signer and s['role'] == role for s in data.digital_signatures):
                    data.digital_signatures.append({
                        'signer': signer,
                        'role': role,
                        'date': date_str
                    })
            
            # Also check for Treasury Officer signature without "Validity" pattern
            # Pattern: "-Treasury Officer" on its own line
            if not any(s['role'] == 'TO' for s in data.digital_signatures):
                to_match = re.search(r'Signed by\s*:\s*(.+?)(?:\n|$).*?-\s*Treasury\s+Officer', text, re.DOTALL)
                if to_match:
                    data.digital_signatures.append({
                        'signer': to_match.group(1).strip(),
                        'role': 'TO',
                        'date': ''
                    })
                    
            # ── Bill Ref ─────────────────────────────────────────────────
            # Pattern: "NO FVC Bill/200020608830" or "Bill Ref No : Pay Bill/Arrear/200017328452"
            bill_ref_patterns = [
                r'NO\s+([A-Za-z\s]+Bill/\d+)',
                r'Bill\s+Ref\s+No\s*:\s*([A-Za-z\s]+(?:Bill|Pay)[A-Za-z/\d\-]+)',
                r'Adjustable\s+by\s+(?:DPF|GPF)/(\d+)',
            ]
            for pat in bill_ref_patterns:
                ref_m = re.search(pat, text, re.IGNORECASE)
                if ref_m:
                    data.bill_ref_no = ref_m.group(1).strip()
                    break
                    
            # ── Sub-vouchers (FVC bills) ─────────────────────────────────
            # Lines like: "17 Material 488 / 08-12-2024 -  0 - 24/12/2024  1,09,453.00"
            # Match: NUMBER DESCRIPTION AMOUNT_WITH_COMMAS
            fvc_lines = re.finditer(
                r'(\d{1,3})\s+'                      # Serial number
                r'(.+?)\s+'                           # Description
                r'([\d,]+\.\d{2})\s*(?:\n|$)',        # Amount at end of line
                text
            )
            for fvc_m in fvc_lines:
                try:
                    serial = int(fvc_m.group(1))
                    desc = fvc_m.group(2).strip()
                    amt = float(fvc_m.group(3).replace(',', ''))
                    # Filter: serial numbers typically 1-99 for sub-vouchers
                    # Exclude noise lines (e.g., instructions, page numbers)
                    if 1 <= serial <= 200 and amt > 0 and len(desc) > 3:
                        # Skip lines that look like instructions or certificates
                        skip_keywords = ['certif', 'instruct', 'subsidiary', 'rule', 'bill must']
                        if not any(kw in desc.lower() for kw in skip_keywords):
                            data.sub_vouchers.append({
                                'description': desc,
                                'amount': amt
                            })
                except Exception:
                    pass

    except Exception as e:
        print(f"Error parsing MPTC PDF {pdf_path}: {e}")
        
    return data
