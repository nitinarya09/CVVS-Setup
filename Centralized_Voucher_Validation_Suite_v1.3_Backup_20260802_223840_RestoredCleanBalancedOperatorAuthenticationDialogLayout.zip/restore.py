import re
import time
"""
restore.py  —  Selective file / folder recovery from .backups snapshots
-----------------------------------------------------------------------
Usage (interactive):
    py -3 restore.py

Usage (command-line):
    py -3 restore.py --list
        Lists all available backup snapshots.

    py -3 restore.py --snapshot backup_20260718_173502 --find epayment_downloader.py
        Shows where a file appears inside a specific snapshot.

    py -3 restore.py --snapshot backup_20260718_173502 --restore "TI Studio Pro/POL Analyser/epayment_downloader.py"
        Restores that file from the chosen snapshot back to the live source tree.

    py -3 restore.py --snapshot backup_20260718_173502 --restore "TI Studio Pro/POL Analyser"
        Restores every backed-up file inside that folder from the snapshot.
"""

import os
import sys
import shutil
import argparse
import datetime

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
BACKUP_ROOT = os.path.join(BASE_DIR, ".backups")


# ── Helpers ───────────────────────────────────────────────────────────────────
def list_snapshots():
    """Return sorted list of (snapshot_name, mtime_str) tuples."""
    if not os.path.exists(BACKUP_ROOT):
        return []
    snapshots = []
    for item in sorted(os.listdir(BACKUP_ROOT)):
        item_path = os.path.join(BACKUP_ROOT, item)
        if os.path.isdir(item_path) and item.startswith("backup_"):
            mtime = os.path.getmtime(item_path)
            mtime_str = datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d  %H:%M:%S")
            snapshots.append((item, mtime_str))
    return snapshots


def find_in_snapshot(snapshot_name, keyword):
    """Return list of relative paths inside snapshot whose name contains keyword."""
    snap_dir = os.path.join(BACKUP_ROOT, snapshot_name)
    results  = []
    for root, dirs, files in os.walk(snap_dir):
        for f in files:
            if keyword.lower() in f.lower():
                rel = os.path.relpath(os.path.join(root, f), snap_dir)
                results.append(rel)
    return results


def restore_path(snapshot_name, rel_target):
    """
    Restore a file or folder from snapshot back to the live source tree.
    rel_target  — relative path inside the snapshot, e.g.
                  "TI Studio Pro/POL Analyser/epayment_downloader.py"
                  or just a folder like "TI Studio Pro/POL Analyser"
    Returns list of (src, dst) pairs that were copied.
    """
    snap_dir   = os.path.join(BACKUP_ROOT, snapshot_name)
    # Normalise separators
    rel_target = rel_target.replace("/", os.sep).replace("\\", os.sep)
    src_path   = os.path.join(snap_dir, rel_target)
    dst_path   = os.path.join(BASE_DIR, rel_target)

    if not os.path.exists(src_path):
        print(f"[RESTORE] FAILED - Not found in snapshot: {src_path}")
        return []

    copied = []

    if os.path.isfile(src_path):
        os.makedirs(os.path.dirname(dst_path), exist_ok=True)
        shutil.copy2(src_path, dst_path)
        copied.append((src_path, dst_path))
        print(f"[RESTORE] OK - Restored file: {dst_path}")

    elif os.path.isdir(src_path):
        for root, dirs, files in os.walk(src_path):
            for f in files:
                s = os.path.join(root, f)
                rel_file = os.path.relpath(s, snap_dir)
                d = os.path.join(BASE_DIR, rel_file)
                os.makedirs(os.path.dirname(d), exist_ok=True)
                shutil.copy2(s, d)
                copied.append((s, d))
                print(f"[RESTORE]    {rel_file}")
        print(f"[RESTORE] OK - Restored {len(copied)} file(s) from folder '{rel_target}'")

    return copied


# ── Interactive mode ──────────────────────────────────────────────────────────
def interactive():
    print("=" * 60)
    print("  TI Studio — Backup Restore Utility")
    print("=" * 60)

    snapshots = list_snapshots()
    if not snapshots:
        print("No backup snapshots found in .backups/")
        return

    print("\nAvailable snapshots:\n")
    for i, (name, mtime) in enumerate(snapshots, 1):
        print(f"  [{i}]  {name}   ({mtime})")

    print()
    choice = input("Enter snapshot number to restore from (or 'q' to quit): ").strip()
    if choice.lower() == "q":
        return
    try:
        idx = int(choice) - 1
        snapshot_name = snapshots[idx][0]
    except (ValueError, IndexError):
        print("Invalid choice.")
        return

    print(f"\nSelected snapshot: {snapshot_name}")
    print("\nOptions:")
    print("  [1]  Search for a file by name")
    print("  [2]  Restore a specific file (enter relative path)")
    print("  [3]  Restore an entire folder (enter relative folder path)")
    print()
    action = input("Choose action [1/2/3]: ").strip()

    if action == "1":
        keyword = input("Enter filename keyword to search: ").strip()
        results = find_in_snapshot(snapshot_name, keyword)
        if not results:
            print(f"No files matching '{keyword}' found in snapshot.")
        else:
            print(f"\nFound {len(results)} match(es):\n")
            for i, r in enumerate(results, 1):
                print(f"  [{i}]  {r}")
            print()
            pick = input("Enter number to restore that file (or Enter to skip): ").strip()
            if pick.isdigit():
                rel = results[int(pick) - 1]
                confirm = input(f"\nRestore '{rel}' from '{snapshot_name}'? This will overwrite the live file. [y/N]: ").strip().lower()
                if confirm == "y":
                    restore_path(snapshot_name, rel)
                else:
                    print("Cancelled.")

    elif action == "2":
        rel = input("Enter relative path of file to restore (e.g. TI Studio Pro/api.py): ").strip()
        confirm = input(f"\nRestore '{rel}' from '{snapshot_name}'? This will overwrite the live file. [y/N]: ").strip().lower()
        if confirm == "y":
            restore_path(snapshot_name, rel)
        else:
            print("Cancelled.")

    elif action == "3":
        rel = input("Enter relative path of folder to restore (e.g. TI Studio Pro/POL Analyser): ").strip()
        confirm = input(f"\nRestore ALL backed-up files in '{rel}' from '{snapshot_name}'? [y/N]: ").strip().lower()
        if confirm == "y":
            restore_path(snapshot_name, rel)
        else:
            print("Cancelled.")

    else:
        print("Invalid action.")


# ── CLI mode ──────────────────────────────────────────────────────────────────
def cli():
    parser = argparse.ArgumentParser(
        description="Restore files/folders from a .backups snapshot."
    )
    parser.add_argument("--list",     action="store_true", help="List all backup snapshots")
    parser.add_argument("--snapshot", type=str, help="Snapshot name, e.g. backup_20260718_173502")
    parser.add_argument("--find",     type=str, help="Keyword to search for inside snapshot")
    parser.add_argument("--restore",  type=str, help="Relative path to file or folder to restore")
    args = parser.parse_args()

    if args.list:
        snapshots = list_snapshots()
        if not snapshots:
            print("No snapshots found.")
        else:
            print(f"\n{'#':<4}  {'Snapshot Name':<35}  {'Created'}")
            print("-" * 60)
            for i, (name, mtime) in enumerate(snapshots, 1):
                print(f"{i:<4}  {name:<35}  {mtime}")
        return

    if args.find:
        if not args.snapshot:
            print("--find requires --snapshot <name>")
            sys.exit(1)
        results = find_in_snapshot(args.snapshot, args.find)
        if not results:
            print(f"No matches for '{args.find}' in {args.snapshot}")
        else:
            for r in results:
                print(r)
        return

    if args.restore:
        if not args.snapshot:
            print("--restore requires --snapshot <name>")
            sys.exit(1)
        restore_path(args.snapshot, args.restore)
        return

    # No flags — fall through to interactive
    interactive()


if __name__ == "__main__":
    # If any CLI flags provided, use CLI mode; otherwise interactive
    if len(sys.argv) > 1:
        cli()
    else:
        interactive()
