# automation/network_monitor.py
# Centralized Voucher Validation Suite v3.1.3 — Disk space monitoring and circuit breaker

import os
import time
import shutil

# =========================================================
# F1: Disk Space Monitoring
# =========================================================

def check_disk_space(download_dir, estimated_items, avg_item_size_kb=500):
    """Check if download drive has enough space before starting batch.
    
    Args:
        download_dir: Path to the download directory
        estimated_items: Number of items to download
        avg_item_size_kb: Average size per item in KB (default 500KB for vouchers)
    
    Returns:
        tuple: (ok: bool, message: str)
            - ok=True: Enough space
            - ok=False with warning message if tight
    """
    try:
        usage = shutil.disk_usage(download_dir)
        free_mb = usage.free / (1024 * 1024)
        estimated_mb = (estimated_items * avg_item_size_kb) / 1024
        
        if estimated_mb > free_mb * 0.95:
            return False, (
                f"🛑 INSUFFICIENT DISK SPACE: Need ~{estimated_mb:,.0f} MB "
                f"but only {free_mb:,.0f} MB free on {os.path.splitdrive(download_dir)[0]}. "
                f"Free up space before starting."
            )
        elif estimated_mb > free_mb * 0.80:
            return True, (
                f"⚠️ LOW DISK SPACE WARNING: Need ~{estimated_mb:,.0f} MB, "
                f"{free_mb:,.0f} MB free on {os.path.splitdrive(download_dir)[0]}. "
                f"Consider freeing space."
            )
        else:
            return True, (
                f"💾 Disk space OK: ~{estimated_mb:,.0f} MB needed, "
                f"{free_mb:,.0f} MB available on {os.path.splitdrive(download_dir)[0]}"
            )
    except Exception as e:
        return True, f"⚠️ Could not check disk space: {e}"

def check_disk_space_periodic(download_dir, min_mb=200):
    """Periodic disk space check during batch processing.
    
    Args:
        download_dir: Path to the download directory
        min_mb: Minimum free space in MB before warning
    
    Returns:
        tuple: (ok: bool, message: str)
    """
    try:
        usage = shutil.disk_usage(download_dir)
        free_mb = usage.free / (1024 * 1024)
        
        if free_mb < min_mb:
            return False, (
                f"🛑 CRITICAL: Only {free_mb:,.0f} MB free on "
                f"{os.path.splitdrive(download_dir)[0]}! "
                f"Auto-pausing to prevent data corruption."
            )
        return True, ""
    except Exception:
        return True, ""

# =========================================================
# F2: Circuit Breaker
# =========================================================

class CircuitBreaker:
    """Automatically pauses batch processing after consecutive failures.
    
    Prevents wasting hours of compute on a down server.
    Auto-resumes after cooldown period with exponential backoff.
    """
    
    def __init__(self, threshold=10, cooldown_seconds=300, log_fn=None):
        """
        Args:
            threshold: Number of consecutive failures before tripping
            cooldown_seconds: Initial cooldown period in seconds (default 5 min)
            log_fn: Logging function
        """
        self.threshold = threshold
        self.initial_cooldown = cooldown_seconds
        self.cooldown_seconds = cooldown_seconds
        self.log_fn = log_fn
        self.consecutive_failures = 0
        self.is_tripped = False
        self.trip_time = None
        self.trip_count = 0  # How many times it has tripped in this batch
    
    def _log(self, msg):
        if self.log_fn:
            try:
                self.log_fn(msg)
            except Exception:
                pass
    
    def record_success(self):
        """Record a successful operation. Resets the failure counter."""
        self.consecutive_failures = 0
        if self.is_tripped:
            self.is_tripped = False
            self._log("✅ Circuit breaker reset — operations resuming normally.")
    
    def record_failure(self):
        """Record a failed operation.
        
        Returns:
            bool: True if the circuit breaker has tripped (workers should pause)
        """
        self.consecutive_failures += 1
        
        if self.consecutive_failures >= self.threshold and not self.is_tripped:
            self.is_tripped = True
            self.trip_time = time.time()
            self.trip_count += 1
            
            # Exponential backoff on cooldown for repeated trips
            self.cooldown_seconds = min(
                self.initial_cooldown * (2 ** (self.trip_count - 1)),
                1800  # Cap at 30 minutes
            )
            
            cooldown_min = self.cooldown_seconds / 60
            self._log(
                f"\n{'━' * 60}\n"
                f"  🛑 CIRCUIT BREAKER TRIPPED\n"
                f"  {self.consecutive_failures} consecutive failures detected.\n"
                f"  Server may be down or unresponsive.\n"
                f"  Auto-resuming in {cooldown_min:.0f} minutes...\n"
                f"  (Trip #{self.trip_count} this batch)\n"
                f"{'━' * 60}\n"
            )
            return True
        
        return False
    
    def should_pause(self):
        """Check if workers should currently be paused.
        
        Returns:
            bool: True if paused (circuit is open), False if OK to proceed
        """
        if not self.is_tripped:
            return False
        
        # Check if cooldown has elapsed
        elapsed = time.time() - self.trip_time
        if elapsed >= self.cooldown_seconds:
            self._log(
                f"⏰ Circuit breaker cooldown elapsed ({self.cooldown_seconds / 60:.0f} min). "
                f"Auto-resuming operations..."
            )
            self.is_tripped = False
            self.consecutive_failures = 0
            return False
        
        return True
    
    def get_status(self):
        """Get human-readable circuit breaker status."""
        if not self.is_tripped:
            return f"✅ OK (consecutive failures: {self.consecutive_failures}/{self.threshold})"
        
        remaining = self.cooldown_seconds - (time.time() - self.trip_time)
        return f"🛑 TRIPPED — resuming in {max(0, remaining):.0f}s"
