import os
import glob
from checks.base_check import BaseValidationCheck
from parsers.mptc_parser import parse_mptc_pdf
from parsers.party_details_parser import parse_party_details_pdf
from parsers.classification_data import ClassificationLookup, FORM_BILL_TYPE_MAP, DEDUCTION_CODES

class AttachmentCompletenessCheck(BaseValidationCheck):
    check_id = "check_realtime_attachment_completeness"
    name = "Voucher Attachment Completeness Check"
    description = "Checks for presence of MPTC, Party Details, and appropriate attachments based on bill type."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            files_found = os.listdir(download_folder) if os.path.exists(download_folder) else []
            missing = []
            manual_review_needed = False

            mptc_found = "Show_MPTC.pdf" in files_found
            if not mptc_found:
                missing.append("Show_MPTC.pdf")

            party_found = "Party_Details.pdf" in files_found or any(f.startswith("bill_party_") and f.endswith(".pdf") for f in files_found)
            if not party_found:
                missing.append("Party_Details.pdf / bill_party_*.pdf")

            # Need to parse form_number to know which attachments are required
            mptc_file = os.path.join(download_folder, "Show_MPTC.pdf")
            form_number = ""
            if mptc_found:
                try:
                    mptc_data = parse_mptc_pdf(mptc_file)
                    form_number = mptc_data.get("form_number", "").strip()
                except:
                    pass

            # Check for PayBill Excel schedule files (epay_*.xls, PayBill_*.xls, *.xls, *.xlsx)
            paybill_excel_files = [f for f in files_found if f.endswith((".xls", ".xlsx"))]
            is_paybill = (
                form_number in ("24", "Form 24", "203") or
                any(k in form_number.lower() for k in ("pay", "salary"))
            )

            # Also check party details if available
            if not is_paybill:
                party_file = os.path.join(download_folder, "Party_Details.pdf")
                if not os.path.exists(party_file):
                    party_pdfs = glob.glob(os.path.join(download_folder, "bill_party_*.pdf"))
                    if party_pdfs: party_file = party_pdfs[0]
                if os.path.exists(party_file):
                    try:
                        party_data = parse_party_details_pdf(party_file)
                        btype = party_data.get("bill_type", "").lower()
                        if any(k in btype for k in ("pay", "salary", "establishment")):
                            is_paybill = True
                    except:
                        pass

            attachments = [f for f in files_found if f.startswith("attachment_") and f.endswith(".pdf")]
            
            bill_types_requiring_attachment = ["28", "34", "46", "24A", "Form 28", "Form 34", "Form 46", "Form 24A"] # FVC, GIA, Medical, TA
            bill_types_requiring_manual = ["28", "46", "24A", "Form 28", "Form 46", "Form 24A"] # GIA, Medical, TA

            if is_paybill:
                # Pay Bills do not require PDF attachments, but MUST contain a PayBill Excel schedule file
                if not paybill_excel_files:
                    missing.append("PayBill Excel Schedule (epay_*.xls / PayBill_*.xls)")
            else:
                if form_number in bill_types_requiring_attachment:
                    if not attachments:
                        missing.append(f"attachment_*.pdf (required for Form {form_number})")
            
            if not is_paybill and form_number in bill_types_requiring_manual:
                manual_review_needed = True

            details = {
                "files_found": files_found,
                "missing": missing,
                "manual_review_needed": manual_review_needed,
                "is_paybill": is_paybill,
                "form_number": form_number
            }

            if manual_review_needed:
                return {"status": "MANUAL_REVIEW", "message": "OCR required for Medical/TA/GIA attachment verification", "details": details}
            
            if not missing:
                msg = "PayBill Excel schedule & main files present" if is_paybill else "All expected files present"
                return {"status": "PASS", "message": msg, "details": details}
            else:
                return {"status": "WARNING", "message": f"Missing: {', '.join(missing)}", "details": details}

        except Exception as e:
            return {"status": "FAIL", "message": f"Error during check: {str(e)}", "details": {}}
