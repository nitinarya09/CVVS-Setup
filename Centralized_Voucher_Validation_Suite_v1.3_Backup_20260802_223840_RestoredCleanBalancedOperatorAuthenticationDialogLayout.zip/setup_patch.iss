; Inno Setup Patch Script for Centralized Voucher Validation Suite v1.2
; Lightweight update patch: overwrites application binary, data, and logic files.

#define MyAppName "Centralized Voucher Validation Suite"
#define MyAppVersion "1.2"
#define MyAppExeName "Centralized_Voucher_Validation_Suite.exe"
#define MyAppPublisher "Office of the Accountant General (A&E) MP"

[Setup]
AppId={{8A19F8D2-4C7B-4E3A-91D0-E9A284F3612B}
AppName={#MyAppName} (Patch Update)
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} Patch v{#MyAppVersion}
AppPublisher={#MyAppPublisher}
LicenseFile=terms.txt
DefaultDirName={localappdata}\Programs\{#MyAppName}
UsePreviousAppDir=yes
CreateAppDir=yes
DisableProgramGroupPage=yes
DisableDirPage=no
DisableReadyPage=no
DisableFinishedPage=no
OutputDir=output
OutputBaseFilename=Centralized_Voucher_Validation_Suite_Patch_v1.2
SetupIconFile=cag_logo.ico
PrivilegesRequired=lowest
CloseApplications=force
RestartApplications=no
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
DisableWelcomePage=no
UninstallDisplayIcon={app}\cag_logo.ico

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Files]
Source: "Centralized_Voucher_Validation_Suite.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "license_generator.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "ddo.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "terms.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "cag_logo.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "cag_logo.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "logo.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "logo.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "data\*"; DestDir: "{app}\data"; Flags: ignoreversion recursesubdirs createallsubdirs

[Dirs]
Name: "{userdesktop}\CVVS Downloads"
Name: "{app}\USER_DATA"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

