import time
"""
Centralized Voucher Validation Suite - PySide6 Dialog Classes (Migration from CustomTkinter)
All 8 dialog classes as QDialog subclasses with dark-themed QSS styling.
"""

import os
import sys
import base64
import datetime
import subprocess

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QWidget, QRadioButton, QButtonGroup, QCalendarWidget,
    QFrame, QApplication, QMessageBox, QSizePolicy, QGridLayout, QComboBox,
    QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView
)
from PySide6.QtCore import Qt, QDate, QSize, QByteArray, QBuffer
from PySide6.QtGui import QFont, QPixmap, QImage, QIcon, QColor

if sys.platform == "win32":
    import winreg

# ---------------------------------------------------------------------------
# Licensing helpers (carried over from dialogs.py)
# ---------------------------------------------------------------------------

PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0qxkAIHGUzKlMgbucEfP
ul2dYvPzAPOf+09rKzXMTmxLITPqrOaXiDZ5HxpWF5pvrobwIz+TZ8lGtd6kp9ic
aMDC5OBVFA/oXnQR6wq5Eb23JXiSIisEW72REqbhocbgTT0RepcKJBbg2vgksoQZ
uj1E+GUTCP+Vd3vJdXvij5eRPlJWrCzp2HJptMqZdcrAez20qauhCMs0LBTQQBCb
1dqblIAPHth+18HyOSdvyrdkoPH3LIJzZqHPLUF1hT1mDHSAFTxKDMVKASeW2Lpi
NcxGw7CwWZA4HPZutX0ZQVk6uotcvuW5TnbQkcJanYDwbwGxpZ1AFr+jCDDZsN/i
5wIDAQAB
-----END PUBLIC KEY-----"""

if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(sys.executable)
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))


def get_machine_id():
    """Retrieve a stable hardware/machine identifier."""
    try:
        output = subprocess.check_output(
            'wmic csproduct get uuid', creationflags=0x08000000
        ).decode('utf-8').strip()
        lines = [line.strip() for line in output.split('\n') if line.strip()]
        if len(lines) > 1 and len(lines[1]) > 10:
            return lines[1]
    except Exception:
        pass

    try:
        cmd = [
            'powershell', '-NoProfile', '-Command',
            '(Get-CimInstance -Class Win32_ComputerSystemProduct).UUID'
        ]
        output = subprocess.check_output(
            cmd, creationflags=0x08000000
        ).decode('utf-8').strip()
        if output and len(output) > 10:
            return output
    except Exception:
        pass

    try:
        registry = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
        key = winreg.OpenKey(registry, r"SOFTWARE\Microsoft\Cryptography")
        machine_guid, _ = winreg.QueryValueEx(key, "MachineGuid")
        if machine_guid:
            return machine_guid
    except Exception:
        pass

    return "UNKNOWN_MACHINE"


def verify_key(key_str, current_machine_id):
    """Verify a base64-encoded license key against the embedded public key."""
    if not key_str:
        return False, "No key provided."
    try:
        decoded = base64.b64decode(key_str.encode('utf-8')).decode('utf-8')
        parts = decoded.split('|')
        if len(parts) != 3:
            return False, "Invalid license key format."

        expiry_str, hwid, sig_hex = parts

        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.serialization import load_pem_public_key

        public_key = load_pem_public_key(PUBLIC_KEY_PEM.encode('utf-8'))
        raw_data = f"{expiry_str}|{hwid}"

        try:
            public_key.verify(
                bytes.fromhex(sig_hex),
                raw_data.encode('utf-8'),
                padding.PKCS1v15(),
                hashes.SHA256()
            )
        except Exception:
            return False, "License signature mismatch."

        if hwid != current_machine_id:
            return False, "License key is for a different machine ID."

        if expiry_str != "NEVER":
            try:
                exp_date = datetime.datetime.strptime(expiry_str, "%Y-%m-%d").date()
                if datetime.date.today() > exp_date:
                    return False, f"License expired on {expiry_str}."
            except Exception:
                return False, "Invalid expiry date in license key."
        return True, expiry_str
    except Exception as e:
        return False, f"Failed to decode key: {e}"


def save_license_key(key):
    """Persist the license key to the Windows registry and a local file."""
    if sys.platform == "win32":
        try:
            key_reg = winreg.CreateKey(
                winreg.HKEY_CURRENT_USER, r"Software\IFMIS_Suite"
            )
            winreg.SetValueEx(key_reg, "LicenseKey", 0, winreg.REG_SZ, key)
            winreg.CloseKey(key_reg)
        except Exception as e:
            print(f"Registry write failed: {e}")

    try:
        with open(os.path.join(APP_DIR, "license.key"), "w", encoding="utf-8") as f:
            f.write(key.strip())
    except Exception as e:
        print(f"License file write failed: {e}")


def read_license_key():
    """Read a previously saved license key from registry or file."""
    if sys.platform == "win32":
        try:
            key_reg = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, r"Software\IFMIS_Suite"
            )
            value, _ = winreg.QueryValueEx(key_reg, "LicenseKey")
            winreg.CloseKey(key_reg)
            if value:
                return value.strip()
        except Exception:
            pass

    try:
        key_path = os.path.join(APP_DIR, "license.key")
        if os.path.exists(key_path):
            with open(key_path, "r", encoding="utf-8") as f:
                return f.read().strip()
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Shared QSS & helpers
# ---------------------------------------------------------------------------

DARK_BG = "#0d1117"
DARK_SIDEBAR = "#161b22"
DARK_CARD = "#21262d"
DARK_BORDER = "#30363d"
DARK_TEXT = "#f8fafc"
DARK_MUTED = "#8b949e"
DARK_ACCENT = "#00c9a7"
DARK_ACCENT_HOVER = "#00e5bf"
DARK_ENTRY_BG = "#0d1117"

FONT_FAMILY = "Segoe UI"

# Base QSS applied to every dialog
BASE_DIALOG_QSS = f"""
    QDialog {{
        background-color: {DARK_BG};
    }}
    QLabel {{
        color: {DARK_TEXT};
        font-family: '{FONT_FAMILY}';
    }}
    QLineEdit {{
        background-color: {DARK_SIDEBAR};
        color: {DARK_TEXT};
        border: 1px solid {DARK_BORDER};
        border-radius: 8px;
        padding: 6px 10px;
        font-family: '{FONT_FAMILY}';
        font-size: 12px;
        selection-background-color: {DARK_ACCENT};
    }}
    QLineEdit:focus {{
        border: 1px solid {DARK_ACCENT};
    }}
    QPushButton {{
        background-color: {DARK_ACCENT};
        color: {DARK_BG};
        border: none;
        border-radius: 8px;
        padding: 8px 16px;
        font-family: '{FONT_FAMILY}';
        font-size: 12px;
        font-weight: bold;
    }}
    QPushButton:hover {{
        background-color: {DARK_ACCENT_HOVER};
    }}
    QPushButton:pressed {{
        background-color: #009e85;
    }}
    QScrollArea {{
        background-color: {DARK_SIDEBAR};
        border: 1px solid {DARK_BORDER};
        border-radius: 8px;
    }}
    QScrollBar:vertical {{
        background: {DARK_SIDEBAR};
        width: 10px;
        border-radius: 5px;
    }}
    QScrollBar::handle:vertical {{
        background: {DARK_BORDER};
        min-height: 30px;
        border-radius: 5px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: {DARK_MUTED};
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0px;
    }}
    QRadioButton {{
        color: {DARK_TEXT};
        font-family: '{FONT_FAMILY}';
        font-size: 11px;
        spacing: 8px;
    }}
    QRadioButton::indicator {{
        width: 16px;
        height: 16px;
        border: 2px solid {DARK_MUTED};
        border-radius: 9px;
        background: transparent;
    }}
    QRadioButton::indicator:checked {{
        background-color: {DARK_ACCENT};
        border-color: {DARK_ACCENT};
    }}
    QRadioButton::indicator:hover {{
        border-color: {DARK_ACCENT};
    }}
    QComboBox {{
        background-color: {DARK_SIDEBAR};
        color: {DARK_TEXT};
        border: 1px solid {DARK_BORDER};
        border-radius: 8px;
        padding: 4px 8px;
        font-family: '{FONT_FAMILY}';
        font-size: 11px;
        min-height: 24px;
    }}
    QComboBox:hover {{
        border-color: {DARK_MUTED};
    }}
    QComboBox:focus {{
        border-color: {DARK_ACCENT};
    }}
    QComboBox::drop-down {{
        subcontrol-origin: padding;
        subcontrol-position: top right;
        width: 20px;
        border-left: 1px solid {DARK_BORDER};
        border-top-right-radius: 8px;
        border-bottom-right-radius: 8px;
        background-color: transparent;
    }}
    QComboBox::down-arrow {{
        image: none;
        width: 0;
        height: 0;
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-top: 5px solid {DARK_MUTED};
        margin-right: 4px;
    }}
    QComboBox QAbstractItemView {{
        background-color: {DARK_CARD};
        color: {DARK_TEXT};
        border: 1px solid {DARK_BORDER};
        border-radius: 4px;
        padding: 4px;
        selection-background-color: {DARK_ACCENT};
        selection-color: {DARK_BG};
        outline: none;
    }}
"""

OUTLINE_BTN_QSS = f"""
    QPushButton {{
        background-color: transparent;
        color: {DARK_MUTED};
        border: 1px solid {DARK_BORDER};
        border-radius: 8px;
        padding: 8px 16px;
        font-family: '{FONT_FAMILY}';
        font-size: 12px;
    }}
    QPushButton:hover {{
        background-color: {DARK_SIDEBAR};
        color: {DARK_TEXT};
    }}
"""


def _center_on_parent(dialog, parent, width, height):
    """Position *dialog* centered over *parent*."""
    if parent is not None:
        parent_geo = parent.geometry()
        x = parent_geo.x() + (parent_geo.width() - width) // 2
        y = parent_geo.y() + (parent_geo.height() - height) // 2
    else:
        screen = QApplication.primaryScreen()
        if screen:
            sg = screen.availableGeometry()
            x = sg.x() + (sg.width() - width) // 2
            y = sg.y() + (sg.height() - height) // 2
        else:
            x, y = 200, 200
    dialog.setGeometry(x, y, width, height)


# ═══════════════════════════════════════════════════════════════════════════
# 1. ActivationDialog
# ═══════════════════════════════════════════════════════════════════════════

class ActivationDialog(QDialog):
    """Product activation dialog – shows HWID & accepts a license key."""

    def __init__(self, parent=None, machine_id=None):
        super().__init__(parent)
        self.machine_id = machine_id or get_machine_id()
        self.result = False

        self.setWindowTitle("Centralized Voucher Validation Suite - Activation")
        self.setFixedSize(540, 380)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setStyleSheet(BASE_DIALOG_QSS)
        self.setModal(True)
        _center_on_parent(self, parent, 540, 380)

        self._build_gui()

    def _build_gui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 25, 30, 20)
        layout.setSpacing(8)

        # Title
        title = QLabel("\U0001f6e1\ufe0f Product Activation Required")
        title.setFont(QFont(FONT_FAMILY, 18, QFont.Bold))
        title.setStyleSheet(f"color: {DARK_ACCENT};")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Subtitle
        sub = QLabel(
            "Please register this software with a valid license key generated by Nitin Arya."
        )
        sub.setFont(QFont(FONT_FAMILY, 10))
        sub.setStyleSheet(f"color: {DARK_MUTED};")
        sub.setAlignment(Qt.AlignCenter)
        sub.setWordWrap(True)
        layout.addWidget(sub)
        layout.addSpacing(10)

        # Info frame
        info_frame = QFrame()
        info_frame.setStyleSheet(
            f"QFrame {{ background-color: {DARK_SIDEBAR}; border: 1px solid {DARK_BORDER}; border-radius: 12px; }}"
        )
        info_layout = QVBoxLayout(info_frame)
        info_layout.setContentsMargins(15, 15, 15, 15)
        info_layout.setSpacing(4)

        hwid_label = QLabel("Your Machine Hardware ID (HWID):")
        hwid_label.setFont(QFont(FONT_FAMILY, 11, QFont.Bold))
        info_layout.addWidget(hwid_label)

        hwid_row = QHBoxLayout()
        hwid_row.setSpacing(10)

        self.entry_hwid = QLineEdit(self.machine_id)
        self.entry_hwid.setReadOnly(True)
        self.entry_hwid.setFont(QFont("Consolas", 11, QFont.Bold))
        self.entry_hwid.setStyleSheet(
            f"QLineEdit {{ background-color: {DARK_ENTRY_BG}; color: {DARK_ACCENT}; "
            f"border: 1px solid {DARK_BORDER}; border-radius: 8px; padding: 5px 10px; }}"
        )
        hwid_row.addWidget(self.entry_hwid, 1)

        btn_copy = QPushButton("\U0001f4cb Copy")
        btn_copy.setFixedSize(80, 30)
        btn_copy.setStyleSheet(
            f"QPushButton {{ background-color: transparent; border: 1px solid {DARK_ACCENT}; "
            f"color: {DARK_ACCENT}; border-radius: 8px; font-family: '{FONT_FAMILY}'; "
            f"font-size: 11px; font-weight: bold; padding: 4px 8px; }}"
            f"QPushButton:hover {{ background-color: #0c362d; }}"
        )
        btn_copy.clicked.connect(self._copy_hwid)
        hwid_row.addWidget(btn_copy)

        info_layout.addLayout(hwid_row)
        layout.addWidget(info_frame)
        layout.addSpacing(10)

        # Key input
        key_label = QLabel("Enter Activation Key:")
        key_label.setFont(QFont(FONT_FAMILY, 11, QFont.Bold))
        layout.addWidget(key_label)

        self.entry_key = QLineEdit()
        self.entry_key.setPlaceholderText("Paste your base64-encoded license key here...")
        self.entry_key.setFont(QFont("Consolas", 10))
        self.entry_key.setFixedHeight(35)
        self.entry_key.setStyleSheet(
            f"QLineEdit {{ background-color: {DARK_SIDEBAR}; color: {DARK_ACCENT}; "
            f"border: 1px solid {DARK_BORDER}; border-radius: 8px; padding: 5px 10px; }}"
            f"QLineEdit:focus {{ border-color: {DARK_ACCENT}; }}"
        )
        layout.addWidget(self.entry_key)
        layout.addSpacing(10)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)

        self.btn_activate = QPushButton("\u26a1 Activate Software")
        self.btn_activate.setFixedHeight(38)
        self.btn_activate.setFont(QFont(FONT_FAMILY, 12, QFont.Bold))
        self.btn_activate.clicked.connect(self._activate_license)
        btn_layout.addWidget(self.btn_activate, 1)

        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setFixedSize(100, 38)
        self.btn_cancel.setFont(QFont(FONT_FAMILY, 12))
        self.btn_cancel.setStyleSheet(OUTLINE_BTN_QSS)
        self.btn_cancel.clicked.connect(self.reject)
        btn_layout.addWidget(self.btn_cancel)

        layout.addLayout(btn_layout)

    def _copy_hwid(self):
        clipboard = QApplication.clipboard()
        clipboard.setText(self.machine_id)
        QMessageBox.information(self, "Copied", "Hardware ID copied to clipboard.")

    def _activate_license(self):
        key = self.entry_key.text().strip()
        valid, msg = verify_key(key, self.machine_id)
        if valid:
            save_license_key(key)
            QMessageBox.information(self, "Success", "Centralized Voucher Validation Suite activated successfully!")
            self.result = True
            self.accept()
        else:
            QMessageBox.critical(
                self, "Activation Failed", f"Invalid activation key:\n{msg}"
            )

    def reject(self):
        self.result = False
        super().reject()


# ═══════════════════════════════════════════════════════════════════════════
# 2. DatePickerDialog
# ═══════════════════════════════════════════════════════════════════════════

class DatePickerDialog(QDialog):
    """Calendar date picker – sets the selected date on *target_entry* (QLineEdit)."""

    def __init__(self, parent=None, target_entry=None):
        super().__init__(parent)
        self.target_entry = target_entry

        self.setWindowTitle("Select Date")
        self.setFixedSize(300, 360)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setModal(True)
        _center_on_parent(self, parent, 300, 360)

        self.setStyleSheet(BASE_DIALOG_QSS + self._calendar_qss())
        self._build_gui()

    @staticmethod
    def _calendar_qss():
        return f"""
            QCalendarWidget {{
                background-color: {DARK_SIDEBAR};
                color: {DARK_TEXT};
                font-family: '{FONT_FAMILY}';
                font-size: 11px;
            }}
            QCalendarWidget QToolButton {{
                color: {DARK_ACCENT};
                background-color: {DARK_CARD};
                border: none;
                border-radius: 4px;
                padding: 4px 8px;
                font-family: '{FONT_FAMILY}';
                font-weight: bold;
                font-size: 11px;
            }}
            QCalendarWidget QToolButton:hover {{
                background-color: {DARK_BORDER};
            }}
            QCalendarWidget QToolButton::menu-indicator {{
                image: none;
            }}
            QCalendarWidget QMenu {{
                background-color: {DARK_CARD};
                color: {DARK_TEXT};
                font-family: '{FONT_FAMILY}';
            }}
            QCalendarWidget QMenu::item:selected {{
                background-color: {DARK_ACCENT};
                color: {DARK_BG};
            }}
            QCalendarWidget QSpinBox {{
                background-color: {DARK_CARD};
                color: {DARK_TEXT};
                border: 1px solid {DARK_BORDER};
                border-radius: 4px;
                font-family: '{FONT_FAMILY}';
                selection-background-color: {DARK_ACCENT};
            }}
            QCalendarWidget QAbstractItemView {{
                background-color: {DARK_SIDEBAR};
                color: {DARK_TEXT};
                selection-background-color: {DARK_ACCENT};
                selection-color: {DARK_BG};
                font-family: '{FONT_FAMILY}';
                outline: none;
            }}
            QCalendarWidget QAbstractItemView:enabled {{
                color: {DARK_TEXT};
            }}
            QCalendarWidget QAbstractItemView:disabled {{
                color: {DARK_MUTED};
            }}
            QCalendarWidget QWidget#qt_calendar_navigationbar {{
                background-color: {DARK_CARD};
                border-bottom: 1px solid {DARK_BORDER};
            }}
        """

    def _build_gui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        # Dropdown selection header
        header_layout = QHBoxLayout()
        header_layout.setSpacing(8)

        self.month_combo = QComboBox()
        months = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ]
        self.month_combo.addItems(months)
        self.month_combo.setFixedHeight(28)
        header_layout.addWidget(self.month_combo, 3)

        self.year_combo = QComboBox()
        current_year = datetime.date.today().year
        # Display years from current_year - 15 to current_year + 5
        years = [str(y) for y in range(current_year - 15, current_year + 6)]
        self.year_combo.addItems(years)
        self.year_combo.setFixedHeight(28)
        header_layout.addWidget(self.year_combo, 2)

        layout.addLayout(header_layout)

        self.calendar = QCalendarWidget()
        self.calendar.setGridVisible(True)
        self.calendar.setVerticalHeaderFormat(QCalendarWidget.NoVerticalHeader)
        self.calendar.setSelectedDate(QDate.currentDate())
        self.calendar.clicked.connect(self._on_date_selected)
        layout.addWidget(self.calendar)

        btn_select = QPushButton("Select Date")
        btn_select.setFixedHeight(32)
        btn_select.setFont(QFont(FONT_FAMILY, 11, QFont.Bold))
        btn_select.clicked.connect(self._confirm_date)
        layout.addWidget(btn_select)

        # Sync dropdowns and connect page/dropdown change slots
        self._sync_dropdowns_to_calendar()
        self.month_combo.currentIndexChanged.connect(self._on_dropdown_changed)
        self.year_combo.currentIndexChanged.connect(self._on_dropdown_changed)
        self.calendar.currentPageChanged.connect(self._on_calendar_page_changed)

    def _sync_dropdowns_to_calendar(self):
        year = self.calendar.yearShown()
        month = self.calendar.monthShown()

        self.month_combo.blockSignals(True)
        self.year_combo.blockSignals(True)

        self.month_combo.setCurrentIndex(month - 1)
        y_idx = self.year_combo.findText(str(year))
        if y_idx != -1:
            self.year_combo.setCurrentIndex(y_idx)
        else:
            self.year_combo.addItem(str(year))
            self.year_combo.setCurrentIndex(self.year_combo.count() - 1)

        self.month_combo.blockSignals(False)
        self.year_combo.blockSignals(False)

    def _on_dropdown_changed(self):
        month = self.month_combo.currentIndex() + 1
        try:
            year = int(self.year_combo.currentText())
        except ValueError:
            year = datetime.date.today().year

        self.calendar.blockSignals(True)
        self.calendar.setCurrentPage(year, month)
        self.calendar.blockSignals(False)

    def _on_calendar_page_changed(self, year, month):
        self._sync_dropdowns_to_calendar()

    def _on_date_selected(self, date):
        """Double-click or single-click on a date cell."""
        pass  # Wait for the button press to confirm

    def _confirm_date(self):
        selected = self.calendar.selectedDate()
        date_str = selected.toString("dd/MM/yyyy")
        if self.target_entry is not None:
            self.target_entry.setText(date_str)
        self.accept()


# ═══════════════════════════════════════════════════════════════════════════
# 3. TreasuryPickerDialog
# ═══════════════════════════════════════════════════════════════════════════

class TreasuryPickerDialog(QDialog):
    """Searchable treasury picker with optional multi-select support."""

    def __init__(self, parent=None, treasury_ids=None, current_val=None, multi_select=False):
        super().__init__(parent)
        self.selected_treasury = None
        self.selected_treasuries = []
        self.multi_select = multi_select

        # Resolve treasury data
        if treasury_ids is not None:
            self._treasury_names = sorted(list(treasury_ids.keys()))
        elif parent is not None and hasattr(parent, "TREASURY_IDS"):
            self._treasury_names = sorted(list(parent.TREASURY_IDS.keys()))
        else:
            self._treasury_names = ["010-BAL-BALAGHAT TREASURY"]

        # Current selection
        if multi_select:
            if isinstance(current_val, (list, tuple, set)):
                self._selected_set = set(current_val)
            else:
                self._selected_set = {current_val} if current_val else set()
        else:
            self._current_val = current_val or ""

        title_text = "Select Treasuries" if multi_select else "Select Treasury"
        h = 550 if multi_select else 500
        self.setWindowTitle(title_text)
        self.setFixedSize(400, h)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setModal(True)
        self.setStyleSheet(BASE_DIALOG_QSS)
        _center_on_parent(self, parent, 400, h)

        self._build_gui()

    def _build_gui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        # Title
        title_text = "\U0001f3db Select Treasury Locations" if self.multi_select else "\U0001f3db Select Treasury Location"
        title = QLabel(title_text)
        title.setFont(QFont(FONT_FAMILY, 14, QFont.Bold))
        title.setStyleSheet(f"color: {DARK_ACCENT};")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Search
        self.search_entry = QLineEdit()
        self.search_entry.setPlaceholderText("Search treasury name or code...")
        self.search_entry.setFixedHeight(32)
        self.search_entry.textChanged.connect(self._filter_treasuries)
        layout.addWidget(self.search_entry)

        # Select All / Clear All (multi-select only)
        if self.multi_select:
            helper_frame = QWidget()
            helper_lay = QHBoxLayout(helper_frame)
            helper_lay.setContentsMargins(0, 0, 0, 0)

            btn_all = QPushButton("☑ Select All")
            btn_all.setFixedHeight(26)
            btn_all.clicked.connect(self._select_all)
            helper_lay.addWidget(btn_all)

            btn_none = QPushButton("☒ Clear All")
            btn_none.setFixedHeight(26)
            btn_none.clicked.connect(self._clear_all)
            helper_lay.addWidget(btn_none)

            layout.addWidget(helper_frame)

        # Scroll area
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.scroll_widget = QWidget()
        self.scroll_widget.setStyleSheet(f"background-color: {DARK_SIDEBAR};")
        self.scroll_layout = QVBoxLayout(self.scroll_widget)
        self.scroll_layout.setContentsMargins(10, 10, 10, 10)
        self.scroll_layout.setSpacing(6)
        self.scroll_layout.setAlignment(Qt.AlignTop)

        self.scroll_area.setWidget(self.scroll_widget)
        layout.addWidget(self.scroll_area, 1)

        # Widgets storage
        self._widgets = []
        self._check_vars = {}
        self.btn_group = None
        if not self.multi_select:
            self.btn_group = QButtonGroup(self)

        self._populate_list(self._treasury_names)

        # Confirm
        btn_confirm = QPushButton("Confirm Selection")
        btn_confirm.setFixedHeight(36)
        btn_confirm.setFont(QFont(FONT_FAMILY, 12, QFont.Bold))
        btn_confirm.clicked.connect(self._confirm)
        layout.addWidget(btn_confirm)

    def _populate_list(self, items):
        for w in self._widgets:
            w.setVisible(False)
        self._widgets.clear()

        if self.multi_select:
            for name in items:
                cb = QCheckBox(name)
                cb.setFont(QFont(FONT_FAMILY, 11))
                cb.setChecked(name in self._selected_set)
                cb.stateChanged.connect(lambda state, n=name: self._toggle_item(n, state))
                self.scroll_layout.addWidget(cb)
                self._widgets.append(cb)
                self._check_vars[name] = cb
        else:
            for name in items:
                rb = QRadioButton(name)
                rb.setFont(QFont(FONT_FAMILY, 11))
                if name == self._current_val:
                    rb.setChecked(True)
                self.btn_group.addButton(rb)
                self.scroll_layout.addWidget(rb)
                self._widgets.append(rb)

    def _toggle_item(self, name, state):
        if state == Qt.CheckState.Checked.value or state == 2:
            self._selected_set.add(name)
        else:
            self._selected_set.discard(name)

    def _select_all(self):
        self._selected_set = set(self._treasury_names)
        for name, cb in self._check_vars.items():
            if cb.isVisible():
                cb.setChecked(True)

    def _clear_all(self):
        self._selected_set.clear()
        for cb in self._check_vars.values():
            cb.setChecked(False)

    def _filter_treasuries(self, text):
        query = text.strip().lower()
        for w in self._widgets:
            w.setVisible(query == "" or query in w.text().lower())

    def _confirm(self):
        if self.multi_select:
            self.selected_treasuries = sorted(list(self._selected_set))
            if not self.selected_treasuries:
                QMessageBox.warning(self, "Selection Error", "Please select at least one treasury.")
                return
            self.selected_treasury = self.selected_treasuries[0] if self.selected_treasuries else None
        else:
            checked = self.btn_group.checkedButton()
            if checked:
                self.selected_treasury = checked.text()
                self.selected_treasuries = [self.selected_treasury]
        self.accept()


# ═══════════════════════════════════════════════════════════════════════════
# 4. OperatorLoginDialog
# ═══════════════════════════════════════════════════════════════════════════

from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QCheckBox, QPushButton, QFrame, QApplication
class OperatorLoginDialog(QDialog):
    """Captures the operator/user name and terms consent before proceeding."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.result = None
        self.telemetry_agreed = True

        self.setWindowTitle("Operator Identity & Consent")
        self.setFixedSize(450, 270)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setModal(True)
        self.setStyleSheet(BASE_DIALOG_QSS)
        _center_on_parent(self, parent, 450, 270)

        self._build_gui()

    def _build_gui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 20, 25, 20)
        layout.setSpacing(10)

        title = QLabel("\U0001f464 Operator Identity Required")
        title.setFont(QFont(FONT_FAMILY, 14, QFont.Bold))
        title.setStyleSheet(f"color: {DARK_ACCENT};")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        instruction = QLabel("Please enter your name/operator code:")
        instruction.setFont(QFont(FONT_FAMILY, 11))
        instruction.setStyleSheet(f"color: {DARK_MUTED};")
        instruction.setAlignment(Qt.AlignCenter)
        layout.addWidget(instruction)

        self.entry_name = QLineEdit()
        self.entry_name.setPlaceholderText("e.g. Operator or Administrator")
        self.entry_name.setFixedHeight(34)
        self.entry_name.setFont(QFont(FONT_FAMILY, 12))
        self.entry_name.returnPressed.connect(self._confirm)
        layout.addWidget(self.entry_name)

        # Terms && Telemetry Consent Checkbox
        from PySide6.QtWidgets import QCheckBox
        self.cb_terms = QCheckBox("I agree to the Terms && Conditions and Telemetry Data Collection")
        self.cb_terms.setFont(QFont(FONT_FAMILY, 10))
        self.cb_terms.setChecked(True)
        layout.addWidget(self.cb_terms)

        # Hyperlink to view detailed terms
        lbl_terms_link = QLabel("<a href='terms' style='color: #00c9a7; font-size: 11px; font-weight: normal; text-decoration: underline;'>Terms and Conditions</a>")
        lbl_terms_link.setFont(QFont(FONT_FAMILY, 9))
        lbl_terms_link.setOpenExternalLinks(False)
        lbl_terms_link.linkActivated.connect(self._show_terms_popup)
        layout.addWidget(lbl_terms_link)

        btn_ok = QPushButton("Proceed")
        btn_ok.setFixedSize(140, 34)
        btn_ok.setFont(QFont(FONT_FAMILY, 12, QFont.Bold))
        btn_ok.clicked.connect(self._confirm)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_row.addWidget(btn_ok)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self.entry_name.setFocus()

    def _show_terms_popup(self, link):
        if link == "terms":
            import os
            terms_path = ""
            if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
                terms_path = os.path.join(sys._MEIPASS, "terms.txt")
            if not terms_path or not os.path.exists(terms_path):
                from core.constants import APP_DIR
                terms_path = os.path.join(APP_DIR, "terms.txt")
            
            terms_text = ""
            if os.path.exists(terms_path):
                try:
                    with open(terms_path, "r", encoding="utf-8") as tf:
                        terms_text = tf.read()
                except Exception: pass
            if not terms_text:
                terms_text = "Centralized Voucher Validation Suite - Terms of Service & Telemetry Consent Policy\n\nTelemetry collects anonymous system data and run status for licensing validation."
            msg = QMessageBox(self)
            msg.setWindowTitle("Centralized Voucher Validation Suite - Terms of Service & Telemetry Policy")
            msg.setText(terms_text)
            msg.setFont(QFont(FONT_FAMILY, 10))
            msg.exec()

    def _confirm(self):
        name = self.entry_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Error", "Operator identity cannot be empty.")
            return
        if not self.cb_terms.isChecked():
            QMessageBox.warning(self, "Consent Required", "You must accept the Terms & Conditions and Telemetry Policy to proceed and use Centralized Voucher Validation Suite.")
            return
        self.result = name
        self.telemetry_agreed = True
        self.accept()

    def reject(self):
        self.result = None
        super().reject()


# ═══════════════════════════════════════════════════════════════════════════
# 5. PasswordInputDialog
# ═══════════════════════════════════════════════════════════════════════════

class PasswordInputDialog(QDialog):
    """Masked password input with OK / Cancel."""

    def __init__(self, parent=None, text="Enter password:", title="Password"):
        super().__init__(parent)
        self.result = None

        self.setWindowTitle(title)
        self.setFixedSize(380, 180)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setModal(True)
        self.setStyleSheet(BASE_DIALOG_QSS)
        _center_on_parent(self, parent, 380, 180)

        self._build_gui(text)

    def _build_gui(self, prompt_text):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 20, 25, 20)
        layout.setSpacing(12)

        prompt = QLabel(prompt_text)
        prompt.setFont(QFont(FONT_FAMILY, 12, QFont.Bold))
        prompt.setWordWrap(True)
        prompt.setAlignment(Qt.AlignCenter)
        layout.addWidget(prompt)

        input_container = QWidget()
        input_layout = QHBoxLayout(input_container)
        input_layout.setContentsMargins(0, 0, 0, 0)
        input_layout.setSpacing(6)

        self.entry = QLineEdit()
        self.entry.setEchoMode(QLineEdit.Password)
        self.entry.setPlaceholderText("Enter password...")
        self.entry.setFixedHeight(34)
        self.entry.setFont(QFont(FONT_FAMILY, 12))
        self.entry.setStyleSheet(
            f"QLineEdit {{ background-color: {DARK_SIDEBAR}; color: {DARK_ACCENT}; "
            f"border: 1px solid {DARK_BORDER}; border-radius: 8px; padding: 5px 10px; }}"
            f"QLineEdit:focus {{ border-color: {DARK_ACCENT}; }}"
        )
        self.entry.returnPressed.connect(self._on_ok)
        input_layout.addWidget(self.entry, 1)

        self.btn_toggle_eye = QPushButton("👁")
        self.btn_toggle_eye.setFixedSize(34, 34)
        self.btn_toggle_eye.setFont(QFont("Segoe UI Emoji", 11))
        self.btn_toggle_eye.setToolTip("Show / Hide Password")
        self.btn_toggle_eye.setStyleSheet(
            f"QPushButton {{ background-color: {DARK_SIDEBAR}; color: {DARK_TEXT}; "
            f"border: 1px solid {DARK_BORDER}; border-radius: 8px; font-size: 13px; "
            f"padding: 0px; margin: 0px; text-align: center; }}"
            f"QPushButton:hover {{ border-color: {DARK_ACCENT}; }}"
        )
        def _toggle_dialog_pass():
            if self.entry.echoMode() == QLineEdit.Password:
                self.entry.setEchoMode(QLineEdit.Normal)
                self.btn_toggle_eye.setText("🙈")
            else:
                self.entry.setEchoMode(QLineEdit.Password)
                self.btn_toggle_eye.setText("👁")
        self.btn_toggle_eye.clicked.connect(_toggle_dialog_pass)
        input_layout.addWidget(self.btn_toggle_eye)

        layout.addWidget(input_container)

        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)

        btn_ok = QPushButton("OK")
        btn_ok.setFixedSize(100, 32)
        btn_ok.setFont(QFont(FONT_FAMILY, 11, QFont.Bold))
        btn_ok.clicked.connect(self._on_ok)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_ok)

        btn_cancel = QPushButton("Cancel")
        btn_cancel.setFixedSize(100, 32)
        btn_cancel.setFont(QFont(FONT_FAMILY, 11))
        btn_cancel.setStyleSheet(OUTLINE_BTN_QSS)
        btn_cancel.clicked.connect(self.reject)
        btn_layout.addWidget(btn_cancel)
        btn_layout.addStretch()

        layout.addLayout(btn_layout)

        self.entry.setFocus()

    def _on_ok(self):
        self.result = self.entry.text()
        self.accept()

    def reject(self):
        self.result = None
        super().reject()


# ═══════════════════════════════════════════════════════════════════════════
# 6. CaptchaInputDialog
# ═══════════════════════════════════════════════════════════════════════════

class CaptchaInputDialog(QDialog):
    """Displays a CAPTCHA image (from bytes) and asks the user to solve it."""

    def __init__(self, parent=None, captcha_bytes=None):
        super().__init__(parent)
        self.result = None
        self._captcha_bytes = captcha_bytes

        self.setWindowTitle("Solve CAPTCHA")
        self.setFixedSize(360, 250)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setModal(True)
        self.setStyleSheet(BASE_DIALOG_QSS)
        _center_on_parent(self, parent, 360, 250)

        self._build_gui()

    def _build_gui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 15, 20, 15)
        layout.setSpacing(10)

        title = QLabel("\U0001f511 Enter Portal CAPTCHA")
        title.setFont(QFont(FONT_FAMILY, 14, QFont.Bold))
        title.setStyleSheet(f"color: {DARK_ACCENT};")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # CAPTCHA image
        self.img_label = QLabel()
        self.img_label.setAlignment(Qt.AlignCenter)
        self.img_label.setFixedHeight(70)
        self.img_label.setStyleSheet(
            f"background-color: {DARK_SIDEBAR}; border: 1px solid {DARK_BORDER}; border-radius: 6px;"
        )

        if self._captcha_bytes:
            qimg = QImage()
            if qimg.loadFromData(QByteArray(self._captcha_bytes)):
                pixmap = QPixmap.fromImage(qimg)
                self.img_label.setPixmap(
                    pixmap.scaled(
                        self.img_label.size(),
                        Qt.KeepAspectRatio,
                        Qt.SmoothTransformation,
                    )
                )
            else:
                self.img_label.setText("Error loading CAPTCHA image")
                self.img_label.setStyleSheet(
                    f"color: #ef4444; background-color: {DARK_SIDEBAR}; "
                    f"border: 1px solid {DARK_BORDER}; border-radius: 6px;"
                )
        else:
            self.img_label.setText("No CAPTCHA data provided")

        layout.addWidget(self.img_label)

        # Text entry
        self.entry = QLineEdit()
        self.entry.setPlaceholderText("Enter CAPTCHA Code")
        self.entry.setFixedHeight(34)
        self.entry.setFont(QFont(FONT_FAMILY, 12))
        self.entry.setAlignment(Qt.AlignCenter)
        self.entry.returnPressed.connect(self._on_submit)
        layout.addWidget(self.entry)

        # Submit
        btn_submit = QPushButton("Submit")
        btn_submit.setFixedSize(140, 34)
        btn_submit.setFont(QFont(FONT_FAMILY, 12, QFont.Bold))
        btn_submit.clicked.connect(self._on_submit)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_row.addWidget(btn_submit)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self.entry.setFocus()

    def _on_submit(self):
        val = self.entry.text().strip()
        if val:
            self.result = val
            self.accept()


# ═══════════════════════════════════════════════════════════════════════════
# 7. HeaderConfigDialog
# ═══════════════════════════════════════════════════════════════════════════

class HeaderConfigDialog(QDialog):
    """Configure keyword lists used for auto-detecting Excel column headers."""

    # Category key → (display label, app attribute name)
    _CATEGORIES = [
        ("Voucher",   "headers_voucher"),
        ("Treasury",  "headers_treasury"),
        ("Major Head", "headers_mh"),
        ("Month",     "headers_month"),
        ("Year",      "headers_year"),
        ("Amount",    "headers_amount"),
        ("DDO",       "headers_ddo"),
        ("From Date", "headers_from_date"),
        ("To Date",   "headers_to_date"),
        ("Bill Type", "headers_bill_type"),
    ]

    def __init__(self, parent=None, app=None):
        super().__init__(parent)
        self.app = app

        self.setWindowTitle("\U0001f4ca Excel Header Identifier Settings")
        self.setFixedSize(520, 480)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setModal(True)
        self.setStyleSheet(BASE_DIALOG_QSS)
        _center_on_parent(self, parent, 520, 480)

        self._entries = {}
        self._build_gui()

    def _build_gui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 15, 20, 15)
        layout.setSpacing(10)

        title = QLabel("\U0001f4ca Excel Header Identifier Settings")
        title.setFont(QFont(FONT_FAMILY, 15, QFont.Bold))
        title.setStyleSheet(f"color: {DARK_ACCENT};")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        desc = QLabel(
            "Edit comma-separated keywords used to automatically identify "
            "column headers when importing Excel files."
        )
        desc.setFont(QFont(FONT_FAMILY, 10))
        desc.setStyleSheet(f"color: {DARK_MUTED};")
        desc.setWordWrap(True)
        desc.setAlignment(Qt.AlignCenter)
        layout.addWidget(desc)
        layout.addSpacing(5)

        # Scrollable grid of categories
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        scroll_widget = QWidget()
        scroll_widget.setStyleSheet(f"background-color: {DARK_SIDEBAR};")
        grid = QGridLayout(scroll_widget)
        grid.setContentsMargins(12, 12, 12, 12)
        grid.setSpacing(8)
        grid.setColumnStretch(1, 1)

        for row_idx, (label_text, attr_name) in enumerate(self._CATEGORIES):
            lbl = QLabel(f"{label_text}:")
            lbl.setFont(QFont(FONT_FAMILY, 11, QFont.Bold))
            lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            lbl.setMinimumWidth(90)
            grid.addWidget(lbl, row_idx, 0)

            entry = QLineEdit()
            entry.setFont(QFont(FONT_FAMILY, 11))
            entry.setFixedHeight(30)
            # Pre-fill from app if available
            if self.app and hasattr(self.app, attr_name):
                current_val = getattr(self.app, attr_name, [])
                if isinstance(current_val, list):
                    entry.setText(", ".join(current_val))
                else:
                    entry.setText(str(current_val))
            grid.addWidget(entry, row_idx, 1)
            self._entries[attr_name] = entry

        scroll_area.setWidget(scroll_widget)
        layout.addWidget(scroll_area, 1)

        # Save button
        btn_save = QPushButton("\U0001f4be Save Settings")
        btn_save.setFixedHeight(38)
        btn_save.setFont(QFont(FONT_FAMILY, 12, QFont.Bold))
        btn_save.clicked.connect(self._save)
        layout.addWidget(btn_save)

    def _save(self):
        if not self.app:
            self.accept()
            return

        for attr_name, entry in self._entries.items():
            raw = entry.text().strip()
            values = [v.strip() for v in raw.split(",") if v.strip()]
            setattr(self.app, attr_name, values)

        if hasattr(self.app, "save_config"):
            self.app.save_config()

        QMessageBox.information(
            self, "Saved", "Excel header keywords have been updated."
        )
        self.accept()


# ═══════════════════════════════════════════════════════════════════════════
# 8. SheetSelectorDialog
# ═══════════════════════════════════════════════════════════════════════════

class SheetSelectorDialog(QDialog):
    """Presents a list of Excel sheet names as clickable buttons."""

    def __init__(self, parent=None, sheet_names=None):
        super().__init__(parent)
        self.result = None
        self._sheet_names = sheet_names or []

        self.setWindowTitle("Select Sheet")
        self.setFixedSize(350, 400)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setModal(True)
        self.setStyleSheet(BASE_DIALOG_QSS)
        _center_on_parent(self, parent, 350, 400)

        self._build_gui()

    def _build_gui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 15, 20, 15)
        layout.setSpacing(10)

        title = QLabel("\U0001f4c4 Select Excel Sheet")
        title.setFont(QFont(FONT_FAMILY, 14, QFont.Bold))
        title.setStyleSheet(f"color: {DARK_ACCENT};")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        desc = QLabel("Click a sheet name to select it:")
        desc.setFont(QFont(FONT_FAMILY, 10))
        desc.setStyleSheet(f"color: {DARK_MUTED};")
        desc.setAlignment(Qt.AlignCenter)
        layout.addWidget(desc)

        # Scrollable list of sheet buttons
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        scroll_widget = QWidget()
        scroll_widget.setStyleSheet(f"background-color: {DARK_SIDEBAR};")
        scroll_layout = QVBoxLayout(scroll_widget)
        scroll_layout.setContentsMargins(10, 10, 10, 10)
        scroll_layout.setSpacing(8)
        scroll_layout.setAlignment(Qt.AlignTop)

        sheet_btn_qss = f"""
            QPushButton {{
                background-color: {DARK_CARD};
                color: {DARK_TEXT};
                border: 1px solid {DARK_BORDER};
                border-radius: 8px;
                padding: 10px 16px;
                font-family: '{FONT_FAMILY}';
                font-size: 12px;
                text-align: left;
            }}
            QPushButton:hover {{
                background-color: {DARK_ACCENT};
                color: {DARK_BG};
                border-color: {DARK_ACCENT};
            }}
        """

        for name in self._sheet_names:
            btn = QPushButton(f"\U0001f4c3  {name}")
            btn.setFixedHeight(40)
            btn.setFont(QFont(FONT_FAMILY, 12))
            btn.setStyleSheet(sheet_btn_qss)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked, n=name: self._select_sheet(n))
            scroll_layout.addWidget(btn)

        scroll_area.setWidget(scroll_widget)
        layout.addWidget(scroll_area, 1)

    def _select_sheet(self, name):
        self.result = name
        self.accept()

    def reject(self):
        self.result = None
        super().reject()


# ══════════════════════════════════════════════════════════════════════════
# 9. UpdateDownloadDialog & DownloadWorker
# ══════════════════════════════════════════════════════════════════════════

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import QProgressBar

class DownloadWorker(QThread):
    progress_updated = Signal(int)
    status_updated = Signal(str)
    download_finished = Signal(str)
    download_failed = Signal(str)

    def __init__(self, update_url):
        super().__init__()
        self.update_url = update_url

    def run(self):
        import urllib.request
        import tempfile
        import os
        try:
            self.status_updated.emit("Connecting to server...")
            req = urllib.request.Request(self.update_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=10) as response:
                total_size = int(response.info().get('Content-Length', 0))

                filename = self.update_url.split("/")[-1]
                temp_dir = tempfile.gettempdir()
                dest_path = os.path.join(temp_dir, filename)

                self.status_updated.emit("Downloading update patch...")

                chunk_size = 8192
                downloaded = 0

                with open(dest_path, 'wb') as f:
                    while True:
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size > 0:
                            percent = int((downloaded / total_size) * 100)
                            self.progress_updated.emit(percent)

                self.download_finished.emit(dest_path)
        except Exception as e:
            self.download_failed.emit(str(e))


class UpdateDownloadDialog(QDialog):
    def __init__(self, update_url, target_version, parent=None):
        super().__init__(parent)
        self.update_url = update_url
        self.target_version = target_version
        self.downloaded_path = None
        self.failed_reason = None

        self.setWindowTitle("Downloading Update")
        self.setFixedSize(400, 150)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        # Style layout matching Dark/Muted theme
        self.setStyleSheet("""
            QDialog {
                background-color: #0d1117;
                color: #f8fafc;
            }
            QLabel {
                color: #f8fafc;
            }
            QProgressBar {
                border: 1px solid #1e293b;
                border-radius: 4px;
                text-align: center;
                background-color: #0d1117;
                color: #f8fafc;
            }
            QProgressBar::chunk {
                background-color: #00c9a7;
                border-radius: 3px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        self.lbl_status = QLabel(f"Downloading patch update v{target_version}...", self)
        self.lbl_status.setFont(QFont(FONT_FAMILY, 11, QFont.Weight.Bold))
        self.lbl_status.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.lbl_status)

        self.progress = QProgressBar(self)
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFixedHeight(22)
        self.progress.setFont(QFont(FONT_FAMILY, 9))
        layout.addWidget(self.progress)

        # Start thread worker
        self.worker = DownloadWorker(self.update_url)
        self.worker.progress_updated.connect(self.progress.setValue)
        self.worker.status_updated.connect(self.lbl_status.setText)
        self.worker.download_finished.connect(self.on_download_finished)
        self.worker.download_failed.connect(self.on_download_failed)
        self.worker.start()

    def on_download_finished(self, dest_path):
        self.downloaded_path = dest_path
        self.accept()

    def on_download_failed(self, error_msg):
        self.failed_reason = error_msg
        self.reject()


class VLCLinkResultDialog(QDialog):
    """Interactive result dialog with Unmatched Records Table View & Smart Reason Detection shown after VLC-COMPAY dataset linking completes."""

    def __init__(self, stats: dict, linked_file_path: str, parent=None):
        super().__init__(parent)
        self.stats = stats
        self.linked_file_path = linked_file_path
        self.user_choice = "skip"  # 'use', 'save', 'skip'
        self._setup_ui()

    def _setup_ui(self):
        self.setWindowTitle("🔗 VLC-COMPAY Linking Execution Summary")
        try:
            from ifmis_suite import get_app_icon
            icon = get_app_icon()
            if not icon.isNull():
                self.setWindowIcon(icon)
        except Exception:
            pass
        self.setFixedSize(980, 660)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)

        bg_dialog = "#0f172a"
        border_col = "#334155"
        text_main = "#f8fafc"
        accent_col = "#00c9a7"

        self.setStyleSheet(f"""
            QDialog {{ background-color: {bg_dialog}; border: 1px solid {border_col}; border-radius: 16px; }}
            QLabel {{ color: {text_main}; background: transparent; }}
            QPushButton {{
                border-radius: 10px; font-weight: 800; padding: 10px 18px; font-size: 13px;
            }}
            QTableWidget {{
                background-color: #1e293b;
                border: 1px solid #334155;
                gridline-color: #334155;
                color: #f8fafc;
                border-radius: 8px;
                font-size: 11px;
            }}
            QHeaderView::section {{
                background-color: #0f172a;
                color: #38bdf8;
                font-weight: 700;
                padding: 6px;
                border: 1px solid #334155;
                font-size: 11px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        # Title
        title = QLabel("🔗 VLC-COMPAY Linking Execution Summary")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        title.setStyleSheet(f"color: {accent_col}; font-weight: 800;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Summary Frame (Grid Layout)
        summary_frame = QFrame(self)
        summary_frame.setStyleSheet("background-color: #1e293b; border: 1px solid #334155; border-radius: 12px;")
        summary_lay = QGridLayout(summary_frame)
        summary_lay.setContentsMargins(18, 12, 18, 12)
        summary_lay.setSpacing(10)

        total_rows = self.stats.get("total_rows", 0)
        matched_rows = self.stats.get("matched_rows", 0)
        unmatched_rows = self.stats.get("unmatched_rows", 0)
        pct_linked = self.stats.get("pct_linked", 0.0)
        elapsed = self.stats.get("elapsed", 0.0)

        l1 = QLabel(f"<b>Total POL Vouchers:</b> {total_rows:,}")
        l2 = QLabel(f"<b>Matched in COMPAY VLC:</b> <font color='#00c9a7'><b>{matched_rows:,} ({pct_linked:.1f}%)</b></font>")
        l3 = QLabel(f"<b>Unmatched Records:</b> <font color='{'#f87171' if unmatched_rows > 0 else '#00c9a7'}'><b>{unmatched_rows:,}</b></font>")
        l4 = QLabel(f"<b>Polars Execution Time:</b> {elapsed:.2f} s")

        for l in (l1, l2, l3, l4):
            l.setFont(QFont("Segoe UI", 11))

        summary_lay.addWidget(l1, 0, 0)
        summary_lay.addWidget(l2, 0, 1)
        summary_lay.addWidget(l3, 1, 0)
        summary_lay.addWidget(l4, 1, 1)
        layout.addWidget(summary_frame)

        # Unmatched Records Section Header / Table
        unmatched_records = self.stats.get("unmatched_records", [])

        if unmatched_rows > 0:
            hdr_unmatched = QLabel(f"⚠️ Unmatched Vouchers ({unmatched_rows:,} total - detailed reasons below):")
            hdr_unmatched.setFont(QFont("Segoe UI", 11, QFont.Bold))
            hdr_unmatched.setStyleSheet("color: #fbbf24; font-weight: 700;")
            layout.addWidget(hdr_unmatched)

            table = QTableWidget()
            headers = ["#", "Treasury", "Major Head", "Voucher No", "Month/Year", "Amount (₹)", "Reason / Detailed Status"]
            table.setColumnCount(len(headers))
            table.setHorizontalHeaderLabels(headers)
            table.verticalHeader().setVisible(False)
            table.setRowCount(len(unmatched_records))

            # Column Width Allocations
            table.setColumnWidth(0, 40)   # #
            table.setColumnWidth(1, 90)   # Treasury
            table.setColumnWidth(2, 90)   # Major Head
            table.setColumnWidth(3, 95)   # Voucher No
            table.setColumnWidth(4, 90)   # Month/Year
            table.setColumnWidth(5, 110)  # Amount
            table.horizontalHeader().setSectionResizeMode(6, QHeaderView.Stretch) # Reason takes remaining space!

            # Helper for column retrieval across alternate key names
            def get_rec_val(rec_dict, keys, default=""):
                for k in keys:
                    for rk, rv in rec_dict.items():
                        if str(rk).strip().lower() == str(k).strip().lower():
                            v_str = str(rv).strip()
                            if v_str and v_str.lower() not in ("none", "null", "nan"):
                                return v_str
                return default

            non_compay_heads = {"8009", "8011", "8658", "8342", "8005", "8010", "8443", "8448"}

            for idx, rec in enumerate(unmatched_records):
                try_cd = get_rec_val(rec, ["TRY_CD", "Treasury", "TRY_CDN", "TRY_NAME", "Treasury_Code"])
                mhcd = get_rec_val(rec, ["MHCD", "Major Head", "SEC_MHCD", "MAJOR_HEAD", "MH"])
                vch_no = get_rec_val(rec, ["SOP_VCH_NO", "VOU_NO", "Voucher_No", "VOUCHER_NO", "VCH_NO", "Bill_No"])
                m_val = get_rec_val(rec, ["MONTH", "MONTH_IN", "VOUCHER_MONTH"])
                y_val = get_rec_val(rec, ["YEAR", "YEAR_IN", "VOUCHER_YEAR"])
                m_y = f"{m_val}/{y_val}".strip("/") if (m_val or y_val) else ""
                amt = get_rec_val(rec, ["SOP_VCH_AMT", "AMOUNT", "Net_Amount", "VCH_AMT", "Total_Amount"], default="0")

                # Smart Reason Detection Engine
                mh_clean = mhcd.strip()
                if mh_clean in non_compay_heads or mh_clean.startswith("8"):
                    reason = f"💡 Non-COMPAY Head (MH {mh_clean} Public Account/Deposit)"
                    reason_color = "#fbbf24"  # Amber/Yellow
                elif not try_cd or not vch_no:
                    reason = "⚠️ Missing Treasury or Voucher No in POL Record"
                    reason_color = "#f87171"  # Red
                else:
                    reason = f"⚠️ No matching key (Try {try_cd}, MH {mh_clean}, Vch {vch_no}) in COMPAY"
                    reason_color = "#f87171"  # Red

                row_items = [
                    str(idx + 1),
                    try_cd or "N/A",
                    mhcd or "N/A",
                    vch_no or "N/A",
                    m_y or "N/A",
                    amt,
                    reason
                ]

                for c_idx, val in enumerate(row_items):
                    item = QTableWidgetItem(val)
                    if c_idx in (0, 1, 2, 3, 4):
                        item.setTextAlignment(Qt.AlignCenter)
                    elif c_idx == 5:
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    else:
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                        item.setForeground(QColor(reason_color))

                    table.setItem(idx, c_idx, item)

            layout.addWidget(table)
        else:
            success_banner = QLabel("🎉 Perfect 100% Match! All vouchers were mapped in the COMPAY VLC dataset.")
            success_banner.setFont(QFont("Segoe UI", 12, QFont.Bold))
            success_banner.setStyleSheet("color: #00c9a7; background: #064e3b; border: 1px solid #10b981; padding: 14px; border-radius: 10px;")
            success_banner.setAlignment(Qt.AlignCenter)
            layout.addWidget(success_banner)

        # Question Prompt
        q_label = QLabel("Would you like to use this linked file for Validation & Voucher Downloading?")
        q_label.setFont(QFont("Segoe UI", 11, QFont.Bold))
        q_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(q_label)

        # Buttons Row
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)

        btn_use = QPushButton("✅ Use Linked File")
        btn_use.setStyleSheet(f"background-color: {accent_col}; color: #020617;")
        btn_use.clicked.connect(self._on_use)
        btn_row.addWidget(btn_use)

        btn_save = QPushButton("💾 Save / Export...")
        btn_save.setStyleSheet("background-color: #3b82f6; color: #ffffff;")
        btn_save.clicked.connect(self._on_save)
        btn_row.addWidget(btn_save)

        btn_skip = QPushButton("❌ Skip & Keep Original")
        btn_skip.setStyleSheet("background-color: #334155; color: #f8fafc;")
        btn_skip.clicked.connect(self._on_skip)
        btn_row.addWidget(btn_skip)

        layout.addLayout(btn_row)

    def _on_use(self):
        self.user_choice = "use"
        self.accept()

    def _on_save(self):
        self.user_choice = "save"
        self.accept()

    def _on_skip(self):
        self.user_choice = "skip"
        self.reject()

