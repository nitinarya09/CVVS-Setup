import time
# gui/tabs_qt/checks_manager_tab.py
# PySide6 GUI tab for managing Validation Checks (Add/Remove/Toggle Python Checks)

import os
import sys
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFrame,
    QPushButton, QLabel, QScrollArea, QMessageBox
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from gui.toggle_switch import ToggleSwitch

def build_checks_manager_tab(app, tab):
    """Build the Checks Manager Tab to manage realtime and post-download python check scripts."""
    layout = QVBoxLayout(tab)
    layout.setContentsMargins(10, 5, 10, 5)
    layout.setSpacing(8)

    # Info Header
    app.lbl_checks_info = QLabel(
        "⚙️ Validation Checks Manager\n"
        "Manage, enable, disable, or add Python check scripts. Each check script in checks/ runs dynamically during or after voucher downloads."
    )
    app.lbl_checks_info.setFont(QFont("Segoe UI", 11))
    font = app.lbl_checks_info.font()
    font.setItalic(True)
    app.lbl_checks_info.setFont(font)
    app.lbl_checks_info.setAlignment(Qt.AlignCenter)
    app.lbl_checks_info.setWordWrap(True)
    app.lbl_checks_info.setProperty("cssClass", "muted")
    layout.addWidget(app.lbl_checks_info)

    # Action Toolbar
    tool_frame = QFrame()
    tool_layout = QHBoxLayout(tool_frame)
    tool_layout.setContentsMargins(0, 0, 0, 0)
    tool_layout.setSpacing(10)

    btn_open_folder = QPushButton("📂 Open Checks Folder")
    btn_open_folder.setProperty("cssClass", "outline")
    btn_open_folder.setFixedHeight(32)

    def _open_checks_dir():
        c_dir = getattr(app, "checks_dir", None) or os.path.join(getattr(app, "APP_DIR", os.getcwd()), "checks")
        os.makedirs(c_dir, exist_ok=True)
        try:
            if sys.platform == "win32":
                os.startfile(c_dir)
            else:
                import subprocess
                subprocess.Popen(["xdg-open", c_dir])
        except Exception as err:
            app.log(f"⚠️ Failed to open checks folder: {err}")

    btn_open_folder.clicked.connect(_open_checks_dir)
    tool_layout.addWidget(btn_open_folder)

    btn_reload_checks = QPushButton("🔄 Reload Check Scripts")
    btn_reload_checks.setProperty("cssClass", "primary")
    btn_reload_checks.setFixedHeight(32)
    tool_layout.addWidget(btn_reload_checks)

    btn_add_script_help = QPushButton("ℹ️ How to Add a Check Script")
    btn_add_script_help.setProperty("cssClass", "secondary")
    btn_add_script_help.setFixedHeight(32)

    def _show_help():
        msg = (
            "How to Add a New Validation Check:\n\n"
            "1. Click 'Open Checks Folder' to open the checks/ directory.\n"
            "2. Create a new Python file (e.g., check_realtime_mycheck.py).\n"
            "3. Inherit from BaseValidationCheck and implement run_realtime() or run_post_download().\n"
            "4. Click 'Reload Check Scripts' above to activate your new check immediately!"
        )
        QMessageBox.information(tab, "Adding Custom Check Scripts", msg)

    btn_add_script_help.clicked.connect(_show_help)
    tool_layout.addWidget(btn_add_script_help)

    layout.addWidget(tool_frame)

    # Scroll area for checks list
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.NoFrame)
    
    container = QWidget()
    container_layout = QVBoxLayout(container)
    container_layout.setContentsMargins(0, 5, 0, 5)
    container_layout.setSpacing(8)

    def refresh_checks_list():
        # Clear existing items in container_layout
        while container_layout.count():
            child = container_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        if hasattr(app, "check_registry"):
            app.check_registry.reload_checks()
            checks = app.check_registry.get_all_checks()
        else:
            checks = []

        if not checks:
            lbl_empty = QLabel("No validation checks found in checks/ directory.")
            lbl_empty.setAlignment(Qt.AlignCenter)
            lbl_empty.setProperty("cssClass", "muted")
            container_layout.addWidget(lbl_empty)
            return

        for chk in checks:
            card = QFrame()
            card.setProperty("cssClass", "card")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(12, 10, 12, 10)

            # Top row: Name + Badge + Toggle Switch
            top_row = QHBoxLayout()
            lbl_name = QLabel(f"{chk.name} ({chk.check_id})")
            lbl_name.setFont(QFont("Segoe UI", 11, QFont.Bold))
            top_row.addWidget(lbl_name, 1)

            # Type badge
            type_text = f"[{chk.check_type.upper()}]"
            lbl_type = QLabel(type_text)
            lbl_type.setFont(QFont("Segoe UI", 9, QFont.Bold))
            lbl_type.setStyleSheet("color: #38bdf8; background-color: rgba(56, 189, 248, 0.1); padding: 2px 6px; border-radius: 4px;")
            top_row.addWidget(lbl_type)

            # Toggle switch
            sw = ToggleSwitch("Enabled" if chk.enabled else "Disabled")
            sw.setChecked(chk.enabled)

            def _make_toggle_handler(check_obj, switch_widget):
                def _on_toggle(state):
                    is_on = bool(state)
                    check_obj.enabled = is_on
                    switch_widget.setText("Enabled" if is_on else "Disabled")
                    app.log(f"Check '{check_obj.name}' status set to: {'ENABLED' if is_on else 'DISABLED'}")
                return _on_toggle

            sw.stateChanged.connect(_make_toggle_handler(chk, sw))
            top_row.addWidget(sw)

            card_layout.addLayout(top_row)

            # Description
            lbl_desc = QLabel(chk.description)
            lbl_desc.setFont(QFont("Segoe UI", 10))
            lbl_desc.setProperty("cssClass", "muted")
            lbl_desc.setWordWrap(True)
            card_layout.addWidget(lbl_desc)

            container_layout.addWidget(card)

        container_layout.addStretch(1)

    btn_reload_checks.clicked.connect(refresh_checks_list)
    scroll.setWidget(container)
    layout.addWidget(scroll, 1)

    # Initial populate
    refresh_checks_list()
