def _clean_str(val):
    if val is None:
        return ""
    s = str(val).strip()
    if s.startswith('="') and s.endswith('"'):
        return s[2:-1].strip()
    elif s.startswith('='):
        return s[1:].strip().strip('"')
    return s

# automation/duplicate_detector.py
# Centralized Voucher Validation Suite v3.5 — Duplicate Payment Attachment Detection Engine
#
# Detects potential double/duplicate payments by comparing attachment files
# across vouchers with the same amount. Two vouchers sharing one or more
# identical attachments (by file size + MD5 hash) are flagged as suspicious.

import os
import hashlib
import json
import time
import datetime
import sqlite3
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

# Files to EXCLUDE from comparison (system-generated, always differ across vouchers)
EXCLUDED_PATTERNS = [
    'show_mptc',      # MPTC PDF — system-generated per voucher
    'bill_party_',    # Party Details — system-generated per bill
    'success.marker',
    'paybill_',       # Paybill Excel
    'fail_',          # Failure screenshots
]

def _is_attachment_file(filename):
    """Check if a file is a user-uploaded attachment (not system-generated)."""
    fn_lower = filename.lower()
    for pattern in EXCLUDED_PATTERNS:
        if pattern in fn_lower:
            return False
    # Must be a document file
    valid_ext = ('.pdf', '.jpg', '.jpeg', '.png', '.tif', '.tiff', '.doc', '.docx', '.xls', '.xlsx')
    if fn_lower.endswith(valid_ext):
        return True
    return False


def _compute_md5(filepath):
    """Compute MD5 hash of a file."""
    hasher = hashlib.md5()
    try:
        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(65536), b''):
                hasher.update(chunk)
        return hasher.hexdigest()
    except Exception:
        return None


@dataclass
class AttachmentInfo:
    filename: str
    size: int
    md5: str
    filepath: str


@dataclass
class DuplicateMatch:
    """Represents a pair of vouchers flagged as potential duplicates."""
    voucher_a: dict          # {treasury, mh, month, year, voucher_no, amount, ddo, folder_path}
    voucher_b: dict
    matching_attachments: list  # [{filename_a, filename_b, size, md5}]
    match_count: int
    total_attachments_a: int
    total_attachments_b: int
    confidence: str          # HIGH / MEDIUM / LOW
    month_gap: int = 0       # Months between the two vouchers


def catalog_voucher_attachments(folder_path, voucher_meta, db_path=None):
    """
    Scan a voucher folder and catalog all user-uploaded attachments.
    
    Args:
        folder_path: Path to the voucher download folder
        voucher_meta: dict with keys: treasury, mh, month, year, voucher_no, amount, ddo
        db_path: Path to the SQLite database (optional, for persistent storage)
    
    Returns:
        List of AttachmentInfo objects
    """
    attachments = []
    
    if not os.path.isdir(folder_path):
        return attachments
    
    for filename in os.listdir(folder_path):
        filepath = os.path.join(folder_path, filename)
        if not os.path.isfile(filepath):
            continue
        if not _is_attachment_file(filename):
            continue
        
        size = os.path.getsize(filepath)
        if size < 100:  # Skip tiny/empty files
            continue
        
        md5 = _compute_md5(filepath)
        if md5 is None:
            continue
        
        info = AttachmentInfo(filename=filename, size=size, md5=md5, filepath=filepath)
        attachments.append(info)
        
        # Persist to database if db_path is provided
        if db_path:
            try:
                _save_attachment_to_db(db_path, voucher_meta, info)
            except Exception:
                pass
    
    return attachments


def _save_attachment_to_db(db_path, meta, attach_info):
    """Save a single attachment record to the voucher_attachments table."""
    conn = sqlite3.connect(db_path, timeout=30.0)
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO voucher_attachments 
            (treasury, major_head, month, year, voucher_no, amount, ddo_code,
             attachment_filename, attachment_size, attachment_md5, folder_path)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            _clean_str(meta.get('treasury', '')),
            _clean_str(meta.get('mh', '')),
            meta.get('month'),
            meta.get('year'),
            _clean_str(meta.get('voucher_no', '')),
            _clean_str(meta.get('amount', '')),
            _clean_str(meta.get('ddo', '')),
            attach_info.filename,
            attach_info.size,
            attach_info.md5,
            str(meta.get('folder_path', '') or os.path.dirname(attach_info.filepath))
        ))
        conn.commit()
    finally:
        conn.close()


def check_realtime_duplicates(voucher_meta, attachments, db_path):
    """
    Check if a newly downloaded voucher shares attachments with any
    previously downloaded voucher of the same amount.
    
    Args:
        voucher_meta: dict with voucher details
        attachments: list of AttachmentInfo from catalog_voucher_attachments
        db_path: path to SQLite database
    
    Returns:
        List of DuplicateMatch objects (empty if no duplicates found)
    """
    if not attachments or not db_path:
        return []
    
    amount = _clean_str(voucher_meta.get('amount', ''))
    current_voucher = _clean_str(voucher_meta.get('voucher_no', ''))
    current_treasury = _clean_str(voucher_meta.get('treasury', ''))
    current_month = voucher_meta.get('month')
    current_year = voucher_meta.get('year')
    
    if not amount:
        return []
    
    matches = []
    
    try:
        conn = sqlite3.connect(db_path, timeout=30.0)
        cursor = conn.cursor()
        
        # Find all attachment records for vouchers with the same amount
        # (excluding the current voucher itself)
        cursor.execute("""
            SELECT DISTINCT treasury, major_head, month, year, voucher_no, 
                   ddo_code, folder_path,
                   attachment_filename, attachment_size, attachment_md5
            FROM voucher_attachments
            WHERE amount = ?
            AND NOT (treasury = ? AND voucher_no = ? AND month = ? AND year = ?)
            ORDER BY treasury, voucher_no
        """, (amount, current_treasury, current_voucher, current_month, current_year))
        
        rows = cursor.fetchall()
        conn.close()
        
        if not rows:
            return []
        
        # Group rows by voucher key
        other_vouchers = {}
        for row in rows:
            key = f"{row[0]}_{row[1]}_{row[2]}_{row[3]}_{row[4]}"
            if key not in other_vouchers:
                other_vouchers[key] = {
                    'meta': {
                        'treasury': row[0], 'mh': row[1], 'month': row[2],
                        'year': row[3], 'voucher_no': row[4], 'ddo': row[5],
                        'amount': amount, 'folder_path': row[6]
                    },
                    'attachments': []
                }
            other_vouchers[key]['attachments'].append({
                'filename': row[7], 'size': row[8], 'md5': row[9]
            })
        
        # Compare current attachments against each other voucher
        for vou_key, other_data in other_vouchers.items():
            matching = []
            for curr_att in attachments:
                for other_att in other_data['attachments']:
                    # Primary match: same size AND same MD5 hash
                    if curr_att.size == other_att['size'] and curr_att.md5 == other_att['md5']:
                        matching.append({
                            'filename_a': curr_att.filename,
                            'filename_b': other_att['filename'],
                            'size': curr_att.size,
                            'md5': curr_att.md5
                        })
                        break  # Avoid double-counting same file
            
            if matching:
                total_a = len(attachments)
                total_b = len(other_data['attachments'])
                match_count = len(matching)
                
                # Determine confidence level
                min_total = min(total_a, total_b)
                if min_total > 0 and match_count >= min_total:
                    confidence = "HIGH"
                elif min_total > 0 and match_count >= (min_total / 2):
                    confidence = "MEDIUM"
                else:
                    confidence = "LOW"
                
                # Time-window confidence boost (B4)
                month_gap = 0
                try:
                    month_a = int(voucher_meta.get('month', 0) or 0)
                    year_a = int(voucher_meta.get('year', 0) or 0)
                    month_b = int(other_data['meta'].get('month', 0) or 0)
                    year_b = int(other_data['meta'].get('year', 0) or 0)
                    if year_a > 0 and year_b > 0:
                        month_gap = abs((year_a * 12 + month_a) - (year_b * 12 + month_b))
                        if month_gap >= 3:
                            confidence = "HIGH"
                        elif month_gap >= 1:
                            if confidence == "LOW":
                                confidence = "MEDIUM"
                            elif confidence == "MEDIUM":
                                confidence = "HIGH"
                except Exception:
                    pass
                
                match_obj = DuplicateMatch(
                    voucher_a=voucher_meta,
                    voucher_b=other_data['meta'],
                    matching_attachments=matching,
                    match_count=match_count,
                    total_attachments_a=total_a,
                    total_attachments_b=total_b,
                    confidence=confidence,
                    month_gap=month_gap
                )
                matches.append(match_obj)
    
    except Exception:
        pass
    
    return matches


def run_batch_sweep(download_dir, db_path, log_fn=None, current_run_keys=None):
    """
    Post-batch sweep: group all cataloged vouchers by amount and check
    for duplicate attachments across each group.

    Args:
        download_dir: root download directory (for report output path)
        db_path: path to SQLite database
        log_fn: optional logging function
        current_run_keys: optional set of keys representing the current run's vouchers

    Returns:
        List of DuplicateMatch objects
    """
    if not db_path or not os.path.exists(db_path):
        return []

    def _safe_log(msg):
        if not log_fn:
            return
        try:
            log_fn(msg)
        except (UnicodeEncodeError, UnicodeDecodeError):
            try:
                log_fn(msg.encode('ascii', errors='replace').decode('ascii'))
            except Exception:
                pass

    all_matches = []

    try:
        conn = sqlite3.connect(db_path, timeout=30.0)
        cursor = conn.cursor()

        # Clean up any legacy corrupt DDO-code-as-amount entries (length >= 12 digits)
        cursor.execute("DELETE FROM voucher_attachments WHERE amount GLOB '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]*'")
        if cursor.rowcount > 0:
            conn.commit()
            _safe_log(f"[DUP-SCAN] Cleaned up {cursor.rowcount} legacy corrupt DDO-as-amount records.")
        
        # Find amounts that appear in more than one distinct voucher
        cursor.execute("""
            SELECT amount, COUNT(DISTINCT treasury || '_' || voucher_no || '_' || month || '_' || year) as vou_count
            FROM voucher_attachments
            GROUP BY amount
            HAVING vou_count > 1
        """)
        
        amount_groups = cursor.fetchall()
        
        _safe_log(f"[DUP-SCAN] Duplicate scan: {len(amount_groups)} amount group(s) with multiple vouchers to check...")
        
        for amount, vou_count in amount_groups:
            # Get all attachments for this amount
            cursor.execute("""
                SELECT treasury, major_head, month, year, voucher_no, ddo_code, folder_path,
                       attachment_filename, attachment_size, attachment_md5
                FROM voucher_attachments
                WHERE amount = ?
                ORDER BY treasury, voucher_no, month, year
            """, (amount,))
            
            rows = cursor.fetchall()
            
            # Group by voucher key (strictly cleaned & normalized)
            vouchers = {}
            for row in rows:
                trs_c = _clean_str(row[0])
                mh_c = _clean_str(row[1])
                m_c = _clean_str(row[2])
                y_c = _clean_str(row[3])
                v_c = _clean_str(row[4])
                key = f"{trs_c}_{mh_c}_{m_c}_{y_c}_{v_c}"

                if key not in vouchers:
                    vouchers[key] = {
                        'meta': {
                            'treasury': trs_c, 'mh': mh_c, 'month': m_c,
                            'year': y_c, 'voucher_no': v_c, 'ddo': _clean_str(row[5]),
                            'amount': amount, 'folder_path': row[6]
                        },
                        'attachments': []
                    }
                vouchers[key]['attachments'].append({
                    'filename': row[7], 'size': row[8], 'md5': row[9]
                })
            
            # Pairwise comparison within the amount group
            vou_keys = list(vouchers.keys())
            for i in range(len(vou_keys)):
                for j in range(i + 1, len(vou_keys)):
                    vou_a = vouchers[vou_keys[i]]
                    vou_b = vouchers[vou_keys[j]]
                    
                    matching = []
                    for att_a in vou_a['attachments']:
                        for att_b in vou_b['attachments']:
                            if att_a['size'] == att_b['size'] and att_a['md5'] == att_b['md5']:
                                matching.append({
                                    'filename_a': att_a['filename'],
                                    'filename_b': att_b['filename'],
                                    'size': att_a['size'],
                                    'md5': att_a['md5']
                                })
                                break
                    
                    if matching:
                        total_a = len(vou_a['attachments'])
                        total_b = len(vou_b['attachments'])
                        match_count = len(matching)
                        
                        min_total = min(total_a, total_b)
                        if min_total > 0 and match_count >= min_total:
                            confidence = "HIGH"
                        elif min_total > 0 and match_count >= (min_total / 2):
                            confidence = "MEDIUM"
                        else:
                            confidence = "LOW"
                        
                        # Time-window confidence boost (B4)
                        month_gap = 0
                        try:
                            month_a = int(vou_a['meta'].get('month', 0) or 0)
                            year_a = int(vou_a['meta'].get('year', 0) or 0)
                            month_b = int(vou_b['meta'].get('month', 0) or 0)
                            year_b = int(vou_b['meta'].get('year', 0) or 0)
                            if year_a > 0 and year_b > 0:
                                month_gap = abs((year_a * 12 + month_a) - (year_b * 12 + month_b))
                                if month_gap >= 3:
                                    confidence = "HIGH"
                                elif month_gap >= 1:
                                    if confidence == "LOW":
                                        confidence = "MEDIUM"
                                    elif confidence == "MEDIUM":
                                        confidence = "HIGH"
                        except Exception:
                            pass
                        
                        # If current_run_keys is specified, check if at least one voucher is in current run
                        if current_run_keys is not None and len(current_run_keys) > 0:
                            k1, k2 = vou_keys[i], vou_keys[j]
                            # Cleaned key lookup helper
                            def _in_run(k):
                                if k in current_run_keys: return True
                                parts = k.split('_')
                                if len(parts) == 5:
                                    alt = f"{parts[0]}_{parts[1]}_{str(int(parts[2]) if parts[2].isdigit() else parts[2])}_{parts[3]}_{parts[4]}"
                                    if alt in current_run_keys: return True
                                return False

                            if not _in_run(k1) and not _in_run(k2):
                                continue

                        match_obj = DuplicateMatch(
                            voucher_a=vou_a['meta'],
                            voucher_b=vou_b['meta'],
                            matching_attachments=matching,
                            match_count=match_count,
                            total_attachments_a=total_a,
                            total_attachments_b=total_b,
                            confidence=confidence,
                            month_gap=month_gap
                        )
                        all_matches.append(match_obj)
        
        conn.close()
        
        # Save flagged pairs to DB
        if all_matches and db_path:
            _save_flags_to_db(db_path, all_matches)
    
    except Exception as e:
        _safe_log(f"[WARNING] Duplicate detection sweep error: {e}")
    
    return all_matches


def _save_flags_to_db(db_path, matches):
    """Save flagged duplicate pairs to the duplicate_flags table."""
    try:
        conn = sqlite3.connect(db_path, timeout=30.0)
        cursor = conn.cursor()
        for m in matches:
            vou_a_key = f"{m.voucher_a.get('treasury')}_{m.voucher_a.get('mh')}_{m.voucher_a.get('month')}_{m.voucher_a.get('year')}_{m.voucher_a.get('voucher_no')}"
            vou_b_key = f"{m.voucher_b.get('treasury')}_{m.voucher_b.get('mh')}_{m.voucher_b.get('month')}_{m.voucher_b.get('year')}_{m.voucher_b.get('voucher_no')}"
            
            # Check if already flagged
            cursor.execute("""
                SELECT id FROM duplicate_flags 
                WHERE (voucher_a_key = ? AND voucher_b_key = ?) 
                   OR (voucher_a_key = ? AND voucher_b_key = ?)
            """, (vou_a_key, vou_b_key, vou_b_key, vou_a_key))
            
            if cursor.fetchone():
                continue
            
            cursor.execute("""
                INSERT INTO duplicate_flags 
                (voucher_a_key, voucher_b_key, amount, matching_attachments,
                 match_count, total_attachments_a, total_attachments_b, confidence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                vou_a_key, vou_b_key,
                str(m.voucher_a.get('amount', '')),
                json.dumps(m.matching_attachments),
                m.match_count,
                m.total_attachments_a,
                m.total_attachments_b,
                m.confidence
            ))
        conn.commit()
        conn.close()
    except Exception:
        pass


def _format_amount(amount_str):
    """Format amount string with Indian comma notation."""
    try:
        amount = int(float(str(amount_str).replace(',', '').strip()))
        s = str(amount)
        if len(s) <= 3:
            return s
        result = s[-3:]
        s = s[:-3]
        while s:
            result = s[-2:] + ',' + result
            s = s[:-2]
        return result
    except Exception:
        return str(amount_str)


def generate_html_report(flagged_pairs, output_path):
    """
    Generate a professional, self-contained HTML report of flagged duplicate pairs.
    
    Args:
        flagged_pairs: list of DuplicateMatch objects
        output_path: path to save the HTML report
    """
    total_amount_at_risk = 0
    for pair in flagged_pairs:
        try:
            total_amount_at_risk += int(float(str(pair.voucher_a.get('amount', 0)).replace(',', '')))
        except Exception:
            pass
    
    # Sort by confidence: HIGH first, then MEDIUM, then LOW
    confidence_order = {'HIGH': 0, 'MEDIUM': 1, 'LOW': 2}
    flagged_pairs.sort(key=lambda x: confidence_order.get(x.confidence, 3))
    
    timestamp = datetime.datetime.now().strftime('%d-%b-%Y %H:%M IST')
    
    confidence_colors = {
        'HIGH': ('#dc2626', '#fef2f2', '🔴'),
        'MEDIUM': ('#d97706', '#fffbeb', '🟡'),
        'LOW': ('#ea580c', '#fff7ed', '🟠'),
    }
    
    pairs_html = ""
    for idx, pair in enumerate(flagged_pairs, 1):
        color, bg_color, emoji = confidence_colors.get(pair.confidence, ('#6b7280', '#f9fafb', '⚪'))
        
        # Build matching attachments rows
        attach_rows = ""
        for att in pair.matching_attachments:
            size_kb = f"{att['size']:,} bytes"
            name_match = "✅" if att['filename_a'] == att['filename_b'] else "⚠️ (different names)"
            attach_rows += f"""
                <tr>
                    <td style="padding:8px 12px;border-bottom:1px solid #374151;">{att['filename_a']}</td>
                    <td style="padding:8px 12px;border-bottom:1px solid #374151;">{att['filename_b']}</td>
                    <td style="padding:8px 12px;border-bottom:1px solid #374151;text-align:right;">{size_kb}</td>
                    <td style="padding:8px 12px;border-bottom:1px solid #374151;text-align:center;">{name_match}</td>
                </tr>"""
        
        va = pair.voucher_a
        vb = pair.voucher_b
        amt_formatted = _format_amount(va.get('amount', ''))
        match_pct = ""
        min_total = min(pair.total_attachments_a, pair.total_attachments_b)
        if min_total > 0:
            pct = round((pair.match_count / min_total) * 100)
            match_pct = f" ({pct}%)"
        
        pairs_html += f"""
        <div style="background:{bg_color};border:2px solid {color};border-radius:12px;margin:20px 0;padding:0;overflow:hidden;">
            <div style="background:{color};color:white;padding:12px 20px;font-size:15px;font-weight:bold;">
                {emoji} PAIR #{idx} — Confidence: {pair.confidence} — Amount: ₹{amt_formatted}
            </div>
            <div style="padding:20px;color:#1f2937;">
                <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
                    <tr>
                        <th style="width:25%;padding:8px;text-align:left;color:#6b7280;font-size:12px;text-transform:uppercase;">Field</th>
                        <th style="width:37.5%;padding:8px;text-align:left;color:#10b981;font-size:13px;font-weight:bold;">Voucher A</th>
                        <th style="width:37.5%;padding:8px;text-align:left;color:#f59e0b;font-size:13px;font-weight:bold;">Voucher B</th>
                    </tr>
                    <tr style="background:rgba(0,0,0,0.06);">
                        <td style="padding:8px;font-weight:600;">Treasury</td>
                        <td style="padding:8px;">{va.get('treasury','')}</td>
                        <td style="padding:8px;">{vb.get('treasury','')}</td>
                    </tr>
                    <tr>
                        <td style="padding:8px;font-weight:600;">Major Head</td>
                        <td style="padding:8px;">{va.get('mh','')}</td>
                        <td style="padding:8px;">{vb.get('mh','')}</td>
                    </tr>
                    <tr style="background:rgba(0,0,0,0.06);">
                        <td style="padding:8px;font-weight:600;">Month / Year</td>
                        <td style="padding:8px;">{va.get('month','')}/{va.get('year','')}</td>
                        <td style="padding:8px;">{vb.get('month','')}/{vb.get('year','')}</td>
                    </tr>
                    <tr>
                        <td style="padding:8px;font-weight:600;">Voucher No.</td>
                        <td style="padding:8px;font-weight:bold;">{va.get('voucher_no','')}</td>
                        <td style="padding:8px;font-weight:bold;">{vb.get('voucher_no','')}</td>
                    </tr>
                    <tr style="background:rgba(0,0,0,0.03);">
                        <td style="padding:8px;font-weight:600;">Amount</td>
                        <td style="padding:8px;font-weight:bold;color:{color};">₹{amt_formatted}</td>
                        <td style="padding:8px;font-weight:bold;color:{color};">₹{_format_amount(vb.get('amount',''))}</td>
                    </tr>
                    <tr>
                        <td style="padding:8px;font-weight:600;">DDO Code</td>
                        <td style="padding:8px;">{va.get('ddo','')}</td>
                        <td style="padding:8px;">{vb.get('ddo','')}</td>
                    </tr>
                </table>
                
                <div style="background:#111827;border-radius:8px;padding:16px;margin-top:12px;">
                    <div style="color:#10b981;font-weight:bold;font-size:14px;margin-bottom:10px;">
                        📎 Matching Attachments: {pair.match_count}/{min_total}{match_pct}
                    </div>
                    <table style="width:100%;border-collapse:collapse;color:#e5e7eb;font-size:13px;">
                        <tr style="color:#6b7280;font-size:11px;text-transform:uppercase;">
                            <th style="padding:8px 12px;text-align:left;">File in Voucher A</th>
                            <th style="padding:8px 12px;text-align:left;">File in Voucher B</th>
                            <th style="padding:8px 12px;text-align:right;">Size</th>
                            <th style="padding:8px 12px;text-align:center;">Name Match</th>
                        </tr>
                        {attach_rows}
                    </table>
                </div>
            </div>
        </div>"""
    
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centralized Voucher Validation Suite — Duplicate Payment Detection Report</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ 
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; 
            background: #0d1117; color: #e5e7eb; padding: 30px;
            line-height: 1.6;
        }}
        .header {{
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            border: 1px solid #334155;
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 24px;
            text-align: center;
        }}
        .header h1 {{
            font-size: 24px;
            color: #f87171;
            margin-bottom: 8px;
        }}
        .header .subtitle {{ color: #94a3b8; font-size: 14px; }}
        .stats {{
            display: flex;
            justify-content: center;
            gap: 40px;
            margin-top: 20px;
            flex-wrap: wrap;
        }}
        .stat-box {{
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 16px 24px;
            text-align: center;
            min-width: 160px;
        }}
        .stat-box .value {{
            font-size: 28px;
            font-weight: 800;
            color: #f87171;
        }}
        .stat-box .label {{
            font-size: 12px;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 4px;
        }}
        .footer {{
            text-align: center;
            color: #4b5563;
            font-size: 12px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #1e293b;
        }}
        @media print {{
            body {{ background: white; color: #111; padding: 10px; }}
            .header {{ background: #f1f5f9; border-color: #cbd5e1; }}
            .header h1 {{ color: #dc2626; }}
            .stat-box {{ background: #f8fafc; border-color: #e2e8f0; }}
            .stat-box .value {{ color: #dc2626; }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔴 Centralized Voucher Validation Suite — Duplicate Payment Detection Report</h1>
        <div class="subtitle">Generated: {timestamp} | Centralized Voucher Validation Suite v3.5</div>
        <div class="stats">
            <div class="stat-box">
                <div class="value">{len(flagged_pairs)}</div>
                <div class="label">Suspicious Pairs</div>
            </div>
            <div class="stat-box">
                <div class="value">₹{_format_amount(total_amount_at_risk)}</div>
                <div class="label">Total Amount at Risk</div>
            </div>
            <div class="stat-box">
                <div class="value">{sum(1 for p in flagged_pairs if p.confidence == 'HIGH')}</div>
                <div class="label">High Confidence</div>
            </div>
            <div class="stat-box">
                <div class="value">{sum(1 for p in flagged_pairs if p.confidence in ('MEDIUM','LOW'))}</div>
                <div class="label">Medium / Low</div>
            </div>
        </div>
    </div>
    
    {pairs_html}
    
    <div class="footer">
        Centralized Voucher Validation Suite v3.5 — Duplicate Payment Attachment Detection Engine<br>
        Developed by AG(A&amp;E) MP Gwalior | Report generated automatically after voucher batch download
    </div>
</body>
</html>"""
    
    try:
        out_dir = os.path.dirname(output_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        return True
    except Exception:
        return False


def _find_mptc_pdf(folder_path):
    """Find the MPTC PDF in a voucher folder. Returns filepath or None."""
    if not folder_path or not os.path.isdir(folder_path):
        return None
    for f in os.listdir(folder_path):
        fl = f.lower()
        if ('show_mptc' in fl or 'mptc' in fl) and fl.endswith('.pdf'):
            fp = os.path.join(folder_path, f)
            if os.path.isfile(fp) and os.path.getsize(fp) > 100:
                return fp
    return None


def _find_party_pdf(folder_path):
    """Find the Party Details PDF in a voucher folder. Returns filepath or None."""
    if not folder_path or not os.path.isdir(folder_path):
        return None
    for f in os.listdir(folder_path):
        fl = f.lower()
        if 'bill_party_' in fl and fl.endswith('.pdf'):
            fp = os.path.join(folder_path, f)
            if os.path.isfile(fp) and os.path.getsize(fp) > 50:
                return fp
    return None


def _find_attachment_pdfs(folder_path):
    """Find all user-uploaded attachment PDFs in a voucher folder."""
    result = []
    if not folder_path or not os.path.isdir(folder_path):
        return result
    for f in os.listdir(folder_path):
        fp = os.path.join(folder_path, f)
        if os.path.isfile(fp) and _is_attachment_file(f) and os.path.getsize(fp) > 100:
            result.append(fp)
    return sorted(result)


def _create_separator_page(writer, title_text, subtitle_text=""):
    """Create a simple separator page with centered title text using pypdf annotations."""
    from pypdf.generic import (
        ArrayObject, DictionaryObject, FloatObject,
        NameObject, TextStringObject, NumberObject
    )
    
    # Create a blank A4 page (595 x 842 points)
    page_width, page_height = 595, 842
    page = writer.add_blank_page(width=page_width, height=page_height)
    
    # Build a content stream with text
    # Use Helvetica-Bold (built-in PDF font, no embedding needed)
    content_lines = []
    content_lines.append("BT")
    
    # Title — large, centered
    content_lines.append("/F1 24 Tf")
    title_width_approx = len(title_text) * 12  # rough char width
    x_title = max(50, (page_width - title_width_approx) // 2)
    content_lines.append(f"{x_title} {page_height // 2 + 40} Td")
    safe_title = title_text.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)')
    content_lines.append(f"({safe_title}) Tj")
    
    # Subtitle — smaller, below title
    if subtitle_text:
        content_lines.append("/F1 14 Tf")
        subtitle_width_approx = len(subtitle_text) * 7
        x_sub = max(50, (page_width - subtitle_width_approx) // 2)
        # Move down from current position
        dx = x_sub - x_title
        content_lines.append(f"{dx} -40 Td")
        safe_sub = subtitle_text.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)')
        content_lines.append(f"({safe_sub}) Tj")
    
    content_lines.append("ET")
    
    content_stream = "\n".join(content_lines)
    
    # Add font resource to the page
    font_dict = DictionaryObject()
    font_dict[NameObject("/Type")] = NameObject("/Font")
    font_dict[NameObject("/Subtype")] = NameObject("/Type1")
    font_dict[NameObject("/BaseFont")] = NameObject("/Helvetica-Bold")
    
    fonts = DictionaryObject()
    fonts[NameObject("/F1")] = font_dict
    
    resources = DictionaryObject()
    resources[NameObject("/Font")] = fonts
    
    page[NameObject("/Resources")] = resources
    
    # Create content stream
    from pypdf.generic import DecodedStreamObject
    stream = DecodedStreamObject()
    stream.set_data(content_stream.encode('latin-1'))
    page[NameObject("/Contents")] = writer._add_object(stream)
    
    return page


def generate_merged_pdfs(flagged_pairs, output_dir, log_fn=None):
    """
    Generate merged comparison PDFs for each flagged duplicate pair.
    
    For each pair, creates a single PDF containing:
    - Separator: "VOUCHER A" header
    - Voucher A's MPTC PDF
    - Voucher A's Party Details
    - Voucher A's Attachments
    - Separator: "VOUCHER B" header
    - Voucher B's MPTC PDF
    - Voucher B's Party Details
    - Voucher B's Attachments
    
    Args:
        flagged_pairs: list of DuplicateMatch objects
        output_dir: directory to save merged PDFs (typically VOUCHERS folder)
        log_fn: optional logging function
        
    Returns:
        List of paths to generated merged PDFs
    """
    try:
        from pypdf import PdfWriter, PdfReader
    except ImportError:
        if log_fn:
            try:
                log_fn("[WARNING] pypdf not available — skipping merged PDF generation")
            except Exception:
                pass
        return []
    
    def _safe_log(msg):
        if not log_fn:
            return
        try:
            log_fn(msg)
        except (UnicodeEncodeError, UnicodeDecodeError):
            try:
                log_fn(msg.encode('ascii', errors='replace').decode('ascii'))
            except Exception:
                pass
    
    generated = []
    
    for pair in flagged_pairs:
        try:
            va = pair.voucher_a
            vb = pair.voucher_b
            amount = va.get('amount', 'unknown')
            mh = va.get('mh', '')
            treasury_a = va.get('treasury', '')
            treasury_b = vb.get('treasury', '')
            vou_a = va.get('voucher_no', '')
            vou_b = vb.get('voucher_no', '')
            folder_a = va.get('folder_path', '')
            folder_b = vb.get('folder_path', '')
            
            if not folder_a or not folder_b:
                continue
            if not os.path.isdir(folder_a) or not os.path.isdir(folder_b):
                continue
            
            import re
            # Build output filename: {amount}_{MH}_Vou{A}_vs_{B}_Merged_{treasury}.pdf
            safe_amount = str(amount).replace(',', '').strip()
            safe_mh = str(mh).strip()
            safe_treasury = re.sub(r"[^\w\s-]", "", str(treasury_a)).strip().replace(" ", "_")
            out_name = f"{safe_amount}_{safe_mh}_Vou{vou_a}_vs_{vou_b}_Double_Payment_Merged_{safe_treasury}.pdf"
            
            merged_vouchers_dir = os.path.join(output_dir, "MERGED VOUCHERS")
            out_path = os.path.join(merged_vouchers_dir, out_name)
            
            writer = PdfWriter()
            page_count = 0
            
            # --- Process Voucher A ---
            try:
                _create_separator_page(
                    writer,
                    f"VOUCHER A  --  Vou No. {vou_a}",
                    f"Treasury: {treasury_a} | MH: {mh} | Amount: {_format_amount(amount)}"
                )
                page_count += 1
            except Exception:
                pass
            
            # MPTC A
            mptc_a = _find_mptc_pdf(folder_a)
            if mptc_a:
                try:
                    reader = PdfReader(mptc_a)
                    bookmark_a_mptc = writer.add_outline_item(
                        f"Vou {vou_a} - MPTC", page_count
                    )
                    for p in reader.pages:
                        writer.add_page(p)
                        page_count += 1
                except Exception:
                    pass
            
            # Party Details A
            party_a = _find_party_pdf(folder_a)
            if party_a:
                try:
                    reader = PdfReader(party_a)
                    writer.add_outline_item(
                        f"Vou {vou_a} - Party Details", page_count
                    )
                    for p in reader.pages:
                        writer.add_page(p)
                        page_count += 1
                except Exception:
                    pass
            
            # Attachments A
            attachments_a = _find_attachment_pdfs(folder_a)
            if attachments_a:
                writer.add_outline_item(
                    f"Vou {vou_a} - Attachments ({len(attachments_a)} files)", page_count
                )
                for att_path in attachments_a:
                    try:
                        reader = PdfReader(att_path)
                        for p in reader.pages:
                            writer.add_page(p)
                            page_count += 1
                    except Exception:
                        pass
            
            # --- Process Voucher B ---
            try:
                _create_separator_page(
                    writer,
                    f"VOUCHER B  --  Vou No. {vou_b}",
                    f"Treasury: {treasury_b} | MH: {mh} | Amount: {_format_amount(amount)}"
                )
                page_count += 1
            except Exception:
                pass
            
            # MPTC B
            mptc_b = _find_mptc_pdf(folder_b)
            if mptc_b:
                try:
                    reader = PdfReader(mptc_b)
                    writer.add_outline_item(
                        f"Vou {vou_b} - MPTC", page_count
                    )
                    for p in reader.pages:
                        writer.add_page(p)
                        page_count += 1
                except Exception:
                    pass
            
            # Party Details B
            party_b = _find_party_pdf(folder_b)
            if party_b:
                try:
                    reader = PdfReader(party_b)
                    writer.add_outline_item(
                        f"Vou {vou_b} - Party Details", page_count
                    )
                    for p in reader.pages:
                        writer.add_page(p)
                        page_count += 1
                except Exception:
                    pass
            
            # Attachments B
            attachments_b = _find_attachment_pdfs(folder_b)
            if attachments_b:
                writer.add_outline_item(
                    f"Vou {vou_b} - Attachments ({len(attachments_b)} files)", page_count
                )
                for att_path in attachments_b:
                    try:
                        reader = PdfReader(att_path)
                        for p in reader.pages:
                            writer.add_page(p)
                            page_count += 1
                    except Exception:
                        pass
            
            # Write merged PDF
            if page_count > 2:  # At least separator pages + some content
                os.makedirs(merged_vouchers_dir, exist_ok=True)
                with open(out_path, 'wb') as f:
                    writer.write(f)
                generated.append(out_path)
                _safe_log(f"[MERGED PDF] {out_name} ({page_count} pages)")
            
        except Exception as e:
            _safe_log(f"[WARNING] Failed to merge pair Vou {va.get('voucher_no','')} vs {vb.get('voucher_no','')}: {str(e)[:60]}")
    
    return generated

def format_console_summary(flagged_pairs):
    """Generate rich console summary of duplicate detection results.
    
    Returns:
        str: Formatted multi-line summary string
    """
    if not flagged_pairs:
        return "✅ No duplicate payment patterns detected in this batch."
    
    high = [p for p in flagged_pairs if p.confidence == "HIGH"]
    medium = [p for p in flagged_pairs if p.confidence == "MEDIUM"]
    low = [p for p in flagged_pairs if p.confidence == "LOW"]
    
    def sum_amount(pairs):
        total = 0
        for p in pairs:
            try:
                total += int(float(str(p.voucher_a.get('amount', 0)).replace(',', '')))
            except Exception:
                pass
        return total
    
    total_risk = sum_amount(flagged_pairs)
    
    lines = [
        "",
        "━" * 56,
        "  🔍 DUPLICATE DETECTION SUMMARY",
        f"  Total Pairs Flagged:     {len(flagged_pairs)}",
        f"  ├── 🔴 HIGH Confidence:   {len(high)}  (₹{_format_amount(sum_amount(high))} at risk)",
        f"  ├── 🟡 MEDIUM:            {len(medium)}  (₹{_format_amount(sum_amount(medium))} at risk)",
        f"  └── 🟠 LOW:               {len(low)}  (₹{_format_amount(sum_amount(low))} at risk)",
        f"  Total Amount at Risk:    ₹{_format_amount(total_risk)}",
        "━" * 56,
        "",
    ]
    return "\n".join(lines)

def _format_amount(amount):
    """Format numeric amount into Indian style formatting."""
    try:
        s = str(int(amount))
        if len(s) <= 3:
            return s
        last_three = s[-3:]
        remaining = s[:-3]
        groups = []
        while remaining:
            groups.append(remaining[-2:])
            remaining = remaining[:-2]
        return ",".join(reversed(groups)) + "," + last_three
    except Exception:
        return str(amount)

