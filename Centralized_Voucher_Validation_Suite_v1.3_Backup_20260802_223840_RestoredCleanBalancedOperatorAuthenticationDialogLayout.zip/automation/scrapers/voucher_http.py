# automation/scrapers/voucher_http.py
# High-speed Direct HTTP Engine for Vouchers (Centralized Voucher Validation Suite)

import os
import re
import time
import calendar
import urllib.parse
from bs4 import BeautifulSoup
import requests

from automation.scrapers.voucher_scraper import (
    validate_downloaded_file,
    compress_pdf_file
)
from automation.scrapers.pol_scraper import _write_task_markers

# Custom headers for IFMIS requests (must match real browser headers)
DEFAULT_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language': 'en-US,en;q=0.9',
    'Origin': 'https://ifmisprod.mptreasury.gov.in',
    'Referer': 'https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Upgrade-Insecure-Requests': '1',
}

BASE_IFMIS_URL = "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm"


def _load_request_template(pe_instance):
    """Load captured Playwright request template if available."""
    try:
        import json
        # Check pe_instance config for db_path to locate template
        db_path = ""
        if hasattr(pe_instance, "config_dict"):
            db_path = pe_instance.config_dict.get("db_path", "")
        elif hasattr(pe_instance, "db_path"):
            db_path = pe_instance.db_path or ""
        
        if db_path:
            tpl_path = os.path.normpath(os.path.join(os.path.dirname(db_path), "voucher_request_template.json"))
            if os.path.exists(tpl_path):
                with open(tpl_path, "r") as f:
                    return json.load(f)
    except Exception:
        pass
    return None


def fetch_voucher_bill_control_no(session, treasury_val, from_date, to_date, mh, vou_no, search_type="voucher_number", extra_params=None):
    """
    Direct HTTP POST to search approved bills and extract billControlNo.
    Replicates the exact form submission that the Playwright browser performs.
    Returns (bill_control_no, err_msg).
    """
    
    # Build payload matching exact Playwright browser form fields
    # IMPORTANT: Do NOT include actionFlag, elementId, or btnSearch in payload!
    # These are NOT part of the HTML form and cause Struts HTTP 500 errors.
    payload = {
        "cmbTreasuryCodeName": str(treasury_val or ""),
        "cmbBillType": "-1",
        "txtFrmBillDate": str(from_date or ""),
        "txtToBillDate": str(to_date or ""),
        "txtMajorHead": str(mh or ""),
        "txtSerialNo": str(vou_no or "") if (search_type == "voucher_number" or not search_type) else "",
        "txtBillCntrlNo": str((extra_params or {}).get("bill_control", "")) if search_type == "bill_control" else "",
        "txtBillRefNo": str((extra_params or {}).get("bill_ref", "")) if search_type == "bill_ref" else "",
        "txtNetAmt": str((extra_params or {}).get("amount", "")) if search_type == "amount" else "",
        "billStatus": "-1",
        "helpHtml": "rnd/Process/Payment Processing.html",
    }

    try:
        # CRITICAL: GET the search page BEFORE every POST to establish form context.
        # IFMIS Struts is stateful — the server creates a form context on GET,
        # and the POST must happen against that same context. Without this GET,
        # the POST fails with HTTP 500 because the form context is expired/missing.
        # This replicates exactly what Playwright does: navigate to page → fill form → submit.
        page_url = f"{BASE_IFMIS_URL}?actionFlag=rnd-toApprovedBillsTreasuryWise&elementId=10072358"
        get_headers = dict(DEFAULT_HEADERS)
        get_headers.pop('Content-Type', None)  # GET requests don't need Content-Type
        session.get(page_url, headers=get_headers, timeout=30, verify=False, allow_redirects=True)

        resp = session.post(page_url, data=payload, headers=DEFAULT_HEADERS, timeout=30, verify=False)
        if resp.status_code != 200:
            return None, f"HTTP Status {resp.status_code}"

        if "j_username" in resp.text or "please login" in resp.text.lower():
            return None, "Session expired"

        # Check for empty / no records found
        content_low = resp.text.lower()
        if "no record found" in content_low or "no records found" in content_low or "no results found" in content_low:
            return None, "No Results Found"
        
        # Check for IFMIS error page
        if "your request cannot be currently processed" in content_low:
            return None, "IFMIS server error"

        # Pattern 1: showBillDtlByCtrlNo('elementId', 'billControlNo') — 2 arguments
        m_ctrl = re.search(r"showBillDtlByCtrlNo\s*\(\s*'[^']+'\s*,\s*'(\d+)'\s*\)", resp.text)
        if m_ctrl:
            return m_ctrl.group(1).strip(), None

        # Pattern 2: showBillDtlByCtrlNo('billControlNo') — 1 argument
        m_ctrl_single = re.search(r"showBillDtlByCtrlNo\s*\(\s*'(\d+)'\s*\)", resp.text)
        if m_ctrl_single:
            return m_ctrl_single.group(1).strip(), None

        # Pattern 3: Any numeric arg inside showBillDtlByCtrlNo(...)
        for m in re.finditer(r"showBillDtlByCtrlNo\s*\(\s*([^)]+)\s*\)", resp.text, re.IGNORECASE):
            nums = re.findall(r"\d{5,15}", m.group(1))
            if nums:
                return nums[-1].strip(), None

        # Pattern 4: billControlNo in href, onclick, or hidden field
        m_ctrl_alt = re.search(r"billControlNo[\"']?\s*[:=,]\s*[\"']?(\d{5,15})", resp.text, re.IGNORECASE)
        if m_ctrl_alt:
            return m_ctrl_alt.group(1).strip(), None

        return None, "billControlNo not found in search results"
    except Exception as ex:
        return None, str(ex)


def download_mptc_html_http(session, bill_control_no, output_pdf_path):
    """
    Fetches MPTC HTML details for a given billControlNo.
    Returns (success, err_msg).
    """
    mptc_url = f"{BASE_IFMIS_URL}?actionFlag=showMPTCDetails&billControlNo={bill_control_no}"
    try:
        headers = dict(DEFAULT_HEADERS)
        headers['Referer'] = f"{BASE_IFMIS_URL}?actionFlag=rnd-toApprovedBillsTreasuryWise"
        resp = session.get(mptc_url, headers=headers, timeout=30, verify=False)
        if resp.status_code == 200 and len(resp.content) > 500:
            if "j_username" in resp.text:
                return False, "Session expired"
            
            # Write raw HTML file first (or render via pdfkit/weasyprint if installed)
            html_path = os.path.splitext(output_pdf_path)[0] + ".html"
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(resp.text)
                
            return True, None
        return False, f"HTTP Status {resp.status_code}"
    except Exception as ex:
        return False, str(ex)


def download_party_details_pdf_http(session, bill_control_no, output_pdf_path):
    """
    Streams Party Details PDF directly from IFMIS backend.
    Returns (success, err_msg).
    """
    party_url = f"{BASE_IFMIS_URL}?actionFlag=getPartyDetailsPDF&billControlNo={bill_control_no}"
    try:
        headers = dict(DEFAULT_HEADERS)
        resp = session.get(party_url, headers=headers, timeout=30, verify=False, stream=True)
        if resp.status_code == 200 and (resp.content.startswith(b"%PDF") or len(resp.content) > 1000):
            with open(output_pdf_path, "wb") as f:
                f.write(resp.content)
            if validate_downloaded_file(output_pdf_path):
                compress_pdf_file(output_pdf_path)
                return True, None
            else:
                if os.path.exists(output_pdf_path):
                    try: os.remove(output_pdf_path)
                    except: pass
                return False, "PDF integrity check failed"
        return False, f"HTTP Status {resp.status_code}"
    except Exception as ex:
        return False, str(ex)


def download_voucher_attachments_http(session, bill_control_no, output_dir, logger_fn=None):
    """
    Fetches and downloads all attachments for a voucher via direct HTTP GET.
    Returns count of downloaded attachments.
    """
    att_page_url = f"{BASE_IFMIS_URL}?actionFlag=getAttachmentsData&billControlNo={bill_control_no}"
    downloaded_count = 0
    try:
        resp = session.get(att_page_url, headers=DEFAULT_HEADERS, timeout=20, verify=False)
        if resp.status_code != 200:
            return 0

        # Extract attachment IDs: openDocumentOnClick('123456', 'filename.pdf')
        att_matches = re.findall(r"openDocumentOnClick\(\s*'([^']+)'(?:\s*,\s*'([^']+)')?\s*\)", resp.text)
        if not att_matches:
            # Fallback: href matching downloadAttachment
            att_matches = re.findall(r"downloadAttachment.*?attachmentId[=\s']*(\d+)", resp.text, re.IGNORECASE)
            att_matches = [(m, f"Attachment_{idx+1}.pdf") for idx, m in enumerate(att_matches)]

        for idx, (att_id, suggested_name) in enumerate(att_matches):
            if not att_id:
                continue
            fname = suggested_name.strip() if suggested_name else f"Attachment_{idx+1}.pdf"
            clean_fname = "".join(c for c in fname if c.isalnum() or c in "._- ")
            out_path = os.path.join(output_dir, clean_fname)

            if os.path.exists(out_path) and validate_downloaded_file(out_path):
                if logger_fn: logger_fn(f"⏭ Attachment {idx+1} ({clean_fname}) already valid. Skipping.")
                downloaded_count += 1
                continue

            dl_url = f"{BASE_IFMIS_URL}?actionFlag=downloadAttachment&attachmentId={att_id}"
            try:
                r_att = session.get(dl_url, headers=DEFAULT_HEADERS, timeout=30, verify=False, stream=True)
                if r_att.status_code == 200 and len(r_att.content) > 500:
                    with open(out_path, "wb") as f:
                        f.write(r_att.content)
                    if validate_downloaded_file(out_path):
                        if out_path.lower().endswith(".pdf"):
                            compress_pdf_file(out_path)
                        downloaded_count += 1
                        if logger_fn: logger_fn(f"✅ Attachment {idx+1} Saved via HTTP: {clean_fname}")
                    else:
                        if os.path.exists(out_path):
                            try: os.remove(out_path)
                            except: pass
            except Exception as att_err:
                if logger_fn: logger_fn(f"⚠️ Attachment {idx+1} download failed: {att_err}")

        return downloaded_count
    except Exception:
        return 0


def download_paybill_excel_http(session, bill_control_no, output_xlsx_path):
    """
    Direct HTTP POST request to export Paybill details as Excel/HTML table.
    Converts raw table to clean .xlsx via Pandas.
    Returns (success, err_msg).
    """
    paybill_url = f"{BASE_IFMIS_URL}?actionFlag=retrievePayrollBillEmpDetailsData"
    payload = {
        "billControlNo": bill_control_no,
        "ExportFormat": "4"
    }

    try:
        resp = session.post(paybill_url, data=payload, headers=DEFAULT_HEADERS, timeout=45, verify=False)
        if resp.status_code != 200 or len(resp.content) < 500:
            return False, f"HTTP Status {resp.status_code}"

        if "j_username" in resp.text:
            return False, "Session expired"

        # Try parsing table with pandas or BeautifulSoup
        try:
            import pandas as pd
            dfs = pd.read_html(resp.text)
            if dfs:
                # Find largest DataFrame by row count
                best_df = max(dfs, key=lambda d: len(d))
                if len(best_df) > 0:
                    best_df.to_excel(output_xlsx_path, index=False, engine='openpyxl')
                    return True, None
        except Exception:
            pass

        # Direct raw write fallback if pandas parsing fails
        with open(output_xlsx_path, "wb") as f:
            f.write(resp.content)

        return True, None
    except Exception as ex:
        return False, str(ex)


def _direct_http_download_voucher(pe_instance, task_info, session, worker_id=1):
    """
    High-Speed Direct HTTP Worker function for downloading full Voucher artifacts.
    Returns (success, skipped, err_msg).
    """
    s_no     = task_info.get("s_no", 1)
    treasury = task_info.get("treasury", "")
    try_val  = task_info.get("try_val", "")
    from_date= task_info.get("from_date", "")
    to_date  = task_info.get("to_date", "")
    mh       = task_info.get("mh", "")
    vou      = task_info.get("voucher", "")
    folder   = task_info.get("download_dir", "")
    
    if not folder and hasattr(pe_instance, "resolve_download_path"):
        try:
            folder = pe_instance.resolve_download_path(task_info, "Voucher")
        except Exception: pass

    if not from_date or not to_date:
        try:
            m = int(task_info.get("month", 1))
            y = int(task_info.get("year", 2026))
            from_date = f"01/{m:02d}/{y}"
            to_date = f"{calendar.monthrange(y, m)[1]:02d}/{m:02d}/{y}"
        except Exception:
            pass

    if not try_val:
        # Priority 1: Use live dropdown options extracted from IFMIS warmup page
        live_opts = getattr(pe_instance, "_live_treasury_options", {})
        t_map = getattr(pe_instance, "TREASURY_MAP", {})
        
        # Resolve treasury input (could be "270", "NEE", "270-NEE-...", etc.)
        code_3digit = str(treasury).strip()
        if code_3digit in t_map:
            code_3digit = t_map[code_3digit]  # "NEE" -> "270"
        elif code_3digit in t_map.values():
            pass  # Already a 3-digit code like "270"
        else:
            # Extract leading digits from strings like "270-NEE-Neemuch"
            import re as _re
            m_digits = _re.match(r"^(\d+)", code_3digit)
            if m_digits:
                code_3digit = m_digits.group(1).zfill(3)
        
        # Look up in live dropdown options (best source — directly from IFMIS page)
        if live_opts and code_3digit in live_opts:
            try_val = live_opts[code_3digit]
        
        # Priority 2: Fallback to hardcoded TREASURY_IDS
        if not try_val:
            t_ids = getattr(pe_instance, "TREASURY_IDS", {})
            # Direct key match
            try_val = t_ids.get(treasury, "")
            if not try_val:
                for tk, tv in t_ids.items():
                    if f"-{treasury}-" in tk or tk.startswith(str(code_3digit)) or f"~{code_3digit}~" in tv:
                        try_val = tv
                        break
            if not try_val:
                for tk, tv in t_ids.items():
                    if str(treasury) in tk:
                        try_val = tv
                        break

    if not try_val:
        return False, False, f"Treasury '{treasury}' ID resolution failed"

    # Step 1: Search voucher and fetch billControlNo
    bill_control_no, err = fetch_voucher_bill_control_no(
        session, try_val, from_date, to_date, mh, vou,
        search_type=task_info.get("search_type", "voucher_number"),
        extra_params=task_info
    )

    if err == "No Results Found":
        _write_task_markers(folder, "skipped", f"Voucher {vou}", extra_info="Reason: No Results Found", task=task_info)
        return True, True, "No Results Found"

    if not bill_control_no:
        return False, False, f"Search failed: {err}"

    os.makedirs(folder, exist_ok=True)
    mptc_path = os.path.join(folder, "Show_MPTC.pdf")
    party_path = os.path.join(folder, "Party_Details.pdf")
    paybill_path = os.path.join(folder, f"Paybill_{vou}.xlsx")

    # Determine user preferences safely for both GUI instance and ScraperWorkerProxy
    paybill_only = False
    if hasattr(pe_instance, "var_paybill_only") and pe_instance.var_paybill_only:
        try: paybill_only = bool(pe_instance.var_paybill_only.get())
        except Exception: paybill_only = bool(pe_instance.var_paybill_only)
    elif hasattr(pe_instance, "paybill_only_val"):
        paybill_only = bool(pe_instance.paybill_only_val)

    should_download_paybill = False
    if hasattr(pe_instance, "var_voucher_download_paybills") and pe_instance.var_voucher_download_paybills:
        try: should_download_paybill = bool(pe_instance.var_voucher_download_paybills.get())
        except Exception: should_download_paybill = bool(pe_instance.var_voucher_download_paybills)
    elif hasattr(pe_instance, "download_paybills_in_vouchers_val"):
        should_download_paybill = bool(pe_instance.download_paybills_in_vouchers_val)

    # Step 2: Concurrently / sequentially download artifacts via HTTP
    if not paybill_only:
        # 2a. Party Details PDF
        download_party_details_pdf_http(session, bill_control_no, party_path)

        # 2b. MPTC Details HTML / PDF
        download_mptc_html_http(session, bill_control_no, mptc_path)

        # 2c. Voucher Attachments
        download_voucher_attachments_http(session, bill_control_no, folder, logger_fn=lambda m: pe_instance.log(f"[Worker {worker_id}] {m}"))

    # 2d. Paybill Excel (if enabled or paybill_only)
    if should_download_paybill or paybill_only:
        download_paybill_excel_http(session, bill_control_no, paybill_path)

    # Write completion marker
    _write_task_markers(folder, "success", f"Voucher {vou}", extra_info=f"BillCtrlNo: {bill_control_no}", task=task_info)
    return True, False, None
