import time
import os
import sys
import threading
import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

class TallyExcelWriter:
    """
    Generates structured Excel outputs categorizing vouchers into 4 distinct sheets & workbooks:
    1. Matched Exact (0% Deviation)
    2. 2% Deviation Exception (0% < Dev <= 2%)
    3. 10% Deviation Exception (2% < Dev <= 10%)
    4. Critical Mismatches (>10% Deviation)
    
    Creates:
    - Master Consolidated Workbook: Tally_Summary_Master_<timestamp>.xlsx (All 4 sheets)
    - 4 Individual Category Workbooks
    """

    def __init__(self, original_headers, output_dir=None):
        self.output_dir = output_dir or os.getcwd()
        os.makedirs(self.output_dir, exist_ok=True)
        self.headers = list(original_headers)
        
        self.tally_columns = [
            "SUMIF Voucher Total",
            "IFMIS Amount",
            "Gross Deviation",
            "Gross Dev %",
            "TDS Amount",
            "GST Amount",
            "Other Deductions",
            "Total Deductions",
            "Portal Net Amount",
            "Net Deviation",
            "Net Dev %",
            "FVC Entry Count",
            "Tally Status",
            "Remarks"
        ]


        self.full_headers = self.headers + self.tally_columns
        self._lock = threading.Lock()

        # Category Specs
        self.CAT_SPECS = {
            "exact": {
                "title": "Matched (Exact 0%)",
                "header_fill": "2E7D32", # Dark Green
                "row_fill": "E8F5E9",    # Light Green
                "prefix": "Tally_MATCHED_Exact"
            },
            "dev_2pct": {
                "title": "2% Deviation Exception",
                "header_fill": "F57F17", # Dark Amber
                "row_fill": "FFFDE7",    # Light Amber
                "prefix": "Tally_EXCEPTION_2pct"
            },
            "dev_10pct": {
                "title": "10% Deviation Exception",
                "header_fill": "E65100", # Dark Orange
                "row_fill": "FFF3E0",    # Light Orange
                "prefix": "Tally_EXCEPTION_10pct"
            },
            "critical": {
                "title": "Critical Mismatches (>10%)",
                "header_fill": "C62828", # Dark Red
                "row_fill": "FFEBEE",    # Light Red
                "prefix": "Tally_MISMATCHED_Critical"
            }
        }

        # 1. Master Consolidated Workbook with 4 worksheets
        self.wb_master = openpyxl.Workbook()
        default_sheet = self.wb_master.active
        
        self.ws_master = {}
        for cat_key, spec in self.CAT_SPECS.items():
            ws = self.wb_master.create_sheet(title=spec["title"])
            ws.append(self.full_headers)
            self._format_headers(ws, spec["header_fill"])
            self.ws_master[cat_key] = ws

        self.wb_master.remove(default_sheet)

        # 2. Individual Category Workbooks
        self.wb_cat = {}
        self.ws_cat = {}
        for cat_key, spec in self.CAT_SPECS.items():
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = spec["title"]
            ws.append(self.full_headers)
            self._format_headers(ws, spec["header_fill"])
            self.wb_cat[cat_key] = wb
            self.ws_cat[cat_key] = ws

        # Legacy backward-compatibility handles
        self.wb_green = self.wb_cat["exact"]
        self.ws_green = self.ws_cat["exact"]
        self.wb_red = self.wb_cat["critical"]
        self.ws_red = self.ws_cat["critical"]

        # Counters
        self.counts = {
            "exact": 0,
            "dev_2pct": 0,
            "dev_10pct": 0,
            "critical": 0
        }
        self.green_count = 0
        self.red_count = 0

    def _format_headers(self, ws, fill_color):
        font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
        fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        align = Alignment(horizontal="center", vertical="center", wrap_text=True)

        for col in range(1, len(self.full_headers) + 1):
            cell = ws.cell(row=1, column=col)
            cell.font = font
            cell.fill = fill
            cell.alignment = align
        ws.row_dimensions[1].height = 28

    def classify_tally_result(self, gross_dev, gross_dev_pct):
        dev_pct_rounded = round(float(gross_dev_pct), 2) if isinstance(gross_dev_pct, (int, float)) else 0.0
        if abs(gross_dev) < 0.01:
            return "exact"
        elif abs(dev_pct_rounded) <= 2.00:
            return "dev_2pct"
        elif abs(dev_pct_rounded) <= 10.00:
            return "dev_10pct"
        else:
            return "critical"


    def add_result(self, row_data, scraped_data, tally_result):
        orig_values = []
        for h in self.headers:
            orig_values.append(row_data.get(h, "") if isinstance(row_data, dict) else "")

        excel_amt = tally_result.get("excel_amount", 0.0)
        portal_total = scraped_data.get("portal_total", 0.0)
        gross_dev = tally_result.get("gross_dev", tally_result.get("gross_deviation", 0.0))
        gross_dev_pct = tally_result.get("gross_dev_pct", tally_result.get("gross_deviation_pct", 0.0))

        tds_amt = scraped_data.get("tds_amount", 0.0)
        gst_amt = scraped_data.get("gst_amount", 0.0)
        other_ded = scraped_data.get("other_deductions_amount", 0.0)
        tot_ded = scraped_data.get("total_deductions", 0.0)

        net_amt = scraped_data.get("net_amount", 0.0)
        if net_amt == 0.0 and portal_total > 0:
            net_amt = portal_total - tot_ded

        net_dev = tally_result.get("net_dev", tally_result.get("net_deviation", 0.0))
        net_dev_pct = tally_result.get("net_dev_pct", tally_result.get("net_deviation_pct", 0.0))

        entry_count = scraped_data.get("entry_count", 0)
        overall_flag = tally_result.get("overall_flag", "RED")
        remarks = tally_result.get("remarks", "")

        cat_key = self.classify_tally_result(gross_dev, gross_dev_pct)

        if cat_key == "exact":
            status_str = "✅ MATCHED (0%)"
        elif cat_key == "dev_2pct":
            status_str = "🟡 EXCEPTION (<=2%)"
        elif cat_key == "dev_10pct":
            status_str = "🟠 EXCEPTION (<=10%)"
        else:
            status_str = "❌ MISMATCH (>10%)"

        gross_pct_str = f"{gross_dev_pct:.2f}%" if isinstance(gross_dev_pct, (int, float)) else str(gross_dev_pct)
        net_pct_str = f"{net_dev_pct:.2f}%" if isinstance(net_dev_pct, (int, float)) else str(net_dev_pct)

        tally_values = [
            excel_amt,
            portal_total,
            gross_dev,
            gross_pct_str,
            tds_amt,
            gst_amt,
            other_ded,
            tot_ded,
            net_amt,
            net_dev,
            net_pct_str,
            entry_count,
            status_str,
            remarks
        ]

        full_row = orig_values + tally_values


        with self._lock:
            self.counts[cat_key] += 1
            if cat_key in ("exact", "dev_2pct"):
                self.green_count += 1
            else:
                self.red_count += 1

            # Append to Master Workbook Sheet
            ws_m = self.ws_master[cat_key]
            ws_m.append(full_row)
            self._style_row(ws_m, ws_m.max_row, cat_key)

            # Append to Category Workbook Sheet
            ws_c = self.ws_cat[cat_key]
            ws_c.append(full_row)
            self._style_row(ws_c, ws_c.max_row, cat_key)

    def _style_row(self, ws, row_idx, cat_key):
        fill_color = self.CAT_SPECS[cat_key]["row_fill"]
        fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        border = Border(
            bottom=Side(style="thin", color="E0E0E0"),
            top=Side(style="thin", color="E0E0E0")
        )

        for col in range(1, len(self.full_headers) + 1):
            cell = ws.cell(row=row_idx, column=col)
            cell.fill = fill
            cell.border = border
            cell.font = Font(name="Segoe UI", size=10)

            header_name = self.full_headers[col - 1]
            if "Total" in header_name or "Amount" in header_name or ("Deviation" in header_name and "%" not in header_name):
                if isinstance(cell.value, (int, float)):
                    cell.number_format = '#,##0.00'
            elif "%" in header_name:
                cell.alignment = Alignment(horizontal="right", vertical="center")

    def save(self, prefix="Tally"):
        os.makedirs(self.output_dir, exist_ok=True)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

        # 1. Save Master Consolidated Workbook
        master_filename = f"{prefix}_Summary_Master_{timestamp}.xlsx"
        master_path = os.path.join(self.output_dir, master_filename)

        for cat_key, ws in self.ws_master.items():
            self._auto_fit_columns(ws)

        self.wb_master.save(master_path)

        # 2. Save Category Workbooks
        cat_paths = {}
        for cat_key, wb in self.wb_cat.items():
            spec = self.CAT_SPECS[cat_key]
            fname = f"{spec['prefix']}_{timestamp}.xlsx"
            fpath = os.path.join(self.output_dir, fname)
            self._auto_fit_columns(self.ws_cat[cat_key])
            wb.save(fpath)
            cat_paths[cat_key] = fpath

        green_path = cat_paths["exact"]
        red_path = cat_paths["critical"]

        # Return backward compatible green, red + master_path
        if len(sys._getframe().f_back.f_code.co_names) >= 4:
            pass

        return green_path, red_path

    def _auto_fit_columns(self, ws):
        for col in ws.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                val_str = str(cell.value or '')
                if len(val_str) > max_len:
                    max_len = len(val_str)
            ws.column_dimensions[col_letter].width = max(max_len + 3, 12)
