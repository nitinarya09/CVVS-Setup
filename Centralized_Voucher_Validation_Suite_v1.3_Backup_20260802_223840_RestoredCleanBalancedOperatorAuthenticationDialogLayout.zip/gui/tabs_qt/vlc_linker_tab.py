# gui/tabs_qt/vlc_linker_tab.py
# PySide6 tab for VLC & COMPAY Dataset Linker in Centralized Voucher Validation Suite v1.2

import os
import threading
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFrame, QLabel,
    QPushButton, QLineEdit, QFileDialog, QProgressBar, QTextEdit, QMessageBox
)
from PySide6.QtCore import Qt, Signal, QObject
from PySide6.QtGui import QFont

class LinkerSignals(QObject):
    log_signal = Signal(str)
    progress_signal = Signal(int)
    done_signal = Signal(str)
    error_signal = Signal(str)

def build_vlc_linker_tab(app, tab):
    """Build the VLC & COMPAY Linker tab inside the PySide6 main application."""
    layout = QVBoxLayout(tab)
    layout.setContentsMargins(15, 10, 15, 10)
    layout.setSpacing(10)

    # Info card
    info_lbl = QLabel(
        "🔗 VLC & COMPAY Data Linker (High-Performance Polars Engine)\n"
        "Joins POL Voucher lists with COMPAY/VLC CSV datasets to add Detail Head (DHCD), Scheme Head (SHCD), and narration keywords.\n"
        "Note: Dataset linking is OPTIONAL. Validation runs fully with or without COMPAY linking."
    )
    info_lbl.setFont(QFont("Segoe UI", 10, QFont.Weight.Medium))
    info_lbl.setWordWrap(True)
    info_lbl.setAlignment(Qt.AlignCenter)
    info_lbl.setProperty("cssClass", "muted")
    layout.addWidget(info_lbl)

    # Main Card
    card = QFrame()
    card.setProperty("cssClass", "card")
    card_lay = QVBoxLayout(card)
    card_lay.setContentsMargins(15, 12, 15, 12)
    card_lay.setSpacing(10)

    # Row 1: POL File Picker
    pol_row = QHBoxLayout()
    lbl_pol = QLabel("1. POL Voucher Excel/CSV:")
    lbl_pol.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    lbl_pol.setFixedWidth(170)
    pol_row.addWidget(lbl_pol)

    app.entry_vlc_pol_path = QLineEdit()
    app.entry_vlc_pol_path.setPlaceholderText("Select POL Voucher List (e.g. Vouchers 03_2026_TEST_LIST.xlsx)")
    app.entry_vlc_pol_path.setFixedHeight(32)
    pol_row.addWidget(app.entry_vlc_pol_path, 1)

    btn_pol_browse = QPushButton("Browse...")
    btn_pol_browse.setProperty("cssClass", "outline")
    btn_pol_browse.setFixedHeight(32)
    btn_pol_browse.clicked.connect(lambda: _browse_pol_file(app))
    pol_row.addWidget(btn_pol_browse)

    card_lay.addLayout(pol_row)

    # Row 2: COMPAY / VLC File Picker
    vlc_row = QHBoxLayout()
    lbl_vlc = QLabel("2. COMPAY / VLC CSV:")
    lbl_vlc.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    lbl_vlc.setFixedWidth(170)
    vlc_row.addWidget(lbl_vlc)

    app.entry_vlc_db_path = QLineEdit()
    app.entry_vlc_db_path.setPlaceholderText("Select COMPAY Detail Classification CSV (e.g. D:\\COMPAY\\compay_FY_2025.csv)")
    app.entry_vlc_db_path.setFixedHeight(32)
    vlc_row.addWidget(app.entry_vlc_db_path, 1)

    btn_vlc_browse = QPushButton("Browse...")
    btn_vlc_browse.setProperty("cssClass", "outline")
    btn_vlc_browse.setFixedHeight(32)
    btn_vlc_browse.clicked.connect(lambda: _browse_vlc_file(app))
    vlc_row.addWidget(btn_vlc_browse)

    card_lay.addLayout(vlc_row)

    # Row 3: Action Buttons
    action_row = QHBoxLayout()
    action_row.setSpacing(10)

    btn_start_link = QPushButton("⚡ Link POL & COMPAY Datasets Now")
    btn_start_link.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    btn_start_link.setFixedHeight(38)
    btn_start_link.setProperty("cssClass", "primary")
    btn_start_link.clicked.connect(lambda: _execute_polars_linker(app, is_split=False))
    action_row.addWidget(btn_start_link, 2)

    btn_start_split = QPushButton("✂️ Extract Trimmed VLC CSV")
    btn_start_split.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    btn_start_split.setFixedHeight(38)
    btn_start_split.setProperty("cssClass", "secondary")
    btn_start_split.clicked.connect(lambda: _execute_polars_linker(app, is_split=True))
    action_row.addWidget(btn_start_split, 1)

    card_lay.addLayout(action_row)

    # Row 4: Progress Bar
    app.vlc_progress = QProgressBar()
    app.vlc_progress.setFixedHeight(8)
    app.vlc_progress.setRange(0, 100)
    app.vlc_progress.setValue(0)
    card_lay.addWidget(app.vlc_progress)

    layout.addWidget(card)

    # Log Terminal
    app.vlc_log_output = QTextEdit()
    app.vlc_log_output.setReadOnly(True)
    app.vlc_log_output.setFont(QFont("Consolas", 10))
    app.vlc_log_output.setPlaceholderText("Linker logs will appear here...")
    layout.addWidget(app.vlc_log_output, 1)

    return tab


def _browse_pol_file(app):
    fn, _ = QFileDialog.getOpenFileName(
        None, "Select POL Voucher Excel / CSV List", "", "Excel / CSV Files (*.xlsx *.xls *.csv)"
    )
    if fn:
        app.entry_vlc_pol_path.setText(fn)


def _browse_vlc_file(app):
    fn, _ = QFileDialog.getOpenFileName(
        None, "Select COMPAY / VLC CSV Database", "", "CSV Files (*.csv)"
    )
    if fn:
        app.entry_vlc_db_path.setText(fn)


def _execute_polars_linker(app, is_split=False):
    pol_path = app.entry_vlc_pol_path.text().strip()
    vlc_path = app.entry_vlc_db_path.text().strip()

    if not pol_path or not os.path.exists(pol_path):
        QMessageBox.warning(None, "Missing Input", "Please select a valid POL Voucher file.")
        return
    if not vlc_path or not os.path.exists(vlc_path):
        QMessageBox.warning(None, "Missing Input", "Please select a valid COMPAY / VLC CSV file.")
        return

    out_dir = os.path.join(os.path.dirname(pol_path), "downloads")
    os.makedirs(out_dir, exist_ok=True)
    default_out = os.path.join(out_dir, f"Linked_{os.path.basename(pol_path).replace('.xlsx', '.csv')}")

    out_path, _ = QFileDialog.getSaveFileName(
        None, "Save Output File", default_out, "CSV File (*.csv);;Excel File (*.xlsx)"
    )
    if not out_path:
        return

    app.vlc_log_output.clear()
    app.vlc_progress.setValue(0)

    signals = LinkerSignals()

    def handle_log(msg):
        app.vlc_log_output.append(msg)

    def handle_prog(pct):
        if pct >= 0:
            app.vlc_progress.setValue(pct)

    signals.log_signal.connect(handle_log)
    signals.progress_signal.connect(handle_prog)

    def worker():
        try:
            from link_vlc_polars import run_linker_engine, run_vlc_splitter
            if is_split:
                run_vlc_splitter(pol_path, vlc_path, out_path, signals.log_signal.emit, signals.progress_signal.emit)
            else:
                run_linker_engine(pol_path, vlc_path, out_path, signals.log_signal.emit, signals.progress_signal.emit)
        except Exception as e:
            signals.log_signal.emit(f"[ERROR] Engine failure: {e}")

    threading.Thread(target=worker, daemon=True).start()
