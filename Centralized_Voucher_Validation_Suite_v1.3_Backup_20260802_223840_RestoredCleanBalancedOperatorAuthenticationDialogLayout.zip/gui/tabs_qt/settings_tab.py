from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QFrame,
    QPushButton, QLabel, QCheckBox, QLineEdit, QComboBox, QGridLayout,
    QSlider, QSizePolicy)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from gui.theme import THEMES
from gui.toggle_switch import ToggleSwitch


def build_settings_tab(app, scroll_frame):
    """Build the Settings tab for Centralized Voucher Validation Suite."""
    grid = QGridLayout(scroll_frame)
    grid.setContentsMargins(10, 5, 10, 10)
    grid.setVerticalSpacing(10)
    grid.setHorizontalSpacing(10)
    grid.setColumnStretch(0, 1)
    grid.setColumnStretch(1, 3)
    grid.setColumnStretch(2, 1)

    # ── Section 1: Paths & Directories ──────────────────────────────────
    lbl_s1 = QLabel("📁 PATHS & DIRECTORIES")
    lbl_s1.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_s1.setProperty("cssClass", "highlight")
    grid.addWidget(lbl_s1, 0, 0, 1, 3, Qt.AlignLeft)

    # Download Root Directory
    lbl_dl_root = QLabel("Download Root Directory:")
    lbl_dl_root.setFont(QFont("Segoe UI", 11))
    lbl_dl_root.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    grid.addWidget(lbl_dl_root, 1, 0)

    app.entry_download_dir = QLineEdit()
    app.entry_download_dir.setFixedHeight(30)
    if hasattr(app, 'var_download_dir'):
        app.var_download_dir.bind_to_widget(app.entry_download_dir)
    grid.addWidget(app.entry_download_dir, 1, 1)

    app.btn_browse_download = QPushButton("Browse...")
    app.btn_browse_download.setProperty("cssClass", "outline")
    app.btn_browse_download.setFixedSize(85, 30)
    app.btn_browse_download.clicked.connect(app.browse_download_dir)
    grid.addWidget(app.btn_browse_download, 1, 2)

    # Download Path Template
    lbl_path_tmpl = QLabel("Download Path Template:")
    lbl_path_tmpl.setFont(QFont("Segoe UI", 11))
    lbl_path_tmpl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    grid.addWidget(lbl_path_tmpl, 2, 0)

    app.entry_path_template = QLineEdit()
    app.entry_path_template.setFixedHeight(30)
    if hasattr(app, 'var_path_template'):
        app.var_path_template.bind_to_widget(app.entry_path_template)
    grid.addWidget(app.entry_path_template, 2, 1, 1, 2)

    # Token help label
    lbl_tokens = QLabel(
        "Tokens: {Output_Folder}, {Treasury}, {DDO_Name}, {Year}, {Month}, "
        "{Voucher_No}, {Amount}, {Major_Head}, {S_No}")
    lbl_tokens.setProperty("cssClass", "muted")
    lbl_tokens.setWordWrap(True)
    lbl_tokens.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
    grid.addWidget(lbl_tokens, 3, 1, 1, 2)

    # ── Section 2: Timeout Configurations ───────────────────────────────
    lbl_s2 = QLabel("⏱ TIMEOUT CONFIGURATIONS (SECONDS)")
    lbl_s2.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_s2.setProperty("cssClass", "highlight")
    grid.addWidget(lbl_s2, 4, 0, 1, 3, Qt.AlignLeft)

    def _add_slider_row(row, label_text, slider_min, slider_max, var_name, lbl_attr):
        lbl = QLabel(label_text)
        lbl.setFont(QFont("Segoe UI", 11))
        lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        grid.addWidget(lbl, row, 0)

        slider = QSlider(Qt.Horizontal)
        slider.setMinimum(slider_min)
        slider.setMaximum(slider_max)
        slider.setFixedHeight(24)
        grid.addWidget(slider, row, 1)

        val_lbl = QLabel("")
        val_lbl.setFont(QFont("Segoe UI", 11, QFont.Bold))
        val_lbl.setFixedWidth(50)
        grid.addWidget(val_lbl, row, 2, Qt.AlignLeft)

        if hasattr(app, var_name):
            getattr(app, var_name).bind_to_widget(slider)

        def update_label(value, _lbl=val_lbl):
            if value >= 60:
                m = value // 60
                s = value % 60
                _lbl.setText(f"{m}m {s:02d}s")
            else:
                _lbl.setText(f"{value}s")
        slider.valueChanged.connect(update_label)
        update_label(slider.value())

        setattr(app, lbl_attr, val_lbl)
        return slider

    app.slider_login_timeout = _add_slider_row(
        5, "Portal Login Wait:", 10, 300, 'var_timeout_login', 'lbl_login_timeout')
    app.slider_pdf_timeout = _add_slider_row(
        6, "PDF Download Timeout:", 5, 300, 'var_timeout_pdf', 'lbl_pdf_timeout')
    app.slider_attachment_timeout = _add_slider_row(
        7, "Attachment Timeout:", 5, 300, 'var_timeout_attachment', 'lbl_attachment_timeout')
    app.slider_xls_timeout = _add_slider_row(
        8, "XLS Download Timeout:", 10, 3600, 'var_timeout_xls', 'lbl_xls_timeout')

    # ── Section 3: Parallel Download Options ────────────────────────────
    lbl_s3 = QLabel("⚡ PARALLEL DOWNLOAD OPTIONS")
    lbl_s3.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_s3.setProperty("cssClass", "highlight")
    grid.addWidget(lbl_s3, 9, 0, 1, 3, Qt.AlignLeft)

    app.sw_parallel = ToggleSwitch("Enable Parallel Downloading")
    app.sw_parallel.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_parallel'):
        app.var_parallel.bind_to_widget(app.sw_parallel)
    grid.addWidget(app.sw_parallel, 10, 0, 1, 2, Qt.AlignLeft)

    app.lbl_parallel_settings_disclaimer = QLabel("(only for high end machines)")
    app.lbl_parallel_settings_disclaimer.setProperty("cssClass", "disclaimer")
    grid.addWidget(app.lbl_parallel_settings_disclaimer, 10, 2, Qt.AlignLeft)

    lbl_workers = QLabel("Parallel Worker Threads:")
    lbl_workers.setFont(QFont("Segoe UI", 11))
    lbl_workers.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    grid.addWidget(lbl_workers, 11, 0)

    app.slider_parallel_workers = QSlider(Qt.Horizontal)
    app.slider_parallel_workers.setMinimum(1)
    app.slider_parallel_workers.setMaximum(20)
    app.slider_parallel_workers.setSingleStep(1)
    app.slider_parallel_workers.setPageStep(1)
    app.slider_parallel_workers.setFixedHeight(24)
    if hasattr(app, 'var_parallel_workers'):
        app.var_parallel_workers.bind_to_widget(app.slider_parallel_workers)
    grid.addWidget(app.slider_parallel_workers, 11, 1)

    app.lbl_parallel_workers = QLabel("")
    app.lbl_parallel_workers.setFont(QFont("Segoe UI", 11, QFont.Bold))
    app.lbl_parallel_workers.setFixedWidth(50)
    grid.addWidget(app.lbl_parallel_workers, 11, 2, Qt.AlignLeft)

    def _update_worker_label(value):
        app.lbl_parallel_workers.setText(str(value))
        if hasattr(app, 'update_timeout_labels'):
            app.update_timeout_labels()
    app.slider_parallel_workers.valueChanged.connect(_update_worker_label)
    _update_worker_label(app.slider_parallel_workers.value())



    app.sw_show_workers = ToggleSwitch("Show Worker Windows (Headful Mode)")
    app.sw_show_workers.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_show_workers'):
        app.var_show_workers.bind_to_widget(app.sw_show_workers)
    grid.addWidget(app.sw_show_workers, 13, 0, 1, 2, Qt.AlignLeft)

    app.sw_headful_monitor = ToggleSwitch("Enable 1 Headful Monitor Browser")
    app.sw_headful_monitor.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_headful_monitor'):
        app.var_headful_monitor.bind_to_widget(app.sw_headful_monitor)
    grid.addWidget(app.sw_headful_monitor, 13, 2, Qt.AlignLeft)

    # ── Section 3.5: Audit Mode & Download Options ────────────────────
    lbl_s3_5 = QLabel("📥 AUDIT MODE & DOWNLOAD OPTIONS")
    lbl_s3_5.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_s3_5.setProperty("cssClass", "highlight")
    grid.addWidget(lbl_s3_5, 14, 0, 1, 3, Qt.AlignLeft)

    app.sw_voucher_sno = ToggleSwitch("Audit Mode (Auto S.No Injection & Directory Naming)")
    app.sw_voucher_sno.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_voucher_sno'):
        app.var_voucher_sno.bind_to_widget(app.sw_voucher_sno)
    grid.addWidget(app.sw_voucher_sno, 15, 0, 1, 3, Qt.AlignLeft)

    app.sw_voucher_paybills = ToggleSwitch("Download Paybill Excel reports")
    app.sw_voucher_paybills.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_voucher_download_paybills'):
        app.var_voucher_download_paybills.bind_to_widget(app.sw_voucher_paybills)
    grid.addWidget(app.sw_voucher_paybills, 16, 0, 1, 3, Qt.AlignLeft)

    app.sw_paybill_only = ToggleSwitch("Download Paybill XLS Only (Skip PDFs/Attachments)")
    app.sw_paybill_only.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_paybill_only'):
        app.var_paybill_only.bind_to_widget(app.sw_paybill_only)
    grid.addWidget(app.sw_paybill_only, 17, 0, 1, 3, Qt.AlignLeft)

    app.sw_scan_existing_vouchers = ToggleSwitch("Scan & Audit Already Downloaded Vouchers (Default: OFF)")
    app.sw_scan_existing_vouchers.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_scan_existing_vouchers'):
        app.var_scan_existing_vouchers.bind_to_widget(app.sw_scan_existing_vouchers)
    grid.addWidget(app.sw_scan_existing_vouchers, 18, 0, 1, 3)

    # ── Section 4: Notifications & Alerts ───────────────────────────────
    lbl_s4 = QLabel("🔔 NOTIFICATIONS & ALERTS")
    lbl_s4.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_s4.setProperty("cssClass", "highlight")
    grid.addWidget(lbl_s4, 19, 0, 1, 3, Qt.AlignLeft)

    app.sw_audio_alerts = ToggleSwitch("Enable Sound Alerts & Audio Prompts")
    app.sw_audio_alerts.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_audio_alerts'):
        app.var_audio_alerts.bind_to_widget(app.sw_audio_alerts)
    grid.addWidget(app.sw_audio_alerts, 20, 0, 1, 2, Qt.AlignLeft)

    app.sw_os_notifications = ToggleSwitch("Enable OS Toast Notifications (System Tray)")
    app.sw_os_notifications.setFont(QFont("Segoe UI", 11))
    if hasattr(app, 'var_os_notifications'):
        app.var_os_notifications.bind_to_widget(app.sw_os_notifications)
    grid.addWidget(app.sw_os_notifications, 21, 0, 1, 2, Qt.AlignLeft)

    # ── Section 5: Graphics & Theming ───────────────────────────────────
    lbl_s5 = QLabel("🎨 GRAPHICS & THEMING")
    lbl_s5.setFont(QFont("Segoe UI", 12, QFont.Bold))
    lbl_s5.setProperty("cssClass", "highlight")
    grid.addWidget(lbl_s5, 22, 0, 1, 3, Qt.AlignLeft)

    lbl_theme = QLabel("Theme Accent Palette:")
    lbl_theme.setFont(QFont("Segoe UI", 11))
    lbl_theme.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    grid.addWidget(lbl_theme, 23, 0)

    app.opt_theme_palette = QComboBox()
    app.opt_theme_palette.setFixedHeight(30)
    app.opt_theme_palette.setFont(QFont("Segoe UI", 11))
    theme_names = list(THEMES.keys())
    app.opt_theme_palette.addItems(theme_names)
    if hasattr(app, 'var_theme_accent'):
        app.var_theme_accent.bind_to_widget(app.opt_theme_palette)
    app.opt_theme_palette.currentTextChanged.connect(
        lambda text: app.change_theme_accent(text) if hasattr(app, 'change_theme_accent') else None)
    grid.addWidget(app.opt_theme_palette, 23, 1, 1, 2)

    # ── Action Buttons ──────────────────────────────────────────────────
    btn_container = QWidget()
    btn_container_layout = QHBoxLayout(btn_container)
    btn_container_layout.setContentsMargins(0, 15, 0, 5)
    btn_container_layout.setSpacing(15)
    btn_container_layout.addStretch(1)

    app.btn_clear_resume = QPushButton("🗑️ Clear Delta Resume Session")
    app.btn_clear_resume.setProperty("cssClass", "danger")
    app.btn_clear_resume.setFixedHeight(32)
    app.btn_clear_resume.setFixedWidth(240)
    app.btn_clear_resume.setFont(QFont("Segoe UI", 11, QFont.Bold))
    app.btn_clear_resume.clicked.connect(app.clear_delta_resume_session)
    btn_container_layout.addWidget(app.btn_clear_resume)

    app.btn_edit_headers = QPushButton("⚙️ Configure Excel Headers")
    app.btn_edit_headers.setProperty("cssClass", "secondary")
    app.btn_edit_headers.setFixedHeight(32)
    app.btn_edit_headers.setFixedWidth(220)
    app.btn_edit_headers.setFont(QFont("Segoe UI", 11, QFont.Bold))
    app.btn_edit_headers.clicked.connect(app.open_header_config_modal)
    btn_container_layout.addWidget(app.btn_edit_headers)

    app.btn_save_config = QPushButton("💾 Save Configuration")
    app.btn_save_config.setProperty("cssClass", "primary")
    app.btn_save_config.setFixedHeight(32)
    app.btn_save_config.setFixedWidth(220)
    app.btn_save_config.setFont(QFont("Segoe UI", 11, QFont.Bold))
    app.btn_save_config.clicked.connect(app.save_config)
    btn_container_layout.addWidget(app.btn_save_config)

    btn_container_layout.addStretch(1)

    grid.addWidget(btn_container, 24, 0, 1, 3)

    if hasattr(app, 'update_timeout_labels'):
        if hasattr(app, 'var_timeout_login'):
            app.var_timeout_login.trace_add("write", app.update_timeout_labels)
        if hasattr(app, 'var_timeout_pdf'):
            app.var_timeout_pdf.trace_add("write", app.update_timeout_labels)
        if hasattr(app, 'var_timeout_attachment'):
            app.var_timeout_attachment.trace_add("write", app.update_timeout_labels)
        if hasattr(app, 'var_timeout_xls'):
            app.var_timeout_xls.trace_add("write", app.update_timeout_labels)
        if hasattr(app, 'var_parallel_workers'):
            app.var_parallel_workers.trace_add("write", app.update_timeout_labels)
        app.update_timeout_labels()

    grid.setRowStretch(20, 1)
