import os
import re
import pandas as pd
from bs4 import BeautifulSoup

def read_paybill_as_df(app_instance, file_path):
    # Check if file exists
    if not os.path.exists(file_path):
        # Try with 'x' extension or without
        if file_path.lower().endswith(".xlsx") and os.path.exists(file_path[:-1]):
            file_path = file_path[:-1]
        elif file_path.lower().endswith(".xls") and os.path.exists(file_path + "x"):
            file_path = file_path + "x"
        else:
            raise FileNotFoundError(f"Paybill file not found: {file_path}")
                
    # 1. Try reading with pd.read_html first
    try:
        df_list = pd.read_html(file_path)
        if df_list:
            return df_list[0]
    except Exception:
        pass
            
    # 2. Try parsing with BeautifulSoup and html.parser (standard python library parser)
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        if "<table" in content.lower() or "<html" in content.lower():
            soup = BeautifulSoup(content, "html.parser")
            tables = soup.find_all("table")
            if tables:
                table = tables[0]
                rows = table.find_all("tr")
                grid = {}
                max_r = 0
                max_c = 0
                for r_idx, row in enumerate(rows):
                    c_idx = 0
                    cells = row.find_all(["td", "th"])
                    for cell in cells:
                        colspan = int(cell.get("colspan", 1))
                        rowspan = int(cell.get("rowspan", 1))
                        while (r_idx, c_idx) in grid:
                            c_idx += 1
                        val = cell.get_text().strip()
                        for dr in range(rowspan):
                            for dc in range(colspan):
                                grid[(r_idx + dr, c_idx + dc)] = val
                        c_idx += colspan
                        max_c = max(max_c, c_idx)
                    max_r = max(max_r, r_idx + 1)
                    
                data = []
                for r in range(max_r):
                    row_data = []
                    for c in range(max_c):
                        row_data.append(grid.get((r, c), ""))
                    data.append(row_data)
                return pd.DataFrame(data)
    except Exception as ex:
        app_instance.log(f"⚠️ Custom HTML parser warning: {ex}")
            
    # 3. Fallback to standard pd.read_excel with manual engine retries
    try:
        return pd.read_excel(file_path)
    except Exception:
        try:
            return pd.read_excel(file_path, engine="openpyxl")
        except Exception:
            return pd.read_excel(file_path, engine="xlrd")

def clean_and_save_flat_paybill(app_instance, xls_path, output_xlsx_path, year, month, vou, treasury, mh):
    try:
        import pandas as pd
        import re
        import os
            
        # Load raw spreadsheet
        df = read_paybill_as_df(app_instance, xls_path)
            
        # Extract metadata from the first 10 rows
        meta_text = ""
        for r in range(min(10, len(df))):
            meta_text += " " + " ".join([str(val) for val in df.iloc[r].dropna()])
            
        ddo_code_match = re.search(r'DDO\s*Code\s*:\s*(\w+)', meta_text, re.IGNORECASE)
        ddo_name_match = re.search(r'DDO\s*Name\s*:\s*([^\n\r\|]+)', meta_text, re.IGNORECASE)
        bill_id_match = re.search(r'Bill\s*Id\s*:\s*(\w+)', meta_text, re.IGNORECASE)
            
        ddo_code = ddo_code_match.group(1).strip() if ddo_code_match else ""
        ddo_name = ddo_name_match.group(1).strip() if ddo_name_match else "UNKNOWN DDO NAME"
        bill_id = bill_id_match.group(1).strip() if bill_id_match else "0"
            
        if not ddo_code:
            fname = os.path.basename(xls_path)
            m = re.search(r'PayBill_(\d+)', fname, re.IGNORECASE)
            ddo_code = m.group(1) if m else "UNKNOWN"
                
        bill_type = "Paybill"
        if "nps" in meta_text.lower():
            bill_type = "MP State-NPS Paybill"
        elif "gpf" in meta_text.lower():
            bill_type = "GPF Paybill"
                
        months_map = {1: "January", 2: "February", 3: "March", 4: "April", 5: "May", 6: "June", 
                      7: "July", 8: "August", 9: "September", 10: "October", 11: "November", 12: "December"}
        try:
            month_str = months_map.get(int(month), str(month))
        except Exception:
            month_str = str(month)
                
        # Locate employee header rows (containing "Employee Name" and "PAYMENT")
        header_idx = -1
        for r in range(len(df)):
            row_str = " ".join([str(val) for val in df.iloc[r].dropna()])
            if "Employee Name" in row_str and "PAYMENT" in row_str:
                header_idx = r
                break
                    
        if header_idx == -1:
            app_instance.log("⚠️ Could not find Employee Name / PAYMENT header structure in downloaded Paybill.")
            return False
                
        subheader_idx = header_idx + 1
        primary_headers = df.iloc[header_idx]
        sub_headers = df.iloc[subheader_idx]
            
        # Build column mapping: col_idx -> list of sub-header names
        col_mapping = {}
        for c in range(df.shape[1]):
            p_val = str(primary_headers.iloc[c]) if pd.notna(primary_headers.iloc[c]) else ""
            s_val = str(sub_headers.iloc[c]) if pd.notna(sub_headers.iloc[c]) else ""
                
            header_to_parse = s_val if s_val else p_val
            header_to_parse = header_to_parse.strip()
            if not header_to_parse:
                continue
                    
            # Clean Account to prevent splitting by slash
            header_to_parse = re.sub(r'[Aa]/[Cc]\b', 'Account', header_to_parse)
                
            tokens = re.split(r'[/|\n]+', header_to_parse)
            cleaned_tokens = []
            for t in tokens:
                t_clean = t.strip()
                if t_clean and t_clean not in ["PAYMENT", "A.G. DEDUCTION", "TRS. DEDUCTION"]:
                    cleaned_tokens.append(t_clean)
                
            col_mapping[c] = cleaned_tokens
                
        # Extract employee data
        employees = []
        current_pay_scale = ""
            
        for r in range(subheader_idx + 1, len(df)):
            row_vals = df.iloc[r]
            col0 = str(row_vals.iloc[0]).strip()
                
            if "PAY SCALE" in col0:
                current_pay_scale = col0
                continue
                    
            # Verify if row is a valid employee record (Sr.No is a valid integer)
            is_emp_row = False
            sr_no_val = 0
            try:
                sr_no_val = int(float(col0))
                is_emp_row = True
            except (ValueError, TypeError, OverflowError):
                pass
                    
            if not is_emp_row:
                continue
                    
            emp_data = {
                "sr_no": sr_no_val,
                "pay_scale": current_pay_scale,
                "employee_name": "UNKNOWN",
                "employee_code": "UNKNOWN",
                "designation": "",
                "gpf_pran": "",
                "bank_ac": "",
                "days_paid": "0",
                "basic_pay": 0,
                "da": 0,
                "grade_pay": 0,
                "allowances": {},
                "deductions": {},
                "total_treasury_deduction": 0,
                "total_ag_deduction": 0,
                "total_deductions": 0,
                "gross_salary": 0,
                "net_salary": 0
            }
                
            for c in range(df.shape[1]):
                if c not in col_mapping:
                    continue
                        
                cell_val = str(row_vals.iloc[c]).strip() if pd.notna(row_vals.iloc[c]) else ""
                sub_keys = col_mapping[c]
                cell_tokens = [t.strip() for t in cell_val.split('\n')]
                    
                p_val = str(primary_headers.iloc[c]).upper() if pd.notna(primary_headers.iloc[c]) else ""
                    
                # Parse Employee details column
                if c == 1 or "EMPLOYEE NAME" in p_val:
                    emp_data["employee_name"] = cell_tokens[0] if len(cell_tokens) > 0 else "UNKNOWN"
                    emp_data["employee_code"] = cell_tokens[1] if len(cell_tokens) > 1 else "UNKNOWN"
                    emp_data["designation"] = cell_tokens[2] if len(cell_tokens) > 2 else ""
                    emp_data["gpf_pran"] = cell_tokens[3] if len(cell_tokens) > 3 else ""
                    emp_data["bank_ac"] = cell_tokens[4] if len(cell_tokens) > 4 else ""
                        
                    days = cell_tokens[5] if len(cell_tokens) > 5 else "0"
                    if not days or days == "(-)" or days.upper() == "NAN":
                        emp_data["days_paid"] = "0"
                    elif days.startswith("(") and days.endswith(")"):
                        emp_data["days_paid"] = days[1:-1]
                    else:
                        emp_data["days_paid"] = days
                    continue
                        
                # Parse other columns (allowances & deductions)
                for idx, key in enumerate(sub_keys):
                    val_str = cell_tokens[idx] if idx < len(cell_tokens) else "0"
                        
                    def clean_num(v):
                        try:
                            s = str(v).strip().replace(',', '')
                            if not s or s == '-' or s == '(-)' or s.upper() == 'NAN':
                                return 0
                            return int(round(float(s)))
                        except ValueError:
                            return 0
                                
                    numeric_val = clean_num(val_str)
                    safe_key = key.strip().upper()
                        
                    # Use XZ matching to map base properties
                    norm_key = safe_key.replace(" ", "").replace("\n", "")
                    norm_key = re.sub(r'[^A-Z0-9]', '', norm_key)
                        
                    is_base = False
                    if 'BASICPAY' in norm_key or norm_key == 'BP':
                        emp_data["basic_pay"] = numeric_val
                        is_base = True
                    elif norm_key == 'DA' or 'DEARNESS' in norm_key:
                        emp_data["da"] = numeric_val
                        is_base = True
                    elif 'GRADEPAY' in norm_key or norm_key == 'GP':
                        emp_data["grade_pay"] = numeric_val
                        is_base = True
                    elif 'GROSS' in norm_key:
                        emp_data["gross_salary"] = numeric_val
                        is_base = True
                    elif 'TOTALAGDED' in norm_key or 'AGDED' in norm_key:
                        emp_data["total_ag_deduction"] = numeric_val
                        is_base = True
                    elif any(k in norm_key for k in ['TOTALTREASURY', 'TOTALTRSDED', 'TREASURYDED', 'TRSDED']):
                        emp_data["total_treasury_deduction"] = numeric_val
                        is_base = True
                    elif 'TOTALDEDUCTION' in norm_key or 'TOTDED' in norm_key:
                        emp_data["total_deductions"] = numeric_val
                        is_base = True
                    elif 'NETSALARY' in norm_key or 'NETPAY' in norm_key or 'NETAMT' in norm_key:
                        emp_data["net_salary"] = numeric_val
                        is_base = True
                            
                    if not is_base:
                        # Map to allowances or deductions dictionary
                        if "DEDUCTION" in p_val or "DED" in p_val:
                            emp_data["deductions"][safe_key] = numeric_val
                        else:
                            emp_data["allowances"][safe_key] = numeric_val
                                
            # Check for header repeat skip
            if emp_data["employee_name"].upper().strip() == "EMPLOYEE NAME" or emp_data["employee_code"].upper().strip() == "EMPLOYEE CODE":
                continue
                    
            employees.append(emp_data)
                
        if employees:
            # Gather all unique sorted keys
            all_allows = sorted(list(set(k for emp in employees for k in emp['allowances'].keys())))
            all_deds = sorted(list(set(k for emp in employees for k in emp['deductions'].keys())))
                
            rows = []
            for emp in employees:
                # Resolve totals if zero
                tot_ded = emp["total_deductions"]
                if tot_ded == 0:
                    tot_ded = emp["total_treasury_deduction"] + emp["total_ag_deduction"]
                        
                gross = emp["gross_salary"]
                if gross == 0 and emp["basic_pay"] > 0:
                    gross = emp["basic_pay"] + emp["da"] + emp["grade_pay"] + sum(emp["allowances"].values())
                        
                net = emp["net_salary"]
                if net == 0 and gross > 0:
                    net = gross - tot_ded
                        
                row = {
                    "Sr No": emp["sr_no"],
                    "Employee Code": emp["employee_code"],
                    "Employee Name": emp["employee_name"],
                    "Designation": emp["designation"],
                    "GPF/PRAN A/c": emp["gpf_pran"],
                    "Bank A/c No": int(emp["bank_ac"]) if emp["bank_ac"].isdigit() else emp["bank_ac"],
                    "Days Paid": emp["days_paid"],
                    "Basic Pay": emp["basic_pay"],
                    "D.A.": emp["da"],
                    "D.A. % of Basic": f"{emp['da'] / emp['basic_pay'] * 100:.1f}%" if emp['basic_pay'] > 0 else "0.0%",
                    "Grade Pay": emp["grade_pay"]
                }
                    
                # Add Allowances and their % of basic
                for allow in all_allows:
                    val = emp["allowances"].get(allow, 0)
                    row[f"Allow: {allow}"] = val
                    row[f"Allow: {allow} % of Basic"] = f"{val / emp['basic_pay'] * 100:.1f}%" if emp['basic_pay'] > 0 else "0.0%"
                        
                row["Gross Salary"] = gross
                    
                # Add Deductions
                for ded in all_deds:
                    row[f"Ded: {ded}"] = emp["deductions"].get(ded, 0)
                        
                row["Total Treasury Deduction"] = emp["total_treasury_deduction"]
                row["Total A.G. Deduction"] = emp["total_ag_deduction"]
                row["Total Deductions"] = tot_ded
                row["Net Salary"] = net
                row["Bill Type"] = bill_type
                row["Month"] = month_str
                row["Year"] = int(year)
                row["Pay Scale"] = emp["pay_scale"]
                row["DDO Code"] = int(ddo_code) if ddo_code.isdigit() else ddo_code
                row["DDO Name"] = ddo_name
                row["Bill ID"] = int(bill_id) if bill_id.isdigit() else bill_id
                row["Source File"] = os.path.basename(xls_path)
                row["Voucher No"] = vou
                row["Voucher_No"] = vou
                row["Treasury"] = treasury
                row["Treasury_Name"] = treasury
                row["Major Head"] = mh
                row["Major_Head"] = mh
                row["Audit Notes"] = ""
                    
                rows.append(row)
                    
            flat_df = pd.DataFrame(rows)
            flat_df.drop_duplicates(inplace=True)
            flat_df.to_excel(output_xlsx_path, index=False)
            app_instance.log(f"✅ Created cleaned flat Paybill Excel (deduplicated & formatted): {os.path.basename(output_xlsx_path)} ({len(flat_df)} rows)")
            return True
        else:
            app_instance.log("⚠️ No employee records parsed from downloaded Paybill.")
            return False
    except Exception as e:
        app_instance.log(f"⚠️ Failed to parse and clean Paybill Excel: {e}")
        import traceback
        app_instance.log(traceback.format_exc())
        return False
