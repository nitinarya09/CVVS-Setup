"""treasury_heads_loader.py - Data loader for Treasury Downloader Head Hierarchy in Centralized Voucher Validation Suite.

Loads Heads.txt (JSON hierarchy) and HTML resources (report page.html, all voucher.html,
sr_pay.html, sr_rec_mh.html) from Treasury Downloader directory to provide dynamic
Major Head options, Sub Major Heads, and Minor Heads.
"""

import os
import sys
import json
import re

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TD_DIR = os.path.join(BASE_DIR, "Treasury Downloader")

_HEADS_HIERARCHY = None
_SOR_OPTIONS = None
_VOUCHER_OPTIONS = None
_PAYMENT_OPTIONS = None
_RECEIPT_MH_OPTIONS = None


def clean_major_code(raw_code):
    """Extract clean 4-digit major head code from any label or string."""
    if not raw_code:
        return ""
    # Split by ' - ' or '-'
    code = str(raw_code).split(" - ")[0].strip()
    code = code.split("-")[0].strip()
    code = code.split()[0].strip()
    return code


def load_all_treasury_heads_data():
    """Load and cache all Treasury Head options and hierarchy."""
    global _HEADS_HIERARCHY, _SOR_OPTIONS, _VOUCHER_OPTIONS, _PAYMENT_OPTIONS, _RECEIPT_MH_OPTIONS
    if _HEADS_HIERARCHY is not None:
        return _HEADS_HIERARCHY, _SOR_OPTIONS, _VOUCHER_OPTIONS, _PAYMENT_OPTIONS, _RECEIPT_MH_OPTIONS

    heads_txt = os.path.join(TD_DIR, "Heads.txt")
    _HEADS_HIERARCHY = {}
    if os.path.exists(heads_txt):
        try:
            with open(heads_txt, "r", encoding="utf-8") as f:
                _HEADS_HIERARCHY = json.load(f)
        except Exception as e:
            print(f"Error loading Heads.txt: {e}")

    def parse_html_options(fname, select_id):
        fpath = os.path.join(TD_DIR, fname)
        options = []
        if os.path.exists(fpath):
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    html = f.read()
                pattern = rf'<select[^>]*id="{select_id}"[^>]*>(.*?)</select>'
                match = re.search(pattern, html, re.DOTALL) or re.search(rf'<select[^>]*name="{select_id}"[^>]*>(.*?)</select>', html, re.DOTALL)
                if match:
                    opts = re.findall(r'<option[^>]*value=["\']([^"\']*)["\'][^>]*>(.*?)</option>', match.group(1), re.DOTALL)
                    for val, text in opts:
                        val = val.strip()
                        text = text.strip()
                        if val == "-1" or (not val and text.startswith(("--", "Select", "select"))):
                            continue
                        options.append((val, text))
            except Exception as e:
                print(f"Error parsing {fname}: {e}")
        return options

    _SOR_OPTIONS = parse_html_options("report page.html", "major")
    _VOUCHER_OPTIONS = parse_html_options("all voucher.html", "HoA")
    _PAYMENT_OPTIONS = parse_html_options("sr_pay.html", "major")
    _RECEIPT_MH_OPTIONS = parse_html_options("sr_rec_mh.html", "major")

    return _HEADS_HIERARCHY, _SOR_OPTIONS, _VOUCHER_OPTIONS, _PAYMENT_OPTIONS, _RECEIPT_MH_OPTIONS


def get_mh_options_for_report(report_type):
    """Return list of (code, text) Major Head tuples for a given report type."""
    _, sor_opts, vouch_opts, pay_opts, rec_opts = load_all_treasury_heads_data()

    if report_type in ["Schedule of Receipt", "Subsidiary Register Receipt", "Subsidiary Register Minor Head - Receipt"]:
        return rec_opts if rec_opts else sor_opts
    elif report_type in ["Subsidiary Register Payment", "Subsidiary Register Minor Head - Expenditure"]:
        return pay_opts if pay_opts else vouch_opts
    elif report_type == "Treasury Wise all Voucher Details":
        return vouch_opts if vouch_opts else pay_opts
    else:
        return []


def get_submajors_for_major(raw_major_code):
    """Return dictionary of submajor heads for a given major head code."""
    hierarchy, _, _, _, _ = load_all_treasury_heads_data()
    clean_code = clean_major_code(raw_major_code)
    if clean_code in hierarchy:
        return hierarchy[clean_code].get("submajors", {})
    return {}


def get_minors_for_submajor(raw_major_code, submajor_code):
    """Return list of minor head dicts for a given major and submajor code."""
    submajors = get_submajors_for_major(raw_major_code)
    if submajor_code in submajors:
        return submajors[submajor_code].get("minors", [])
    return []
