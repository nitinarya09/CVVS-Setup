# core/constants.py
# Centralized Voucher Validation Suite v3.5 — Application constants and configuration

import os
import sys
import uuid
import re

TOOL_VERSION = "1.3"
RUN_ID = uuid.uuid4().hex[:8]

# Dedicated Remote Control Gist URL for Centralized Voucher Validation Suite
GIST_REMOTE_CONFIG_URL = "https://gist.githubusercontent.com/nitinarya09/f89743e1c62e729148b1cdeb54d6551b/raw/validation_suite_config.json"

# Determine application directory
if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(sys.executable)
else:
    APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

# Treasury code mapping (3-letter code → numeric ID)
TREASURY_MAP = {
    "BAL": "010", "BAD": "020", "BET": "030", "BHI": "040", "BPL": "050",
    "VIN": "051", "VAL": "052", "CTB": "054", "CHA": "060", "CHI": "070",
    "DAM": "080", "DAT": "090", "DEW": "100", "DHA": "110", "DIN": "120",
    "GUN": "130", "GWL": "140", "MML": "141", "HAR": "150", "HOS": "160",
    "IND": "170", "INC": "171", "JBP": "180", "JBC": "181", "JHA": "190",
    "KAT": "200", "KHA": "210", "KAR": "220", "MAN": "230", "MND": "240",
    "MOR": "250", "NAR": "260", "NEE": "270", "PAN": "280", "RIS": "290",
    "RAJ": "300", "RAT": "310", "REW": "320", "SAG": "330", "SAT": "340",
    "SEH": "350", "SEO": "360", "SHA": "370", "SAJ": "380", "SHI": "390",
    "SHE": "400", "SID": "410", "TIK": "420", "UJJ": "430", "UMA": "440",
    "VID": "450", "ANU": "460", "ASH": "470", "BUR": "480", "ALI": "490",
    "SNG": "500", "AGR": "510", "NIW": "520",
}

TREASURY_IDS = {
    "010-BAL-BALAGHAT TREASURY": "18312~010~BALAGHAT TREASURY",
    "020-BAD-Barwani District Treasury": "18071~020~Barwani District Treasury",
    "030-BET-Betul District Treasury": "17863~030~Betul District Treasury",
    "040-BHI-Bhind Treasury": "17575~040~Bhind Treasury",
    "050-BPL-District Treasury Office Bhopal": "17472~050~District Treasury Office Bhopal",
    "051-VIN-Vindhyachal Treasury": "17465~051~Vindhyachal Treasury",
    "052-VAL-Vallabh Bhawan Treasury, Bhopal": "17470~052~Vallabh Bhawan Treasury, Bhopal",
    "054-CTB-Principal Treasury Officer Centre Treasury Bhopal": "50027814~054~Principal Treasury Officer Centre Treasury Bhopal",
    "060-CHA-Chhatarpur Treasury": "17081~060~Chhatarpur Treasury",
    "070-CHI-Chhindwara Treasury": "16858~070~Chhindwara Treasury",
    "080-DAM-Damoh Treasury": "16573~080~Damoh Treasury",
    "090-DAT-Datia Treasury": "16419~090~Datia Treasury",
    "100-DEW-Dewas Treasury": "16304~100~Dewas Treasury",
    "110-DHA-Dhar Treasury": "16117~110~Dhar Treasury",
    "120-DIN-Dindori Treasury": "15743~120~Dindori Treasury",
    "130-GUN-Guna Treasury": "15710~130~Guna Treasury",
    "140-GWL-Gwalior Gorkhi Treasury": "15549~140~Gwalior Gorkhi Treasury",
    "141-MML-Motimahal Gwalior Treasury": "15547~141~Motimahal Gwalior Treasury",
    "150-HAR-Harda Treasury": "15292~150~Harda Treasury",
    "160-HOS-Hoshangabad Treasury": "15182~160~Hoshangabad Treasury",
    "170-IND-Indore District Treasury": "14925~170~Indore District Treasury",
    "171-INC-Indore City Treasury": "14929~171~Indore City Treasury",
    "180-JBP-Jabalpur District Treasury": "14605~180~Jabalpur District Treasury",
    "181-JBP-Jabalpur City Treasury": "14593~181~Jabalpur City Treasury",
    "190-JHA-Jhabua Treasury": "14278~190~Jhabua Treasury",
    "200-KAT-Katni Treasury": "14080~200~Katni Treasury",
    "210-KHA-Khandva Treasury": "13880~210~Khandva Treasury",
    "220-KAR-Khargaun Treasury": "13688~220~Khargaun Treasury",
    "230-MAN-Mandla Treasury": "13412~230~Mandla Treasury",
    "240-MND-Mandsaur Treasury": "13136~240~Mandsaur Treasury",
    "250-MOE-Morena Treasury": "12959~250~Morena Treasury",
    "260-NAR-Narsinghpur Treasury": "12775~260~Narsinghpur Treasury",
    "270-NEE-Neemuch District Treasury": "12605~270~Neemuch District Treasury",
    "280-PAN-Panna Treasury": "12473~280~Panna Treasury",
    "290-RIS-Raisen Treasury": "12326~290~Raisen Treasury",
    "300-RAJ-Rajgarh Treasury": "12147~300~Rajgarh Treasury",
    "310-RAT-Ratlam Treasury": "11969~310~Ratlam Treasury",
    "320-REW-Rewa Treasury": "11741~320~Rewa Treasury",
    "330-SAG-Sagar Treasury": "11416~330~Sagar Treasury",
    "340-SAT-Satna Treasury": "11125~340~Satna Treasury",
    "350-SEH-Sehore Treasury": "10878~350~Sehore Treasury",
    "360-SEO-Seoni Treasury": "10703~360~Seoni Treasury",
    "370-SHA-Shahdol Treasury": "10460~370~Shahdol Treasury",
    "380-SAJ-Shajapur Treasury": "10266~380~Shajapur Treasury",
    "390-SHI-Shivpuri Treasury": "10120~390~Shivpuri Treasury",
    "400-SHE-Sheopur Treasury": "9963~400~Sheopur Treasury",
    "410-SID-Seedhi Treasury": "9855~410~Seedhi Treasury",
    "420-TIK-Tikamgarh Treasury": "9660~420~Tikamgarh Treasury",
    "430-UJJ-Ujjain Treasury": "9491~430~Ujjain Treasury",
    "440-UMA-Umaria Treasury": "9242~440~Umaria Treasury",
    "450-VID-Vidisha Treasury": "9123~450~Vidisha Treasury",
    "460-ANU-Anupur Treasury": "18665~460~Anupur Treasury",
    "470-ASH-Ashoknagar Treasury": "18483~470~Ashoknagar Treasury",
    "480-BUR-Burhanpur Treasury": "18393~480~Burhanpur Treasury",
    "490-ALI-Alirajpur Treasury": "8950~490~Alirajpur Treasury",
    "500-SNG-Singrauli Treasury": "8833~500~Singrauli Treasury",
    "510-AGR-Agar Malwa Treasury": "18736~510~Agar Malwa Treasury",
    "520-NIW-District Treasury Office Niwari": "50027813~520~District Treasury Office Niwari"
}

def parse_ddo_file():
    mapping = {}
    try:
        ddo_path = os.path.join(APP_DIR, "ddo.txt")
        if os.path.exists(ddo_path):
            with open(ddo_path, "r", encoding="utf-8") as f:
                content = f.read()
            blocks = re.split(r"=== (.*?) ===", content)
            for i in range(1, len(blocks), 2):
                treasury_name = blocks[i].strip().replace("(V-)", "")
                ddos = [line.strip() for line in blocks[i + 1].split("\n") if line.strip()]
                mapping[treasury_name] = ddos
    except Exception as e:
        print(f"Error loading ddo.txt: {e}")
    return mapping

DDO_DATABASE = parse_ddo_file()

# VLC Downloader Constants
TREASURY_VLC_IDS = {
    '010 - BALAGHAT TREASURY': '18312',
    '020 - Barwani District Treasury': '18071',
    '030 - Betul District Treasury': '17863',
    '040 - Bhind Treasury': '17575',
    '050 - District Treasury Office Bhopal': '17472',
    '051 - Vindhyachal Treasury': '17465',
    '052 - Vallabh Bhawan Treasury, Bhopal': '17470',
    '054 - Principal Treasury Officer Centre Treasury Bhopal': '50027814',
    '060 - Chhatarpur Treasury': '17081',
    '070 - Chhindwara Treasury': '16858',
    '080 - Damoh Treasury': '16573',
    '090 - Datia Treasury': '16419',
    '100 - Dewas Treasury': '16304',
    '110 - Dhar Treasury': '16117',
    '120 - Dindori Treasury': '15743',
    '130 - Guna Treasury': '15710',
    '140 - Gwalior Gorkhi Treasury': '15549',
    '141 - Motimahal Gwalior Treasury': '15547',
    '150 - Harda Treasury': '15292',
    '160 - Hoshangabad Treasury': '15182',
    '170 - Indore District Treasury': '14925',
    '171 - Indore City Treasury': '14929',
    '180 - Jabalpur District Treasury': '14605',
    '181 - Jabalpur City Treasury': '14593',
    '190 - Jhabua Treasury': '14278',
    '200 - Katni Treasury': '14080',
    '210 - Khandva Treasury': '13880',
    '220 - Khargaun Treasury': '13688',
    '230 - Mandla Treasury': '13412',
    '240 - Mandsaur Treasury': '13136',
    '250 - Morena Treasury': '12959',
    '260 - Narsinghpur Treasury': '12775',
    '270 - Neemuch District Treasury': '12605',
    '280 - Panna Treasury': '12473',
    '290 - Raisen Treasury': '12326',
    '300 - Rajgarh Treasury': '12147',
    '310 - Ratlam Treasury': '11969',
    '320 - Rewa Treasury': '11741',
    '330 - Sagar Treasury': '11416',
    '340 - Satna Treasury': '11125',
    '350 - Sehore Treasury': '10878',
    '360 - Seoni Treasury': '10703',
    '370 - Shahdol Treasury': '10460',
    '380 - Shajapur Treasury': '10266',
    '390 - Shivpuri Treasury': '10120',
    '400 - Sheopur Treasury': '9963',
    '410 - Seedhi Treasury': '9855',
    '420 - Tikamgarh Treasury': '9660',
    '430 - Ujjain Treasury': '9491',
    '440 - Umaria Treasury': '9242',
    '450 - Vidisha Treasury': '9123',
    '460 - Anupur Treasury': '18665',
    '470 - Ashoknagar Treasury': '18483',
    '480 - Burhanpur Treasury': '18393',
    '490 - Alirajpur Treasury': '8950',
    '500 - Singrauli Treasury': '8833',
    '510 - Agar Malwa Treasury': '18736',
    '520 - District Treasury Office Niwari': '50027813',
    '530 - District Treasury Mauganj': '50027815',
    '540 - District Treasury Pandhurna': '50027816',
    '550 - District Treasury Maihar': '50027817'
}

VLC_MODULES = [
    {"name": "Voucher Summary", "code": "402", "el_id": "100011002607", "folder": "Voucher_Summary"},
    {"name": "Voucher Details", "code": "403", "el_id": "100011002609", "folder": "Voucher_Details"},
    {"name": "Voucher Detail - Details Headwise", "code": "404", "el_id": "100011002611", "folder": "Voucher_Detail_Headwise"},
    {"name": "AG Deduction", "code": "405", "el_id": "100011002613", "folder": "AG_Deduction"},
    {"name": "NON AG Deduction", "code": "406", "el_id": "100011002615", "folder": "Non_AG_Deduction"}
]

VLC_MONTH_MAP = {
    "January": 1, "February": 2, "March": 3, "April": 4, "May": 5, "June": 6,
    "July": 7, "August": 8, "September": 9, "October": 10, "November": 11, "December": 12
}

