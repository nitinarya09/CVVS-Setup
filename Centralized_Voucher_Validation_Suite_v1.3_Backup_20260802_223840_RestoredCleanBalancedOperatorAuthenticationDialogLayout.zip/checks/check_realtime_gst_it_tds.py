# checks/check_realtime_gst_it_tds.py
# Realtime GST TDS & Income Tax TDS Deduction Compliance Verification Check

import os
import re
from checks.base_check import BaseValidationCheck
from parsers.mptc_parser import parse_mptc_pdf
from parsers.party_details_parser import parse_party_details_pdf


class CheckRealtimeGstitTds(BaseValidationCheck):
    check_id = "check_realtime_gst_it_tds"
    name = "GST & Income Tax TDS Compliance Check"
    description = "Inspects MPTC voucher PDF & party details to verify statutory GST TDS (2% on contracts > ₹2.5L) and Income Tax TDS (1%-2% on contractor/service payments > ₹30k under Sec 194C/194J)."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            # 1. Parse Voucher Amounts
            gross_amt_raw = voucher_data.get("amount", 0.0) or voucher_data.get("scraped_amount", 0.0)
            try:
                gross_amt = float(str(gross_amt_raw).replace(",", "").strip())
            except (ValueError, TypeError):
                gross_amt = 0.0

            total_deductions = float(voucher_data.get("total_deductions", 0.0) or 0.0)

            # 2. Inspect MPTC PDF for Bill Classification
            mptc_path = os.path.join(download_folder, "Show_MPTC.pdf")
            form_number = ""
            form_title = ""
            object_head = ""
            major_head = str(voucher_data.get("mh", "")).strip()
            raw_text = ""
            sub_vouchers = []

            if os.path.exists(mptc_path):
                mptc_data = parse_mptc_pdf(mptc_path)
                form_number = str(mptc_data.form_number).strip()
                form_title = str(mptc_data.form_title).upper().strip()
                object_head = str(mptc_data.object_head).strip()
                if mptc_data.major_head:
                    major_head = str(mptc_data.major_head).strip()
                raw_text = str(mptc_data.raw_text).upper()
                sub_vouchers = mptc_data.sub_vouchers

            # 3. Check for Exempt Claim Types
            # Personal Paybills, GPF, Pension, Medical, TA/DA, and Statutory Grants-in-Aid without commercial contracts
            exempt_forms = {"24", "27", "28", "43", "44", "56", "63"}
            exempt_obj_heads = {"01", "02", "03", "04", "06", "11", "12", "56", "63"}
            
            is_exempt = False
            exempt_reason = ""

            if form_number in exempt_forms:
                is_exempt = True
                exempt_reason = f"Personal employee claim (Form MPTC {form_number})"
            elif object_head in exempt_obj_heads:
                is_exempt = True
                exempt_reason = f"Personal / establishment object head ({object_head})"
            elif "ESTABLISHMENT PAY BILL" in form_title or "PAY BILL" in form_title or "PROVIDENT FUND" in raw_text or "GPF" in raw_text:
                is_exempt = True
                exempt_reason = "Paybill / GPF / Personal establishment claim"
            elif "PENSION" in form_title or "PENSION" in raw_text:
                is_exempt = True
                exempt_reason = "Pension / Gratuity bill"
            elif "MEDICAL" in form_title or "TRAVELLING ALLOWANCE" in form_title:
                is_exempt = True
                exempt_reason = "Medical reimbursement or TA/DA claim"
            elif "GRANT-IN-AID" in raw_text or "GRANT-IN-BILL" in raw_text:
                # Statutory inter-departmental grants are exempt unless commercial contractor sub-vouchers exist
                if not any("CONTRACT" in str(sv.get("description", "")).upper() for sv in sub_vouchers):
                    is_exempt = True
                    exempt_reason = "Statutory Grant-in-Aid transfer"

            if is_exempt:
                return {
                    "status": "SKIPPED",
                    "message": f"TDS Check SKIPPED: {exempt_reason}.",
                    "details": {"gross_amount": gross_amt, "form_number": form_number, "reason": exempt_reason}
                }

            if gross_amt <= 0.0:
                return {
                    "status": "SKIPPED",
                    "message": "TDS Check SKIPPED: Voucher amount is zero or unavailable.",
                    "details": {"gross_amount": 0.0}
                }

            # 4. Check for Contractor / Works / Service / Vendor Payment Indicators
            # Contractor payments correspond to MPTC Form 34/46, specific Object Heads (27, 28, 31, 14, 32, 13),
            # or party/text keywords (CONTRACTOR, WORKS, CONSTRUCTION, MAINTENANCE, OUTSOURCED, VENDOR, PVT LTD, FIRM)
            contractor_obj_heads = {"13", "14", "27", "28", "31", "32", "42", "63"}
            contractor_keywords = [
                "CONTRACT", "CONTRACTOR", "WORKS", "CONSTRUCTION", "MAINTENANCE",
                "REPAIR", "SERVICE", "OUTSOURC", "MANPOWER", "SECURITY", "VENDOR",
                "SUPPLIER", "PVT LTD", "LIMITED", "INFRA", "BUILDER", "CONSULTANT"
            ]

            has_contractor_head = object_head in contractor_obj_heads
            has_contractor_keyword = any(kw in raw_text for kw in contractor_keywords)
            
            # Check Party Details PDF if available
            party_path = os.path.join(download_folder, "Party_Details.pdf")
            party_text = ""
            if os.path.exists(party_path):
                party_data = parse_party_details_pdf(party_path)
                party_text = " ".join([str(p.get("name", "")).upper() for p in party_data.parties])
                if any(kw in party_text for kw in contractor_keywords):
                    has_contractor_keyword = True

            # If not explicitly a contractor/vendor/works payment, skip IT TDS (to avoid false positives on routine claims)
            is_contractor_payment = has_contractor_head or has_contractor_keyword

            # 5. Evaluate GST TDS (Sec 51 CGST Act)
            # Mandatory 2% deduction on taxable contract payments > ₹2,50,000
            gst_tds_threshold = 250000.0
            gst_tds_expected = gross_amt * 0.02
            
            # 6. Evaluate Income Tax TDS (Sec 194C / 194J / 194I IT Act)
            # Applies to Contractor payments > ₹30,000 single claim or ₹1 Lakh aggregate p.a.
            it_tds_threshold = 30000.0
            it_tds_expected_min = gross_amt * 0.01

            flags = []

            # GST TDS Check (only on contractor/vendor procurement > ₹2.5L)
            if is_contractor_payment and gross_amt >= gst_tds_threshold:
                if total_deductions == 0.0:
                    flags.append(
                        f"⚠️ GST TDS MISSING: Works/procurement contract ₹{gross_amt:,.2f} exceeds ₹2.50 Lakhs threshold (Sec 51 CGST Act), but no 2% GST TDS (~ ₹{gst_tds_expected:,.2f}) or deductions are recorded."
                    )

            # Income Tax TDS Check (only on contractor/works/services payments > ₹30k)
            if is_contractor_payment and gross_amt >= it_tds_threshold:
                if total_deductions == 0.0:
                    flags.append(
                        f"⚠️ IT TDS MISSING (Sec 194C/194J): Contractor/service payment ₹{gross_amt:,.2f} exceeds ₹30,000 single contract threshold, but no Income Tax TDS (1%-2% ~ ₹{it_tds_expected_min:,.2f}) is deducted."
                    )

            if flags:
                return {
                    "status": "WARNING",
                    "message": " | ".join(flags) + " (Note: Verify if exempt inter-state supply, statutory grant, or exempted firm).",
                    "details": {
                        "gross_amount": gross_amt,
                        "total_deductions": total_deductions,
                        "form_number": form_number,
                        "object_head": object_head,
                        "is_contractor_payment": is_contractor_payment
                    }
                }

            if is_contractor_payment:
                return {
                    "status": "PASS",
                    "message": f"TDS Compliance PASS: Contractor/works claim ₹{gross_amt:,.2f} evaluated with deductions recorded (₹{total_deductions:,.2f}).",
                    "details": {"gross_amount": gross_amt, "total_deductions": total_deductions}
                }

            return {
                "status": "SKIPPED",
                "message": f"TDS Check SKIPPED: Standard administrative claim ₹{gross_amt:,.2f} (non-contractor bill).",
                "details": {"gross_amount": gross_amt, "form_number": form_number, "object_head": object_head}
            }

        except Exception as e:
            return {
                "status": "FAIL",
                "message": f"Error in GST/IT TDS Check: {e}",
                "details": {}
            }
