# checks/check_realtime_aapda_scheme.py
# Check 33: MH 2245 Aapda / Disaster Relief Payments Scheme Check
# Centralized Voucher Validation Suite v1.2

import os
from checks.base_check import BaseValidationCheck

class CheckRealtimeAapdaScheme(BaseValidationCheck):
    check_id = "check_realtime_aapda_scheme"
    name = "Check 33: MH 2245 Aapda Disaster Relief Scheme Head Check"
    description = "Verifies scheme-head classification and detail-wise data coverage for MH 2245 (Natural Calamities)."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            mh = str(voucher_data.get("mh", "")).strip().lstrip("0")
            if mh != "2245":
                return {
                    "status": "PASS",
                    "message": "Not Major Head 2245 (Aapda/Disaster Relief)",
                    "details": {"mh": mh}
                }

            scheme_head = voucher_data.get("scheme_head", "")
            detail_head = voucher_data.get("detail_head", "")
            vlc_mapped = voucher_data.get("vlc_mapped", False)

            details = {
                "mh": mh,
                "scheme_head": scheme_head,
                "detail_head": detail_head,
                "vlc_mapped": vlc_mapped
            }

            if not scheme_head:
                if vlc_mapped:
                    return {
                        "status": "WARNING",
                        "message": "MH 2245 Aapda voucher mapped with VLC, but scheme head code is missing or unassigned",
                        "details": details
                    }
                else:
                    return {
                        "status": "WARNING",
                        "message": "MH 2245 Aapda voucher lacks scheme head details. VLC data mapping required for full coverage",
                        "details": details
                    }

            return {
                "status": "PASS",
                "message": f"MH 2245 Disaster Relief voucher verified with valid Scheme Head: {scheme_head}",
                "details": details
            }

        except Exception as e:
            return {
                "status": "FAIL",
                "message": f"Error in MH 2245 Aapda Check: {str(e)}",
                "details": {}
            }
