"""
qt_theme.py - QSS stylesheet generator for Centralized Voucher Validation Suite (PySide6).

Reads the canonical colour tokens from ``gui.theme.THEMES`` and produces a
fully resolved Qt Style Sheet string for any registered theme.

Public API
----------
    resolve_color(color_val, mode='dark')  → str
    generate_qss(theme_name)               → str
    get_console_tag_colors(theme_name)     → dict[str, str]
    get_theme_names()                      → list[str]
"""

from gui.theme import THEMES


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def resolve_color(color_val, mode="dark"):
    """Return a single CSS colour string from *color_val*.

    *color_val* may be:
      - a ``(light, dark)`` tuple  → return the element matching *mode*
      - a plain string             → return as-is  (e.g. ``"transparent"``)

    Parameters
    ----------
    color_val : str | tuple[str, str]
    mode : ``'light'`` | ``'dark'``
    """
    if isinstance(color_val, (list, tuple)):
        return color_val[0] if mode == "light" else color_val[1]
    return color_val


def _c(theme, token, mode):
    """Shorthand: resolve *token* from *theme* dict for *mode*."""
    return resolve_color(theme[token], mode)


def get_theme_names():
    """Return a list of all available theme names."""
    return list(THEMES.keys())


# ---------------------------------------------------------------------------
# Console tag colours
# ---------------------------------------------------------------------------

def get_console_tag_colors(theme_name):
    """Return a mapping ``{tag_name: foreground_hex}`` for the log console.

    Tags: info, success, error, warning, skip, header, timestamp, highlight.
    """
    theme = THEMES.get(theme_name, THEMES[get_theme_names()[0]])
    mode = theme.get("APPEARANCE_MODE", "dark")

    if mode == "dark":
        return {
            "info":      "#93c5fd",  # Vibrant Soft Sky Blue
            "success":   "#3fb950",  # Vibrant Emerald Green
            "error":     "#f85149",  # Vibrant Bright Crimson Red
            "warning":   "#d29922",  # Vibrant Gold Amber Yellow
            "skip":      "#38bdf8",  # Vibrant Cyan / Electric Blue
            "header":    "#c084fc",  # Vibrant Purple / Lavender Header
            "timestamp": "#8b949e",  # Cool Slate Gray
            "highlight": "#58a6ff",  # Bright Royal Blue
            "secondary": "#a5d6ff",  # Light Ice Blue
        }
    else:
        return {
            "info":      "#094192",  # Bold Dark Navy Blue
            "success":   "#0d6224",  # Bold Dark Forest Green
            "error":     "#a40e1b",  # Dark Crimson Red
            "warning":   "#7a4d00",  # Dark Amber
            "skip":      "#035a86",  # Deep Cyan
            "header":    "#5c2bb8",  # Dark Purple
            "timestamp": "#020617",  # Dark Slate Black
            "highlight": "#094192",  # Royal Blue
            "secondary": "#0550ae",  # Ocean Blue
        }


# ---------------------------------------------------------------------------
# QSS Generator
# ---------------------------------------------------------------------------

def generate_qss(theme_name):
    """Return a complete Qt Style Sheet string for *theme_name*.

    Every widget class used in Centralized Voucher Validation Suite is covered.  All colour values are
    drawn from the canonical ``THEMES`` dict so that switching theme at runtime
    only requires calling ``QApplication.instance().setStyleSheet(generate_qss(name))``.
    """
    theme = THEMES.get(theme_name, THEMES[get_theme_names()[0]])
    mode = theme.get("APPEARANCE_MODE", "dark")

    # -- Resolve every token once ----------------------------------------
    bg_window        = _c(theme, "BG_WINDOW", mode)
    bg_sidebar       = _c(theme, "BG_SIDEBAR", mode)
    bg_card          = _c(theme, "BG_CARD", mode)
    border_color     = _c(theme, "BORDER_COLOR", mode)
    text_main        = _c(theme, "TEXT_MAIN", mode)
    text_muted       = _c(theme, "TEXT_MUTED", mode)
    text_highlight   = _c(theme, "TEXT_HIGHLIGHT", mode)
    bg_entry         = _c(theme, "BG_ENTRY", mode)
    bg_textbox       = _c(theme, "BG_TEXTBOX", mode)

    btn_pri_bg       = _c(theme, "BTN_PRIMARY_BG", mode)
    btn_pri_hover    = _c(theme, "BTN_PRIMARY_HOVER", mode)
    btn_pri_text     = _c(theme, "BTN_PRIMARY_TEXT", mode)

    btn_sec_bg       = _c(theme, "BTN_SECONDARY_BG", mode)
    btn_sec_hover    = _c(theme, "BTN_SECONDARY_HOVER", mode)
    btn_sec_text     = _c(theme, "BTN_SECONDARY_TEXT", mode)

    btn_dan_bg       = _c(theme, "BTN_DANGER_BG", mode)
    btn_dan_hover    = _c(theme, "BTN_DANGER_HOVER", mode)
    btn_dan_text     = _c(theme, "BTN_DANGER_TEXT", mode)

    btn_warn_bg      = _c(theme, "BTN_WARNING_BG", mode)
    btn_warn_hover   = _c(theme, "BTN_WARNING_HOVER", mode)
    btn_warn_text    = _c(theme, "BTN_WARNING_TEXT", mode)

    btn_out_bg       = _c(theme, "BTN_OUTLINE_BG", mode)
    btn_out_border   = _c(theme, "BTN_OUTLINE_BORDER", mode)
    btn_out_text     = _c(theme, "BTN_OUTLINE_TEXT", mode)
    btn_out_hover    = _c(theme, "BTN_OUTLINE_HOVER", mode)

    # Derived / computed colours
    # A slightly translucent version of the border for subtle separators
    scrollbar_bg     = bg_sidebar
    scrollbar_handle = border_color
    tab_selected_bg  = bg_card
    tab_hover_bg     = bg_sidebar
    tooltip_bg       = bg_card
    tooltip_border   = border_color
    tooltip_text     = text_main

    # Progress-bar chunk reuses the primary accent
    progress_chunk   = btn_pri_bg
    progress_bg      = border_color

    # Checkbox / radio indicator colours
    indicator_checked   = btn_pri_bg
    indicator_unchecked = border_color




    # ------------------------------------------------------------------
    # Build the stylesheet
    # ------------------------------------------------------------------
    qss = f"""
/* ================================================================
   Centralized Voucher Validation Suite — Auto-generated QSS for "{theme_name}"
   Mode: {mode}
   ================================================================ */

/* ----------------------------------------------------------------
   Global defaults
   ---------------------------------------------------------------- */
* {{
    font-family: "Segoe UI", -apple-system, BlinkMacSystemFont, sans-serif;
    font-size: 11.5px;
    font-weight: 500;
    outline: none;
}}

/* ----------------------------------------------------------------
   QMainWindow / QWidget (base backgrounds)
   ---------------------------------------------------------------- */
QMainWindow {{
    background-color: {bg_window};
}}
QWidget#centralWidget {{
    background-color: {bg_window};
}}
QWidget {{
    background-color: transparent;
    color: {text_main};
}}

/* ----------------------------------------------------------------
   QFrame cards & sidebar
   ---------------------------------------------------------------- */
QFrame[cssClass="card"] {{
    background-color: {bg_card};
    border: 1px solid {border_color};
    border-radius: 12px;
}}
QFrame[cssClass="sidebar"] {{
    background-color: {bg_sidebar};
    border: none;
}}

/* ----------------------------------------------------------------
   QLabel
   ---------------------------------------------------------------- */
QLabel {{
    background-color: transparent;
    color: {text_main};
    padding: 0px;
    border: none;
    font-weight: 500;
}}
QLabel[cssClass="muted"] {{
    color: {text_muted};
    font-size: 10.5px;
    font-weight: 600;
}}
QLabel[cssClass="highlight"] {{
    color: {text_highlight};
    font-size: 11.5px;
    font-weight: 700;
}}
QLabel[cssClass="disclaimer"] {{
    color: #ffaa00; /* warning orange-yellow */
    font-size: 9px;
    font-style: italic;
    font-weight: bold;
}}

/* ----------------------------------------------------------------
   QPushButton — default (neutral)
   ---------------------------------------------------------------- */
QPushButton {{
    background-color: {bg_card};
    color: {text_main};
    border: 1px solid {border_color};
    border-radius: 8px;
    padding: 2px 12px;
    font-weight: 500;
    min-height: 24px;
}}
QPushButton:hover {{
    background-color: {bg_sidebar};
    border-color: {text_muted};
}}
QPushButton:pressed {{
    background-color: {border_color};
}}
QPushButton:disabled {{
    background-color: {bg_sidebar};
    color: {text_muted};
    border-color: {border_color};
}}

/* ---- Primary (green / accent) ---- */
QPushButton[cssClass="primary"] {{
    background-color: {btn_pri_bg};
    color: {btn_pri_text};
    border: 1px solid {btn_pri_bg};
    border-radius: 8px;
    font-weight: 600;
}}
QPushButton[cssClass="primary"]:hover {{
    background-color: {btn_pri_hover};
    border-color: {btn_pri_hover};
}}
QPushButton[cssClass="primary"]:pressed {{
    background-color: {btn_pri_bg};
}}
QPushButton[cssClass="primary"]:disabled {{
    background-color: {bg_sidebar};
    color: {text_muted};
    border-color: {border_color};
}}

/* ---- Secondary (blue) ---- */
QPushButton[cssClass="secondary"] {{
    background-color: {btn_sec_bg};
    color: {btn_sec_text};
    border: 1px solid {btn_sec_bg};
    border-radius: 8px;
    font-weight: 600;
}}
QPushButton[cssClass="secondary"]:hover {{
    background-color: {btn_sec_hover};
    border-color: {btn_sec_hover};
}}
QPushButton[cssClass="secondary"]:pressed {{
    background-color: {btn_sec_bg};
}}
QPushButton[cssClass="secondary"]:disabled {{
    background-color: {bg_sidebar};
    color: {text_muted};
    border-color: {border_color};
}}

/* ---- Danger (red) ---- */
QPushButton[cssClass="danger"] {{
    background-color: {btn_dan_bg};
    color: {btn_dan_text};
    border: 1px solid {btn_dan_bg};
    border-radius: 8px;
    font-weight: 600;
}}
QPushButton[cssClass="danger"]:hover {{
    background-color: {btn_dan_hover};
    border-color: {btn_dan_hover};
}}
QPushButton[cssClass="danger"]:pressed {{
    background-color: {btn_dan_bg};
}}
QPushButton[cssClass="danger"]:disabled {{
    background-color: {bg_sidebar};
    color: {text_muted};
    border-color: {border_color};
}}

/* ---- Warning (amber) ---- */
QPushButton[cssClass="warning"] {{
    background-color: {btn_warn_bg};
    color: {btn_warn_text};
    border: 1px solid {btn_warn_bg};
    border-radius: 8px;
    font-weight: 600;
}}
QPushButton[cssClass="warning"]:hover {{
    background-color: {btn_warn_hover};
    border-color: {btn_warn_hover};
}}
QPushButton[cssClass="warning"]:pressed {{
    background-color: {btn_warn_bg};
}}
QPushButton[cssClass="warning"]:disabled {{
    background-color: {bg_sidebar};
    color: {text_muted};
    border-color: {border_color};
}}

/* ---- Outline (transparent bg, border) ---- */
QPushButton[cssClass="outline"] {{
    background-color: {btn_out_bg};
    color: {btn_out_text};
    border: 1px solid {btn_out_border};
    border-radius: 8px;
    font-weight: 500;
}}
QPushButton[cssClass="outline"]:hover {{
    background-color: {btn_out_hover};
    border-color: {btn_out_border};
}}
QPushButton[cssClass="outline"]:pressed {{
    background-color: {btn_out_border};
    color: {btn_pri_text};
}}
QPushButton[cssClass="outline"]:disabled {{
    background-color: transparent;
    color: {text_muted};
    border-color: {border_color};
}}

/* ----------------------------------------------------------------
   QLineEdit
   ---------------------------------------------------------------- */
QLineEdit {{
    background-color: {bg_entry};
    color: {text_main};
    border: 1px solid {border_color};
    border-radius: 8px;
    padding: 2px 10px;
    min-height: 24px;
    selection-background-color: {btn_pri_bg};
    selection-color: {btn_pri_text};
}}
QLineEdit:focus {{
    border-color: {btn_pri_bg};
}}
QLineEdit:disabled {{
    background-color: {bg_sidebar};
    color: {text_muted};
}}

/* ----------------------------------------------------------------
   QTextEdit / QPlainTextEdit (console)
   ---------------------------------------------------------------- */
QTextEdit, QPlainTextEdit {{
    background-color: {bg_textbox};
    color: {text_main};
    border: 1px solid {border_color};
    border-radius: 8px;
    padding: 6px;
    font-family: "Consolas", "Cascadia Mono", monospace;
    font-size: 11px;
    font-weight: 600;
    selection-background-color: {btn_pri_bg};
    selection-color: {btn_pri_text};
}}
QTextEdit:focus, QPlainTextEdit:focus {{
    border-color: {btn_pri_bg};
}}

/* ----------------------------------------------------------------
   QComboBox
   ---------------------------------------------------------------- */
QComboBox {{
    background-color: {bg_entry};
    color: {text_main};
    border: 1px solid {border_color};
    border-radius: 8px;
    padding: 2px 10px;
    min-height: 24px;
}}
QComboBox:hover {{
    border-color: {text_muted};
}}
QComboBox:focus {{
    border-color: {btn_pri_bg};
}}
QComboBox::drop-down {{
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 24px;
    border-left: 1px solid {border_color};
    border-top-right-radius: 8px;
    border-bottom-right-radius: 8px;
    background-color: transparent;
}}
QComboBox::down-arrow {{
    image: none;
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid {text_muted};
    margin-right: 6px;
}}
QComboBox QAbstractItemView {{
    background-color: {bg_card};
    color: {text_main};
    border: 1px solid {border_color};
    border-radius: 4px;
    padding: 4px;
    selection-background-color: {btn_pri_bg};
    selection-color: {btn_pri_text};
    outline: none;
}}
QComboBox:disabled {{
    background-color: {bg_sidebar};
    color: {text_muted};
}}

/* ----------------------------------------------------------------
   QSpinBox / QDoubleSpinBox
   ---------------------------------------------------------------- */
QSpinBox, QDoubleSpinBox {{
    background-color: {bg_entry};
    color: {text_main};
    border: 1px solid {border_color};
    border-radius: 8px;
    padding: 4px 10px;
    min-height: 28px;
}}
QSpinBox:focus, QDoubleSpinBox:focus {{
    border-color: {btn_pri_bg};
}}
QSpinBox::up-button, QDoubleSpinBox::up-button {{
    subcontrol-origin: border;
    subcontrol-position: top right;
    width: 20px;
    border-left: 1px solid {border_color};
    border-top-right-radius: 8px;
    background-color: transparent;
}}
QSpinBox::down-button, QDoubleSpinBox::down-button {{
    subcontrol-origin: border;
    subcontrol-position: bottom right;
    width: 20px;
    border-left: 1px solid {border_color};
    border-bottom-right-radius: 8px;
    background-color: transparent;
}}
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow {{
    image: none;
    width: 0; height: 0;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-bottom: 5px solid {text_muted};
}}
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow {{
    image: none;
    width: 0; height: 0;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid {text_muted};
}}

/* ----------------------------------------------------------------
   QProgressBar
   ---------------------------------------------------------------- */
QProgressBar {{
    background-color: {progress_bg};
    border: none;
    border-radius: 3px;
    height: 6px;
    text-align: center;
    font-size: 0px;
    max-height: 6px;
}}
QProgressBar::chunk {{
    background-color: {progress_chunk};
    border-radius: 3px;
}}

/* ----------------------------------------------------------------
   QCheckBox
   ---------------------------------------------------------------- */
QCheckBox {{
    color: {text_main};
    font-weight: 600;
    font-size: 11.5px;
    spacing: 8px;
    background-color: transparent;
}}
QCheckBox::indicator {{
    width: 18px;
    height: 18px;
    border: 2px solid {indicator_unchecked};
    border-radius: 4px;
    background-color: transparent;
}}
QCheckBox::indicator:hover {{
    border-color: {text_muted};
}}
QCheckBox::indicator:checked {{
    background-color: {indicator_checked};
    border-color: {indicator_checked};
    image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='none' stroke='%23ffffff' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round' d='M3 8.5l3.5 3.5 6.5-6.5'/%3E%3C/svg%3E");
}}
QCheckBox::indicator:checked:hover {{
    background-color: {btn_pri_hover};
    border-color: {btn_pri_hover};
}}
QCheckBox::indicator:disabled {{
    border-color: {border_color};
    background-color: {bg_sidebar};
}}
QCheckBox:disabled {{
    color: {text_muted};
}}

/* Toggle switches are now custom-painted (gui/toggle_switch.py) — no QSS needed */

/* ----------------------------------------------------------------
   QRadioButton
   ---------------------------------------------------------------- */
QRadioButton {{
    color: {text_main};
    font-weight: 600;
    font-size: 11.5px;
    spacing: 8px;
    background-color: transparent;
}}
QRadioButton::indicator {{
    width: 18px;
    height: 18px;
    border: 2px solid {indicator_unchecked};
    border-radius: 10px;
    background-color: transparent;
}}
QRadioButton::indicator:hover {{
    border-color: {text_muted};
}}
QRadioButton::indicator:checked {{
    background-color: {indicator_checked};
    border-color: {indicator_checked};
    image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Ccircle cx='8' cy='8' r='4' fill='%23ffffff'/%3E%3C/svg%3E");
}}
QRadioButton::indicator:disabled {{
    border-color: {border_color};
    background-color: {bg_sidebar};
}}

/* ----------------------------------------------------------------
   QSlider (horizontal)
   ---------------------------------------------------------------- */
QSlider::groove:horizontal {{
    background-color: {progress_bg};
    height: 6px;
    border-radius: 3px;
}}
QSlider::handle:horizontal {{
    background-color: {btn_pri_bg};
    border: 2px solid {btn_pri_bg};
    width: 16px;
    height: 16px;
    margin: -6px 0;
    border-radius: 9px;
}}
QSlider::handle:horizontal:hover {{
    background-color: {btn_pri_hover};
    border-color: {btn_pri_hover};
}}
QSlider::sub-page:horizontal {{
    background-color: {btn_pri_bg};
    border-radius: 3px;
}}
QSlider::add-page:horizontal {{
    background-color: {progress_bg};
    border-radius: 3px;
}}

/* ----------------------------------------------------------------
   QSlider (vertical)
   ---------------------------------------------------------------- */
QSlider::groove:vertical {{
    background-color: {progress_bg};
    width: 6px;
    border-radius: 3px;
}}
QSlider::handle:vertical {{
    background-color: {btn_pri_bg};
    border: 2px solid {btn_pri_bg};
    width: 16px;
    height: 16px;
    margin: 0 -6px;
    border-radius: 9px;
}}
QSlider::handle:vertical:hover {{
    background-color: {btn_pri_hover};
    border-color: {btn_pri_hover};
}}

/* ----------------------------------------------------------------
   QTabWidget / QTabBar — segmented-button look matching CTkTabview
   ---------------------------------------------------------------- */
QTabWidget {{
    background-color: transparent;
    border: none;
}}
QTabWidget::pane {{
    background-color: {bg_card};
    border: 1px solid {border_color};
    border-radius: 8px;
    padding: 8px;
    top: -1px;
}}
QTabBar {{
    background-color: transparent;
    border: none;
    qproperty-drawBase: 0;
}}
QTabBar::tab {{
    background-color: {bg_sidebar};
    color: {text_main};
    border: 1px solid {border_color};
    border-bottom: none;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    padding: 10px 20px;
    margin-right: 4px;
    font-weight: 700;
    font-size: 11.5px;
}}
QTabBar::tab:hover {{
    background-color: {tab_hover_bg};
    color: {text_main};
}}
QTabBar::tab:selected {{
    background-color: {tab_selected_bg};
    color: {text_highlight};
    border-color: {border_color};
    border-bottom: 1px solid {tab_selected_bg};
    font-weight: 700;
    font-size: 11px;
}}
QTabBar::tab:disabled {{
    color: {text_muted};
    background-color: {bg_sidebar};
}}

/* ----------------------------------------------------------------
   QScrollBar (vertical) — thin, rounded, themed
   ---------------------------------------------------------------- */
QScrollBar:vertical {{
    background-color: transparent;
    width: 10px;
    margin: 2px;
    border: none;
    border-radius: 5px;
}}
QScrollBar::handle:vertical {{
    background-color: {scrollbar_handle};
    min-height: 30px;
    border-radius: 4px;
    margin: 2px;
}}
QScrollBar::handle:vertical:hover {{
    background-color: {text_muted};
}}
QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical {{
    height: 0px;
    background: none;
    border: none;
}}
QScrollBar::add-page:vertical,
QScrollBar::sub-page:vertical {{
    background: none;
}}

/* ----------------------------------------------------------------
   QScrollBar (horizontal) — thin, rounded, themed
   ---------------------------------------------------------------- */
QScrollBar:horizontal {{
    background-color: transparent;
    height: 10px;
    margin: 2px;
    border: none;
    border-radius: 5px;
}}
QScrollBar::handle:horizontal {{
    background-color: {scrollbar_handle};
    min-width: 30px;
    border-radius: 4px;
    margin: 2px;
}}
QScrollBar::handle:horizontal:hover {{
    background-color: {text_muted};
}}
QScrollBar::add-line:horizontal,
QScrollBar::sub-line:horizontal {{
    width: 0px;
    background: none;
    border: none;
}}
QScrollBar::add-page:horizontal,
QScrollBar::sub-page:horizontal {{
    background: none;
}}

/* ----------------------------------------------------------------
   QScrollArea
   ---------------------------------------------------------------- */
QScrollArea {{
    background-color: transparent;
    border: none;
}}
QScrollArea > QWidget > QWidget {{
    background-color: transparent;
}}

/* ----------------------------------------------------------------
   QGroupBox
   ---------------------------------------------------------------- */
QGroupBox {{
    background-color: {bg_card};
    border: 1px solid {border_color};
    border-radius: 8px;
    margin-top: 14px;
    padding: 12px 8px 8px 8px;
    font-weight: 600;
    color: {text_main};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 2px 12px;
    color: {text_highlight};
}}

/* ----------------------------------------------------------------
   QToolTip
   ---------------------------------------------------------------- */
QToolTip {{
    background-color: {tooltip_bg};
    color: {tooltip_text};
    border: 1px solid {tooltip_border};
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 10px;
}}

/* ----------------------------------------------------------------
   QMenuBar / QMenu
   ---------------------------------------------------------------- */
QMenuBar {{
    background-color: {bg_sidebar};
    color: {text_main};
    border-bottom: 1px solid {border_color};
    padding: 2px;
}}
QMenuBar::item {{
    background-color: transparent;
    padding: 6px 12px;
    border-radius: 4px;
}}
QMenuBar::item:selected {{
    background-color: {bg_card};
    color: {text_highlight};
}}
QMenu {{
    background-color: {bg_card};
    color: {text_main};
    border: 1px solid {border_color};
    border-radius: 8px;
    padding: 4px;
}}
QMenu::item {{
    padding: 6px 28px 6px 20px;
    border-radius: 4px;
}}
QMenu::item:selected {{
    background-color: {btn_pri_bg};
    color: {btn_pri_text};
}}
QMenu::separator {{
    height: 1px;
    background-color: {border_color};
    margin: 4px 8px;
}}

/* ----------------------------------------------------------------
   QHeaderView (table / tree headers)
   ---------------------------------------------------------------- */
QHeaderView {{
    background-color: transparent;
    border: none;
}}
QHeaderView::section {{
    background-color: {bg_sidebar};
    color: {text_main};
    border: none;
    border-right: 1px solid {border_color};
    border-bottom: 1px solid {border_color};
    padding: 6px 10px;
    font-weight: 600;
}}
QHeaderView::section:hover {{
    background-color: {bg_card};
    color: {text_highlight};
}}

/* ----------------------------------------------------------------
   QTableWidget / QTableView / QTreeWidget / QTreeView
   ---------------------------------------------------------------- */
QTableWidget, QTableView, QTreeWidget, QTreeView {{
    background-color: {bg_entry};
    alternate-background-color: {bg_sidebar};
    color: {text_main};
    border: 1px solid {border_color};
    border-radius: 8px;
    gridline-color: {border_color};
    selection-background-color: {btn_pri_bg};
    selection-color: {btn_pri_text};
    outline: none;
}}
QTableWidget::item, QTableView::item,
QTreeWidget::item, QTreeView::item {{
    padding: 4px 8px;
    border: none;
}}
QTableWidget::item:selected, QTableView::item:selected,
QTreeWidget::item:selected, QTreeView::item:selected {{
    background-color: {btn_pri_bg};
    color: {btn_pri_text};
}}

/* ----------------------------------------------------------------
   QStatusBar
   ---------------------------------------------------------------- */
QStatusBar {{
    background-color: {bg_sidebar};
    color: {text_muted};
    border-top: 1px solid {border_color};
    font-size: 10px;
    padding: 2px 8px;
}}
QStatusBar::item {{
    border: none;
}}

/* ----------------------------------------------------------------
   QSplitter
   ---------------------------------------------------------------- */
QSplitter::handle {{
    background-color: {border_color};
}}
QSplitter::handle:horizontal {{
    width: 2px;
}}
QSplitter::handle:vertical {{
    height: 2px;
}}

/* ----------------------------------------------------------------
   QDialog
   ---------------------------------------------------------------- */
QDialog {{
    background-color: {bg_window};
    color: {text_main};
}}

/* ----------------------------------------------------------------
   Enterprise Metric Cards & Status Badges
   ---------------------------------------------------------------- */
QFrame[cssClass="metric-card"] {{
    background-color: {bg_card};
    border: 1px solid {border_color};
    border-radius: 12px;
    padding: 8px 12px;
}}
QFrame[cssClass="metric-card"]:hover {{
    border: 1px solid {text_highlight};
}}

QLabel[cssClass="metric-value"] {{
    font-size: 17px;
    font-weight: 800;
    color: {text_highlight};
}}
QLabel[cssClass="metric-label"] {{
    font-size: 10px;
    font-weight: 700;
    color: {text_muted};
    text-transform: uppercase;
}}

QTabWidget::pane {{
    border: 1px solid {border_color};
    border-radius: 12px;
    background-color: {bg_card};
    top: -1px;
}}

QTabBar::tab {{
    background-color: {bg_sidebar};
    color: {text_muted};
    border: 1px solid {border_color};
    border-bottom: none;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    padding: 8px 18px;
    font-size: 11.5px;
    font-weight: 700;
    margin-right: 4px;
}}

QTabBar::tab:selected {{
    background-color: {btn_pri_bg};
    color: #ffffff;
    border: 1px solid {btn_pri_bg};
    border-bottom: 3px solid #00e5bf;
    font-weight: 800;
}}

QTabBar::tab:hover:!selected {{
    background-color: {bg_window};
    color: {text_main};
}}

QHeaderView::section {{
    background-color: {bg_sidebar};
    color: {text_main};
    padding: 6px 10px;
    border: none;
    border-bottom: 2px solid {text_highlight};
    font-weight: 700;
    font-size: 11px;
}}

QTableView {{
    background-color: {bg_card};
    gridline-color: {border_color};
    selection-background-color: {text_highlight};
    selection-color: {btn_pri_text};
    border: 1px solid {border_color};
    border-radius: 10px;
}}

QTableView::item:alternate {{
    background-color: {bg_entry};
}}
"""

    return qss.strip()



    return qss.strip()
