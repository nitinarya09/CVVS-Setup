import os
from checks.base_check import BaseValidationCheck
from parsers.mptc_parser import parse_mptc_pdf


class SubvoucherArithmeticCheck(BaseValidationCheck):
    check_id = "check_realtime_subvoucher_arithmetic"
    name = "Sub-Voucher Arithmetic Verification Check"
    description = "For FVC bills (Form 34), compares sum of sub-voucher amounts with total_amount."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            mptc_file = os.path.join(download_folder, "Show_MPTC.pdf")
            if not os.path.exists(mptc_file):
                return {"status": "SKIPPED", "message": "No MPTC PDF found", "details": {}}

            mptc = parse_mptc_pdf(mptc_file)
            form_number = mptc.form_number.strip()

            if form_number != "34":
                return {"status": "SKIPPED", "message": "Not an FVC bill (Form %s)" % form_number, "details": {"form_number": form_number}}

            sub_vouchers = mptc.sub_vouchers  # list of {description, amount}

            if not sub_vouchers:
                return {"status": "SKIPPED", "message": "No sub-vouchers parseable from FVC bill", "details": {}}

            total_amount = mptc.total_amount or voucher_data.get("amount", 0.0)
            sum_sub_vouchers = sum(float(sv.get("amount", 0.0)) for sv in sub_vouchers)
            diff = abs(sum_sub_vouchers - total_amount)

            if diff <= 1.0:
                return {"status": "PASS",
                        "message": "Sum of %d sub-vouchers (Rs.%.2f) matches total (Rs.%.2f)" % (len(sub_vouchers), sum_sub_vouchers, total_amount),
                        "details": {"sub_voucher_count": len(sub_vouchers), "sum": sum_sub_vouchers, "total": total_amount}}
            else:
                return {"status": "MISMATCH",
                        "message": "Sub-voucher sum Rs.%.2f != total Rs.%.2f (diff: Rs.%.2f)" % (sum_sub_vouchers, total_amount, diff),
                        "details": {"sub_voucher_count": len(sub_vouchers), "sum": sum_sub_vouchers, "total": total_amount, "difference": diff}}

        except Exception as e:
            return {"status": "FAIL", "message": "Error during check: %s" % str(e), "details": {}}
