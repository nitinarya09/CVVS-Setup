"""
qt_compat.py - PySide6 Widget Compatibility Layer for Centralized Voucher Validation Suite.

This module monkey-patches PySide6 widgets (QWidget, QLineEdit, QTextEdit, 
QCheckBox, QComboBox, QProgressBar) to add compatibility methods matching 
Tkinter/CustomTkinter APIs.

It must be imported before initializing the QApplication or any GUI layouts.
"""

import re
from PySide6.QtWidgets import QApplication, QWidget, QLineEdit, QCheckBox, QComboBox, QProgressBar, QTextEdit, QSlider
from PySide6.QtGui import QTextCursor


def apply_compat_layer():
    # ── 1. configure & config ────────────────────────────
    def configure(self, **kwargs):
        for key, val in kwargs.items():
            if key == "state":
                if val == "normal":
                    self.setEnabled(True)
                    if hasattr(self, "setReadOnly"):
                        self.setReadOnly(False)
                elif val == "disabled":
                    self.setEnabled(False)
                elif val == "readonly" or val == "read-only":
                    self.setEnabled(True)
                    if hasattr(self, "setReadOnly"):
                        self.setReadOnly(True)
            elif key == "text":
                if hasattr(self, "setText"):
                    self.setText(str(val))
                elif hasattr(self, "setTitle"):
                    self.setTitle(str(val))
            elif key == "text_color":
                self.setStyleSheet(f"color: {val};")
            elif key == "fg_color" or key == "bg_color" or key == "bg":
                self.setStyleSheet(f"background-color: {val};")
            elif key == "values" and isinstance(self, QComboBox):
                self.clear()
                self.addItems(val)
            elif key == "value" and isinstance(self, QProgressBar):
                self.setValue(int(val * 100) if val <= 1.0 else int(val))
            elif key == "mode" and isinstance(self, QProgressBar):
                if val == "indeterminate":
                    self.setRange(0, 0)
                else:
                    self.setRange(0, 100)
    
    QWidget.configure = configure
    QWidget.config = configure

    # ── 2. cget ──────────────────────────────────────────
    def cget(self, attr):
        if attr == "state":
            if not self.isEnabled():
                return "disabled"
            if hasattr(self, "isReadOnly") and self.isReadOnly():
                return "readonly"
            return "normal"
        if hasattr(self, attr):
            return getattr(self, attr)
        return None
    QWidget.cget = cget

    # ── 3. get ───────────────────────────────────────────
    def get(self):
        if isinstance(self, QLineEdit):
            return self.text()
        elif isinstance(self, QCheckBox):
            return self.isChecked()
        elif isinstance(self, QComboBox):
            return self.currentText()
        elif isinstance(self, QTextEdit):
            return self.toPlainText()
        elif hasattr(self, "text"):
            return self.text()
        return None
    QWidget.get = get

    # ── 4. set ───────────────────────────────────────────
    def set(self, val):
        if isinstance(self, QLineEdit):
            self.setText(str(val))
        elif isinstance(self, QCheckBox):
            self.setChecked(bool(val))
        elif isinstance(self, QComboBox):
            self.setCurrentText(str(val))
        elif isinstance(self, QTextEdit):
            self.setPlainText(str(val))
    QWidget.set = set

    # ── 5. delete ────────────────────────────────────────
    def delete_method(self, first, last=None):
        if isinstance(self, QLineEdit):
            if first == 0 and (last == 'end' or last is None):
                self.clear()
            else:
                text = self.text()
                if last == 'end' or last is None:
                    new_text = text[:first]
                else:
                    new_text = text[:first] + text[last:]
                self.setText(new_text)
        elif isinstance(self, QTextEdit):
            if first == 0 or first == "0.0" or first == "1.0":
                if last == "end" or last is None:
                    self.clear()

    QLineEdit.delete = delete_method
    QTextEdit.delete = delete_method

    # ── 6. insert ────────────────────────────────────────
    def insert_method(self, index, string):
        if isinstance(self, QLineEdit):
            if index == 0 or index == "insert":
                self.setText(string)
            else:
                text = self.text()
                new_text = text[:index] + string + text[index:]
                self.setText(new_text)
        elif isinstance(self, QTextEdit):
            if index == "end" or index == "insert":
                cursor = self.textCursor()
                cursor.movePosition(QTextCursor.End)
                cursor.insertText(string)
                self.setTextCursor(cursor)
                self.ensureCursorVisible()

    QLineEdit.insert = insert_method
    QTextEdit.insert = insert_method

    # ── 7. see ───────────────────────────────────────────
    def see_method(self, index):
        if isinstance(self, QTextEdit):
            cursor = self.textCursor()
            cursor.movePosition(QTextCursor.End)
            self.setTextCursor(cursor)
            self.ensureCursorVisible()
    QTextEdit.see = see_method

    # ── 8. Window Title & Geometry ───────────────────────
    _native_geometry = QWidget.geometry

    def geometry_method(self, geom_str=None):
        if geom_str is None:
            return _native_geometry(self)
        
        match = re.match(r'^(?:(\d+)x(\d+))?(?:([+-]\d+)([+-]\d+))?$', geom_str)
        if match:
            w_str, h_str, x_str, y_str = match.groups()
            w = int(w_str) if w_str else None
            h = int(h_str) if h_str else None
            x = int(x_str) if x_str else None
            y = int(y_str) if y_str else None
            
            if w is not None and h is not None and x is not None and y is not None:
                self.setGeometry(x, y, w, h)
            elif w is not None and h is not None:
                self.resize(w, h)
            elif x is not None and y is not None:
                self.move(x, y)
    QWidget.geometry = geometry_method

    def title_method(self, *args):
        if args:
            self.setWindowTitle(str(args[0]))
        return self.windowTitle()
    QWidget.title = title_method

    # ── 9. Visibility & Focus Controls ───────────────────
    QWidget.withdraw = lambda self: self.hide()
    
    def deiconify_method(self):
        self.show()
        if hasattr(self, "raise_"):
            self.raise_()
    QWidget.deiconify = deiconify_method

    def grab_set_method(self):
        from PySide6.QtCore import Qt
        if hasattr(self, "setWindowModality"):
            self.setWindowModality(Qt.WindowModality.ApplicationModal)
    QWidget.grab_set = grab_set_method

    def grab_release_method(self):
        from PySide6.QtCore import Qt
        if hasattr(self, "setWindowModality"):
            self.setWindowModality(Qt.WindowModality.NonModal)
    QWidget.grab_release = grab_release_method

    QWidget.focus = lambda self: self.setFocus()
    QWidget.focus_set = lambda self: self.setFocus()
    
    def focus_force_method(self):
        self.raise_()
        self.activateWindow()
        self.setFocus()
    QWidget.focus_force = focus_force_method

    QWidget.destroy = lambda self: (self.close(), self.deleteLater())
    QWidget.update_idletasks = lambda self: QApplication.processEvents()

    # ── 10. winfo Methods ────────────────────────────────
    def winfo_exists_method(self):
        try:
            self.objectName()
            return True
        except (RuntimeError, ReferenceError, AttributeError):
            return False
    QWidget.winfo_exists = winfo_exists_method

    QWidget.winfo_width = lambda self: self.width()
    QWidget.winfo_height = lambda self: self.height()
    QWidget.winfo_x = lambda self: self.x()
    QWidget.winfo_y = lambda self: self.y()
    QWidget.winfo_ismapped = lambda self: self.isVisible()

    def winfo_screenwidth_method(self):
        screen = QApplication.primaryScreen()
        return screen.geometry().width() if screen else 1920
    QWidget.winfo_screenwidth = winfo_screenwidth_method

    def winfo_screenheight_method(self):
        screen = QApplication.primaryScreen()
        return screen.geometry().height() if screen else 1080
    QWidget.winfo_screenheight = winfo_screenheight_method

    def winfo_children_method(self):
        return [c for c in self.children() if isinstance(c, QWidget)]
    QWidget.winfo_children = winfo_children_method

    # ── 11. Ignore scroll wheel events on QComboBox & QSlider ────
    QComboBox.wheelEvent = lambda self, event: event.ignore()
    QSlider.wheelEvent = lambda self, event: event.ignore()


# Apply immediately upon import to be safe
apply_compat_layer()
print("PySide6 Widget Compatibility Layer applied.")
