@echo off
title Centralized Voucher Validation Suite v1.0 - Release Builder
echo ========================================================
echo Centralized Voucher Validation Suite v1.0 - Release Builder
echo ========================================================
echo.

set ISCC_PATH=C:\Program Files (x86)\Inno Setup 6\ISCC.exe

:: 1. Terminate Running Instances
echo Terminating active instances to release file locks...
taskkill /f /im Centralized_Voucher_Validation_Suite.exe >nul 2>&1
taskkill /f /im license_generator.exe >nul 2>&1

:: 2. Run PyInstaller
echo.
echo [1/5] Compiling Main Executable (Centralized_Voucher_Validation_Suite.exe)...
py -3 -m PyInstaller centralized_validation_suite.spec --noconfirm --clean

echo.
echo [2/5] Compiling License Generator (license_generator.exe)...
py -3 -m PyInstaller --noconsole --onefile --icon="cag_logo.ico" --name license_generator license_generator.py --noconfirm --clean

:: 3. Sync compiled binaries to root
if exist "dist\Centralized_Voucher_Validation_Suite.exe" copy /y "dist\Centralized_Voucher_Validation_Suite.exe" "Centralized_Voucher_Validation_Suite.exe"
if exist "dist\license_generator.exe" copy /y "dist\license_generator.exe" "license_generator.exe"

:: 4. Copy Playwright Browsers to pw-browsers
echo.
echo [3/5] Syncing Playwright browsers (pw-browsers)...
if not exist "pw-browsers" mkdir "pw-browsers"
set PW_SRC=%LOCALAPPDATA%\ms-playwright
if not exist "%PW_SRC%" set PW_SRC=%USERPROFILE%\.cache\ms-playwright
if exist "%PW_SRC%" xcopy /s /e /y /q "%PW_SRC%\chromium-*" "pw-browsers\" >nul 2>&1

:: 5. Assemble Portable Directory
echo.
echo [4/5] Assembling Portable Folder & Standalone Packages...
if not exist "output" mkdir "output"
set PORTABLE_DIR=output\Centralized_Voucher_Validation_Suite_Portable_v1.0
if exist "%PORTABLE_DIR%" rmdir /s /q "%PORTABLE_DIR%"
mkdir "%PORTABLE_DIR%"

copy /y "Centralized_Voucher_Validation_Suite.exe" "%PORTABLE_DIR%\"
copy /y "license_generator.exe" "%PORTABLE_DIR%\"
copy /y "ddo.txt" "%PORTABLE_DIR%\"
copy /y "terms.txt" "%PORTABLE_DIR%\"
if exist "data" xcopy /s /e /y /q "data" "%PORTABLE_DIR%\data\"
if exist "pw-browsers" xcopy /s /e /y /q "pw-browsers" "%PORTABLE_DIR%\pw-browsers\"

:: Assemble Patch Directory
set PATCH_DIR=output\Centralized_Voucher_Validation_Suite_Patch_v1.0
if exist "%PATCH_DIR%" rmdir /s /q "%PATCH_DIR%"
mkdir "%PATCH_DIR%"

copy /y "Centralized_Voucher_Validation_Suite.exe" "%PATCH_DIR%\"
copy /y "license_generator.exe" "%PATCH_DIR%\"
copy /y "ddo.txt" "%PATCH_DIR%\"
copy /y "terms.txt" "%PATCH_DIR%\"
if exist "data" xcopy /s /e /y /q "data" "%PATCH_DIR%\data\"

:: 6. Build Inno Setup Installers
echo.
echo [5/5] Compiling Inno Setup Installers...
"%ISCC_PATH%" setup.iss
"%ISCC_PATH%" setup_patch.iss

:: 7. Clean PyInstaller Temporary Residue
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"

echo.
echo ========================================================
echo [SUCCESS] ALL BUILDS COMPLETED SUCCESSFULLY!
echo ========================================================
