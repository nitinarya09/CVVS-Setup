import time
# checks/base_check.py
# Base class for all validation checks in Centralized Voucher Validation Suite

class BaseValidationCheck:
    """
    Abstract Base Class for Validation Checks.
    Each check script in checks/ should inherit from this class or define
    equivalent attributes and methods.
    """
    check_id: str = "base_check"
    name: str = "Base Check"
    description: str = "Base validation check description"
    check_type: str = "realtime"  # 'realtime' or 'post_download'
    enabled: bool = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        """
        Executes per-voucher real-time check immediately after a voucher is downloaded.
        
        Args:
            voucher_data: dict containing keys: treasury, mh, month, year, voucher_no, amount, ddo, etc.
            download_folder: path to the downloaded voucher directory
            context: dictionary with shared application state / engines
            
        Returns:
            dict with keys:
                'status': 'PASS', 'WARNING', 'FAIL', or 'SKIPPED'
                'message': summary message
                'details': optional dict of detailed findings
        """
        return {
            "status": "SKIPPED",
            "message": "Not implemented",
            "details": {}
        }

    def run_post_download(self, all_vouchers_data: list, output_dir: str, context: dict) -> dict:
        """
        Executes post-download check after all vouchers in batch finish downloading.
        
        Args:
            all_vouchers_data: list of dicts for all processed vouchers
            output_dir: directory path for saving reports/logs
            context: dictionary with shared application state / engines
            
        Returns:
            dict with keys:
                'status': 'PASS', 'WARNING', 'FAIL', or 'COMPLETED'
                'message': summary message
                'rows': list of result rows to be added to consolidated report
                'summary_stats': dict of summary counters
        """
        return {
            "status": "COMPLETED",
            "message": "Not implemented",
            "rows": [],
            "summary_stats": {}
        }
