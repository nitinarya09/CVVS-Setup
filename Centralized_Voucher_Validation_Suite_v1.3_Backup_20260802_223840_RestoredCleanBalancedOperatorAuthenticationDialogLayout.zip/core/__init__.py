# core/__init__.py
# Centralized Voucher Validation Suite v3.1.3 — Core shared business logic module
