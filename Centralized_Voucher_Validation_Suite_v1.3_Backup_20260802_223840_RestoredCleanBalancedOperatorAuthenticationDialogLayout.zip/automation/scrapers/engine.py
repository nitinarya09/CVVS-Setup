import sys
import os
if sys.platform == "win32":
    os.environ["PYTHONUNBUFFERED"] = "1"
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = os.environ.get("PLAYWRIGHT_BROWSERS_PATH", "")

def kill_process_tree(pid):
    """Forcefully terminates a process and all its child subprocesses on Windows."""
    if not pid:
        return
    if sys.platform == "win32":
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=0x08000000
            )
        except Exception:
            pass
    else:
        try:
            os.kill(int(pid), 9)
        except Exception:
            pass

from database.db_manager import get_cached_audit_results, save_audit_results_batch
import os
import sys
import time
import zipfile
import json
import datetime
import traceback
import threading
import asyncio
import multiprocessing
import random
import collections
from playwright.sync_api import sync_playwright

class ProgressTracker:
    """Tracks batch progress and calculates ETA. (Enhancement E1)"""
    
    def __init__(self, total_items):
        self.total = total_items
        self.completed = 0
        self.failed = 0
        self.skipped = 0
        self.start_time = time.time()
        self.window = collections.deque(maxlen=20)
        self.last_eta_log_time = 0
        self.last_eta_log_count = 0
    
    def record_item(self, duration_seconds=None, status="success"):
        """Record a processed item."""
        if status == "success":
            self.completed += 1
        elif status == "failed":
            self.failed += 1
        elif status == "skipped":
            self.skipped += 1
        
        if duration_seconds and duration_seconds > 0:
            self.window.append(duration_seconds)
    
    def get_eta_string(self):
        """Get formatted progress/ETA string."""
        processed = self.completed + self.failed + self.skipped
        if processed == 0:
            return ""
        
        pct = (processed / self.total) * 100 if self.total > 0 else 0
        elapsed = time.time() - self.start_time
        
        # Calculate speed from rolling window
        if self.window:
            avg_time = sum(self.window) / len(self.window)
            items_per_min = 60.0 / avg_time if avg_time > 0 else 0
        else:
            items_per_min = (processed / elapsed * 60) if elapsed > 0 else 0
        
        # ETA calculation
        remaining = self.total - processed
        if items_per_min > 0:
            eta_minutes = remaining / items_per_min
            if eta_minutes >= 60:
                eta_str = f"{eta_minutes / 60:.0f}h {eta_minutes % 60:.0f}m"
            else:
                eta_str = f"{eta_minutes:.0f}m"
        else:
            eta_str = "calculating..."
        
        return (
            f"⏳ Progress: {processed}/{self.total} ({pct:.1f}%) | "
            f"Speed: {items_per_min:.1f} items/min | "
            f"ETA: ~{eta_str} | "
            f"✅{self.completed} ❌{self.failed} ⏭️{self.skipped}"
        )
    
    def should_log_eta(self):
        """Check if it's time to log an ETA update (every 30 items or 5 minutes)."""
        processed = self.completed + self.failed + self.skipped
        now = time.time()
        
        if processed - self.last_eta_log_count >= 30:
            self.last_eta_log_count = processed
            self.last_eta_log_time = now
            return True
        if now - self.last_eta_log_time >= 300:  # 5 minutes
            self.last_eta_log_count = processed
            self.last_eta_log_time = now
            return True
        return False


from automation.scrapers.voucher_scraper import SessionExpiredError, BrowserConnectionDeadError
import ssl
import requests
from requests.adapters import HTTPAdapter

class LegacyCipherAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        try:
            context.set_ciphers('ALL:@SECLEVEL=0')
        except Exception:
            try:
                context.set_ciphers('DEFAULT@SECLEVEL=1')
            except Exception:
                context.set_ciphers('DEFAULT')
        try:
            context.options |= 0x4  # OP_LEGACY_SERVER_CONNECT
        except Exception:
            pass
        try:
            context.minimum_version = ssl.TLSVersion.TLSv1
        except Exception:
            pass
        kwargs['ssl_context'] = context
        return super().init_poolmanager(*args, **kwargs)

    def send(self, *args, **kwargs):
        kwargs.setdefault('verify', False)
        return super().send(*args, **kwargs)

def load_run_state(operator_name, base_path):
    state_file = os.path.join(base_path, ".run_state.json")
    if os.path.exists(state_file):
        try:
            with open(state_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"completed": []}

def save_run_state(operator_name, base_path, completed_key):
    state_file = os.path.join(base_path, ".run_state.json")
    state = load_run_state(operator_name, base_path)
    if completed_key not in state["completed"]:
        state["completed"].append(completed_key)
        try:
            with open(state_file, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=4)
        except Exception:
            pass

def apply_webdriver_mask(page):
    try:
        page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    except Exception:
        pass

def configure_page_stealth_and_metrics(page, result_queue_getter):
    try:
        page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    except Exception:
        pass
        
    import time
    request_times = {}
    
    def on_request(request):
        try:
            if request.resource_type in ["document", "xhr", "fetch"]:
                request_times[request] = time.time()
        except: pass
        
    def on_response(response):
        try:
            req = response.request
            if req in request_times:
                latency = time.time() - request_times[req]
                del request_times[req]
                q = result_queue_getter()
                if q:
                    q.put(('http_metric', latency, response.status))
        except Exception: pass
        
    page.on("request", on_request)
    page.on("response", on_response)

class ConcurrencyAutoTuner:
    def __init__(self, user_worker_limit, log_func):
        self.user_worker_limit = user_worker_limit
        self.log = log_func
        self.latencies = []
        self.errors_in_window = []
        self.max_window_size = 20
        self.current_concurrency = user_worker_limit
        
    def record_metric(self, latency, status_code):
        self.latencies.append(latency)
        if len(self.latencies) > self.max_window_size:
            self.latencies.pop(0)
            
        is_error = 1 if (status_code == 503 or status_code >= 500) else 0
        self.errors_in_window.append(is_error)
        if len(self.errors_in_window) > self.max_window_size:
            self.errors_in_window.pop(0)
            
        if len(self.latencies) >= 3:
            avg_latency = sum(self.latencies) / len(self.latencies)
            
            if avg_latency > 12.0 or status_code == 503:
                if self.current_concurrency > 1:
                    new_concurrency = max(1, self.current_concurrency - 1)
                    self.log(f"📉 Auto-Tuner: Avg latency is {avg_latency:.2f}s (Threshold: >12.0s) or 503 error detected. Scaling back concurrency from {self.current_concurrency} to {new_concurrency}.")
                    self.current_concurrency = new_concurrency
                    return self.current_concurrency
            elif avg_latency < 7.0 and sum(self.errors_in_window) == 0:
                if self.current_concurrency < self.user_worker_limit:
                    new_concurrency = self.current_concurrency + 1
                    self.log(f"📈 Auto-Tuner: Avg latency is {avg_latency:.2f}s (Threshold: <7s) and no errors. Scaling up concurrency from {self.current_concurrency} to {new_concurrency} (User Limit: {self.user_worker_limit}).")
                    self.current_concurrency = new_concurrency
                    return self.current_concurrency
        return None

def get_stealth_context_args_for_worker(config_dict, base_args=None):
    if base_args is None:
        base_args = {}
    import random
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ]
    VIEWPORTS = [
        {"width": 1920, "height": 1080},
        {"width": 1366, "height": 768},
        {"width": 1440, "height": 900},
        {"width": 1536, "height": 864},
        {"width": 1280, "height": 720}
    ]
    
    if config_dict.get("stealth_mode", False):
        base_args["user_agent"] = random.choice(USER_AGENTS)
        base_args["viewport"] = random.choice(VIEWPORTS)
    else:
        ua = config_dict.get("user_agent", None)
        if ua:
            base_args["user_agent"] = ua
            
    base_args["accept_downloads"] = True
    return base_args

class ScraperWorkerProxy:
    def __init__(self, worker_id, result_queue, stop_event, config_dict):
        self.worker_id = worker_id
        self.result_queue = result_queue
        self.stop_event = stop_event
        
        self.download_dir = config_dict["download_dir"]
        self.batch_subfolder = config_dict.get("batch_subfolder", "").strip()
        self.var_path_template_val = config_dict["path_template"]
        self.audio_alerts = config_dict["audio_alerts"]
        self.os_notifications = config_dict["os_notifications"]
        self.download_paybills_in_vouchers_val = config_dict["download_paybills_in_vouchers"]
        self.paybill_only_val = config_dict.get("paybill_only", False)
        self.TIMEOUT_DOWNLOAD_PDF = config_dict["timeout_pdf"]
        self.TIMEOUT_DOWNLOAD_ATTACHMENT = config_dict["timeout_attachment"]
        self.TIMEOUT_DOWNLOAD_XLS = config_dict["timeout_xls"]
        self.TIMEOUT_LOGIN = config_dict["timeout_login"]
        self.TIMEOUT_MULTIPLIER = config_dict.get("timeout_multiplier", 1.0)
        self.TREASURY_MAP = config_dict["treasury_map"]
        self.TREASURY_IDS = config_dict["treasury_ids"]
        
        self.voucher_master_report = config_dict["voucher_master_report"]
        self.voucher_failed_file = config_dict["voucher_failed_file"]
        self.paybill_master_report = config_dict["paybill_master_report"]
        self.paybill_failed_file = config_dict["paybill_failed_file"]
        self.pol_failed_file = config_dict["pol_failed_file"]
        self.PANDAS_AVAILABLE = config_dict["pandas_available"]
        
        # Attributes needed by process_single_ddo_task in pol_scraper
        self.db_path = config_dict.get("db_path", "")
        self.base_path = os.path.dirname(self.db_path) if self.db_path else ""
        self._workers_count = config_dict.get("workers_count", 3)
        
        # Observable list implementation for downloaded folders
        self.downloaded_folders_this_run = []
        self._success_count = 0
        self._fail_count = 0
        self._skip_count = 0
        self._counter_lock = threading.Lock()
        
    @property
    def stop_requested(self):
        return self.stop_event.is_set()

    @property
    def success_count(self):
        return self._success_count

    @success_count.setter
    def success_count(self, val):
        diff = val - self._success_count
        self._success_count = val
        if diff > 0:
            self.result_queue.put(('increment', 'success', diff))

    @property
    def fail_count(self):
        return self._fail_count

    @fail_count.setter
    def fail_count(self, val):
        diff = val - self._fail_count
        self._fail_count = val
        if diff > 0:
            self.result_queue.put(('increment', 'fail', diff))

    @property
    def skip_count(self):
        return self._skip_count

    @skip_count.setter
    def skip_count(self, val):
        diff = val - self._skip_count
        self._skip_count = val
        if diff > 0:
            self.result_queue.put(('increment', 'skip', diff))

    @property
    def var_voucher_download_paybills(self):
        class VarWrapper:
            def __init__(self, val): self.val = val
            def get(self): return self.val
        return VarWrapper(self.download_paybills_in_vouchers_val)

    @property
    def var_paybill_only(self):
        class VarWrapper:
            def __init__(self, val): self.val = val
            def get(self): return self.val
        return VarWrapper(self.paybill_only_val)

    @property
    def var_path_template(self):
        class VarWrapper:
            def __init__(self, val): self.val = val
            def get(self): return self.val
        return VarWrapper(self.var_path_template_val)

    @property
    def var_parallel_workers(self):
        class VarWrapper:
            def __init__(self, val): self.val = val
            def get(self): return self.val
        return VarWrapper(getattr(self, '_workers_count', 3))

    @property
    def var_parallel(self):
        class VarWrapper:
            def __init__(self, val): self.val = val
            def get(self): return self.val
        return VarWrapper(True)

    def log(self, message, tag=None):
        self.result_queue.put(('log', f"[Worker {self.worker_id}] {message}", tag))

    def write_pol_summary(self, file_type, content):
        self.result_queue.put(('pol_write', file_type, content))

    def update_stats(self, current=None, progress=None):
        self.result_queue.put(('stats', current, progress))

    def add_downloaded_folder(self, folder):
        if folder not in self.downloaded_folders_this_run:
            self.downloaded_folders_this_run.append(folder)
            self.result_queue.put(('downloaded_folder', folder))

    def clean_folder_name(self, name):
        if not name: return "UNKNOWN"
        return "".join(c for c in str(name) if c.isalnum() or c in (" ", "_", "-", ".")).strip()

    def resolve_download_path(self, row_data, default_subfolder="Voucher"):
        sub_lower = str(default_subfolder).strip().lower()
        if "paybill" in sub_lower:
            category = "Paybills"
        elif "tally" in sub_lower:
            category = "TALLY_VOUCHERS"
        elif "voucher" in sub_lower:
            category = "VOUCHERS"
        elif "pol" in sub_lower:
            category = "POL"
        else:
            category = default_subfolder.upper()
            
        if hasattr(self, "batch_subfolder") and self.batch_subfolder and category not in ("Paybills", "TALLY_VOUCHERS"):
            category = os.path.normpath(os.path.join(category, self.batch_subfolder))
            
        if category == "TALLY_VOUCHERS":
            output_dir = getattr(self, "get_tally_output_dir", lambda: None)() or getattr(self, "tally_output_dir", None)
            if not output_dir and hasattr(self, "entry_tally_output") and self.entry_tally_output:
                try: output_dir = self.entry_tally_output.text().strip()
                except Exception: pass
            if not output_dir:
                output_dir = os.path.join(self.download_dir, "Tally_Results")
            output_dir = os.path.normpath(output_dir)
            t_raw = str(row_data.get('treasury', '')).strip()
            tr_short = t_raw
            if hasattr(self, "TREASURY_MAP"):
                for k, v in self.TREASURY_MAP.items():
                    if v == t_raw:
                        tr_short = k
                        break
            clean_tr = self.clean_folder_name(tr_short)
            clean_mh = self.clean_folder_name(str(row_data.get('mh', '')))
            clean_vch = self.clean_folder_name(str(row_data.get('voucher', '')))
            amt_val = row_data.get('amount')
            clean_amt = self.clean_folder_name(str(amt_val)) if amt_val not in (None, "", "None") else ""
            try: m_lbl = f"{int(row_data.get('month', 1)):02d}_{int(row_data.get('year', 2026))}"
            except Exception: m_lbl = "UNKNOWN_DATE"
            folder_parts = [str(row_data.get('s_no', '1')), clean_tr, clean_mh, m_lbl, clean_vch]
            if clean_amt: folder_parts.append(clean_amt)
            folder_name = "_".join(folder_parts)
            return os.path.normpath(os.path.join(output_dir, "Vouchers", folder_name))

            
        if category == "Paybills":
            t_raw = str(row_data.get('treasury', '')).strip()
            clean_tr = self.clean_folder_name(t_raw)
            clean_mh = self.clean_folder_name(str(row_data.get('mh', '')))
            try:
                m_lbl = f"{int(row_data.get('month', 1)):02d}"
            except Exception:
                m_lbl = "01"
            try:
                y_lbl = str(int(row_data.get('year', 2026)))
            except Exception:
                y_lbl = "2026"
            sub_dir = f"{t_raw}_{clean_tr}_{clean_mh}_{m_lbl}_{y_lbl}"
            return os.path.normpath(os.path.join(self.download_dir, "Paybills", sub_dir))

        if category == "SALARY BILL":
            t_raw = str(row_data.get('treasury', '')).strip()
            clean_tr = self.clean_folder_name(t_raw)
            clean_mh = self.clean_folder_name(str(row_data.get('mh', '')))
            try:
                m_lbl = f"{int(row_data.get('month', 1)):02d}"
            except Exception:
                m_lbl = "01"
            try:
                y_lbl = str(int(row_data.get('year', 2026)))
            except Exception:
                y_lbl = "2026"
            sub_dir = f"{clean_tr}_{clean_mh}_{m_lbl}_{y_lbl}"
            return os.path.normpath(os.path.join(self.download_dir, "SALARY BILL", sub_dir))

        # Reverse map 3-digit treasury code to short name for folder naming
        t_raw = str(row_data.get('treasury', '')).strip()
        tr_short = t_raw
        if category != "POL" and hasattr(self, "TREASURY_MAP"):
            for k, v in self.TREASURY_MAP.items():
                if v == t_raw:
                    tr_short = k
                    break

        if category == "POL":
            clean_tr = self.clean_folder_name(tr_short)
            clean_ddo_code = self.clean_folder_name(str(row_data.get('ddo_code', '')))
            clean_ddo_name = self.clean_folder_name(str(row_data.get('ddo_name', '')))
            
            if clean_ddo_code and clean_ddo_name and clean_ddo_code != clean_ddo_name:
                ddo_folder = f"{clean_ddo_code}_{clean_ddo_name}"
            else:
                ddo_folder = clean_ddo_code or clean_ddo_name or "UNKNOWN_DDO"
                
            return os.path.normpath(os.path.join(self.download_dir, category, f"{clean_tr}_POL", ddo_folder))

        template = self.var_path_template_val.strip()
        if not template:
            folder_name = row_data.get("folder_name")
            if not folder_name:
                try:
                    m_lbl = f"{int(row_data.get('month', 1)):02d}_{int(row_data.get('year', 2026))}"
                except Exception:
                    m_lbl = "UNKNOWN_DATE"
                clean_tr = self.clean_folder_name(tr_short)
                clean_vch = self.clean_folder_name(str(row_data.get('voucher', '')))
                amt_val = row_data.get('amount')
                clean_amt = self.clean_folder_name(str(amt_val)) if amt_val not in (None, "", "None") else ""
                folder_parts = [
                    str(row_data.get('s_no', '1')),
                    clean_tr,
                    str(row_data.get('mh', '')),
                    m_lbl,
                    clean_vch
                ]
                if clean_amt and clean_amt not in ("None", "UNKNOWN"):
                    folder_parts.append(clean_amt)
                folder_name = "_".join(folder_parts)
            return os.path.join(self.download_dir, category, folder_name)
        
        clean_tr = self.clean_folder_name(tr_short)
        clean_vch = self.clean_folder_name(str(row_data.get('voucher', '')))
        clean_amt = self.clean_folder_name(str(row_data.get('amount', '')))
        clean_mh = self.clean_folder_name(str(row_data.get('mh', '')))
        clean_ddo = self.clean_folder_name(str(row_data.get('ddo', '')))
        try:
            m_lbl = f"{int(row_data.get('month', 1)):02d}"
        except Exception:
            m_lbl = "01"
        try:
            y_lbl = str(int(row_data.get('year', 2026)))
        except Exception:
            y_lbl = "2026"
        s_no = str(row_data.get('s_no', ''))

        path = template
        if "{Output_Folder}" in path:
            path = path.replace("{Output_Folder}", os.path.join(self.download_dir, category))
        else:
            path = os.path.join(self.download_dir, category, path)
            
        path = path.replace("{Treasury}", clean_tr)
        path = path.replace("{Year}", y_lbl)
        path = path.replace("{Month}", m_lbl)
        path = path.replace("{DDO_Name}", clean_ddo)
        path = path.replace("{DDO}", clean_ddo)
        path = path.replace("{Voucher_No}", clean_vch)
        path = path.replace("{Voucher}", clean_vch)
        path = path.replace("{Amount}", clean_amt)
        path = path.replace("{Major_Head}", clean_mh)
        path = path.replace("{MH}", clean_mh)
        path = path.replace("{S_No}", s_no)

        path = os.path.normpath(path)
        return path

    def safe_fill(self, page, selector, value):
        loc = page.locator(selector)
        loc.wait_for(state="visible")
        loc.fill(str(value))

    def get_locator_in_frames(self, p_page, selector):
        if p_page.locator(selector).count() > 0: return p_page.locator(selector).first
        for frame in p_page.frames:
            if frame.locator(selector).count() > 0: return frame.locator(selector).first
        return p_page.locator(selector).first

    def select_dropdown(self, page, selector, code):
        code_raw = str(code).strip()
        if code_raw.startswith('="') and code_raw.endswith('"'):
            code_raw = code_raw[2:-1].strip()
        elif code_raw.startswith('='):
            code_raw = code_raw[1:].strip().strip('"').strip("'")
        code = code_raw.strip('"').strip("'").strip().upper()
        if not code:
            return False

        resolved_num = None
        # 1. Direct 3-letter lookup (e.g. SID -> 410)
        if code in self.TREASURY_MAP:
            resolved_num = self.TREASURY_MAP[code]
        # 2. Direct 3-digit numeric code (e.g. 410)
        elif code in self.TREASURY_MAP.values():
            resolved_num = code
        else:
            # 3. Numeric translation search (e.g. 50 -> 050, 41 -> 410)
            if code.isdigit():
                if len(code) == 1:
                    code_pad = "0" + code + "0"
                elif len(code) == 2:
                    code_pad = "0" + code
                elif len(code) == 3:
                    code_pad = code
                else:
                    code_pad = code[:3]
                if code_pad in self.TREASURY_MAP.values():
                    resolved_num = code_pad

            # 4. Search in TREASURY_IDS keys
            if not resolved_num:
                for k, v in self.TREASURY_IDS.items():
                    if code in k.upper():
                        # Extract 3-digit code from key like "410-SID-Sidhi"
                        parts = k.split("-")
                        if parts and parts[0].isdigit():
                            resolved_num = parts[0]
                        else:
                            resolved_num = v.split("~")[0].strip()
                        break

        dropdown = page.locator(f"#{selector}")
        dropdown.wait_for(state="attached")
        try: page.wait_for_function(f"document.querySelectorAll('#{selector} option').length > 1", timeout=5000)
        except Exception: return False

        options = dropdown.locator("option").all()

        # Step A: Try matching by resolved_num (e.g. 410 or "410 - ")
        if resolved_num:
            for opt in options:
                txt = opt.inner_text().strip()
                val = (opt.get_attribute("value") or "").strip()
                # Check option text starts with resolved_num (e.g. "410 - SIDHI TREASURY")
                if txt.startswith(resolved_num) or (resolved_num in txt.split(" ")[0]):
                    dropdown.select_option(value=val)
                    return True
                # Check if value contains or matches resolved_num
                if resolved_num in val:
                    dropdown.select_option(value=val)
                    return True

        # Step B: Direct fallback matching on raw input code
        for opt in options:
            txt = opt.inner_text().strip().upper()
            val = (opt.get_attribute("value") or "").strip()
            if code in txt or code in val:
                dropdown.select_option(value=val)
                return True

        return False

from automation.scrapers.voucher_scraper import merge_and_rename_pdfs, download_voucher_browserless
ScraperWorkerProxy.merge_and_rename_pdfs = merge_and_rename_pdfs
ScraperWorkerProxy.download_voucher_browserless = download_voucher_browserless

def _ensure_browser_alive(browser, pw, cdp_url, browser_name, kwargs, proxy, worker_id):
    """Check if browser connection is alive. If dead, reconnect via CDP or launch fallback.
    Returns a live browser instance, or raises Exception if all reconnection attempts fail."""
    try:
        if browser and browser.is_connected():
            return browser
    except Exception:
        pass
    
    proxy.log(f"⚠️ [Worker {worker_id}] Browser connection dead. Attempting reconnection...")
    
    # Try CDP reconnection first
    if cdp_url:
        try:
            browser = pw.chromium.connect_over_cdp(cdp_url)
            proxy.log(f"✅ [Worker {worker_id}] Reconnected to shared CDP browser.")
            return browser
        except Exception as ce:
            proxy.log(f"⚠️ [Worker {worker_id}] CDP reconnection failed: {ce}")
    
    # Fallback: launch a local browser
    try:
        launcher = getattr(pw, browser_name)
        browser = launcher.launch(**kwargs)
        proxy.log(f"✅ [Worker {worker_id}] Launched local fallback browser.")
        return browser
    except Exception as le:
        proxy.log(f"❌ [Worker {worker_id}] Failed to launch fallback browser: {le}")
    
    raise Exception(f"[Worker {worker_id}] All browser reconnection attempts failed.")


def multiprocess_voucher_worker(worker_id, mode, state_file, task_queue, result_queue, stop_event, pause_event, wp_event, config_dict, use_chrome):
    from playwright.sync_api import sync_playwright
    from automation.scrapers.voucher_scraper import process_voucher_vch, process_voucher_pb, process_voucher_tally, SessionExpiredError, BrowserConnectionDeadError
    
    proxy = ScraperWorkerProxy(worker_id, result_queue, stop_event, config_dict)
    
    pw = None
    browser = None
    context = None
    page = None
    try:
        pw = sync_playwright().start()
        browser_name = "chromium" if use_chrome else "firefox"
        headless_state = not config_dict.get("show_workers", False)
        if config_dict.get("headful_monitor", False):
            headless_state = True
        kwargs = {"headless": headless_state}
        if not use_chrome:
            kwargs["firefox_user_prefs"] = {
                "network.trr.mode": 5,
                "network.dns.disableIPv6": True,
                "widget.windows.window_occlusion_tracking.enabled": False,
                "dom.min_background_timeout_value": 10000,
                "privacy.reduceTimerPrecision": False,
                "network.proxy.type": 5,
                "network.proxy.no_proxies_on": "localhost, 127.0.0.1, .mptreasury.gov.in, mptreasury.gov.in"
            }
        if use_chrome:
            if headless_state:
                kwargs["args"] = [
                    "--headless=new",
                    "--disable-gpu",
                    "--no-sandbox",
                    "--disable-backgrounding-occluded-windows",
                    "--disable-background-timer-throttling",
                    "--disable-renderer-backgrounding",
                    "--disable-background-networking",
                    "--window-position=-2400,-2400",
                    "--window-size=10,10"
                ]
            else:
                kwargs["args"] = [
                    "--start-maximized",
                    "--disable-backgrounding-occluded-windows",
                    "--disable-background-timer-throttling",
                    "--disable-renderer-backgrounding",
                    "--disable-background-networking"
                ]
# Use bundled Playwright Chromium
        try:
            cdp_url = config_dict.get("cdp_url")
            if cdp_url:
                try:
                    browser = pw.chromium.connect_over_cdp(cdp_url)
                    proxy.log(f"👷 Connected to shared background CDP browser.")
                except Exception as ce:
                    proxy.log(f"⚠️ Failed to connect over CDP: {ce}. Falling back to launching separate browser...")
                    browser = None

            if not browser:
                launcher = getattr(pw, browser_name)
                browser = launcher.launch(**kwargs)
        except Exception:
            if not browser:
                launcher = getattr(pw, browser_name)
                browser = launcher.launch(headless=headless_state)

        context_args = get_stealth_context_args_for_worker(config_dict, {
            "storage_state": state_file
        })
        context = browser.new_context(**context_args)
        page = context.new_page()
        # Set default action timeout scaled dynamically based on concurrent workers count (capped at 90s)
        act_timeout = min(90000, max(60000, int(60000 * config_dict.get("timeout_multiplier", 1.0))))
        page.set_default_timeout(act_timeout)
        configure_page_stealth_and_metrics(page, lambda: result_queue)

        downloads_since_last_restart = 0
        delay_multiplier = 1.0

        while not proxy.stop_requested:
            # Check pause status
            while (pause_event.is_set() or (wp_event and wp_event.is_set())) and not proxy.stop_requested:
                if task_queue.empty():
                    break
                time.sleep(1)
            if proxy.stop_requested:
                break

            try:
                item_idx, row_data = task_queue.get_nowait()
                result_queue.put(('heartbeat', worker_id, time.time()))
            except Exception:
                break
            
            # 1. Incremental Speed-up: check if completed folder marker exists
            try:
                target_dir = proxy.resolve_download_path(row_data, "Voucher" if mode in ("voucher", "voucher_search") else "Paybill")
                marker_file = os.path.join(target_dir, "SUCCESS.marker")
                if mode != "voucher_search" and os.path.exists(marker_file):
                    proxy.log(f"⏭️ [Worker {worker_id}] Skipping already completed voucher {row_data.get('voucher')} (Folder marker found)")
                    key = f"{row_data.get('treasury')}_{row_data.get('mh')}_{row_data.get('month')}_{row_data.get('year')}_{row_data.get('voucher')}"
                    result_queue.put(('task_skip', row_data, key, target_dir))
                    continue
            except Exception as dbe:
                proxy.log(f"⚠️ Cache check error: {dbe}")

            # Browser process recycling
            if downloads_since_last_restart >= 20:
                proxy.log("Recycling browser session to release leaked memory...")
                try:
                    page.close()
                    context.close()
                except Exception: pass
                time.sleep(5)
                browser = _ensure_browser_alive(browser, pw, cdp_url, browser_name, kwargs, proxy, worker_id)
                context_args = get_stealth_context_args_for_worker(config_dict, {
                    "storage_state": state_file
                })
                context = browser.new_context(**context_args)
                page = context.new_page()
                configure_page_stealth_and_metrics(page, lambda: result_queue)
                downloads_since_last_restart = 0

            # Adaptive Jitter
            time.sleep(random.uniform(1.5, 4.0) * delay_multiplier)

            # Try browserless download first!
            db_path = config_dict.get("db_path")
            template_path = os.path.normpath(os.path.join(os.path.dirname(db_path), "voucher_request_template.json"))
            browserless_success = False
            
            if mode != "tally" and os.path.exists(template_path):
                try:
                    proxy.log(f"⚡ [Worker {worker_id}] Fetching {mode} voucher {row_data.get('voucher')}...")
                    browserless_success = proxy.download_voucher_browserless(
                        row_data, mode, config_dict, template_path, state_file, page, context
                    )
                except Exception as ble:
                    proxy.log(f"⚠️ [Worker {worker_id}] Browserless attempt failed: {ble}. Falling back to Playwright.")

            if browserless_success:
                key = f"{row_data.get('treasury')}_{row_data.get('mh')}_{row_data.get('month')}_{row_data.get('year')}_{row_data.get('voucher')}"
                result_queue.put(('task_result', True, row_data, key))
                downloads_since_last_restart += 1
                continue

            # 2. Self-Healing 3-attempt loop
            success = False
            worker_attempts = 0
            while worker_attempts < 3 and not success and not proxy.stop_requested:
                # Wait if paused
                while (pause_event.is_set() or (wp_event and wp_event.is_set())) and not proxy.stop_requested:
                    time.sleep(1)
                if proxy.stop_requested:
                    break

                worker_attempts += 1
                local_failures = []
                try:
                    # Setup page response hook to check 503/429
                    def check_response(response):
                        nonlocal delay_multiplier
                        if response.status in [429, 503]:
                            proxy.log(f"⚠️ Received HTTP {response.status} rate-limiting. Throttling wait delays...")
                            delay_multiplier = min(delay_multiplier * 1.5, 5.0)
                            result_queue.put(('auto_throttle',))
                    page.on("response", check_response)

                    if mode in ("voucher", "voucher_search"):
                        process_voucher_vch(proxy, page, context, row_data, local_failures)
                    elif mode == "tally":
                        process_voucher_tally(proxy, page, context, row_data, local_failures)
                    else:
                        process_voucher_pb(proxy, page, context, row_data, local_failures)
                    
                    page.remove_listener("response", check_response)

                    if local_failures:
                        if worker_attempts < 3:
                            proxy.log(f"⚠️ [Worker {worker_id}] Attempt {worker_attempts}/3 failed. Re-initiating context (Localized View Reset) for retry...")
                            local_failures.clear()
                            try:
                                page.close()
                                context.close()
                            except Exception: pass
                            browser = _ensure_browser_alive(browser, pw, cdp_url, browser_name, kwargs, proxy, worker_id)
                            context_args = get_stealth_context_args_for_worker(config_dict, {
                                "storage_state": state_file
                            })
                            context = browser.new_context(**context_args)
                            page = context.new_page()
                            # Apply automatic timeout scaling for retry attempts
                            scaled_timeout = int(act_timeout * (1.5 ** worker_attempts))
                            page.set_default_timeout(scaled_timeout)
                            proxy.log(f"⚠️ [Worker {worker_id}] Scaling default timeout to {scaled_timeout // 1000}s for retry...")
                            configure_page_stealth_and_metrics(page, lambda: result_queue)
                            continue
                        for fail_row in local_failures:
                            result_queue.put(('task_result', False, fail_row))
                    else:
                        key = f"{row_data.get('treasury')}_{row_data.get('mh')}_{row_data.get('month')}_{row_data.get('year')}_{row_data.get('voucher')}"
                        result_queue.put(('task_result', True, row_data, key))
                        downloads_since_last_restart += 1
                    success = True
                except SessionExpiredError:
                    proxy.log(f"🔴 [Worker {worker_id}] Session expired. Pausing worker and notifying parent...")
                    result_queue.put(('session_expired', row_data))
                    # Wait for re-authentication
                    pause_event.wait()
                    # Recreate page & context to inherit fresh tokens
                    try:
                        page.close()
                        context.close()
                    except Exception: pass
                    context_args = get_stealth_context_args_for_worker(config_dict, {
                        "storage_state": state_file
                    })
                    context = browser.new_context(**context_args)
                    page = context.new_page()
                    page.set_default_timeout(act_timeout)
                    configure_page_stealth_and_metrics(page, lambda: result_queue)
                    # Reset attempts for fresh start
                    worker_attempts = 0
                except BrowserConnectionDeadError as bcd:
                    proxy.log(f"❌ [Worker {worker_id}] Browser connection dead: {bcd}. Reconnecting context...")
                    try:
                        if not browser or not browser.is_connected():
                            if cdp_url:
                                browser = pw.chromium.connect_over_cdp(cdp_url)
                    except Exception:
                        browser = None

                    if not browser or not browser.is_connected():
                        try:
                            launcher = getattr(pw, browser_name)
                            browser = launcher.launch(**kwargs)
                        except Exception as le:
                            proxy.log(f"⚠️ [Worker {worker_id}] Failed to launch local fallback browser: {le}")
                            browser = None

                    try:
                        page.close()
                    except Exception: pass
                    try:
                        context.close()
                    except Exception: pass

                    if browser:
                        context_args = get_stealth_context_args_for_worker(config_dict, {
                            "storage_state": state_file
                        })
                        context = browser.new_context(**context_args)
                        page = context.new_page()
                        scaled_timeout = int(act_timeout * (1.5 ** worker_attempts))
                        page.set_default_timeout(scaled_timeout)
                        configure_page_stealth_and_metrics(page, lambda: result_queue)
                    else:
                        raise Exception("Failed to reconnect browser context or launch fallback local browser.")
                except Exception as ex:
                    from automation.scrapers.voucher_scraper import is_browser_connection_dead
                    is_dead = is_browser_connection_dead(ex)
                    if is_dead:
                        proxy.log(f"❌ [Worker {worker_id}] Connection dead detected in general handler: {ex}. Reconnecting browser...")
                        try:
                            if not browser or not browser.is_connected():
                                if cdp_url:
                                    browser = pw.chromium.connect_over_cdp(cdp_url)
                        except Exception:
                            browser = None
                        
                        if not browser or not browser.is_connected():
                            try:
                                launcher = getattr(pw, browser_name)
                                browser = launcher.launch(**kwargs)
                            except Exception as le:
                                proxy.log(f"⚠️ [Worker {worker_id}] Failed to launch local fallback browser: {le}")
                                browser = None

                    if worker_attempts < 3:
                        proxy.log(f"⚠️ [Worker {worker_id}] Attempt {worker_attempts}/3 failed: {ex}. Retrying...")
                        try:
                            page.close()
                        except Exception: pass
                        try:
                            context.close()
                        except Exception: pass
                        
                        if browser:
                            context_args = get_stealth_context_args_for_worker(config_dict, {
                                "storage_state": state_file
                            })
                            context = browser.new_context(**context_args)
                            page = context.new_page()
                            scaled_timeout = int(act_timeout * (1.5 ** worker_attempts))
                            page.set_default_timeout(scaled_timeout)
                            proxy.log(f"⚠️ [Worker {worker_id}] Scaling default timeout to {scaled_timeout // 1000}s for retry...")
                            configure_page_stealth_and_metrics(page, lambda: result_queue)
                            time.sleep(2 ** worker_attempts)
                        else:
                            raise Exception("Browser is dead and failed to recreate context.")
                    else:
                        result_queue.put(('task_result', False, row_data))
                        success = True # Stop attempting if max retries exceeded
    except Exception as ex:
        result_queue.put(('log', f"Worker process crash: {ex}", "error"))
    finally:
        try:
            if page: page.close()
            if context: context.close()
            if browser: browser.close()
            if pw: pw.stop()
        except Exception: pass

def rebuild_payload(post_data, task_data):
    import urllib.parse
    import re
    parsed = urllib.parse.parse_qs(post_data)
    for k in list(parsed.keys()):
        k_low = k.lower()
        if "ddo" in k_low:
            ddo_name = task_data["ddo_name"]
            m_code = re.search(r"^(\d+)", ddo_name.strip())
            ddo_code_prefix = m_code.group(1) if m_code else ddo_name.split("-")[0].strip()
            parsed[k] = [ddo_code_prefix]
        elif "from" in k_low:
            parsed[k] = [task_data["sub_from"]]
        elif "to" in k_low:
            parsed[k] = [task_data["sub_to"]]
        elif "tsry" in k_low or "treasury" in k_low:
            parsed[k] = [task_data["try_val"]]
        elif "sna" in k_low:
            parsed[k] = [task_data["sna_val"]]
    return urllib.parse.urlencode(parsed, doseq=True)

def process_single_ddo_task_browserless(proxy, session, task_data, worker_id, template):
    import os
    import re
    import time
    import urllib.parse
    from automation.scrapers.voucher_scraper import SessionExpiredError
    
    expected_filename = task_data["expected_filename"]
    skipped_marker = task_data["skipped_marker"]
    success_path = task_data["success_path"]
    skipped_summary_path = task_data["skipped_summary_path"]
    failed_path = task_data["failed_path"]
    ddo_name = task_data["ddo_name"]
    treasury_name = task_data["treasury_name"]
    
    url = template["url"]
    method = template["method"]
    post_data = template.get("post_data", "")
    headers = template.get("headers", {})
    
    headers = {k: v for k, v in headers.items() if k.lower() not in ["host", "content-length"]}
    
    url_parts = list(urllib.parse.urlparse(url))
    query = url_parts[4]
    if query:
        url_parts[4] = rebuild_payload(query, task_data)
    new_url = urllib.parse.urlunparse(url_parts)
    
    new_post_data = None
    if method == "POST" and post_data:
        new_post_data = rebuild_payload(post_data, task_data)
        
    try:
        # Debug: log the actual request being made
        proxy.log(f"🔍 [Worker {worker_id}] (HTTP) {method} → {new_url[:120]}...")
        if method == "POST":
            response = session.post(new_url, data=new_post_data, headers=headers, timeout=60, verify=False)
        else:
            response = session.get(new_url, headers=headers, timeout=60, verify=False)
            
        if response.status_code != 200:
            proxy.log(f"❌ [Worker {worker_id}] HTTP error code: {response.status_code} | Final URL: {response.url[:120]}")
            return False
            
        content_type = response.headers.get("Content-Type", "").lower()
        content = response.content
        
        is_html = "text/html" in content_type or b"<html" in content[:200].lower() or b"<!doctype html" in content[:200].lower()
        
        if is_html:
            html_text = content.decode("utf-8", errors="ignore").lower()
            
            # Debug: log response details for diagnosis
            proxy.log(f"🔍 [Worker {worker_id}] (HTTP) Got HTML response ({len(content)} bytes) | Content-Type: {content_type} | Final URL: {response.url[:100]}")
            # Log first 300 chars to understand what page we got
            snippet = content.decode("utf-8", errors="ignore")[:300].replace("\n", " ").replace("\r", "")
            proxy.log(f"🔍 [Worker {worker_id}] (HTTP) Response snippet: {snippet[:200]}")
            
            if "no records found" in html_text or "no record found" in html_text or "no records" in html_text:
                proxy.log(f"⏭️ [Worker {worker_id}] (HTTP) No records found for DDO '{ddo_name}' - skipping.")
                download_dir = os.path.dirname(expected_filename)
                os.makedirs(download_dir, exist_ok=True)
                try:
                    skipped_marker_file = os.path.join(download_dir, "skipped.marker")
                    with open(skipped_marker_file, "w", encoding="utf-8") as smf:
                        smf.write(f"SKIPPED_NO_RECORDS\nDate: {time.strftime('%Y-%m-%d %H:%M:%S')}\nDDO: {ddo_name}\n")
                except Exception: pass
                
                try:
                    failed_marker_file = os.path.join(download_dir, "failed.marker")
                    if os.path.exists(failed_marker_file):
                        os.remove(failed_marker_file)
                except Exception: pass
                
                proxy.write_pol_summary('skipped', f"{ddo_name}\n")
                proxy.write_pol_summary('success', f"⏭️ SKIPPED: {ddo_name} (No Records/Report Found.)\n")
                
                return "skipped"
            else:
                # Check for specific session expiration indicators in the HTML response
                expired_indicators = [
                    "session expired", "session has expired", "session timeout", 
                    "logged out", "please login again", "re-login", "login again"
                ]
                is_expired = any(ind in html_text for ind in expired_indicators)
                if not is_expired:
                    if "j_username" in html_text or "j_password" in html_text or "getuseridforotp" in response.url.lower():
                        is_expired = True
                
                if is_expired:
                    proxy.log(f"🔍 [Worker {worker_id}] (HTTP) Session expiry triggered by: j_username={'j_username' in html_text}, j_password={'j_password' in html_text}, url_check={'getuseridforotp' in response.url.lower()}")
                    raise SessionExpiredError("Session expired detected in HTTP response HTML.")
                proxy.log(f"❌ [Worker {worker_id}] Received unexpected HTML response.")
                return False
        else:
            os.makedirs(os.path.dirname(expected_filename), exist_ok=True)
            with open(expected_filename, "wb") as ef:
                ef.write(content)
                
            from automation.scrapers.voucher_scraper import validate_downloaded_file
            if not validate_downloaded_file(expected_filename):
                proxy.log(f"❌ [Worker {worker_id}] (HTTP) File failed basic integrity validation.")
                if os.path.exists(expected_filename):
                    try: os.remove(expected_filename)
                    except: pass
                return False
                
            ddo_code_prefix = ""
            m_code = re.search(r"^(\d+)", ddo_name.strip())
            if m_code: ddo_code_prefix = m_code.group(1)
            else: ddo_code_prefix = ddo_name.split("-")[0].strip()
            
            from automation.scrapers.pol_scraper import _verify_xls_ddo
            if _verify_xls_ddo(proxy, expected_filename, ddo_code_prefix, treasury_name):
                proxy.log(f"✅ [Worker {worker_id}] (HTTP) Saved verified XLS file: {os.path.basename(expected_filename)}")
                download_dir = os.path.dirname(expected_filename)
                try:
                    success_marker_file = os.path.join(download_dir, "success.marker")
                    with open(success_marker_file, "w", encoding="utf-8") as smf:
                        smf.write(f"SUCCESS\nDate: {time.strftime('%Y-%m-%d %H:%M:%S')}\nDDO: {ddo_name}\nFile: {os.path.basename(expected_filename)}\n")
                except Exception: pass
                
                try:
                    failed_marker_file = os.path.join(download_dir, "failed.marker")
                    if os.path.exists(failed_marker_file):
                        os.remove(failed_marker_file)
                except Exception: pass

                proxy.write_pol_summary('success', f"✅ SUCCESS: {ddo_name}\n")
                return "success"
            else:
                proxy.log(f"❌ [Worker {worker_id}] (HTTP) Verification failed for DDO '{ddo_name}'. Data mismatch.")
                if os.path.exists(expected_filename):
                    try: os.remove(expected_filename)
                    except: pass
                return False
    except Exception as e:
        if isinstance(e, SessionExpiredError):
            raise e
        proxy.log(f"⚠️ [Worker {worker_id}] HTTP request error: {e}")
        return False

def multiprocess_pol_worker(worker_id, state_file, task_queue, result_queue, stop_event, pause_event, wp_event, config_dict, use_chrome):
    try:
        # Ensure project root is on sys.path for subprocess imports (PyInstaller + multiprocessing)
        import sys
        import traceback as tb_mod
        project_root = config_dict.get("project_root", "")
        if project_root and project_root not in sys.path:
            sys.path.insert(0, project_root)
        # Also add the directory containing the main script
        main_script_dir = os.path.dirname(os.path.abspath(sys.argv[0])) if sys.argv else ""
        if main_script_dir and main_script_dir not in sys.path:
            sys.path.insert(0, main_script_dir)

        from playwright.sync_api import sync_playwright
        from automation.scrapers.pol_scraper import process_single_ddo_task
        import requests
        import json
        import random
        
        # Suppress SSL warnings from urllib3 for legacy cipher connections
        try:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except Exception:
            pass
        
        proxy = ScraperWorkerProxy(worker_id, result_queue, stop_event, config_dict)
        mode = config_dict.get("mode", "pol")
        
        pw = None
        browser = None
        context = None
        page = None
        http_session = None
        
        downloads_since_last_restart = 0
        delay_multiplier = 1.0
        
        # POL downloads use direct HTTP mode when session cookies are available.
        use_browserless = os.path.exists(state_file) if state_file else False
        if use_browserless:
            proxy.log(f"⚡ [Worker {worker_id}] Starting in direct HTTP fast mode.")
        else:
            proxy.log(f"👷 [Worker {worker_id}] Starting in worker mode.")
    except Exception as init_err:
        # Worker crashed during initialization — report to parent via result_queue
        import traceback as tb_mod
        err_msg = f"🔴 [Worker {worker_id}] FATAL: Worker crashed during startup: {init_err}\n{tb_mod.format_exc()}"
        try:
            result_queue.put(('log', err_msg, 'ERROR'))
        except Exception:
            pass
        return
        
    try:
        while not proxy.stop_requested:
            # Check pause status
            while (pause_event.is_set() or (wp_event and wp_event.is_set())) and not proxy.stop_requested:
                if task_queue.empty():
                    break
                time.sleep(1)
            if proxy.stop_requested:
                break
                
            try:
                task_item = task_queue.get()
                if task_item is None:
                    break
                item_idx, task_data = task_item
            except Exception:
                break
                
            # Incremental Speed-up: cache check
            try:
                db_path = config_dict.get("db_path")
                ddo_code = ""
                try:
                    import re
                    m_code = re.search(r"^(\d+)", task_data['ddo_name'].strip())
                    if m_code: ddo_code = m_code.group(1)
                except: pass
                
                m_val, y_val = None, None
                try:
                    my_str = str(task_data['month_year']).replace('/', '_').replace('-', '_')
                    parts = my_str.split('_')
                    if len(parts) >= 2:
                        m_val = str(int(parts[0]))
                        y_val = int(parts[1])
                except Exception: pass
                
                from database.db_manager import is_pol_downloaded
                is_done = is_pol_downloaded(db_path, task_data.get('clean_treasury'), ddo_code, m_val, y_val)
                if not is_done:
                    ef = task_data.get("expected_filename")
                    sm = task_data.get("skipped_marker")
                    if ef and os.path.exists(ef):
                        is_done = True
                    elif sm and os.path.exists(sm):
                        is_done = True
                        
                if is_done:
                    proxy.log(f"⏭️ [Worker {worker_id}] Skipping already completed/skipped DDO {task_data.get('ddo_name')} (Incremental Speed-up)")
                    key = f"{task_data['clean_treasury']}_{task_data['ddo_name']}_{task_data['month_year']}"
                    result_queue.put(('pol_skip', task_data, key))
                    continue
            except Exception as dbe:
                proxy.log(f"⚠️ Cache check error: {dbe}")
                
            # Dynamic HTTP Session Initialization
            if use_browserless and not http_session:
                proxy.log(f"👷 [Worker {worker_id}] Initializing HTTP session...")
                http_session = requests.Session()
                try:
                    http_session.mount("https://", LegacyCipherAdapter())
                except Exception as mount_err:
                    proxy.log(f"⚠️ Failed to mount cipher adapter: {mount_err}")
                
                # Copy cookies from state_file
                cookies_list = []
                try:
                    if os.path.exists(state_file):
                        with open(state_file, "r") as f:
                            cookies_list = json.load(f).get("cookies", [])
                except Exception as ce:
                    proxy.log(f"⚠️ Failed to parse state_file cookies: {ce}")
                    
                for c in cookies_list:
                    http_session.cookies.set(c['name'], c['value'], domain=c['domain'], path=c['path'])
                    
                is_voucher = (mode in ("voucher", "voucher_search"))
                action_flag_str = "rnd-toApprovedBillsTreasuryWise" if is_voucher else "rnd-paymentOrderListForAG"
                warmup_url = f"https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag={action_flag_str}&elementId=10072358"

                http_session.headers.update({
                    "User-Agent": config_dict.get("user_agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"),
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Connection": "keep-alive",
                    "Origin": "https://ifmisprod.mptreasury.gov.in",
                    "Referer": warmup_url,
                })
                
                # Warm-up: GET report page to establish session context
                warmup_ok = False
                warmup_resp_text = ""
                for warmup_attempt in range(3):
                    try:
                        warmup_resp = http_session.get(warmup_url, timeout=30, verify=False, allow_redirects=True)
                        warmup_html = warmup_resp.text.lower()
                        
                        if "j_username" in warmup_html or "j_password" in warmup_html:
                            proxy.log(f"🔴 [Worker {worker_id}] Session cookies need refresh. Reloading state file...")
                            time.sleep(2)
                            try:
                                if os.path.exists(state_file):
                                    with open(state_file, "r") as f:
                                        fresh_cookies = json.load(f).get("cookies", [])
                                    http_session.cookies.clear()
                                    for c in fresh_cookies:
                                        http_session.cookies.set(c['name'], c['value'], domain=c['domain'], path=c['path'])
                            except Exception: pass
                            continue
                        else:
                            warmup_ok = True
                            warmup_resp_text = warmup_resp.text
                            proxy.log(f"✅ [Worker {worker_id}] Direct HTTP session ready.")
                            break
                    except Exception as warmup_err:
                        proxy.log(f"⚠️ [Worker {worker_id}] Session check attempt {warmup_attempt+1}/3 failed: {warmup_err}")
                        time.sleep(2)
                
                # Extract live treasury dropdown options from warmup response
                if warmup_ok and is_voucher and warmup_resp_text:
                    try:
                        import re as _re
                        # Parse <select name="cmbTreasuryCodeName"> options
                        select_block = _re.search(r'<select[^>]*name=["\']cmbTreasuryCodeName["\'][^>]*>(.*?)</select>', warmup_resp_text, _re.DOTALL | _re.IGNORECASE)
                        if select_block:
                            opts = _re.findall(r'<option\s+value=["\']([^"\']+)["\'][^>]*>', select_block.group(1), _re.IGNORECASE)
                            if opts:
                                # Build map: numeric treasury code -> full option value
                                # e.g. "270" -> "12605~270~Neemuch District Treasury"
                                live_treasury_map = {}
                                for opt_val in opts:
                                    parts = opt_val.split("~")
                                    if len(parts) >= 2:
                                        live_treasury_map[parts[1].strip()] = opt_val
                                proxy._live_treasury_options = live_treasury_map
                                proxy.log(f"📋 [Worker {worker_id}] Cached {len(live_treasury_map)} live treasury dropdown values.")
                    except Exception as parse_err:
                        proxy.log(f"⚠️ [Worker {worker_id}] Treasury option extraction: {parse_err}")
                
                if not warmup_ok:
                    proxy.log(f"🔴 [Worker {worker_id}] Session expired. Emitting re-authentication request...")
                    result_queue.put(('pol_session_expired', None))
                    http_session = None
                    # Do not fall back to browser mode; wait for session refresh
                    time.sleep(5)
                    continue
                
            # Recycle browser session if Playwright is active
            if not use_browserless and page and downloads_since_last_restart >= 20:
                proxy.log("Recycling browser session to release leaked memory...")
                try:
                    page.close()
                    context.close()
                except: pass
                time.sleep(5)
                context_args = get_stealth_context_args_for_worker(config_dict, {
                    "storage_state": state_file if os.path.exists(state_file) else None
                })
                context = browser.new_context(**context_args)
                page = context.new_page()
                # Set default action timeout scaled dynamically based on concurrent workers count (capped at 90s)
                act_timeout = min(90000, max(60000, int(60000 * config_dict.get("timeout_multiplier", 1.0))))
                page.set_default_timeout(act_timeout)
                configure_page_stealth_and_metrics(page, lambda: result_queue)
                downloads_since_last_restart = 0
                
            # Adaptive Jitter
            if use_browserless:
                time.sleep(random.uniform(0.3, 1.0) * delay_multiplier)
            else:
                time.sleep(random.uniform(1.0, 3.0) * delay_multiplier)
            
            # Executing download task (3 attempts)
            success = False
            worker_attempts = 0
            
            while worker_attempts < 3 and not success and not proxy.stop_requested:
                while (pause_event.is_set() or (wp_event and wp_event.is_set())) and not proxy.stop_requested:
                    time.sleep(1)
                if proxy.stop_requested: break
                
                worker_attempts += 1
                
                if use_browserless:
                    try:
                        is_voucher_task = (mode in ("voucher", "voucher_search")) or ("voucher" in task_data or "voucher_no" in task_data)
                        if is_voucher_task:
                            from automation.scrapers.voucher_http import _direct_http_download_voucher
                            http_success, http_skipped, http_err = _direct_http_download_voucher(
                                proxy, task_data, http_session, worker_id
                            )
                            if http_success:
                                downloads_since_last_restart += 1
                                key = f"{task_data.get('treasury', '')}_{task_data.get('voucher', '')}"
                                if not http_skipped:
                                    result_queue.put(('task_result', True, task_data))
                                else:
                                    result_queue.put(('task_skip', task_data))
                                success = True
                            else:
                                if worker_attempts < 3:
                                    sleep_sec = worker_attempts * 3
                                    proxy.log(f"⚠️ [Worker {worker_id}] (HTTP) Attempt {worker_attempts}/3 failed: {http_err}. Pausing {sleep_sec}s for connection recovery before retry...")
                                    time.sleep(sleep_sec)
                                else:
                                    result_queue.put(('task_result', False, task_data))
                                    success = True
                        else:
                            from automation.scrapers.pol_scraper import _direct_http_download_ddo
                            http_success, http_skipped, http_err = _direct_http_download_ddo(
                                proxy, task_data, http_session, {}, worker_id
                            )
                            if http_success:
                                downloads_since_last_restart += 1
                                key = f"{task_data.get('clean_treasury', '')}_{task_data.get('ddo_name', '')}_{task_data.get('month_year', '')}"
                                if not http_skipped:
                                    result_queue.put(('pol_success', task_data, key))
                                else:
                                    result_queue.put(('pol_skip', task_data, key))
                                success = True
                            else:
                                if "session expired" in str(http_err).lower():
                                    raise SessionExpiredError(f"HTTP worker {worker_id} session expired")
                                if worker_attempts < 3:
                                    sleep_sec = worker_attempts * 3
                                    proxy.log(f"⚠️ [Worker {worker_id}] (HTTP) Attempt {worker_attempts}/3 failed: {http_err}. Pausing {sleep_sec}s for connection recovery before retry...")
                                    time.sleep(sleep_sec)
                                else:
                                    result_queue.put(('pol_fail', task_data))
                                    success = True
                    except SessionExpiredError:
                        proxy.log(f"🔴 [Worker {worker_id}] (HTTP) Session expired. Pausing worker for re-authentication...")
                        result_queue.put(('pol_session_expired', task_data))
                        pause_event.wait()
                        # Refresh cookies
                        cookies_list = []
                        try:
                            if os.path.exists(state_file):
                                with open(state_file, "r") as f:
                                    cookies_list = json.load(f).get("cookies", [])
                        except: pass
                        http_session.cookies.clear()
                        for c in cookies_list:
                            http_session.cookies.set(c['name'], c['value'], domain=c['domain'], path=c['path'])
                        worker_attempts = 0
                    except Exception as hex_err:
                        proxy.log(f"⚠️ [Worker {worker_id}] (HTTP) Unexpected error: {hex_err}. Retrying...")
                        if worker_attempts >= 3:
                            proxy.log(f"⚠️ [Worker {worker_id}] Browserless HTTP failed. Falling back to browser-based Playwright...")
                            use_browserless = False
                            # Fallback immediately
                            break
                        time.sleep(2 ** worker_attempts)
                else:
                    # Playwright fallback execution path
                    if not page:
                        proxy.log(f"👷 [Worker {worker_id}] Initializing browser fallback...")
                        try:
                            pw = sync_playwright().start()
                            browser_name = "chromium" if use_chrome else "firefox"
                            headless_state = not config_dict.get("show_workers", False)
                            if config_dict.get("headful_monitor", False):
                                headless_state = True
                            kwargs = {"headless": headless_state}
                            if not use_chrome:
                                kwargs["firefox_user_prefs"] = {
                                    "network.trr.mode": 5,
                                    "network.dns.disableIPv6": True,
                                    "widget.windows.window_occlusion_tracking.enabled": False,
                                    "dom.min_background_timeout_value": 10000,
                                    "privacy.reduceTimerPrecision": False,
                                    "network.proxy.type": 5,
                                    "network.proxy.no_proxies_on": "localhost, 127.0.0.1, .mptreasury.gov.in, mptreasury.gov.in"
                                }
                            else:
                                kwargs["args"] = [
                                    "--start-maximized",
                                    "--disable-backgrounding-occluded-windows",
                                    "--disable-background-timer-throttling",
                                    "--disable-renderer-backgrounding",
                                    "--disable-background-networking"
                                ]
                                if headless_state:
                                    kwargs["args"].extend(["--window-position=-2400,-2400", "--window-size=10,10"])
                            
                            cdp_url = config_dict.get("cdp_url")
                            if cdp_url:
                                try:
                                    browser = pw.chromium.connect_over_cdp(cdp_url)
                                    proxy.log(f"👷 Connected to shared background CDP browser.")
                                except Exception as ce:
                                    proxy.log(f"⚠️ Failed to connect over CDP: {ce}. Falling back to launching separate browser...")
                                    browser = None
                                    
                            if not browser:
                                launcher = getattr(pw, browser_name)
                                browser = launcher.launch(**kwargs)
                        except Exception as b_err:
                            proxy.log(f"❌ [Worker {worker_id}] Failed to launch browser fallback: {b_err}")
                            if not browser:
                                launcher = getattr(pw, browser_name)
                                browser = launcher.launch(headless=headless_state)
                                
                        context_args = get_stealth_context_args_for_worker(config_dict, {
                            "storage_state": state_file if os.path.exists(state_file) else None
                        })
                        context = browser.new_context(**context_args)
                        page = context.new_page()
                        configure_page_stealth_and_metrics(page, lambda: result_queue)
                        
                    try:
                        def check_response(response):
                            nonlocal delay_multiplier
                            if response.status in [429, 503]:
                                proxy.log(f"⚠️ Received HTTP {response.status} rate-limiting. Throttling wait delays...")
                                delay_multiplier = min(delay_multiplier * 1.5, 5.0)
                                result_queue.put(('auto_throttle',))
                                
                        page.on("response", check_response)
                        task_success = process_single_ddo_task(proxy, page, task_data, worker_id)
                        page.remove_listener("response", check_response)
                        
                        if task_success:
                            downloads_since_last_restart += 1
                            key = f"{task_data['clean_treasury']}_{task_data['ddo_name']}_{task_data['month_year']}"
                            result_queue.put(('pol_success', task_data, key))
                        else:
                            if worker_attempts < 3:
                                proxy.log(f"⚠️ [Worker {worker_id}] DDO task failed, retrying from scratch (attempt {worker_attempts}/3)...")
                                try:
                                    page.close()
                                    context.close()
                                except: pass
                                browser = _ensure_browser_alive(browser, pw, cdp_url, browser_name, kwargs, proxy, worker_id)
                                context_args = get_stealth_context_args_for_worker(config_dict, {"storage_state": state_file if os.path.exists(state_file) else None})
                                context = browser.new_context(**context_args)
                                page = context.new_page()
                                # Apply automatic timeout scaling for retry attempts
                                scaled_timeout = int(act_timeout * (1.5 ** worker_attempts))
                                page.set_default_timeout(scaled_timeout)
                                proxy.log(f"⚠️ [Worker {worker_id}] Scaling default timeout to {scaled_timeout // 1000}s for retry...")
                                configure_page_stealth_and_metrics(page, lambda: result_queue)
                                continue
                            result_queue.put(('pol_fail', task_data))
                        success = True
                    except SessionExpiredError:
                        proxy.log(f"🔴 [Worker {worker_id}] Session expired. Pausing worker and notifying parent...")
                        result_queue.put(('pol_session_expired', task_data))
                        pause_event.wait()
                        try:
                            page.close()
                            context.close()
                        except: pass
                        context_args = get_stealth_context_args_for_worker(config_dict, {
                            "storage_state": state_file if os.path.exists(state_file) else None
                        })
                        context = browser.new_context(**context_args)
                        page = context.new_page()
                        page.set_default_timeout(act_timeout)
                        configure_page_stealth_and_metrics(page, lambda: result_queue)
                        worker_attempts = 0
                    except BrowserConnectionDeadError as bcd:
                        proxy.log(f"❌ [Worker {worker_id}] Browser connection dead: {bcd}. Reconnecting context...")
                        try:
                            if not browser or not browser.is_connected():
                                if cdp_url:
                                    browser = pw.chromium.connect_over_cdp(cdp_url)
                        except Exception:
                            browser = None

                        if not browser or not browser.is_connected():
                            try:
                                launcher = getattr(pw, browser_name)
                                browser = launcher.launch(**kwargs)
                            except Exception as le:
                                proxy.log(f"⚠️ [Worker {worker_id}] Failed to launch local fallback browser: {le}")
                                browser = None

                        try:
                            page.close()
                        except: pass
                        try:
                            context.close()
                        except: pass

                        if browser:
                            context_args = get_stealth_context_args_for_worker(config_dict, {
                                "storage_state": state_file if os.path.exists(state_file) else None
                            })
                            context = browser.new_context(**context_args)
                            page = context.new_page()
                            scaled_timeout = int(act_timeout * (1.5 ** worker_attempts))
                            page.set_default_timeout(scaled_timeout)
                            configure_page_stealth_and_metrics(page, lambda: result_queue)
                        else:
                            raise Exception("Failed to reconnect browser context or launch fallback local browser.")
                    except Exception as e:
                        from automation.scrapers.voucher_scraper import is_browser_connection_dead
                        is_dead = is_browser_connection_dead(e)
                        if is_dead:
                            proxy.log(f"❌ [Worker {worker_id}] Connection dead detected in general handler: {e}. Reconnecting browser...")
                            try:
                                if not browser or not browser.is_connected():
                                    if cdp_url:
                                        browser = pw.chromium.connect_over_cdp(cdp_url)
                            except Exception:
                                browser = None
                            
                            if not browser or not browser.is_connected():
                                try:
                                    launcher = getattr(pw, browser_name)
                                    browser = launcher.launch(**kwargs)
                                except Exception as le:
                                    proxy.log(f"⚠️ [Worker {worker_id}] Failed to launch local fallback browser: {le}")
                                    browser = None

                        if worker_attempts < 3:
                            proxy.log(f"⚠️ [Worker {worker_id}] Attempt {worker_attempts}/3 failed: {e}. Retrying...")
                            try:
                                page.close()
                            except: pass
                            try:
                                context.close()
                            except: pass
                            
                            if browser:
                                context_args = get_stealth_context_args_for_worker(config_dict, {
                                    "storage_state": state_file if os.path.exists(state_file) else None
                                })
                                context = browser.new_context(**context_args)
                                page = context.new_page()
                                scaled_timeout = int(act_timeout * (1.5 ** worker_attempts))
                                page.set_default_timeout(scaled_timeout)
                                proxy.log(f"⚠️ [Worker {worker_id}] Scaling default timeout to {scaled_timeout // 1000}s for retry...")
                                configure_page_stealth_and_metrics(page, lambda: result_queue)
                                time.sleep(2 ** worker_attempts)
                            else:
                                raise Exception("Browser is dead and failed to recreate context.")
                        else:
                            result_queue.put(('pol_fail', task_data))
                            success = True
    except Exception as ex:
        result_queue.put(('log', f"POL Worker process crash: {ex}", "error"))
    finally:
        try:
            if page: page.close()
            if context: context.close()
            if browser: browser.close()
            if pw: pw.stop()
        except Exception: pass

def _launch_browser_with_failover_headless(self, pw_instance, use_chrome):
    browser_name = "chromium" if use_chrome else "firefox"
    headless_state = True
    if hasattr(self, "var_show_workers") and self.var_show_workers.get():
        headless_state = False
        
    kwargs = {"headless": headless_state}
    if not use_chrome:
        kwargs["firefox_user_prefs"] = {
            "network.trr.mode": 5,
            "network.dns.disableIPv6": True,
            "widget.windows.window_occlusion_tracking.enabled": False,
            "dom.min_background_timeout_value": 10000,
            "privacy.reduceTimerPrecision": False,
            "network.proxy.type": 5,
            "network.proxy.no_proxies_on": "localhost, 127.0.0.1, .mptreasury.gov.in, mptreasury.gov.in"
        }
    if use_chrome:
        kwargs["args"] = [
            "--start-maximized",
            "--disable-backgrounding-occluded-windows",
            "--disable-background-timer-throttling",
            "--disable-renderer-backgrounding",
            "--disable-background-networking"
        ]
# Use bundled Playwright Chromium
    try:
        launcher = getattr(pw_instance, browser_name)
        browser = launcher.launch(**kwargs)
        return browser, browser_name
    except Exception as e:
        try:
            launcher = getattr(pw_instance, browser_name)
            return launcher.launch(headless=headless_state), browser_name
        except Exception:
            raise e

def _run_automation_task(self, mode, run_failed):
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001 | 0x00000002)
        except Exception: pass

    try:
        asyncio.set_event_loop(None)
    except Exception:
        pass
    
    # OS Toast notification & Sound Alert on batch run starts
    self.show_notification("Batch Started", f"Centralized Voucher Validation Suite {mode.upper()} batch processing initiated.")
    self.play_sound("asterisk")

    try:
        try:
            from core.security import get_machine_id
            from core.constants import RUN_ID, TOOL_VERSION
            from core.telemetry import send_silent_log
            start_payload = {
                "run_id": RUN_ID,
                "tool_version": TOOL_VERSION,
                "event": "run_start",
                "mode": mode.upper(),
                "operator": self.operator_name,
                "hwid": get_machine_id(),
                "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            if getattr(self, 'var_telemetry_enabled', None) and self.var_telemetry_enabled.get():
                threading.Thread(
                    target=send_silent_log,
                    args=(self.operator_name, json.dumps(start_payload)),
                    daemon=True
                ).start()
        except Exception: pass

        username = self.entry_user.text().strip() if hasattr(self.entry_user, "text") else str(self.entry_user.get()).strip()
        password = self.entry_pass.text().strip() if hasattr(self.entry_pass, "text") else str(self.entry_pass.get()).strip()

        if mode == "vlc":
            if self.var_dryrun.get():
                self._run_dry_mode_vlc(run_failed)
            else:
                self._run_vlc_live_mode(username, password, run_failed)
        elif mode == "pol":
            if getattr(self, "pol_run_from_excel", False):
                if run_failed:
                    excel_rows = self.load_failed_pol_rows()
                else:
                    path = self.pol_excel_file_path
                    sheet = self.pol_selected_sheet
                    excel_rows = self.parse_pol_excel_sheet(path, sheet)
                
                if not excel_rows:
                    self.log("❌ No valid rows found in selected POL Excel worksheet.")
                    return
                    
                if self.var_dryrun.get():
                    self._run_dry_mode_pol_excel(excel_rows)
                else:
                    self._run_pol_excel_mode(username, password, run_failed, excel_rows=excel_rows)
            else:
                target_ddos = getattr(self, "pol_selected_ddos", [])
                if not target_ddos and not run_failed:
                    self.log("❌ No DDOs selected.")
                    return
                
                if self.var_dryrun.get():
                    self._run_dry_mode_pol(target_ddos, run_failed)
                else:
                    self._run_pol_live_mode(username, password, target_ddos, run_failed)
        elif mode == "payroll":
            params = getattr(self, "payroll_params", {})
            if not params:
                self.log("❌ No Payroll parameters found.")
                return
            
            months_to_process = params.get("months_to_process", [])
            treasury = params.get("treasury", "")
            dept = params.get("dept", "")
            mhcd = params.get("mhcd", "")
            gpf_idx = params.get("gpf_idx", 1)
            
            failed_file = self.voucher_failed_file
            if not run_failed:
                try:
                    with open(failed_file, "w", encoding="utf-8") as f:
                        f.write(f"# Failed PAYROLL Vouchers - Started {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                        f.write("# Format: S.No|MH|Treasury|Voucher|Amount|Month|Year\n")
                except Exception: pass

            if self.var_dryrun.get():
                self._run_dry_mode_payroll(months_to_process, treasury, dept, mhcd)
            else:
                self._run_live_mode_payroll(username, password, months_to_process, treasury, dept, mhcd, gpf_idx)
        elif mode == "treasury":
            report_type = self.opt_treasury_report_type.currentText() if hasattr(self, 'opt_treasury_report_type') else "Schedule of Receipt"
            from_date = self.entry_treasury_from.text().strip() if hasattr(self, 'entry_treasury_from') else ""
            to_date = self.entry_treasury_to.text().strip() if hasattr(self, 'entry_treasury_to') else ""
            year = self.opt_treasury_year.currentText().strip() if hasattr(self, 'opt_treasury_year') else ""
            month = self.opt_treasury_month.currentText().strip() if hasattr(self, 'opt_treasury_month') else ""
            
            selected_treasuries = []
            if hasattr(self, "treasury_combo") and hasattr(self.treasury_combo, "checkedItems"):
                selected_treasuries = self.treasury_combo.checkedItems()

            major_items = []
            if hasattr(self, "major_head_checkboxes"):
                major_items = [text for text, cb in self.major_head_checkboxes.items() if cb.isChecked()]
            
            from automation.scrapers.treasury_runner import run_treasury_downloader_batch
            run_treasury_downloader_batch(
                app=self,
                report_type=report_type,
                selected_treasuries=selected_treasuries,
                from_date=from_date,
                to_date=to_date,
                year=year,
                month=month,
                major_items=major_items,
                run_failed=run_failed
            )
        elif mode == "tally":
            path = getattr(self, "tally_excel_file_path", None) or getattr(self, "voucher_excel_file_path", None)
            sheet = getattr(self, "tally_selected_sheet", "") or getattr(self, "voucher_selected_sheet", "")
            if not path or not os.path.exists(path):
                self.log("❌ Please select a valid Voucher Excel spreadsheet for Tally verification.")
                return

            raw_rows = self.parse_excel_sheet(path, sheet, True)
            if not raw_rows:
                self.log("❌ No valid rows found in selected worksheet database.")
                return

            # Group multiple beneficiary rows for the same voucher & sum their Amount_Paid entries
            grouped_vouchers = {}
            voucher_order = []
            for r in raw_rows:
                vou = str(r.get("voucher", "")).strip()
                mh = str(r.get("mh", "")).strip()
                treasury = str(r.get("treasury", "")).strip()
                month = str(r.get("month", "")).strip()
                year = str(r.get("year", "")).strip()
                v_key = (vou, mh, treasury, month, year) if (vou or mh or treasury) else id(r)


                from automation.scrapers.voucher_scraper import extract_row_amount
                amt_val = extract_row_amount(r)

                if v_key not in grouped_vouchers:
                    m_row = dict(r)
                    m_row["amount"] = amt_val
                    m_row["payee_count"] = 1
                    grouped_vouchers[v_key] = m_row
                    voucher_order.append(v_key)
                else:
                    grouped_vouchers[v_key]["amount"] += amt_val
                    grouped_vouchers[v_key]["payee_count"] += 1

            excel_rows = [grouped_vouchers[k] for k in voucher_order]

            output_dir = getattr(self, "get_tally_output_dir", lambda: None)() or getattr(self, "tally_output_dir", None)
            if not output_dir and hasattr(self, "entry_tally_output") and self.entry_tally_output:
                try: output_dir = self.entry_tally_output.text().strip()
                except Exception: pass
            if not output_dir:
                output_dir = os.path.join(self.download_dir, "Tally_Results")
            output_dir = os.path.normpath(output_dir)
            os.makedirs(output_dir, exist_ok=True)
            headers = list(raw_rows[0].keys())

            from tally_excel_writer import TallyExcelWriter
            self.tally_writer = TallyExcelWriter(original_headers=headers, output_dir=output_dir)

            total_items = len(excel_rows)
            self.log(f"📊 Launching Voucher Total Tally Verification ({len(raw_rows)} rows grouped into {total_items} unique vouchers)...")
            self._run_excel_live_mode(username, password, excel_rows, total_items, mode)

            if hasattr(self, "tally_writer") and self.tally_writer:
                green_path, red_path = self.tally_writer.save()
                self.log("─────────────────────────────────────────────────────────────")
                self.log("📊 TALLY EXECUTION COMPLETE SUMMARY:")
                self.log(f"  🟢 Matched Vouchers: {self.tally_writer.green_count}")
                self.log(f"  🔴 Mismatched Vouchers: {self.tally_writer.red_count}")
                self.log(f"  📂 Matched Excel: {green_path}")
                self.log(f"  📂 Mismatched Excel: {red_path}")
        else:
            if run_failed:
                excel_rows = self.load_failed_vouchers(mode)
            else:
                path = self.voucher_excel_file_path if mode == "voucher" else self.paybill_excel_file_path
                sheet = self.voucher_selected_sheet if mode == "voucher" else self.paybill_selected_sheet
                audit_mode = self.var_voucher_sno.get() if mode == "voucher" else self.var_paybill_sno.get()
                excel_rows = self.parse_excel_sheet(path, sheet, audit_mode)

            if not excel_rows:
                self.log("❌ No valid rows found in selected worksheet database.")
                return

            # SUMIF Voucher Aggregation: Group multiple payee/beneficiary rows for the same voucher and sum their amounts
            if mode in ("voucher", "tally", "voucher_search") and excel_rows:
                from automation.scrapers.voucher_scraper import extract_row_amount
                grouped_vouchers = {}
                voucher_order = []
                for r in excel_rows:
                    vou = str(r.get("voucher", "")).strip().lstrip("0")
                    mh = str(r.get("mh", "")).strip().lstrip("0")
                    treasury = str(r.get("treasury", "")).strip().lstrip("0")
                    month = str(r.get("month", "")).strip()
                    year = str(r.get("year", "")).strip()
                    v_key = (vou, mh, treasury, month, year) if (vou and mh and treasury) else id(r)

                    amt_val = extract_row_amount(r)

                    if v_key not in grouped_vouchers:
                        m_row = dict(r)
                        m_row["amount"] = round(amt_val, 2)
                        m_row["payee_count"] = 1
                        grouped_vouchers[v_key] = m_row
                        voucher_order.append(v_key)
                    else:
                        grouped_vouchers[v_key]["amount"] = round(grouped_vouchers[v_key]["amount"] + amt_val, 2)
                        grouped_vouchers[v_key]["payee_count"] += 1

                grouped_rows = [grouped_vouchers[k] for k in voucher_order]
                if len(grouped_rows) < len(excel_rows):
                    self.log(f"📊 SUMIF Voucher Aggregation: {len(excel_rows)} payee rows grouped into {len(grouped_rows)} unique vouchers with combined totals.")
                excel_rows = grouped_rows

            total_items = len(excel_rows)

            failed_file = self.voucher_failed_file if mode in ("voucher", "voucher_search") else self.paybill_failed_file
            if not run_failed:
                try:
                    with open(failed_file, "w", encoding="utf-8") as f:
                        f.write(f"# Failed {mode.upper()} Vouchers - Started {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                        f.write("# Format: S.No|MH|Treasury|Voucher|Amount|Month|Year\n")
                except Exception: pass

            if self.var_dryrun.get():
                self._run_dry_mode_excel(excel_rows, total_items, mode)
            else:
                self._run_excel_live_mode(username, password, excel_rows, total_items, mode)

        if not self.post_process_done:
            self._post_process(mode)

        # OS Toast notification & Sound Alert on batch run success
        self.show_notification("Batch Complete", f"Centralized Voucher Validation Suite {mode.upper()} batch processing completed.")
        self.play_sound("question")

    except Exception as e:
        self.play_sound("hand")
        if self.stop_requested:
            self.log("🛑 Run aborted: Stop safety triggered by user.")
            self._log_run_failure(mode, "USER_ABORT", "Run aborted: Stop safety triggered by user.")
        else:
            self.log(f"❌ FATAL EXCEPTION: {e}")
            try:
                with open(self.run_log_file, "a", encoding="utf-8") as f:
                    f.write(traceback.format_exc())
            except Exception: pass
            self._log_run_failure(mode, "FATAL_EXCEPTION", str(e))
    finally:
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001 | 0x00000002)
            except Exception: pass
        self.safe_after(0, lambda: self.set_ui_lock_state(is_locked=False))

def _run_excel_live_mode(self, username, password, excel_rows, total_items, mode):
    result_queue = None
    use_chrome = (mode in ("voucher", "voucher_search")) or self.var_browser.get().startswith("Google Chrome")
    is_parallel_enabled = getattr(self, "var_parallel", None) and self.var_parallel.get()
    workers_count = getattr(self, "var_parallel_workers", None) and self.var_parallel_workers.get() or 1
    
    # State Checkpointing & Session Auto-Resume
    run_state = load_run_state(self.operator_name, self.base_path)
    completed_keys = set(run_state.get("completed", []))
    db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
    
    self.current_run_keys = set()
    filtered_rows = []
    skipped_count_run = 0
    seen_keys_in_run = set()
    
    from database.db_manager import is_voucher_downloaded
    from parsers.excel_mapper import resolve_treasury_code
    
    for row in excel_rows:
        t_raw = str(row.get('treasury', '')).strip()
        t_code = resolve_treasury_code(t_raw, self.TREASURY_MAP, self.TREASURY_IDS)
        mh = str(row.get('mh', '')).strip()
        month = str(row.get('month', '')).strip()
        year = str(row.get('year', '')).strip()
        voucher = str(row.get('voucher', '')).strip()
        
        # Deduplication key (independent of row serial numbers/prefixes)
        def _clean_k(val):
            s = str(val).strip()
            if s.startswith('="') and s.endswith('"'): return s[2:-1].strip()
            elif s.startswith('='): return s[1:].strip().strip('"')
            return s
        t_clean = _clean_k(t_code)
        mh_clean = _clean_k(mh)
        m_clean = _clean_k(month)
        y_clean = _clean_k(year)
        v_clean = _clean_k(voucher)
        key = f"{t_clean}_{mh_clean}_{m_clean}_{y_clean}_{v_clean}"
        self.current_run_keys.add(key)
        
        if key in seen_keys_in_run:
            # Skip duplicates found inside the same incoming Excel spreadsheet
            skipped_count_run += 1
            continue
            
        target_dir = self.resolve_download_path(row, "Voucher" if mode in ("voucher", "voucher_search") else "Paybill")
        marker_file = os.path.join(target_dir, "SUCCESS.marker")
        
        # Perform historical check against local directory marker file OR SQLite database record
        has_db_download = False
        if mode in ("voucher", "voucher_search", "payroll"):
            if os.path.exists(target_dir):
                has_db_download = is_voucher_downloaded(db_path, t_code, mh, month, year, voucher)
            
        if key in completed_keys or os.path.exists(marker_file) or has_db_download:
            skipped_count_run += 1
            if getattr(self, "var_scan_existing_vouchers", None) and self.var_scan_existing_vouchers.get():
                try:
                    v_no = str(row.get("voucher", ""))
                    trs = str(row.get("treasury", ""))
                    mh_val = str(row.get("mh", ""))
                    m_val = str(row.get("month", ""))
                    y_val = str(row.get("year", ""))
                    amt_val = str(row.get("amount", ""))

                    # 1. Fast SQLite Cache Check (< 1ms)
                    cached_results = get_cached_audit_results(db_path, trs, mh_val, m_val, y_val, v_no)
                    if cached_results:
                        for cres in cached_results:
                            if hasattr(self, "result_queue") and self.result_queue:
                                self.result_queue.put(("task_audit_finding", cres))
                    else:
                        # 2. Only run disk PDF audit if Show_MPTC.pdf exists
                        mptc_pdf_path = os.path.join(target_dir, "Show_MPTC.pdf")
                        if os.path.exists(mptc_pdf_path):
                            voucher_data_dict = {
                                "voucher_no": v_no,
                                "treasury": trs,
                                "mh": mh_val,
                                "month": m_val,
                                "year": y_val,
                                "amount": amt_val,
                                "ddo": str(row.get("ddo", ""))
                            }
                            if hasattr(self, "trigger_realtime_checks"):
                                fresh_results = self.trigger_realtime_checks(voucher_data_dict, target_dir)
                                if fresh_results:
                                    save_audit_results_batch(db_path, fresh_results)
                except Exception as scan_err:
                    self.log(f"⚠️ Pre-scan audit notice for existing voucher #{row.get('voucher')}: {scan_err}")
        else:
            filtered_rows.append(row)
            seen_keys_in_run.add(key)
            
    if skipped_count_run > 0:
        self.log(f"⏭️ Skipping {skipped_count_run} already completed items (Session Auto-Resume).")
        with self._counter_lock:
            self.skip_count += skipped_count_run
            
    excel_rows = filtered_rows
    total_items = len(excel_rows)
    with self._counter_lock:
        self.stats_total = total_items + skipped_count_run
        self.update_stats()
    
    if not excel_rows:
        self.log("✨ All items for this run are already completed (Session Auto-Resume).")
        self._post_process(mode)
        self.post_process_done = True
        return

    reuse_session = False
    if self.browser and self.browser_context and self.browser_page:
        active_is_chrome = "chromium" in self.browser.__class__.__name__.lower()
        if active_is_chrome == use_chrome:
            try:
                if not self.browser_page.is_closed() and self._is_logged_in(self.browser_page):
                    self.log("🔄 Active authenticated session detected in currently open browser. Bypassing login!")
                    reuse_session = True
            except Exception: pass

    if is_parallel_enabled and workers_count > 1:
        # === PARALLEL SUBPROCESS WORKERS WORKFLOW ===
        if not reuse_session:
            self.safe_logout_and_close(self.browser_page, silent=True)
            self.log(f"🌐 Launching Playwright browser interface for Login sequence...")
            if not self.playwright:
                self.playwright = sync_playwright().start()

            try:
                browser, self.browser_used = self._launch_browser_with_failover(use_chrome)
                # Force browser window to foreground for user CAPTCHA/OTP entries
                self.bring_browser_to_front()
            except Exception as e:
                self.log(f"❌ Critical Error: {e}")
                return

            state_file_path = os.path.join(self.base_path, "browser_state.json")
            valid_state = self._get_valid_storage_state(state_file_path)
                    
            context_args = {"accept_downloads": True}
            if use_chrome:
                context_args["no_viewport"] = True
            if valid_state:
                context_args["storage_state"] = valid_state
            context_args = self.get_stealth_context_args(context_args)
            context = browser.new_context(**context_args)
            page = context.new_page()
            configure_page_stealth_and_metrics(page, lambda: result_queue)

            self.browser = browser
            self.browser_context = context
            self.browser_page = page

            try:
                logged_in_page = self._perform_portal_login(page, context, username, password)
                if not logged_in_page:
                    if self.stop_requested:
                        self.log("🛑 Keeping the browser open and the active session intact on Stop command.")
                    else:
                        self._cleanup_browser_session()
                    return
                page = logged_in_page
                self.browser_page = page
            except Exception as e:
                self.log(f"❌ Login Error: {e}")
                if self.stop_requested:
                    self.log("🛑 Keeping the browser open and the active session intact on Stop command.")
                else:
                    self._cleanup_browser_session()
                return
        else:
            page = self.browser_page
            context = self.browser_context
            try:
                self.log("🔄 Resetting browser page to home dashboard...")
                page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag", timeout=25000, wait_until="domcontentloaded")
            except Exception as e:
                self.log(f"⚠️ Warning: Failed to reset to dashboard: {e}")

        state_file = os.path.join(self.base_path, "session_state.json")
        try:
            if self.var_direct_dashboard.get():
                self.log("ℹ️ Direct Dashboard Mode: Bypassing OTP wait loop. Establishing session on report page...")
                try:
                    page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", wait_until="domcontentloaded", timeout=45000)
                except Exception as ne:
                    self.log(f"⚠️ Direct Dashboard navigation warning: {ne}")
            else:
                if self._is_on_otp_page(page) or not self._is_logged_in(page) or "getuseridforotp" in page.url.lower():
                    self.log("⏳ Awaiting OTP completion on main page before spawning workers...")
                    while self._is_on_otp_page(page) or not self._is_logged_in(page) or "getuseridforotp" in page.url.lower():
                        if self.stop_requested: return
                        time.sleep(1)
                    self.log("🔓 Login detected on main page! Proceeding to capture session...")

            try:
                self.main_user_agent = page.evaluate("navigator.userAgent")
            except Exception:
                self.main_user_agent = None

            context.storage_state(path=state_file)
            self.log("✅ Session storage state captured. Spawning parallel workers...")


            
            # Setup network request listener on Worker 1's browser page
            captured_voucher_request = {}
            voucher_template_path = os.path.normpath(os.path.join(os.path.dirname(db_path), "voucher_request_template.json"))
            
            def capture_voucher_request(req):
                try:
                    req_url = req.url
                    if "rnd-toApprovedBillsTreasuryWise" in req_url:
                        captured_voucher_request["url"] = req_url
                        captured_voucher_request["method"] = req.method
                        captured_voucher_request["headers"] = req.headers
                        captured_voucher_request["post_data"] = req.post_data or ""
                        with open(voucher_template_path, "w", encoding="utf-8") as tf:
                            json.dump(captured_voucher_request, tf, indent=4)
                except Exception:
                    pass

            if page:
                page.on("request", capture_voucher_request)

            # Bring main Python GUI tool directly to the foreground
            self.bring_to_front()
            
            # Control main browser window visibility based on Hybrid/Stealth mode & settings
            if hasattr(self, "var_stealth") and self.var_stealth.get():
                self.set_browser_visibility(False)
                self.log("🕵️ Hybrid Stealth Mode active: Hiding browser window during downloading.")
            elif mode == "tally" or (self.var_headful_monitor.get() if hasattr(self, "var_headful_monitor") else False) or self.var_show_workers.get():
                self.set_browser_visibility(True)
                if mode == "tally":
                    self.log("👁️ Voucher Tally Mode: Main browser window kept visible for verification.")
                else:
                    self.log("👷 Keeping Worker 1 (Main Window) visible.")
            else:
                self.set_browser_visibility(False)
                self.log("👷 Headless Parallel Mode: Hiding Worker 1 (Main Window) in background.")

            # F1: Disk space pre-check
            from automation.network_monitor import check_disk_space, check_disk_space_periodic, CircuitBreaker
            disk_ok, disk_msg = check_disk_space(self.download_dir, total_items)
            self.log(disk_msg)
            if not disk_ok:
                self.log("🛑 Aborting batch due to insufficient disk space.")
                self._cleanup_browser_session()
                return

            # F2: Circuit breaker
            circuit_breaker = CircuitBreaker(threshold=10, cooldown_seconds=300, log_fn=self.log)
            self.circuit_breaker = circuit_breaker

            # E1: Progress tracker
            progress_tracker = ProgressTracker(total_items)
            self.progress_tracker = progress_tracker

            # A3: Worker heartbeat tracking & F1 periodic check variables
            worker_heartbeat = {}
            self.worker_heartbeat = worker_heartbeat
            items_since_disk_check = 0

            task_queue = multiprocessing.Queue()
            for idx, row in enumerate(excel_rows):
                task_queue.put((idx + 1, row))

            result_queue = multiprocessing.Queue()
            self.stop_event = multiprocessing.Event()
            pause_event = multiprocessing.Event()
            self.active_pause_event = pause_event
            self.concurrency_tuner = ConcurrencyAutoTuner(workers_count, self.log)
            self.worker_pause_events = {}
            
            # Calculate dynamic timeout scaling multiplier based on parallel workers
            # Multiplier starts at 1.0, increases by 0.25 for every worker beyond the first
            timeout_multiplier = 1.0 + max(0, workers_count - 1) * 0.25
            if workers_count > 1:
                self.log(f"⚡ Dynamic timeout scaling applied: Multiplied timeouts by {timeout_multiplier:.2f}x to compensate for {workers_count} parallel workers.")
                
            # Launch shared background CDP browser if parallel mode is active
            cdp_url = None
            if workers_count > 1:
                try:
                    cdp_url = self.launch_shared_cdp_browser(use_chrome)
                except Exception as ex:
                    self.log(f"⚠️ Failed to launch shared CDP browser: {ex}")

            # Prepare configuration dict to pass to workers
            config_dict = {
                "mode": mode,
                "stealth_mode": self.var_stealth.get(),
                "batch_subfolder": self.var_batch_subfolder.get().strip() if hasattr(self, "var_batch_subfolder") else "",
                "download_dir": self.download_dir,
                "db_path": db_path,
                "cdp_url": cdp_url,
                "path_template": self.var_path_template.get(),
                "audio_alerts": self.var_audio_alerts.get(),
                "os_notifications": self.var_os_notifications.get(),
                "download_paybills_in_vouchers": self.var_voucher_download_paybills.get(),
                "paybill_only": self.var_paybill_only.get(),
                "timeout_multiplier": timeout_multiplier,
                "timeout_pdf": int(self.var_timeout_pdf.get() * 1000 * timeout_multiplier),
                "timeout_attachment": int(self.var_timeout_attachment.get() * 1000 * timeout_multiplier),
                "timeout_xls": int(self.var_timeout_xls.get() * 1000 * timeout_multiplier),
                "timeout_login": int(self.var_timeout_login.get() * 1000 * timeout_multiplier),
                "treasury_map": self.TREASURY_MAP,
                "treasury_ids": self.TREASURY_IDS,
                "voucher_master_report": self.voucher_master_report,
                "voucher_failed_file": self.voucher_failed_file,
                "paybill_master_report": self.paybill_master_report,
                "paybill_failed_file": self.paybill_failed_file,
                "pol_failed_file": self.pol_failed_file,
                "pandas_available": getattr(self, "PANDAS_AVAILABLE", False),
                "show_workers": self.var_show_workers.get(),
                "headful_monitor": self.var_headful_monitor.get() if hasattr(self, "var_headful_monitor") else False,
                "user_agent": getattr(self, "main_user_agent", None),
                "project_root": os.path.dirname(os.path.abspath(sys.argv[0])) if sys.argv else "",
            }

            failed_rows = []
            session_expired_flag = [False]
            completed_count = [0]
            result_queue_empty_event = threading.Event()
            
            # Log & status receiver thread
            def log_receiver():
                nonlocal items_since_disk_check
                while not result_queue_empty_event.is_set():
                    try:
                        msg = result_queue.get(timeout=0.1)
                        if msg[0] == 'log':
                            self.log(msg[1], msg[2])
                        elif msg[0] == 'stats':
                            self.update_stats(current=msg[1], progress=msg[2])
                        elif msg[0] == 'increment':
                            counter_type, diff = msg[1], msg[2]
                            with self._counter_lock:
                                if counter_type == 'success': self.success_count += diff
                                elif counter_type == 'fail': self.fail_count += diff
                                elif counter_type == 'skip': self.skip_count += diff
                            self.update_stats()
                        elif msg[0] == 'downloaded_folder':
                            folder = msg[1]
                            if folder not in self.downloaded_folders_this_run:
                                self.downloaded_folders_this_run.append(folder)
                        elif msg[0] == 'heartbeat':
                            w_id, ts = msg[1], msg[2]
                            self.worker_heartbeat[w_id] = ts
                        elif msg[0] == 'task_audit_finding':
                            finding = msg[1]
                            try:
                                from gui.tabs_qt.validation_results_tab import add_realtime_result_to_table
                                if hasattr(self, "safe_after"):
                                    self.safe_after(0, lambda r=finding: add_realtime_result_to_table(self, r))
                            except Exception:
                                pass
                            if hasattr(self, "check_registry") and self.check_registry:
                                if hasattr(self.check_registry, "all_findings"):
                                    self.check_registry.all_findings.append(finding)
                        elif msg[0] == 'task_result':
                            success, row_data = msg[1], msg[2]
                            if success:
                                self.circuit_breaker.record_success()
                                self.progress_tracker.record_item(status="success")
                                completed_count[0] += 1
                                current_prog = completed_count[0] / total_items
                                self.update_stats(current=row_data['voucher'], progress=current_prog)
                                # Persistent State Checkpointing
                                if len(msg) > 3:
                                    save_run_state(self.operator_name, self.base_path, msg[3])
                                
                                # Cache download to SQLite DB
                                try:
                                    from database.db_manager import save_download_record
                                    db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
                                    download_dir_resolved = ""
                                    try:
                                        download_dir_resolved = self.resolve_download_path(row_data, "Voucher" if mode == "voucher" else "Paybill")
                                    except Exception: pass
                                    save_download_record(
                                        db_path=db_path,
                                        mode=mode,
                                        treasury=row_data.get('treasury'),
                                        major_head=row_data.get('mh'),
                                        month=row_data.get('month'),
                                        year=row_data.get('year'),
                                        voucher_no=row_data.get('voucher'),
                                        amount=row_data.get('amount'),
                                        ddo_code=row_data.get('ddo'),
                                        file_path=download_dir_resolved
                                    )
                                except Exception as dbe:
                                    self.log(f"⚠️ Failed to cache download in history database: {dbe}")
                            else:
                                tripped = self.circuit_breaker.record_failure()
                                self.progress_tracker.record_item(status="failed")
                                if tripped:
                                    pause_event.set()
                                failed_rows.append(row_data)
                                completed_count[0] += 1
                                
                            # Periodic ETA & disk check
                            if self.progress_tracker.should_log_eta():
                                self.log(self.progress_tracker.get_eta_string())
                                
                            items_since_disk_check += 1
                            if items_since_disk_check >= 100:
                                items_since_disk_check = 0
                                disk_ok, disk_msg = check_disk_space_periodic(self.download_dir)
                                if not disk_ok:
                                    self.log(disk_msg)
                                    pause_event.set()
                        elif msg[0] == 'task_skip':
                            row_data = msg[1]
                            target_dir = msg[3] if len(msg) > 3 else ""
                            completed_count[0] += 1
                            current_prog = completed_count[0] / total_items
                            with self._counter_lock:
                                self.skip_count += 1
                            self.update_stats(current=row_data['voucher'], progress=current_prog)
                            
                            # Live scan pre-existing skipped voucher if scan_existing_vouchers toggle is ON!
                            if getattr(self, "var_scan_existing_vouchers", None) and self.var_scan_existing_vouchers.get():
                                if target_dir and os.path.exists(target_dir):
                                    try:
                                        voucher_data_dict = {
                                            "voucher_no": str(row_data.get("voucher", "")),
                                            "treasury": str(row_data.get("treasury", "")),
                                            "mh": str(row_data.get("mh", "")),
                                            "month": str(row_data.get("month", "")),
                                            "year": str(row_data.get("year", "")),
                                            "amount": str(row_data.get("amount", "")),
                                            "ddo": str(row_data.get("ddo", ""))
                                        }
                                        if hasattr(self, "trigger_realtime_checks"):
                                            self.trigger_realtime_checks(voucher_data_dict, target_dir)
                                    except Exception as scan_err:
                                        self.log(f"⚠️ Audit scan notice for existing voucher #{row_data.get('voucher')}: {scan_err}")

                            self.progress_tracker.record_item(status="skipped")
                            if self.progress_tracker.should_log_eta():
                                self.log(self.progress_tracker.get_eta_string())
                        elif msg[0] == 'session_expired':
                            row_data = msg[1]
                            self.circuit_breaker.record_failure()
                            self.progress_tracker.record_item(status="failed")
                            self.log("⚠️ Session expiration detected. Initiating automated recovery...")
                            self.reauthenticate_portal(username, password, state_file, pause_event)
                            failed_rows.append(msg[1])
                            completed_count[0] += 1
                        elif msg[0] == 'auto_throttle':
                            # Auto-throttling worker counts down
                            current_workers = self.var_parallel_workers.get()
                            if current_workers > 1:
                                self.var_parallel_workers.set(current_workers - 1)
                                self.log(f"⚠️ Rate-limit warnings detected on portal. Reduced worker threads count slider to {current_workers - 1}.")
                        elif msg[0] == 'http_metric':
                            latency, status_code = msg[1], msg[2]
                            if hasattr(self, 'concurrency_tuner') and self.concurrency_tuner:
                                new_concurrency = self.concurrency_tuner.record_metric(latency, status_code)
                                if new_concurrency is not None:
                                    for w_id, wp_event in getattr(self, "worker_pause_events", {}).items():
                                        if w_id <= new_concurrency:
                                            if wp_event.is_set():
                                                wp_event.clear()
                                                self.log(f"🟢 Resuming background worker {w_id} due to optimal latency/error rate.")
                                        else:
                                            if not wp_event.is_set():
                                                wp_event.set()
                                                self.log(f"⏸️ Pausing background worker {w_id} to reduce concurrency.")
                    except Exception: pass

            recv_thread = threading.Thread(target=log_receiver, daemon=True)
            recv_thread.start()

            # Main window worker (Worker 1)
            parent_update_lock = threading.Lock()
            failed_rows_lock = threading.Lock()

            def run_main_window_worker():
                worker_id = 1
                downloads_since_last_restart = 0
                while not self.stop_requested and not session_expired_flag[0]:
                    try:
                        try:
                            item_idx, row_data = task_queue.get_nowait()
                        except Exception: # queue empty
                            break
                            
                        # 1. Incremental Speed-up for Worker 1: check if completed folder marker exists
                        try:
                            target_dir = self.resolve_download_path(row_data, "Voucher" if mode in ("voucher", "voucher_search") else "Paybill")
                            marker_file = os.path.join(target_dir, "SUCCESS.marker")
                            if mode != "voucher_search" and os.path.exists(marker_file):
                                self.log(f"⏭️ [Worker {worker_id} - Main Window] Skipping already completed voucher {row_data.get('voucher')} (Folder marker found)")
                                if getattr(self, "var_scan_existing_vouchers", None) and self.var_scan_existing_vouchers.get():
                                    try:
                                        voucher_data_dict = {
                                            "voucher_no": row_data.get("voucher", ""),
                                            "treasury": row_data.get("treasury", ""),
                                            "mh": row_data.get("mh", ""),
                                            "month": row_data.get("month", ""),
                                            "year": row_data.get("year", ""),
                                            "amount": row_data.get("amount", ""),
                                            "ddo": row_data.get("ddo", "")
                                        }
                                        if hasattr(self, "trigger_realtime_checks"):
                                            self.trigger_realtime_checks(voucher_data_dict, target_dir)
                                    except Exception as scan_err:
                                        self.log(f"⚠️ Audit scan notice for existing voucher #{row_data.get('voucher')}: {scan_err}")
                                self.progress_tracker.record_item(status="skipped")
                                with self._counter_lock:
                                    self.skip_count += 1
                                with parent_update_lock:
                                    completed_count[0] += 1
                                    current_prog = completed_count[0] / total_items
                                    self.update_stats(current=row_data['voucher'], progress=current_prog)
                                if self.progress_tracker.should_log_eta():
                                    self.log(self.progress_tracker.get_eta_string())
                                continue
                        except Exception as dbe:
                            self.log(f"⚠️ Cache check error: {dbe}")

                        self.log(f"👷 [Worker {worker_id} - Main Window] Processing Voucher {row_data.get('voucher')} (S.No. {item_idx})")
                        self.last_main_page_activity = time.time()
                        local_failures = []
                        try:
                            if mode in ("voucher", "voucher_search"):
                                self.process_voucher_vch(page, context, row_data, local_failures)
                            elif mode == "tally":
                                self.process_voucher_tally(page, context, row_data, local_failures)
                            elif mode in ("paybill", "payroll"):
                                self.process_voucher_pb(page, context, row_data, local_failures)
                            
                            if local_failures:
                                self.circuit_breaker.record_failure()
                                self.progress_tracker.record_item(status="failed")
                                with failed_rows_lock:
                                    failed_rows.extend(local_failures)
                            else:
                                self.circuit_breaker.record_success()
                                self.progress_tracker.record_item(status="success")
                                # Save state
                                key = f"{row_data.get('treasury')}_{row_data.get('mh')}_{row_data.get('month')}_{row_data.get('year')}_{row_data.get('voucher')}"
                                save_run_state(self.operator_name, self.base_path, key)
                                downloads_since_last_restart += 1
                        except SessionExpiredError:
                            self.circuit_breaker.record_failure()
                            self.progress_tracker.record_item(status="failed")
                            self.log("🔴 [Worker 1 - Main Window] Session expired. Initiating re-authentication...")
                            task_queue.put((item_idx, row_data))
                            reauth_ok = self.reauthenticate_portal(username, password, state_file, pause_event)
                            if not reauth_ok:
                                session_expired_flag[0] = True
                                break
                            continue
                        except BrowserConnectionDeadError as bcd:
                            self.circuit_breaker.record_failure()
                            self.progress_tracker.record_item(status="failed")
                            self.log(f"❌ [Worker {worker_id} - Main Window] Browser connection dead: {bcd}")
                            session_expired_flag[0] = True
                            with failed_rows_lock:
                                failed_rows.append(row_data)
                            break
                        except Exception as ex:
                            self.circuit_breaker.record_failure()
                            self.progress_tracker.record_item(status="failed")
                            self.log(f"⚠️ [Worker {worker_id} - Main Window] Error processing voucher {row_data.get('voucher')}: {ex}")
                            with failed_rows_lock:
                                failed_rows.append(row_data)
                        finally:
                            with parent_update_lock:
                                completed_count[0] += 1
                                current_prog = completed_count[0] / total_items
                                self.update_stats(current=row_data['voucher'], progress=current_prog)
                            if self.progress_tracker.should_log_eta():
                                self.log(self.progress_tracker.get_eta_string())
                            self.last_main_page_activity = time.time()
                    except Exception as loop_ex:
                        self.log(f"⚠️ [Worker {worker_id} - Main Window] Loop error: {loop_ex}")

            try:
                state_file_path = os.path.join(self.base_path, "browser_state.json")
                # Voucher downloads use Playwright worker subprocesses (via shared CDP browser)
                # to interact with IFMIS Struts form forms reliably without HTTP 500 errors.
                use_browserless = False
                processes = []
                threads = []
                self.worker_pause_events = {}

                self.log(f"🚀 Spawning {workers_count - 1} concurrent Playwright worker subprocesses for parallel downloading...")
                for w_id in range(2, workers_count + 1):
                    wp_event = multiprocessing.Event()
                    self.worker_pause_events[w_id] = wp_event
                    p = multiprocessing.Process(
                        target=multiprocess_voucher_worker,
                        args=(w_id, mode, state_file, task_queue, result_queue, self.stop_event, pause_event, wp_event, config_dict, use_chrome),
                        daemon=True
                    )
                    p.start()
                    processes.append(p)

                # Run Worker 1 in the main window (parent thread)
                run_main_window_worker()

                # Wait for all processes to finish or stop request
                last_hb_time = time.time()
                while any(p.is_alive() for p in processes):
                    if self.stop_requested or session_expired_flag[0]:
                        self.stop_event.set()
                        for p in processes:
                            try:
                                p_pid = getattr(p, 'pid', None)
                                if p_pid: kill_process_tree(p_pid)
                                else: p.terminate()
                            except Exception:
                                pass
                        # Cleanly terminate worker Chrome processes and hide remaining windows
                        if sys.platform == "win32":
                            try:
                                main_pid = getattr(self, "cdp_browser_process", None) and getattr(self.cdp_browser_process, "pid", None)
                                import psutil
                                for proc in psutil.process_iter(['pid', 'name']):
                                    if proc.info['name'] and proc.info['name'].lower() in ('chrome.exe', 'chromedriver.exe'):
                                        if main_pid and proc.info['pid'] == main_pid:
                                            continue
                                        kill_process_tree(proc.info['pid'])
                            except Exception: pass
                        if hasattr(self, "set_browser_visibility"):
                            try: self.set_browser_visibility(False)
                            except Exception: pass
                        break
                    
                    # Safe keep-alive heartbeat execution on the correct thread
                    if time.time() - last_hb_time > 90:
                        try:
                            if self.browser_page and not self.browser_page.is_closed():
                                self.log("💓 Heartbeat: keeping main browser session alive...")
                                self.browser_page.evaluate("fetch('ifms.htm?actionFlag=rnd-paymentOrderListForAG&elementId=10072358').catch(() => {})")
                                self.update_browser_status("💤 Centralized Voucher Validation Suite: Main browser session kept alive in background. Next operation ready.", bg_color="#111827", text_color="#10b981")
                        except Exception as hb_ex:
                            self.log(f"⚠️ Heartbeat error: {hb_ex}")
                        last_hb_time = time.time()

                    time.sleep(0.5)

                for p in processes: p.join()

                # Restore main browser window visibility after parallel run finishes
                self.set_browser_visibility(True)

                if session_expired_flag[0]:
                    self.log("🔴 Parallel run aborted: IFMIS Session Expired or Connection Lost. Please log in again.")

                # Process the deferred retry queue sweep at the end
                if failed_rows and not self.stop_requested and not session_expired_flag[0]:
                    self.log(f"\n🔁 SEQUENCE INITIATING DEFERRED RUN OF FAILURES (Sequential Sweep - {len(failed_rows)} rows)...")
                    retry_rows = failed_rows.copy()
                    failed_rows.clear()
                    
                    # Run deferred retries sequentially in main visible browser for user visibility
                    for idx, row_data in enumerate(retry_rows, 1):
                        if self.stop_requested:
                            self.log("🛑 Stop request confirmed. Aborting failure retry sweep.")
                            break
                        self.update_stats(current=f"Retry: {row_data['voucher']}", progress=(idx / len(retry_rows)))
                        try:
                            local_failures = []
                            if mode in ("voucher", "voucher_search"):
                                self.process_voucher_vch(page, context, row_data, local_failures)
                            elif mode == "tally":
                                self.process_voucher_tally(page, context, row_data, local_failures)
                            elif mode in ("paybill", "payroll"):
                                self.process_voucher_pb(page, context, row_data, local_failures)

                            
                            if local_failures:
                                failed_rows.extend(local_failures)
                            else:
                                # Save state
                                key = f"{row_data.get('treasury')}_{row_data.get('mh')}_{row_data.get('month')}_{row_data.get('year')}_{row_data.get('voucher')}"
                                save_run_state(self.operator_name, self.base_path, key)
                        except SessionExpiredError:
                            self.log("🔴 Session expired during deferred retry sweep.")
                            failed_rows.extend(retry_rows[idx-1:])
                            break
                        except BrowserConnectionDeadError as bcd:
                            self.log(f"🔴 Browser connection dead during deferred retry sweep: {bcd}")
                            failed_rows.extend(retry_rows[idx-1:])
                            break
                        except Exception:
                            failed_rows.append(row_data)

            finally:
                result_queue_empty_event.set()
                if page:
                    try: page.remove_listener("request", capture_voucher_request)
                    except: pass
                try: recv_thread.join(timeout=2.0)
                except Exception: pass

            self.log("🎯 Batch execution sequence finished.")
            self.update_stats(current="Idle", progress=1.0)
            
            with self._counter_lock: total_failed = self.fail_count
            if total_failed > 0: self.log(f"📝 failures logged under: Failed_{mode.upper()}s.txt")
            
            self._post_process(mode)
            self.post_process_done = True 
            
        finally:
            if self.stop_requested:
                self.log("🛑 Keeping the browser open and the active session intact on Stop command.")
            else:
                self.update_browser_status("🎯 Centralized Voucher Validation Suite: Batch execution completed. Session remains open in background.", bg_color="#10b981", text_color="#111827")
            self.log("👉 The UI is unlocked! You can run failed ones or start a new batch directly.")
            
            if os.path.exists(state_file):
                try: os.remove(state_file)
                except: pass
            
    else:
        # === ORIGINAL SEQUENTIAL RUN WORKFLOW ===
        if not reuse_session:
            self.safe_logout_and_close(self.browser_page, silent=True)
            self.log(f"🌐 Launching Playwright browser interface ({'Chromium' if use_chrome else 'Firefox'} Mode)...")
            if not self.playwright:
                self.playwright = sync_playwright().start()

            try:
                browser, self.browser_used = self._launch_browser_with_failover(use_chrome)
            except Exception as e:
                self.log(f"❌ Critical Error: {e}")
                return

            state_file_path = os.path.join(self.base_path, "browser_state.json")
            valid_state = self._get_valid_storage_state(state_file_path)
                    
            context_args = {"accept_downloads": True}
            if use_chrome:
                context_args["no_viewport"] = True
            if valid_state:
                context_args["storage_state"] = valid_state
            context_args = self.get_stealth_context_args(context_args)
            context = browser.new_context(**context_args)
            page = context.new_page()
            self.apply_webdriver_mask(page)

            self.browser = browser
            self.browser_context = context
            self.browser_page = page

            try:
                logged_in_page = self._perform_portal_login(page, context, username, password)
                if not logged_in_page:
                    if self.stop_requested:
                        self.log("🛑 Keeping the browser open and the active session intact on Stop command.")
                    else:
                        self._cleanup_browser_session()
                    return
                page = logged_in_page
                context = self.browser_context
                self.browser_page = page
            except Exception as e:
                self.log(f"❌ Login Error: {e}")
                if self.stop_requested:
                    self.log("🛑 Keeping the browser open and the active session intact on Stop command.")
                else:
                    self._cleanup_browser_session()
                return
        else:
            page = self.browser_page
            context = self.browser_context
            try:
                self.log("🔄 Resetting browser page to home dashboard...")
                page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag", timeout=25000, wait_until="domcontentloaded")
            except Exception as e:
                self.log(f"⚠️ Warning: Failed to reset to dashboard: {e}")

        try:
            failed_rows = []
            session_expired = False
            downloads_since_last_restart = 0
            
            for idx, row_data in enumerate(excel_rows, 1):
                if self.stop_requested: break
                self.log(f"📊 Progress: {idx}/{total_items}")
                self.update_stats(current=row_data['voucher'], progress=(idx / total_items))
                
                # Browser process recycling
                if downloads_since_last_restart >= 20:
                    self.log("Recycling browser session to release leaked memory...")
                    try:
                        page.close()
                        context.close()
                    except Exception: pass
                    time.sleep(5)
                    state_file_path = os.path.join(self.base_path, "browser_state.json")
                    valid_state = self._get_valid_storage_state(state_file_path)
                            
                    context_args = {"accept_downloads": True}
                    if use_chrome:
                        context_args["no_viewport"] = True
                    if valid_state:
                        context_args["storage_state"] = valid_state
                    context_args = self.get_stealth_context_args(context_args)
                    context = self.browser.new_context(**context_args)
                    page = context.new_page()
                    self.apply_webdriver_mask(page)
                    # Navigate to approved bills page using restored cookies
                    try:
                        self.resilient_goto(page, "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", base_timeout=45000)
                    except Exception as goto_ex:
                        if self._is_on_login_page(page):
                            self.log("🔑 Session expired during recycling. Requesting single-flight re-authentication...")
                            self.reauthenticate_portal(username, password, state_file_path, self.pause_event)
                    downloads_since_last_restart = 0

                # Adaptive sleep jitter
                time.sleep(random.uniform(1.5, 4.0))

                try:
                    local_failures = []
                    if mode in ("voucher", "voucher_search"):
                        self.process_voucher_vch(page, context, row_data, local_failures)
                    elif mode == "tally":
                        self.process_voucher_tally(page, context, row_data, local_failures)
                    elif mode in ("paybill", "payroll"):
                        self.process_voucher_pb(page, context, row_data, local_failures)
                    
                    if local_failures:
                        failed_rows.extend(local_failures)
                    else:
                        # Save state
                        key = f"{row_data.get('treasury')}_{row_data.get('mh')}_{row_data.get('month')}_{row_data.get('year')}_{row_data.get('voucher')}"
                        save_run_state(self.operator_name, self.base_path, key)
                        downloads_since_last_restart += 1
                        
                        # Cache download to SQLite DB
                        try:
                            from database.db_manager import save_download_record
                            db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
                            save_download_record(
                                db_path=db_path,
                                mode=mode,
                                treasury=row_data.get('treasury'),
                                major_head=row_data.get('mh'),
                                month=row_data.get('month'),
                                year=row_data.get('year'),
                                voucher_no=row_data.get('voucher'),
                                amount=row_data.get('amount'),
                                ddo_code=row_data.get('ddo'),
                                file_path=""
                            )
                        except Exception as dbe:
                            self.log(f"⚠️ Failed to cache download in history database: {dbe}")
                except SessionExpiredError:
                    self.session_expiry_count += 1
                    self.log("🔴 IFMS portal session expired. Process sequence terminated.")
                    session_expired = True
                    failed_rows.extend(excel_rows[idx-1:])
                    break
                except Exception:
                    failed_rows.append(row_data)

            # Deferred End-of-Run Retry Sweep
            if failed_rows and not self.stop_requested and not session_expired:
                self.log("\n🔁 SEQUENCE INITIATING DEFERRED RETRY SWEEP OF FAILURES...")
                retry_rows = failed_rows.copy()
                failed_rows.clear()
                for idx, row_data in enumerate(retry_rows, 1):
                    if self.stop_requested: break
                    self.update_stats(current=f"Retry: {row_data['voucher']}", progress=(idx / len(retry_rows)))
                    try:
                        local_failures = []
                        if mode in ("voucher", "voucher_search"):
                            self.process_voucher_vch(page, context, row_data, local_failures)
                        elif mode == "tally":
                            self.process_voucher_tally(page, context, row_data, local_failures)
                        elif mode in ("paybill", "payroll"):
                            self.process_voucher_pb(page, context, row_data, local_failures)

                        if local_failures:
                            failed_rows.extend(local_failures)
                        else:
                            key = f"{row_data.get('treasury')}_{row_data.get('mh')}_{row_data.get('month')}_{row_data.get('year')}_{row_data.get('voucher')}"
                            save_run_state(self.operator_name, self.base_path, key)
                            
                            # Cache download to SQLite DB
                            try:
                                from database.db_manager import save_download_record
                                db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
                                save_download_record(
                                    db_path=db_path,
                                    mode=mode,
                                    treasury=row_data.get('treasury'),
                                    major_head=row_data.get('mh'),
                                    month=row_data.get('month'),
                                    year=row_data.get('year'),
                                    voucher_no=row_data.get('voucher'),
                                    amount=row_data.get('amount'),
                                    ddo_code=row_data.get('ddo'),
                                    file_path=""
                                )
                            except Exception as dbe:
                                self.log(f"⚠️ Failed to cache download in history database: {dbe}")
                    except SessionExpiredError:
                        session_expired = True
                        failed_rows.extend(retry_rows[idx-1:])
                        break
                    except Exception:
                        failed_rows.append(row_data)

            self.log("🎯 Batch execution sequence finished.")
            self.update_stats(current="Idle", progress=1.0)
            
            with self._counter_lock: total_failed = self.fail_count
            if total_failed > 0: self.log(f"📝 failures logged under: Failed_{mode.upper()}s.txt")
            
            self._post_process(mode)
            self.post_process_done = True 

        finally:
            if self.stop_requested:
                self.log("🛑 Keeping the browser open and the active session intact on Stop command.")
            else:
                self.update_browser_status("🎯 Centralized Voucher Validation Suite: Batch execution completed. Session remains open in background.", bg_color="#10b981", text_color="#111827")
            self.log("👉 The UI is unlocked! You can run failed ones or start a new batch directly.")

def _run_dry_mode_excel(self, excel_rows, total_items, mode):
    self.log("\n" + "="*55)
    self.log(f"🚀 DRY SEQUENCE INITIATED: BYPASSING LIVE IFMS PORTAL ({mode.upper()})")
    self.log("="*55)
    for idx, row_data in enumerate(excel_rows, 1):
        if self.stop_requested: break
        vou = row_data["voucher"]
        self.update_stats(current=vou, progress=(idx / total_items))
        self.log(f"🔍 [{idx}/{total_items}] DRY-RUN Voucher: {vou} | Treasury: {row_data['treasury']} | Major Head: {row_data['mh']}")
        time.sleep(0.5)
        with self._counter_lock: self.success_count += 1
    self.update_stats(current="Idle", progress=1.0)
    self.log("🎯 DRY Batch completed.")

def _run_dry_mode_pol(self, target_ddos, run_failed):
    self.log("\n" + "="*55)
    self.log("🚀 DRY SEQUENCE INITIATED: BYPASSING LIVE IFMS PORTAL (POL CHECKLIST)")
    self.log("="*55)
    total_ddos = len(target_ddos)
    for idx, ddo in enumerate(target_ddos):
        if self.stop_requested: break
        self.update_stats(current=ddo[:15], progress=(idx / total_ddos))
        self.log(f"🔍 [{idx+1}/{total_ddos}] DRY-RUN POL DDO: {ddo}")
        time.sleep(0.5)
        with self._counter_lock: self.success_count += 1
    self.update_stats(current="Idle", progress=1.0)
    self.log("🎯 DRY POL Batch completed.")

def _run_dry_mode_pol_excel(self, excel_rows):
    self.log("\n" + "="*55)
    self.log("🚀 DRY SEQUENCE INITIATED: BYPASSING LIVE IFMS PORTAL (POL EXCEL LIST)")
    self.log("="*55)
    total_rows = len(excel_rows)
    for idx, row in enumerate(excel_rows):
        if self.stop_requested: break
        ddo = row['ddo']
        self.update_stats(current=ddo[:15], progress=(idx / total_rows))
        self.log(f"🔍 [{idx+1}/{total_rows}] DRY-RUN POL Row DDO: {ddo} | Treasury: {row['treasury']} | Dates: {row['from_date']} - {row['to_date']}")
        time.sleep(0.5)
        with self._counter_lock: self.success_count += 1
    self.update_stats(current="Idle", progress=1.0)
    self.log("🎯 DRY POL Excel Batch completed.")

def _post_process(self, mode):
    if self.var_archive.get() and self.downloaded_folders_this_run:
        self.log("📦 Compressing completed downloads into Zip archive...")
        
        if str(mode).lower() == "pol":
            pol_dir = os.path.join(self.download_dir, "POL")
            os.makedirs(pol_dir, exist_ok=True)
            
            # Extract treasury names from downloaded folders
            treasuries_found = []
            for folder in self.downloaded_folders_this_run:
                parts = os.path.normpath(folder).split(os.sep)
                for p in parts:
                    if p.upper().startswith("POL_") and len(p) > 4:
                        tr_name = p[4:].strip()
                        if tr_name and tr_name not in treasuries_found:
                            treasuries_found.append(tr_name)

            if not treasuries_found and hasattr(self, "current_treasury") and self.current_treasury:
                clean_tr = re.sub(r"[^\w\s-]", "", str(self.current_treasury)).strip().replace(" ", "_")
                if clean_tr:
                    treasuries_found.append(clean_tr)

            if treasuries_found:
                tr_label = "_".join(treasuries_found[:2])
                zip_name = f"POL_{tr_label}.zip"
            else:
                zip_name = f"POL_{time.strftime('%Y%m%d_%H%M%S')}.zip"

            zip_filename = os.path.join(pol_dir, zip_name)
        else:
            zip_filename = os.path.join(self.download_dir, f"IFMIS_{mode.upper()}_Batch_{time.strftime('%Y%m%d_%H%M%S')}.zip")

        try:
            with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for folder in self.downloaded_folders_this_run:
                    if not os.path.exists(folder): continue
                    if os.path.isfile(folder):
                        zipf.write(folder, os.path.basename(folder))
                    else:
                        for root, dirs, files in os.walk(folder):
                            for file in files:
                                f_path = os.path.join(root, file)
                                rel_path = os.path.relpath(f_path, os.path.dirname(folder))
                                zipf.write(f_path, rel_path)
            self.log(f"✅ Created Zip Archive: {os.path.basename(zip_filename)} at {zip_filename}")
        except Exception as ex:
            self.log(f"⚠️ Failed to package ZIP archive: {ex}")

    try:
        from core.security import get_machine_id
        from core.constants import RUN_ID, TOOL_VERSION
        from core.telemetry import send_silent_log
        
        runtime_secs = 0
        if hasattr(self, "run_start_time") and self.run_start_time:
            try: runtime_secs = int(time.time() - self.run_start_time)
            except Exception: pass

        end_payload = {
            "run_id": RUN_ID,
            "tool_version": TOOL_VERSION,
            "event": "batch_complete",
            "mode": mode.upper(),
            "operator": self.operator_name,
            "hwid": get_machine_id(),
            "success": self.success_count,
            "success_count": self.success_count,
            "failed": self.fail_count,
            "fail_count": self.fail_count,
            "skipped": self.skip_count,
            "skip_count": self.skip_count,
            "runtime_seconds": runtime_secs,
            "browser_used": getattr(self, "browser_used", "UNKNOWN"),
            "captcha_attempts": getattr(self, "captcha_attempts", 0),
            "captcha_success": getattr(self, "captcha_success", 0),
            "timeouts": getattr(self, "timeout_count", 0),
            "session_expiry_count": getattr(self, "session_expiry_count", 0),
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        if getattr(self, 'var_telemetry_enabled', None) and self.var_telemetry_enabled.get():
            threading.Thread(
                target=send_silent_log,
                args=(self.operator_name, json.dumps(end_payload)),
                daemon=True
            ).start()
    except Exception: pass

    # Clear run state checkpoint if the batch completed with zero failures
    if getattr(self, "fail_count", 0) == 0:
        state_file = os.path.join(self.base_path, ".run_state.json")
        if os.path.exists(state_file):
            try:
                os.remove(state_file)
                self.log("🧹 Batch completed with 100% success. Cleared session auto-resume checkpoint.")
            except Exception:
                pass

    # --- v3.1: Duplicate Payment Detection — Batch Sweep & Report ---
    if mode.lower() == "voucher":
        try:
            from automation.duplicate_detector import run_batch_sweep, generate_html_report, generate_merged_pdfs
            _dup_db = getattr(self, 'db_path', None)
            if _dup_db and os.path.exists(_dup_db):
                flagged_pairs = run_batch_sweep(self.download_dir, _dup_db, log_fn=self.log, current_run_keys=getattr(self, 'current_run_keys', None))
                from automation.duplicate_detector import format_console_summary
                self.log(format_console_summary(flagged_pairs))
                if flagged_pairs:
                    _voucher_dir = os.path.join(self.download_dir, "VOUCHERS")
                    if not os.path.isdir(_voucher_dir):
                        _voucher_dir = self.download_dir
                    report_path = os.path.join(_voucher_dir, f"Duplicate_Payment_Report_{time.strftime('%Y%m%d_%H%M%S')}.html")
                    generate_html_report(flagged_pairs, report_path)
                    self.log(f"📄 Report saved to: {report_path}")
                    # Generate merged comparison PDFs for each flagged pair
                    merged_pdfs = []
                    try:
                        merged_pdfs = generate_merged_pdfs(flagged_pairs, _voucher_dir, log_fn=self.log)
                        if merged_pdfs:
                            self.log(f"📎 Generated {len(merged_pdfs)} merged comparison PDF(s) in VOUCHERS folder.")
                    except Exception as _merge_err:
                        self.log(f"⚠️ Merged PDF generation skipped: {str(_merge_err)[:60]}")

                    # --- Wire Duplicate Findings into GUI Table, SQLite Cache & Consolidated Reports ---
                    dup_findings = []
                    for pair in flagged_pairs:
                        v_a = getattr(pair, 'voucher_a', {}) if isinstance(getattr(pair, 'voucher_a', None), dict) else {}
                        v_b = getattr(pair, 'voucher_b', {}) if isinstance(getattr(pair, 'voucher_b', None), dict) else {}
                        
                        v1_no = str(v_a.get('voucher_no', getattr(pair, 'v1_no', '')))
                        v2_no = str(v_b.get('voucher_no', getattr(pair, 'v2_no', '')))
                        v1_trs = str(v_a.get('treasury', getattr(pair, 'v1_trs', '')))
                        v2_trs = str(v_b.get('treasury', getattr(pair, 'v2_trs', '')))
                        amt = v_a.get('amount', getattr(pair, 'amount', 0.0))
                        
                        try:
                            f_amt = float(amt)
                            amt_str = f"₹{f_amt:,.2f}"
                        except Exception:
                            amt_str = str(amt)

                        match_cnt = getattr(pair, 'match_count', 1)

                        f_entry1 = {
                            "voucher_no": v1_no,
                            "treasury": v1_trs,
                            "mh": str(v_a.get('mh', '')),
                            "month": str(v_a.get('month', '')),
                            "year": str(v_a.get('year', '')),
                            "amount": amt_str,
                            "check_name": "Duplicate Payment & Double Claim Check",
                            "status": "SUSPICIOUS",
                            "message": f"🚨 DOUBLE PAYMENT ALERT! Shares {match_cnt} identical attachment MD5 hash(es) with Voucher #{v2_no} (Treasury: {v2_trs}, Amount: {amt_str})."
                        }
                        f_entry2 = {
                            "voucher_no": v2_no,
                            "treasury": v2_trs,
                            "mh": str(v_b.get('mh', '')),
                            "month": str(v_b.get('month', '')),
                            "year": str(v_b.get('year', '')),
                            "amount": amt_str,
                            "check_name": "Duplicate Payment & Double Claim Check",
                            "status": "SUSPICIOUS",
                            "message": f"🚨 DOUBLE PAYMENT ALERT! Shares {match_cnt} identical attachment MD5 hash(es) with Voucher #{v1_no} (Treasury: {v1_trs}, Amount: {amt_str})."
                        }
                        dup_findings.extend([f_entry1, f_entry2])

                    # 1. Emit live to GUI table
                    for dfind in dup_findings:
                        if hasattr(self, "result_queue") and self.result_queue:
                            self.result_queue.put(("task_audit_finding", dfind))
                        if hasattr(self, "trigger_realtime_checks"):
                            try:
                                from gui.tabs_qt.validation_results_tab import add_realtime_result_to_table
                                if hasattr(self, "safe_after"):
                                    self.safe_after(0, lambda r=dfind: add_realtime_result_to_table(self, r))
                            except Exception:
                                pass

                    # 2. Save to SQLite Cache
                    if _dup_db:
                        try:
                            save_audit_results_batch(_dup_db, dup_findings)
                        except Exception:
                            pass

                    # 3. Register with check_registry for Excel & HTML Reports
                    if hasattr(self, "check_registry") and self.check_registry:
                        for dfind in dup_findings:
                            if hasattr(self.check_registry, "all_findings"):
                                self.check_registry.all_findings.append(dfind)

                    try:
                        import webbrowser
                        webbrowser.open(report_path)
                    except Exception:
                        pass
        except Exception as _dup_err:
            self.log(f"⚠️ Duplicate detection post-processing skipped: {str(_dup_err)[:80]}")

    # Trigger Post-Download Check Suite & Consolidated Reports Generation
    if hasattr(self, "trigger_post_download_checks"):
        try:
            self.log("📊 Generating Consolidated Excel Report & HTML Summary Dashboard...")
            all_rows = getattr(self, "excel_rows", []) or []
            summary = self.trigger_post_download_checks(all_rows, self.download_dir)
            if summary:
                if summary.get("excel_path"):
                    self.log(f"📊 Consolidated Excel Report generated: {os.path.basename(summary['excel_path'])}")
                if summary.get("html_path"):
                    self.log(f"🌐 HTML Summary Dashboard generated: {os.path.basename(summary['html_path'])}")
        except Exception as _report_err:
            self.log(f"⚠️ Notice generating consolidated reports: {_report_err}")

    # Send Telegram Notification Summary if enabled
    if hasattr(self, "send_telegram_alert"):
        success = getattr(self, "success_count", 0)
        failed = getattr(self, "fail_count", 0)
        skipped = getattr(self, "skip_count", 0)
        total = success + failed + skipped
        msg = f"*Batch Processing Complete!*\n\n*Mode*: {mode.upper()}\n*Total Items*: {total}\n*Success*: {success}\n*Failed*: {failed}\n*Skipped*: {skipped}"
        self.send_telegram_alert(msg)

    # Prompt user to open downloads folder (one-click access)
    if not getattr(self, "stop_requested", False):
        def ask_open_folder():
            try:
                import os
                
                target_folder = self.download_dir
                if getattr(self, "downloaded_folders_this_run", None):
                    first_item = self.downloaded_folders_this_run[0]
                    if os.path.exists(first_item):
                        if os.path.isdir(first_item):
                            target_folder = first_item
                        else:
                            target_folder = os.path.dirname(first_item)
                
                if os.path.exists(target_folder):
                    from PySide6.QtWidgets import QMessageBox
                    btn = QMessageBox.question(
                        self,
                        "Open Downloads Folder?",
                        "Batch processing completed successfully.\n\nDo you want to open the downloads folder to view the downloaded files?",
                        QMessageBox.Yes | QMessageBox.No,
                        QMessageBox.Yes
                    )
                    if btn == QMessageBox.Yes:
                        os.startfile(target_folder)
                else:
                    self.log(f"⚠️ Downloads folder not found: {target_folder}")
            except Exception as e:
                self.log(f"⚠️ Failed to prompt/open downloads folder: {e}")

        self.after(200, ask_open_folder)

def _log_run_failure(self, mode, event_type, error_msg):
    try:
        from core.security import get_machine_id
        from core.constants import RUN_ID, TOOL_VERSION
        from core.telemetry import send_silent_log
        fail_payload = {
            "run_id": RUN_ID,
            "tool_version": TOOL_VERSION,
            "event": "run_failure",
            "mode": mode.upper(),
            "operator": self.operator_name,
            "hwid": get_machine_id(),
            "failure_type": event_type,
            "error": error_msg[:200],
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        if getattr(self, 'var_telemetry_enabled', None) and self.var_telemetry_enabled.get():
            threading.Thread(
                target=send_silent_log,
                args=(self.operator_name, json.dumps(fail_payload)),
                daemon=True
            ).start()
    except Exception: pass


def _run_dry_mode_vlc(self, run_failed):
    """Simulate downloading VLC reports in dry-run mode."""
    self.log("\n" + "=" * 55)
    self.log("🚀 DRY RUN MODE (VLC TEXT FILES) INITIATED: BYPASSING PORTAL")
    self.log("=" * 55)

    selected_modules = getattr(self, "vlc_selected_modules", [])
    selected_treasuries = getattr(self, "vlc_selected_treasuries", [])
    
    if hasattr(self, 'entry_vlc_from') and self.entry_vlc_from.text().strip():
        from_date_str = self.entry_vlc_from.text().strip()
    else:
        from_date_str = self.var_vlc_from_date.get()

    if hasattr(self, 'entry_vlc_to') and self.entry_vlc_to.text().strip():
        to_date_str = self.entry_vlc_to.text().strip()
    else:
        to_date_str = self.var_vlc_to_date.get()

    if hasattr(self, 'vlc_list_dropdown'):
        list_type_str = self.vlc_list_dropdown.currentText()
    else:
        list_type_str = self.var_vlc_list_type.get()

    from automation.scrapers.vlc_scraper import parse_date_to_dmy
    try:
        f_day, f_month, f_year = parse_date_to_dmy(from_date_str)
        t_day, t_month, t_year = parse_date_to_dmy(to_date_str)
    except Exception:
        f_day, f_month, f_year = 1, 4, 2025
        t_day, t_month, t_year = 31, 3, 2026

    if (f_year > t_year) or (f_year == t_year and f_month > t_month):
        f_day, f_month, f_year, t_day, t_month, t_year = t_day, t_month, t_year, f_day, f_month, f_year

    from core.constants import VLC_MONTH_MAP
    rev_month_map = {v: k for k, v in VLC_MONTH_MAP.items()}
    months_in_range = []
    curr_year, curr_month = f_year, f_month
    while (curr_year < t_year) or (curr_year == t_year and curr_month <= t_month):
        month_name = rev_month_map.get(curr_month)
        if month_name:
            months_in_range.append((str(curr_year), month_name))
        curr_month += 1
        if curr_month > 12:
            curr_month = 1
            curr_year += 1

    total_tasks = len(selected_modules) * len(selected_treasuries) * len(months_in_range)
    with self._counter_lock:
        self.stats_total = total_tasks
        self.success_count = 0
        self.fail_count = 0
        self.skip_count = 0

    self.update_stats(progress=0.0)
    self.log(f"📋 DRY RUN Scope: {len(selected_modules)} Modules × {len(selected_treasuries)} Treasuries × {len(months_in_range)} Month(s) = {total_tasks} Simulated Tasks")

    completed = 0
    for mod in selected_modules:
        if self.stop_requested: break
        for tsry in selected_treasuries:
            if self.stop_requested: break
            for year_val, month_name in months_in_range:
                if self.stop_requested: break
                completed += 1
                self.log(f"📊 [DRY-RUN] Task {completed}/{total_tasks}: {mod['name']} | {tsry} | {month_name} {year_val} ({list_type_str})")
                time.sleep(0.15)
                with self._counter_lock:
                    self.success_count += 1
                self.update_stats(progress=completed / total_tasks)

    self.log(f"🎉 DRY RUN (VLC) Completed: {self.success_count} simulated tasks completed successfully.")


def _run_dry_mode_payroll(self, months_to_process, treasury, dept, mhcd):
    self.log("\n" + "="*55)
    self.log("🚀 DRY RUN MODE (PAYROLL) INITIATED: BYPASSING IFMS")
    self.log("="*55)
    
    total_months = len(months_to_process)
    mock_vouchers_per_month = 3
    total_vouchers = mock_vouchers_per_month * total_months
    
    with self._counter_lock:
        self.stats_total = total_vouchers
        self.update_stats()
    
    processed_count = 0
    for m_idx, (year, month) in enumerate(months_to_process, 1):
        if self.stop_requested: break
        self.log(f"Starting simulated month → {month}/{year}")
        
        mock_vouchers = [f"DryVou1_{month}", f"DryVou2_{month}", f"DryVou3_{month}"]
        for v_idx, vou in enumerate(mock_vouchers, 1):
            if self.stop_requested: break
            processed_count += 1
            self.log(f"Simulating download for voucher {v_idx}/3: {vou}")
            self.update_stats(current=vou, progress=(processed_count / total_vouchers))
            time.sleep(1.0)
            
            row_data = {
                "s_no": str(processed_count), "mh": mhcd, "treasury": treasury, "voucher": vou, "amount": "",
                "month": int(month), "year": int(year)
            }
            
            folder = self.resolve_download_path(row_data, "Salary Bill")
            os.makedirs(folder, exist_ok=True)
            
            mock_file = os.path.join(folder, f"{vou}_{month}_{year}_{treasury}{dept}0000.xlsx")
            import openpyxl
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Mock Voucher"
            ws.append(["DDO CODE: " + f"{treasury}{dept}0101"])
            ws.append(["Voucher Number", "Month", "Year", "DDO Code"])
            ws.append([vou, month, year, f"{treasury}{dept}0101"])
            wb.save(mock_file)
            
            with open(os.path.join(folder, "SUCCESS.marker"), "w") as f: f.write("DONE")
            with self._counter_lock: 
                self.success_count += 1
                if folder not in self.downloaded_folders_this_run:
                    self.downloaded_folders_this_run.append(folder)
            
            try:
                from database.db_manager import save_download_record
                db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
                save_download_record(
                    db_path=db_path,
                    mode="voucher",
                    treasury=treasury,
                    major_head=mhcd,
                    month=int(month),
                    year=int(year),
                    voucher_no=vou,
                    amount="",
                    ddo_code=f"{treasury}{dept}0101",
                    file_path=folder
                )
            except Exception as dbe:
                self.log(f"⚠️ Failed to cache download: {dbe}")
                
    self.log("\n🎯 SIMULATED PAYROLL BATCH COMPLETE")
    self.update_stats(current="Idle", progress=1.0)
    self._post_process("payroll")
    self.post_process_done = True


def _run_live_mode_payroll(self, username, password, months_to_process, treasury, dept, mhcd, gpf_idx):
    self.log("🌐 Launching Playwright Browser for Payroll Downloader...")
    use_chrome = self.var_browser.get().startswith("Google Chrome")
    
    reuse_session = False
    if self.browser and self.browser_context and self.browser_page:
        active_is_chrome = "chromium" in self.browser.__class__.__name__.lower()
        if active_is_chrome == use_chrome:
            try:
                if not self.browser_page.is_closed() and self._is_logged_in(self.browser_page):
                    self.log("🔄 Active authenticated session detected in currently open browser. Bypassing login!")
                    reuse_session = True
            except Exception: pass
            
    if not reuse_session:
        self.safe_logout_and_close(self.browser_page)
        
        if not self.playwright:
            from playwright.sync_api import sync_playwright
            self.playwright = sync_playwright().start()
            
        try:
            browser, self.browser_used = self._launch_browser_with_failover(use_chrome)
            self.bring_browser_to_front()
        except Exception as e:
            self.log(f"❌ Critical Error: {e}")
            self.safe_after(0, lambda: self.set_ui_lock_state(is_locked=False))
            return

        state_file_path = os.path.join(self.base_path, "browser_state.json")
        context_args = {"accept_downloads": True}
        if use_chrome:
            context_args["no_viewport"] = True
        context_args = self.get_stealth_context_args(context_args)
        context = browser.new_context(**context_args)
        page = context.new_page()
        self.apply_webdriver_mask(page)
        
        self.browser = browser
        self.browser_context = context
        self.browser_page = page
        
        try:
            logged_in_page = self._perform_portal_login(page, context, username, password)
            if not logged_in_page:
                self.safe_logout_and_close(self.browser_page)
                self.safe_after(0, lambda: self.set_ui_lock_state(is_locked=False))
                return
            page = logged_in_page
            self.browser_page = page
        except Exception as e:
            self.log(f"❌ Login Error: {e}")
            self.safe_logout_and_close(self.browser_page)
            self.safe_after(0, lambda: self.set_ui_lock_state(is_locked=False))
            return
    else:
        page = self.browser_page
        context = self.browser_context
        
    try:
        self.log("⏳ Waiting for page to stabilize...")
        time.sleep(2)
        try: page.wait_for_load_state("networkidle", timeout=5000)
        except: pass
        
        self.process_salary_voucher_dropdown_loop(
            page=page,
            context=context,
            months_to_process=months_to_process,
            treasury_code=treasury,
            dept_code=dept,
            mhcd=mhcd,
            gpf_idx=gpf_idx
        )
        
        self.log("\n🎯 PAYROLL BATCH PROCESS COMPLETE")
        self.update_stats(current="Idle", progress=1.0)
        self._post_process("payroll")
        self.post_process_done = True
        
    except Exception as e:
        self.log(f"❌ FATAL ERROR IN PAYROLL: {e}")
    finally:
        if self.stop_requested:
            self.log("🛑 Keeping the browser open on Stop command.")
        else:
            self.update_browser_status("🎯 Centralized Voucher Validation Suite: Payroll Downloader execution completed.", bg_color="#10b981", text_color="#111827")
            self.log("👉 The UI is unlocked! You can run another batch or view results directly.")
        self.safe_after(0, lambda: self.set_ui_lock_state(is_locked=False))
