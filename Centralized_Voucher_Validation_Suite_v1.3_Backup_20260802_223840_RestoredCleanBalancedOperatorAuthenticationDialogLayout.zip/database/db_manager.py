import os
import re
import time
import tempfile
import zipfile
import sqlite3
import pandas as pd

def sqlite3_connect_optimized(*args, **kwargs):
    kwargs.setdefault('timeout', 30.0)
    conn = sqlite3.connect(*args, **kwargs)
    conn = sqlite3.connect(*args, **kwargs)
    try:
        cursor = conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL;")
        cursor.execute("PRAGMA synchronous=NORMAL;")
        cursor.execute("PRAGMA cache_size=-64000;")  # 64MB cache
        cursor.execute("PRAGMA temp_store=MEMORY;")
    except Exception:
        pass
    return conn

def paybill_row_to_js(row):
    # Formats the raw sqlite database row array into JS objects for datatable parsing
    return {
        "id": row[0],
        "sr_no": row[1],
        "employee_name": row[2],
        "employee_code": row[3],
        "designation": row[4],
        "gpf_dpf_pran_ac": row[5],
        "bank_ac_no": row[6],
        "days_paid": row[7],
        "basic_pay": row[8],
        "da": row[9],
        "grade_pay_amount": row[10],
        "gross_salary": row[11],
        "total_treasury_deduction": row[12],
        "total_ag_deduction": row[13],
        "total_deductions": row[14],
        "net_salary": row[15],
        "ddo_code": row[16],
        "ddo_name": row[17],
        "bill_id": row[18],
        "bill_date": row[19],
        "bill_type": row[20],
        "month": row[21],
        "year": row[22],
        "pay_scale": row[23],
        "source_file": row[24],
        "explanation": row[29] if len(row) > 29 else ""
    }

def pol_row_to_js(row):
    return {
        "id": row[0],
        "sr_no": row[1],
        "party_code": row[2],
        "party_name": row[3],
        "entity_id": row[5],
        "voucher_no": row[6],
        "try_code_num": row[7],
        "try_code_char": row[8],
        "major_head": row[9],
        "fy_month": row[10],
        "fy_year": row[11],
        "serial_no": row[12],
        "date_of_payment": row[13],
        "payment_month": row[14],
        "payment_year": row[15],
        "amount_paid": row[16],
        "ifsc_code": row[17],
        "account_no": row[18],
        "payment_mode": row[20],
        "bill_ref_no": row[21],
        "advice_no": row[22],
        "cheque_no": row[23],
        "efile_no": row[24],
        "utr_no": row[25],
        "ddo_code": row[26],
        "ddo_name": row[27],
        "date_range": row[28],
        "source_file": row[29],
        "bill_type": row[30],
        "bank_name": row[31],
        "bank_branch": row[32],
        "explanation": row[34] if len(row) > 34 else ""
    }

def init_db_schema(db_path):
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL;")
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS payroll_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sr_no TEXT,
            employee_name TEXT,
            employee_code TEXT,
            designation TEXT,
            gpf_dpf_pran_ac TEXT,
            bank_ac_no TEXT,
            days_paid TEXT,
            basic_pay REAL,
            da REAL,
            grade_pay_amount REAL,
            gross_salary REAL,
            total_treasury_deduction REAL,
            total_ag_deduction REAL,
            total_deductions REAL,
            net_salary REAL,
            ddo_code TEXT,
            ddo_name TEXT,
            bill_id TEXT,
            bill_date TEXT,
            bill_type TEXT,
            month TEXT,
            year INTEGER,
            pay_scale TEXT,
            source_file TEXT,
            normalized_account_no TEXT,
            normalized_employee_name TEXT,
            allowances_json TEXT,
            deductions_json TEXT,
            import_hash TEXT
        );
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS pol_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sr_no TEXT,
            party_code TEXT,
            party_name TEXT,
            normalized_party_name TEXT,
            entity_id TEXT,
            voucher_no TEXT,
            try_code_num TEXT,
            try_code_char TEXT,
            major_head TEXT,
            fy_month TEXT,
            fy_year TEXT,
            serial_no TEXT,
            date_of_payment TEXT,
            payment_month TEXT,
            payment_year INTEGER,
            amount_paid REAL,
            ifsc_code TEXT,
            account_no TEXT,
            normalized_account_no TEXT,
            payment_mode TEXT,
            bill_ref_no TEXT,
            advice_no TEXT,
            cheque_no TEXT,
            efile_no TEXT,
            utr_no TEXT,
            ddo_code TEXT,
            ddo_name TEXT,
            date_range TEXT,
            source_file TEXT,
            bill_type TEXT,
            bank_name TEXT,
            bank_branch TEXT,
            import_hash TEXT
        );
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_findings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT,
            check_key TEXT,
            record_id INTEGER,
            rule_name TEXT,
            severity TEXT,
            explanation TEXT
        );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_paybill_emp_code ON payroll_records(employee_code);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_paybill_bank ON payroll_records(bank_ac_no);")

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS audit_results_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            treasury TEXT,
            major_head TEXT,
            month TEXT,
            year TEXT,
            voucher_no TEXT,
            amount TEXT,
            check_name TEXT,
            status TEXT,
            message TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(treasury, major_head, month, year, voucher_no, check_name) ON CONFLICT REPLACE
        );
        ''')
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_audit_cache_lookup ON audit_results_cache(treasury, major_head, month, year, voucher_no);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_paybill_hash ON payroll_records(import_hash);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_paybill_dup_detect ON payroll_records(import_hash, employee_code, year, month, net_salary);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_pol_voucher ON pol_records(voucher_no);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_pol_account ON pol_records(account_no);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_pol_hash ON pol_records(import_hash);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_pol_dup_detect ON pol_records(import_hash, normalized_account_no, voucher_no, amount_paid, party_code);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_findings_key ON audit_findings(category, check_key);")
    
        # Download History Cache for duplicate prevention & archive explorer
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS downloads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mode TEXT,
            treasury TEXT,
            major_head TEXT,
            month TEXT,
            year INTEGER,
            voucher_no TEXT,
            amount REAL,
            ddo_code TEXT,
            file_path TEXT,
            download_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_history_voucher ON downloads(voucher_no);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_history_dup ON downloads(mode, treasury, major_head, month, year, voucher_no);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_history_pol ON downloads(mode, treasury, ddo_code, month, year);")
    
        # Task Runs table — persistent tracking for self-healing supervisor
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS task_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id TEXT NOT NULL,
            mode TEXT NOT NULL,
            task_key TEXT NOT NULL,
            treasury TEXT,
            status TEXT DEFAULT 'pending',
            retry_count INTEGER DEFAULT 0,
            error_message TEXT,
            error_category TEXT,
            worker_id INTEGER,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_task_runs_key ON task_runs(run_id, task_key);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_task_runs_status ON task_runs(run_id, status);")
    
        # Voucher Attachment Fingerprints — for duplicate payment detection (v3.1)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS voucher_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            treasury TEXT NOT NULL,
            major_head TEXT,
            month INTEGER,
            year INTEGER,
            voucher_no TEXT NOT NULL,
            amount TEXT,
            ddo_code TEXT,
            attachment_filename TEXT NOT NULL,
            attachment_size INTEGER NOT NULL,
            attachment_md5 TEXT NOT NULL,
            folder_path TEXT,
            cataloged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_attach_amount ON voucher_attachments(amount);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_attach_size_md5 ON voucher_attachments(attachment_size, attachment_md5);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_attach_voucher ON voucher_attachments(treasury, voucher_no, year, month);")
    
        # Duplicate Payment Flags — stores confirmed flagged pairs (v3.1)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS duplicate_flags (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            voucher_a_key TEXT NOT NULL,
            voucher_b_key TEXT NOT NULL,
            amount TEXT,
            matching_attachments TEXT,
            match_count INTEGER,
            total_attachments_a INTEGER,
            total_attachments_b INTEGER,
            confidence TEXT,
            flagged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
    
        conn.commit()
    finally:
        if conn:
            conn.close()

def init_db(self):
    self.db_path = os.path.join(self.base_path, "ifmis_workspace.db")
    init_db_schema(self.db_path)

def get_payroll_stats(db_path, import_hash):
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 
                COUNT(*), 
                COUNT(DISTINCT source_file), 
                COUNT(DISTINCT bank_ac_no), 
                COUNT(DISTINCT employee_code), 
                COUNT(DISTINCT designation), 
                SUM(gross_salary), 
                SUM(net_salary), 
                SUM(total_deductions) 
            FROM payroll_records 
            WHERE import_hash = ?
        """, (import_hash,))
        row = cursor.fetchone()
        total_rows = row[0] or 0
        files_loaded = row[1] or 0
        unique_accounts = row[2] or 0
        unique_employees = row[3] or 0
        unique_designations = row[4] or 0
        total_gross = row[5] or 0.0
        total_net = row[6] or 0.0
        total_deductions = row[7] or 0.0
        return {
            "filesLoaded": files_loaded,
            "totalRows": total_rows,
            "uniqueAccounts": unique_accounts,
            "uniqueEmployees": unique_employees,
            "uniqueDesignations": unique_designations,
            "duplicatesRemoved": 0,
            "totalGrossAmount": total_gross,
            "totalNetAmount": total_net,
            "totalDeductions": total_deductions
        }
    finally:
        if conn:
            conn.close()

def get_pol_stats(db_path, import_hash):
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 
                COUNT(*), 
                COUNT(DISTINCT source_file), 
                COUNT(DISTINCT account_no), 
                COUNT(DISTINCT party_code), 
                SUM(amount_paid) 
            FROM pol_records 
            WHERE import_hash = ?
        """, (import_hash,))
        row = cursor.fetchone()
        total_rows = row[0] or 0
        files_loaded = row[1] or 0
        unique_accounts = row[2] or 0
        unique_parties = row[3] or 0
        total_amount = row[4] or 0.0
        return {
            "filesLoaded": files_loaded,
            "totalRows": total_rows,
            "uniqueAccounts": unique_accounts,
            "partyCodes": unique_parties,
            "duplicatesRemoved": 0,
            "totalAmount": total_amount
        }
    finally:
        if conn:
            conn.close()

def run_pol_audit(db_path, import_hash):
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        df = pd.read_sql_query("SELECT * FROM pol_records WHERE import_hash = ?", conn, params=(import_hash,))
        if df.empty:
            return
        findings = []
        
        # single_acct_multi_ben
        acct_parties = df.groupby('normalized_account_no')['party_code'].nunique()
        shared_accts = acct_parties[acct_parties > 1].index.tolist()
        flagged = df[df['normalized_account_no'].isin(shared_accts) & (df['normalized_account_no'] != '')]
        for idx, row in flagged.iterrows():
            others = df[(df['normalized_account_no'] == row['normalized_account_no']) & (df['party_code'] != row['party_code'])]
            other_parties = ", ".join(others['party_code'].unique())
            explanation = f"Account shared with other parties: {other_parties}"
            findings.append(('pol', 'single_acct_multi_ben', row['id'], 'Single Account - Multiple Beneficiaries', 'WARNING', explanation))
            
        # multi_party_account
        party_accts = df.groupby('party_code')['normalized_account_no'].nunique()
        multi_acct_parties = party_accts[party_accts > 1].index.tolist()
        flagged = df[df['party_code'].isin(multi_acct_parties)]
        for idx, row in flagged.iterrows():
            others = df[(df['party_code'] == row['party_code']) & (df['normalized_account_no'] != row['normalized_account_no'])]
            other_accts = ", ".join(others['account_no'].unique())
            explanation = f"Party has multiple accounts: {other_accts}"
            findings.append(('pol', 'multi_party_account', row['id'], 'Multi-Account Party', 'WARNING', explanation))
            
        # duplicate_utr
        dup_utr = df[(df['utr_no'].fillna('').str.strip() != '') & (df.duplicated(['utr_no'], keep=False))]
        for idx, row in dup_utr.iterrows():
            explanation = f"Duplicate UTR number found: {row['utr_no']}"
            findings.append(('pol', 'duplicate_utr', row['id'], 'Duplicate UTR No', 'WARNING', explanation))

        cursor = conn.cursor()
        cursor.execute("DELETE FROM audit_findings WHERE category = 'pol'")
        cursor.executemany("""
        INSERT INTO audit_findings (category, check_key, record_id, rule_name, severity, explanation)
        VALUES (?, ?, ?, ?, ?, ?)
        """, findings)
        conn.commit()
    finally:
        if conn:
            conn.close()

def run_payroll_audit(db_path, import_hash):
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        df = pd.read_sql_query("SELECT * FROM payroll_records WHERE import_hash = ?", conn, params=(import_hash,))
        if df.empty:
            return
        findings = []
        
        # shared_account
        dup_accts = df[df['normalized_account_no'].fillna('').str.strip() != '']
        dup_accts = dup_accts[dup_accts.groupby('normalized_account_no')['employee_code'].transform('nunique') > 1]
        for idx, row in dup_accts.iterrows():
            shares = dup_accts[dup_accts['normalized_account_no'] == row['normalized_account_no']]
            other_names = [f"{r['employee_code']} ({r['employee_name']})" for _, r in shares.iterrows() if r['employee_code'] != row['employee_code']]
            explanation = f"Account shared with: {', '.join(other_names)}"
            findings.append(('paybill', 'shared_account', row['id'], 'Shared Bank Accounts', 'WARNING', explanation))
            
        # duplicate_employees
        dup_emps = df[df.groupby(['employee_code', 'month', 'year'])['id'].transform('count') > 1]
        for idx, row in dup_emps.iterrows():
            explanation = f"Duplicate payroll record in {row['month']}/{row['year']}"
            findings.append(('paybill', 'duplicate_employees', row['id'], 'Duplicate Employee Records', 'WARNING', explanation))
            
        # zero_net_salary
        zero_sal = df[df['net_salary'] == 0]
        for idx, row in zero_sal.iterrows():
            explanation = f"Zero net salary (Gross: {row['gross_salary']}, Ded: {row['total_deductions']})"
            findings.append(('paybill', 'zero_net_salary', row['id'], 'Zero Net Salary', 'WARNING', explanation))

        cursor = conn.cursor()
        cursor.execute("DELETE FROM audit_findings WHERE category = 'paybill'")
        cursor.executemany("""
        INSERT INTO audit_findings (category, check_key, record_id, rule_name, severity, explanation)
        VALUES (?, ?, ?, ?, ?, ?)
        """, findings)
        conn.commit()
    finally:
        if conn:
            conn.close()

def generate_server_report(db_path, mode, import_hash):
    # Create temp zip file
    temp_zip_fd, temp_zip_path = tempfile.mkstemp(suffix='.zip')
    os.close(temp_zip_fd)
    
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        
        # Get distinct checks that actually have findings for this import hash
        table = "payroll_records" if mode == "paybill" else "pol_records"
        cursor.execute(f"""
        SELECT DISTINCT f.check_key, f.rule_name 
        FROM audit_findings f 
        JOIN {table} r ON f.record_id = r.id 
        WHERE r.import_hash = ? AND f.category = ?
        """, (import_hash, mode))
        checks = cursor.fetchall()
        
        with zipfile.ZipFile(temp_zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            # 1. Summary Sheet
            summary_rows = [
                [f"IFMS {mode.capitalize()} - Server Audit Analysis Report"],
                ["Generated:", time.strftime("%d-%b-%Y %H:%M:%S")],
                [""],
                ["DATASET STATISTICS"],
                ["Total Records Checked", 0],
                ["Flagged Anomalies Identified", 0],
                [""],
                ["RISK SUMMARY"],
                ["Analysis Check", "Flagged Count", "Status", "Severity"]
            ]
            
            # Get count of total records in table
            cursor.execute(f"SELECT COUNT(*) FROM {table} WHERE import_hash = ?", (import_hash,))
            total_records = cursor.fetchone()[0]
            summary_rows[4][1] = total_records
            
            # Get count of total flagged findings
            cursor.execute(f"""
            SELECT COUNT(*) 
            FROM audit_findings f 
            JOIN {table} r ON f.record_id = r.id 
            WHERE r.import_hash = ? AND f.category = ?
            """, (import_hash, mode))
            flagged_records = cursor.fetchone()[0]
            summary_rows[5][1] = flagged_records
            
            for ck, rule_name in checks:
                cursor.execute(f"""
                SELECT COUNT(*) 
                FROM audit_findings f 
                JOIN {table} r ON f.record_id = r.id 
                WHERE r.import_hash = ? AND f.category = ? AND f.check_key = ?
                """, (import_hash, mode, ck))
                count = cursor.fetchone()[0]
                status = "🔴 HIGH RISK" if count > 50 else ("⚠️ WARNING" if count > 0 else "✅ OK")
                summary_rows.append([rule_name, count, status, "HIGH" if count > 50 else "MEDIUM"])
                
            summary_df = pd.DataFrame(summary_rows[9:], columns=summary_rows[8])
            temp_csv_fd, temp_csv_path = tempfile.mkstemp(suffix='.csv')
            os.close(temp_csv_fd)
            
            try:
                with open(temp_csv_path, 'w', newline='', encoding='utf-8') as f_csv:
                    # Write custom header comments
                    f_csv.write("sep=,\n")
                    for r in summary_rows[:8]:
                        f_csv.write(",".join(map(lambda x: f'"{str(x)}"' if ',' in str(x) else str(x), r)) + "\n")
                summary_df.to_csv(temp_csv_path, mode='a', index=False, encoding='utf-8')
                zf.write(temp_csv_path, "Audit_Summary.csv")
            finally:
                if os.path.exists(temp_csv_path):
                    os.remove(temp_csv_path)
            
            # 2. Write flagged records for each check key
            for ck, rule_name in checks:
                clean_name = re.sub(r'[\\/*?:\[\]]', '-', rule_name)[:30].strip()
                temp_csv_fd, temp_csv_path = tempfile.mkstemp(suffix='.csv')
                os.close(temp_csv_fd)
                
                try:
                    first = True
                    has_data = False
                    for chunk in pd.read_sql_query(f"""
                        SELECT r.*, f.explanation 
                        FROM {table} r 
                        JOIN audit_findings f ON r.id = f.record_id 
                        WHERE r.import_hash = ? AND f.category = ? AND f.check_key = ?
                    """, conn, params=(import_hash, mode, ck), chunksize=50000):
                        if not chunk.empty:
                            has_data = True
                            chunk = chunk.drop(columns=['id', 'import_hash', 'allowances_json', 'deductions_json', 'ifsc_code', 'bank_name', 'bank_branch'], errors='ignore')
                            if first:
                                with open(temp_csv_path, 'w', newline='', encoding='utf-8') as f_csv:
                                    f_csv.write("sep=,\n")
                            chunk.to_csv(temp_csv_path, mode='a', header=first, index=False, encoding='utf-8')
                            first = False
                    if has_data:
                        zf.write(temp_csv_path, f"{clean_name}.csv")
                finally:
                    if os.path.exists(temp_csv_path):
                        os.remove(temp_csv_path)
    finally:
        if conn:
            conn.close()
    return temp_zip_path

# =========================================================
# DOWNLOAD CACHING HELPERS
# =========================================================

def save_download_record(db_path, mode, treasury, major_head, month, year, voucher_no, amount, ddo_code, file_path):
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        
        # Clean inputs
        treasury_clean = str(treasury).strip() if treasury else None
        major_head_clean = str(major_head).strip() if major_head else None
        month_clean = str(month).strip() if month else None
        try:
            year_val = int(year) if year else None
        except Exception:
            year_val = None
        voucher_clean = str(voucher_no).strip() if voucher_no else None
        try:
            amount_val = float(amount) if amount else 0.0
        except Exception:
            amount_val = 0.0
        ddo_clean = str(ddo_code).strip() if ddo_code else None
        
        cursor.execute("""
        INSERT INTO downloads (mode, treasury, major_head, month, year, voucher_no, amount, ddo_code, file_path)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (mode, treasury_clean, major_head_clean, month_clean, year_val, voucher_clean, amount_val, ddo_clean, file_path))
        conn.commit()
    except Exception as e:
        print(f"Error saving download record: {e}")
    finally:
        if conn:
            conn.close()

def is_voucher_downloaded(db_path, treasury, major_head, month, year, voucher_no):
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        
        # Clean inputs for matching
        treasury_clean = str(treasury).strip() if treasury else None
        major_head_clean = str(major_head).strip() if major_head else None
        month_clean = str(month).strip() if month else None
        try:
            year_val = int(year) if year else None
        except Exception:
            year_val = None
        voucher_clean = str(voucher_no).strip() if voucher_no else None
        
        # We check both voucher and paybill modes
        cursor.execute("""
        SELECT COUNT(*) FROM downloads 
        WHERE (mode = 'voucher' OR mode = 'paybill') 
          AND treasury = ? 
          AND major_head = ? 
          AND month = ? 
          AND year = ? 
          AND voucher_no = ?
        """, (treasury_clean, major_head_clean, month_clean, year_val, voucher_clean))
        count = cursor.fetchone()[0]
        return count > 0
    except Exception as e:
        print(f"Error checking duplicate: {e}")
        return False
    finally:
        if conn:
            conn.close()

def is_pol_downloaded(db_path, treasury, ddo_code, month, year):
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        
        treasury_clean = str(treasury).strip() if treasury else None
        ddo_clean = str(ddo_code).strip() if ddo_code else None
        month_clean = str(month).strip() if month else None
        try:
            year_val = int(year) if year else None
        except Exception:
            year_val = None
            
        cursor.execute("""
        SELECT COUNT(*) FROM downloads 
        WHERE mode = 'pol' 
          AND treasury = ? 
          AND ddo_code = ? 
          AND month = ? 
          AND year = ?
          AND file_path IS NOT NULL
          AND file_path != ''
          AND file_path != 'SKIPPED'
        """, (treasury_clean, ddo_clean, month_clean, year_val))
        count = cursor.fetchone()[0]
        return count > 0
    except Exception as e:
        print(f"Error checking duplicate POL: {e}")
        return False
    finally:
        if conn:
            conn.close()

# =========================================================
# TASK RUNS — SELF-HEALING SUPERVISOR HELPERS
# =========================================================

def record_task_attempt(db_path, run_id, mode, task_key, treasury=None, worker_id=None):
    """Record the start of a task attempt in the task_runs table."""
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute("""
        INSERT INTO task_runs (run_id, mode, task_key, treasury, status, worker_id, started_at)
        VALUES (?, ?, ?, ?, 'running', ?, datetime('now'))
        """, (run_id, mode, str(task_key).strip(), treasury, worker_id))
        conn.commit()
        return cursor.lastrowid
    except Exception as e:
        print(f"Error recording task attempt: {e}")
        return None
    finally:
        if conn:
            conn.close()


def update_task_result(db_path, task_run_id, status, error_message=None, error_category=None):
    """Update a task_runs record with the outcome of the attempt."""
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute("""
        UPDATE task_runs 
        SET status = ?, error_message = ?, error_category = ?, completed_at = datetime('now')
        WHERE id = ?
        """, (status, error_message, error_category, task_run_id))
        conn.commit()
    except Exception as e:
        print(f"Error updating task result: {e}")
    finally:
        if conn:
            conn.close()


def increment_task_retry(db_path, run_id, task_key):
    """Increment the retry_count for a specific task in the current run."""
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute("""
        UPDATE task_runs 
        SET retry_count = retry_count + 1, status = 'pending'
        WHERE run_id = ? AND task_key = ? AND status = 'failed'
        ORDER BY id DESC LIMIT 1
        """, (run_id, str(task_key).strip()))
        conn.commit()
    except Exception as e:
        print(f"Error incrementing retry count: {e}")
    finally:
        if conn:
            conn.close()


def get_failed_tasks(db_path, run_id, max_retries=3):
    """Get all failed tasks for a run that haven't exceeded the retry budget."""
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute("""
        SELECT task_key, mode, treasury, retry_count, error_category, error_message
        FROM task_runs 
        WHERE run_id = ? AND status = 'failed' AND retry_count < ?
        ORDER BY id
        """, (run_id, max_retries))
        return cursor.fetchall()
    except Exception as e:
        print(f"Error getting failed tasks: {e}")
        return []
    finally:
        if conn:
            conn.close()


def get_run_stats(db_path, run_id):
    """Get aggregate statistics for a run: counts by status."""
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute("""
        SELECT status, COUNT(*) as cnt
        FROM task_runs 
        WHERE run_id = ?
        GROUP BY status
        """, (run_id,))
        return dict(cursor.fetchall())
    except Exception as e:
        print(f"Error getting run stats: {e}")
        return {}
    finally:
        if conn:
            conn.close()


def get_error_distribution(db_path, run_id):
    """Get the distribution of error categories for failed tasks in a run."""
    conn = None
    try:
        conn = sqlite3_connect_optimized(db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute("""
        SELECT error_category, COUNT(*) as cnt
        FROM task_runs 
        WHERE run_id = ? AND status = 'failed' AND error_category IS NOT NULL
        GROUP BY error_category
        ORDER BY cnt DESC
        """, (run_id,))
        return dict(cursor.fetchall())
    except Exception as e:
        print(f"Error getting error distribution: {e}")
        return {}
    finally:
        if conn:
            conn.close()



# ── SQLite Audit Results Cache Helpers ─────────────────────────────────────
def save_audit_results_batch(db_path, results_list):
    """Fast bulk insertion of audit results into SQLite audit_results_cache table."""
    if not results_list or not db_path:
        return
    try:
        conn = sqlite3_connect_optimized(db_path)
        cursor = conn.cursor()
        data_rows = []
        for r in results_list:
            data_rows.append((
                str(r.get("treasury", "")),
                str(r.get("mh", "")),
                str(r.get("month", "")),
                str(r.get("year", "")),
                str(r.get("voucher_no", "")),
                str(r.get("amount", "")),
                str(r.get("check_name", "")),
                str(r.get("status", "")),
                str(r.get("message", ""))
            ))
        cursor.executemany("""
            INSERT OR REPLACE INTO audit_results_cache 
            (treasury, major_head, month, year, voucher_no, amount, check_name, status, message)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, data_rows)
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error saving audit results to SQLite cache: {e}")

def get_cached_audit_results(db_path, treasury=None, mh=None, month=None, year=None, voucher_no=None):
    """Retrieve cached audit results from SQLite table in 10ms."""
    if not db_path or not os.path.exists(db_path):
        return []
    try:
        conn = sqlite3_connect_optimized(db_path)
        cursor = conn.cursor()
        if treasury and mh and month and year and voucher_no:
            cursor.execute("""
                SELECT treasury, major_head, month, year, voucher_no, amount, check_name, status, message
                FROM audit_results_cache
                WHERE treasury=? AND major_head=? AND month=? AND year=? AND voucher_no=?
            """, (str(treasury), str(mh), str(month), str(year), str(voucher_no)))
        else:
            cursor.execute("""
                SELECT treasury, major_head, month, year, voucher_no, amount, check_name, status, message
                FROM audit_results_cache
            """)
        rows = cursor.fetchall()
        conn.close()
        
        results = []
        for row in rows:
            results.append({
                "treasury": row[0],
                "mh": row[1],
                "month": row[2],
                "year": row[3],
                "voucher_no": row[4],
                "amount": row[5],
                "check_name": row[6],
                "status": row[7],
                "message": row[8]
            })
        return results
    except Exception as e:
        print(f"Error fetching cached audit results from SQLite: {e}")
        return []
