# Responsive multi-theme color palettes for Centralized Voucher Validation Suite (Light, Dark)

THEMES = {
    "Emerald Teal (Dark)": {
        "APPEARANCE_MODE": "dark",
        "BG_WINDOW": ("#f0f2f5", "#0d1117"),
        "BG_SIDEBAR": ("#e1e4e8", "#161b22"),
        "BG_CARD": ("#ffffff", "#21262d"),
        "BORDER_COLOR": ("#d0d7de", "#30363d"),
        "TEXT_MAIN": ("#0f172a", "#f8fafc"),
        "TEXT_MUTED": ("#1e293b", "#8b949e"),
        "TEXT_HIGHLIGHT": ("#008060", "#00c9a7"),
        "BG_ENTRY": ("#ffffff", "#0d1117"),
        "BG_TEXTBOX": ("#ffffff", "#090d16"),
        
        "BTN_PRIMARY_BG": ("#008060", "#00c9a7"),
        "BTN_PRIMARY_HOVER": ("#00664d", "#00e5bf"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_SECONDARY_BG": ("#1d4ed8", "#3b82f6"),
        "BTN_SECONDARY_HOVER": ("#1e3a8a", "#1d4ed8"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_DANGER_BG": ("#dc2626", "#ef4444"),
        "BTN_DANGER_HOVER": ("#991b1b", "#dc2626"),
        "BTN_DANGER_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#008060", "#00c9a7"),
        "BTN_OUTLINE_TEXT": ("#008060", "#00c9a7"),
        "BTN_OUTLINE_HOVER": ("#e6f3f0", "#0c362d")
    },
    "Emerald Teal (Light)": {
        "APPEARANCE_MODE": "light",
        "BG_WINDOW": ("#e6f4f1", "#0d1117"),
        "BG_SIDEBAR": ("#d3ebe6", "#161b22"),
        "BG_CARD": ("#ffffff", "#21262d"),
        "BORDER_COLOR": ("#9ecbc2", "#30363d"),
        "TEXT_MAIN": ("#020617", "#f8fafc"),
        "TEXT_MUTED": ("#0f172a", "#8b949e"),
        "TEXT_HIGHLIGHT": ("#0f766e", "#00c9a7"),
        "BG_ENTRY": ("#f4faf9", "#0d1117"),
        "BG_TEXTBOX": ("#f0f8f6", "#090d16"),
        
        "BTN_PRIMARY_BG": ("#0f766e", "#00c9a7"),
        "BTN_PRIMARY_HOVER": ("#115e59", "#00e5bf"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_SECONDARY_BG": ("#2563eb", "#3b82f6"),
        "BTN_SECONDARY_HOVER": ("#1d4ed8", "#1d4ed8"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_DANGER_BG": ("#dc2626", "#ef4444"),
        "BTN_DANGER_HOVER": ("#b91c1c", "#dc2626"),
        "BTN_DANGER_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#0f766e", "#00c9a7"),
        "BTN_OUTLINE_TEXT": ("#0f766e", "#00c9a7"),
        "BTN_OUTLINE_HOVER": ("#e0f7f3", "#0c362d")
    },
    "Classic Sapphire (Dark)": {
        "APPEARANCE_MODE": "dark",
        "BG_WINDOW": ("#f1f5f9", "#080c14"),
        "BG_SIDEBAR": ("#e2e8f0", "#0e1626"),
        "BG_CARD": ("#ffffff", "#172237"),
        "BORDER_COLOR": ("#94a3b8", "#26354a"),
        "TEXT_MAIN": ("#020617", "#f1f5f9"),
        "TEXT_MUTED": ("#0f172a", "#94a3b8"),
        "TEXT_HIGHLIGHT": ("#1d4ed8", "#3b82f6"),
        "BG_ENTRY": ("#ffffff", "#080c14"),
        "BG_TEXTBOX": ("#ffffff", "#05080f"),
        
        "BTN_PRIMARY_BG": ("#1d4ed8", "#3b82f6"),
        "BTN_PRIMARY_HOVER": ("#1e3a8a", "#60a5fa"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#ffffff"),
        
        "BTN_SECONDARY_BG": ("#0f766e", "#14b8a6"),
        "BTN_SECONDARY_HOVER": ("#115e59", "#2dd4bf"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#0f172a"),
        
        "BTN_DANGER_BG": ("#dc2626", "#ef4444"),
        "BTN_DANGER_HOVER": ("#991b1b", "#dc2626"),
        "BTN_DANGER_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#1d4ed8", "#3b82f6"),
        "BTN_OUTLINE_TEXT": ("#1d4ed8", "#3b82f6"),
        "BTN_OUTLINE_HOVER": ("#eff6ff", "#101e36")
    },
    "Classic Sapphire (Light)": {
        "APPEARANCE_MODE": "light",
        "BG_WINDOW": ("#eaf2fd", "#080c14"),
        "BG_SIDEBAR": ("#dbe7f9", "#0e1626"),
        "BG_CARD": ("#ffffff", "#172237"),
        "BORDER_COLOR": ("#a3c4f3", "#26354a"),
        "TEXT_MAIN": ("#020617", "#f1f5f9"),
        "TEXT_MUTED": ("#0f172a", "#94a3b8"),
        "TEXT_HIGHLIGHT": ("#2563eb", "#3b82f6"),
        "BG_ENTRY": ("#f4f8fe", "#080c14"),
        "BG_TEXTBOX": ("#eff5fe", "#05080f"),
        
        "BTN_PRIMARY_BG": ("#2563eb", "#3b82f6"),
        "BTN_PRIMARY_HOVER": ("#1d4ed8", "#60a5fa"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#ffffff"),
        
        "BTN_SECONDARY_BG": ("#0f766e", "#14b8a6"),
        "BTN_SECONDARY_HOVER": ("#115e59", "#2dd4bf"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#0f172a"),
        
        "BTN_DANGER_BG": ("#dc2626", "#ef4444"),
        "BTN_DANGER_HOVER": ("#991b1b", "#dc2626"),
        "BTN_DANGER_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#2563eb", "#3b82f6"),
        "BTN_OUTLINE_TEXT": ("#2563eb", "#3b82f6"),
        "BTN_OUTLINE_HOVER": ("#eff6ff", "#101e36")
    },
    "Midnight Amethyst (Dark)": {
        "APPEARANCE_MODE": "dark",
        "BG_WINDOW": ("#fbfaff", "#0a0712"),
        "BG_SIDEBAR": ("#f0ebfc", "#140e24"),
        "BG_CARD": ("#ffffff", "#1f1635"),
        "BORDER_COLOR": ("#e1dbf5", "#322354"),
        "TEXT_MAIN": ("#1a0b36", "#f4f0fa"),
        "TEXT_MUTED": ("#1a0b36", "#a799c4"),
        "TEXT_HIGHLIGHT": ("#7c3aed", "#a78bfa"),
        "BG_ENTRY": ("#ffffff", "#0a0712"),
        "BG_TEXTBOX": ("#ffffff", "#06040b"),
        
        "BTN_PRIMARY_BG": ("#7c3aed", "#a78bfa"),
        "BTN_PRIMARY_HOVER": ("#6d28d9", "#c084fc"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#120224"),
        
        "BTN_SECONDARY_BG": ("#0284c7", "#38bdf8"),
        "BTN_SECONDARY_HOVER": ("#0369a1", "#7dd3fc"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#0a0712"),
        
        "BTN_DANGER_BG": ("#dc2626", "#ef4444"),
        "BTN_DANGER_HOVER": ("#991b1b", "#dc2626"),
        "BTN_DANGER_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#7c3aed", "#a78bfa"),
        "BTN_OUTLINE_TEXT": ("#7c3aed", "#a78bfa"),
        "BTN_OUTLINE_HOVER": ("#f5f3ff", "#180d2b")
    },
    "Midnight Amethyst (Light)": {
        "APPEARANCE_MODE": "light",
        "BG_WINDOW": ("#f3edfd", "#0a0712"),
        "BG_SIDEBAR": ("#e8dcfb", "#140e24"),
        "BG_CARD": ("#ffffff", "#1f1635"),
        "BORDER_COLOR": ("#cbb5f7", "#322354"),
        "TEXT_MAIN": ("#1a0b36", "#f4f0fa"),
        "TEXT_MUTED": ("#2e1065", "#a799c4"),
        "TEXT_HIGHLIGHT": ("#7c3aed", "#a78bfa"),
        "BG_ENTRY": ("#f9f5fe", "#0a0712"),
        "BG_TEXTBOX": ("#f5f0fe", "#06040b"),
        
        "BTN_PRIMARY_BG": ("#7c3aed", "#a78bfa"),
        "BTN_PRIMARY_HOVER": ("#6d28d9", "#c084fc"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#120224"),
        
        "BTN_SECONDARY_BG": ("#0284c7", "#38bdf8"),
        "BTN_SECONDARY_HOVER": ("#0369a1", "#7dd3fc"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#0a0712"),
        
        "BTN_DANGER_BG": ("#dc2626", "#ef4444"),
        "BTN_DANGER_HOVER": ("#991b1b", "#dc2626"),
        "BTN_DANGER_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#7c3aed", "#a78bfa"),
        "BTN_OUTLINE_TEXT": ("#7c3aed", "#a78bfa"),
        "BTN_OUTLINE_HOVER": ("#f5f3ff", "#180d2b")
    },
    "Crimson Ruby (Dark)": {
        "APPEARANCE_MODE": "dark",
        "BG_WINDOW": ("#fdfafb", "#0f080a"),
        "BG_SIDEBAR": ("#f7eaed", "#1c0f13"),
        "BG_CARD": ("#ffffff", "#2c171e"),
        "BORDER_COLOR": ("#edd0d7", "#482631"),
        "TEXT_MAIN": ("#3c0d18", "#faeff2"),
        "TEXT_MUTED": ("#3c0d18", "#cda5b0"),
        "TEXT_HIGHLIGHT": ("#e11d48", "#fb7185"),
        "BG_ENTRY": ("#ffffff", "#0f080a"),
        "BG_TEXTBOX": ("#ffffff", "#0a0406"),
        
        "BTN_PRIMARY_BG": ("#e11d48", "#fb7185"),
        "BTN_PRIMARY_HOVER": ("#be123c", "#fda4af"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#1f0007"),
        
        "BTN_SECONDARY_BG": ("#4f46e5", "#818cf8"),
        "BTN_SECONDARY_HOVER": ("#3730a3", "#a5b4fc"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#fdfafb"),
        
        "BTN_DANGER_BG": ("#b91c1c", "#f87171"),
        "BTN_DANGER_HOVER": ("#7f1d1d", "#f87171"),
        "BTN_DANGER_TEXT": ("#ffffff", "#ffffff"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#e11d48", "#fb7185"),
        "BTN_OUTLINE_TEXT": ("#e11d48", "#fb7185"),
        "BTN_OUTLINE_HOVER": ("#fff1f2", "#260e16")
    },
    "Crimson Ruby (Light)": {
        "APPEARANCE_MODE": "light",
        "BG_WINDOW": ("#fdeef1", "#0f080a"),
        "BG_SIDEBAR": ("#f9d8de", "#1c0f13"),
        "BG_CARD": ("#ffffff", "#2c171e"),
        "BORDER_COLOR": ("#f4a8b7", "#482631"),
        "TEXT_MAIN": ("#4c0519", "#faeff2"),
        "TEXT_MUTED": ("#881337", "#cda5b0"),
        "TEXT_HIGHLIGHT": ("#e11d48", "#fb7185"),
        "BG_ENTRY": ("#fcf2f4", "#0f080a"),
        "BG_TEXTBOX": ("#faeaed", "#0a0406"),
        
        "BTN_PRIMARY_BG": ("#e11d48", "#fb7185"),
        "BTN_PRIMARY_HOVER": ("#be123c", "#fda4af"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#1f0007"),
        
        "BTN_SECONDARY_BG": ("#4f46e5", "#818cf8"),
        "BTN_SECONDARY_HOVER": ("#3730a3", "#a5b4fc"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#fdfafb"),
        
        "BTN_DANGER_BG": ("#b91c1c", "#f87171"),
        "BTN_DANGER_HOVER": ("#7f1d1d", "#f87171"),
        "BTN_DANGER_TEXT": ("#ffffff", "#ffffff"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#e11d48", "#fb7185"),
        "BTN_OUTLINE_TEXT": ("#e11d48", "#fb7185"),
        "BTN_OUTLINE_HOVER": ("#fff1f2", "#260e16")
    },
    "Nordic Frost (Dark)": {
        "APPEARANCE_MODE": "dark",
        "BG_WINDOW": ("#f0f4f8", "#0f171e"),
        "BG_SIDEBAR": ("#d9e2ec", "#1b262c"),
        "BG_CARD": ("#ffffff", "#243b53"),
        "BORDER_COLOR": ("#94a3b8", "#334e68"),
        "TEXT_MAIN": ("#020617", "#f0f4f8"),
        "TEXT_MUTED": ("#0f172a", "#9fb3c8"),
        "TEXT_HIGHLIGHT": ("#0083b0", "#00b4db"),
        "BG_ENTRY": ("#ffffff", "#0f171e"),
        "BG_TEXTBOX": ("#ffffff", "#080f14"),
        
        "BTN_PRIMARY_BG": ("#0083b0", "#00b4db"),
        "BTN_PRIMARY_HOVER": ("#005f73", "#33c9eb"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#0f171e"),
        
        "BTN_SECONDARY_BG": ("#486581", "#627d98"),
        "BTN_SECONDARY_HOVER": ("#334e68", "#829ab1"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#f0f4f8"),
        
        "BTN_DANGER_BG": ("#dc2626", "#ef4444"),
        "BTN_DANGER_HOVER": ("#991b1b", "#dc2626"),
        "BTN_DANGER_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#0083b0", "#00b4db"),
        "BTN_OUTLINE_TEXT": ("#0083b0", "#00b4db"),
        "BTN_OUTLINE_HOVER": ("#e0f7fa", "#0c2b33")
    },
    "Nordic Frost (Light)": {
        "APPEARANCE_MODE": "light",
        "BG_WINDOW": ("#e8f0f8", "#0f171e"),
        "BG_SIDEBAR": ("#d8e5f2", "#1b262c"),
        "BG_CARD": ("#ffffff", "#243b53"),
        "BORDER_COLOR": ("#a5c4dd", "#334e68"),
        "TEXT_MAIN": ("#020617", "#f0f4f8"),
        "TEXT_MUTED": ("#0f172a", "#9fb3c8"),
        "TEXT_HIGHLIGHT": ("#2980b9", "#00b4db"),
        "BG_ENTRY": ("#f1f6fb", "#0f171e"),
        "BG_TEXTBOX": ("#ebf3fa", "#080f14"),
        
        "BTN_PRIMARY_BG": ("#2980b9", "#00b4db"),
        "BTN_PRIMARY_HOVER": ("#3498db", "#33c9eb"),
        "BTN_PRIMARY_TEXT": ("#ffffff", "#0f171e"),
        
        "BTN_SECONDARY_BG": ("#7f8c8d", "#627d98"),
        "BTN_SECONDARY_HOVER": ("#95a5a6", "#829ab1"),
        "BTN_SECONDARY_TEXT": ("#ffffff", "#f0f4f8"),
        
        "BTN_DANGER_BG": ("#dc2626", "#ef4444"),
        "BTN_DANGER_HOVER": ("#991b1b", "#dc2626"),
        "BTN_DANGER_TEXT": ("#ffffff", "#f8fafc"),
        
        "BTN_WARNING_BG": ("#d97706", "#f59e0b"),
        "BTN_WARNING_HOVER": ("#b45309", "#d97706"),
        "BTN_WARNING_TEXT": ("#ffffff", "#0d1117"),
        
        "BTN_OUTLINE_BG": "transparent",
        "BTN_OUTLINE_BORDER": ("#2980b9", "#00b4db"),
        "BTN_OUTLINE_TEXT": ("#2980b9", "#00b4db"),
        "BTN_OUTLINE_HOVER": ("#eaf2f8", "#0c2b33")
    }
}

# Backward-compatibility fallback (Emerald Teal)
BG_WINDOW = THEMES["Emerald Teal (Dark)"]["BG_WINDOW"]
BG_SIDEBAR = THEMES["Emerald Teal (Dark)"]["BG_SIDEBAR"]
BG_CARD = THEMES["Emerald Teal (Dark)"]["BG_CARD"]
BORDER_COLOR = THEMES["Emerald Teal (Dark)"]["BORDER_COLOR"]
TEXT_MAIN = THEMES["Emerald Teal (Dark)"]["TEXT_MAIN"]
TEXT_MUTED = THEMES["Emerald Teal (Dark)"]["TEXT_MUTED"]
TEXT_HIGHLIGHT = THEMES["Emerald Teal (Dark)"]["TEXT_HIGHLIGHT"]
BG_ENTRY = THEMES["Emerald Teal (Dark)"]["BG_ENTRY"]
BG_TEXTBOX = THEMES["Emerald Teal (Dark)"]["BG_TEXTBOX"]

BTN_PRIMARY_BG = THEMES["Emerald Teal (Dark)"]["BTN_PRIMARY_BG"]
BTN_PRIMARY_HOVER = THEMES["Emerald Teal (Dark)"]["BTN_PRIMARY_HOVER"]
BTN_PRIMARY_TEXT = THEMES["Emerald Teal (Dark)"]["BTN_PRIMARY_TEXT"]

BTN_SECONDARY_BG = THEMES["Emerald Teal (Dark)"]["BTN_SECONDARY_BG"]
BTN_SECONDARY_HOVER = THEMES["Emerald Teal (Dark)"]["BTN_SECONDARY_HOVER"]
BTN_SECONDARY_TEXT = THEMES["Emerald Teal (Dark)"]["BTN_SECONDARY_TEXT"]

BTN_DANGER_BG = THEMES["Emerald Teal (Dark)"]["BTN_DANGER_BG"]
BTN_DANGER_HOVER = THEMES["Emerald Teal (Dark)"]["BTN_DANGER_HOVER"]
BTN_DANGER_TEXT = THEMES["Emerald Teal (Dark)"]["BTN_DANGER_TEXT"]

BTN_WARNING_BG = THEMES["Emerald Teal (Dark)"]["BTN_WARNING_BG"]
BTN_WARNING_HOVER = THEMES["Emerald Teal (Dark)"]["BTN_WARNING_HOVER"]
BTN_WARNING_TEXT = THEMES["Emerald Teal (Dark)"]["BTN_WARNING_TEXT"]

BTN_OUTLINE_BG = THEMES["Emerald Teal (Dark)"]["BTN_OUTLINE_BG"]
BTN_OUTLINE_BORDER = THEMES["Emerald Teal (Dark)"]["BTN_OUTLINE_BORDER"]
BTN_OUTLINE_TEXT = THEMES["Emerald Teal (Dark)"]["BTN_OUTLINE_TEXT"]
BTN_OUTLINE_HOVER = THEMES["Emerald Teal (Dark)"]["BTN_OUTLINE_HOVER"]
