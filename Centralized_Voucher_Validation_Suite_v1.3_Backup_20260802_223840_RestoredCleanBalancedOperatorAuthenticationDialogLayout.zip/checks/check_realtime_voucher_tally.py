import os
from checks.base_check import BaseValidationCheck
from parsers.mptc_parser import parse_mptc_pdf
from parsers.party_details_parser import parse_party_details_pdf


class CheckRealtimeVoucherTally(BaseValidationCheck):
    check_id = "check_realtime_voucher_tally"
    name = "Realtime Voucher Tally Verification Check"
    description = "Real-time verification of scraped bill total / MPTC total against Excel input amount."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            # 1. Extract Input Amount from Excel
            input_amt_raw = voucher_data.get("amount", 0.0)
            try:
                input_amt = float(str(input_amt_raw).replace(",", "").strip())
            except (ValueError, TypeError):
                input_amt = 0.0

            # 2. Extract Portal Totals, Deductions, and Net Paid Amount
            portal_total = float(voucher_data.get("scraped_amount", 0.0) or voucher_data.get("gross_amount", 0.0) or voucher_data.get("expenditure_amount", 0.0))
            total_deductions = float(voucher_data.get("total_deductions", 0.0))
            net_amount = float(voucher_data.get("net_amount", 0.0))
            
            # Fallback for net_amount if 0.0
            if net_amount == 0.0 and portal_total > 0:
                net_amount = max(0.0, portal_total - total_deductions)

            # 3. Fallback to PDF parsers if scraped amounts are missing
            source_label = "Portal Scraped"
            if portal_total == 0.0:
                mptc_path = os.path.join(download_folder, "Show_MPTC.pdf")
                if os.path.exists(mptc_path):
                    mptc_data = parse_mptc_pdf(mptc_path)
                    if mptc_data.total_amount > 0:
                        portal_total = mptc_data.total_amount
                        net_amount = portal_total - total_deductions
                        source_label = "MPTC PDF"

                if portal_total == 0.0:
                    party_path = os.path.join(download_folder, "Party_Details.pdf")
                    if os.path.exists(party_path):
                        party_data = parse_party_details_pdf(party_path)
                        total_party = sum(p.get("amount", 0.0) for p in party_data.parties)
                        if total_party > 0:
                            portal_total = total_party
                            net_amount = portal_total - total_deductions
                            source_label = "Party Details PDF"

            if portal_total == 0.0 and input_amt == 0.0:
                return {
                    "status": "SKIPPED",
                    "message": "Real-time Tally: No input or scraped amount available to compare.",
                    "details": {"input_amount": 0.0, "scraped_amount": 0.0}
                }

            if portal_total == 0.0:
                return {
                    "status": "WARNING",
                    "message": "Real-time Tally: Input amount is ₹{:,.2f}, but could not determine scraped/MPTC total.".format(input_amt),
                    "details": {"input_amount": input_amt, "scraped_amount": 0.0}
                }

            # 4. v3.5 Tally Engine Differential & Deduction Calculations
            gross_dev = abs(input_amt - portal_total)
            gross_dev_pct = (gross_dev / portal_total * 100.0) if portal_total > 0 else 0.0
            net_dev = abs(input_amt - net_amount) if net_amount > 0 else gross_dev
            net_dev_pct = (net_dev / net_amount * 100.0) if net_amount > 0 else 0.0

            # Deduction differential match check
            ded_diff = abs(gross_dev - total_deductions)
            is_deduction_matched = (total_deductions > 0) and (abs(net_dev) < 1.00 or ded_diff < 1.00)
            is_within_tolerance = (portal_total > 0 and abs(gross_dev) <= (portal_total * 0.02)) or (net_amount > 0 and abs(net_dev) <= (net_amount * 0.02))

            details = {
                "input_amount": input_amt,
                "portal_total": portal_total,
                "net_amount": net_amount,
                "total_deductions": total_deductions,
                "gross_dev": gross_dev,
                "net_dev": net_dev,
                "source": source_label
            }

            # 5. Determine Tally Pass vs Mismatch according to v3.5 Rules
            if abs(gross_dev) < 1.00:
                return {
                    "status": "PASS",
                    "message": "Real-time Tally MATCHED (Exact Gross) : Input ₹{:,.2f} == Voucher Gross ₹{:,.2f}".format(input_amt, portal_total),
                    "details": details
                }
            elif is_deduction_matched:
                return {
                    "status": "PASS",
                    "message": "Real-time Tally MATCHED (Net Paid Amount after Deductions ₹{:,.2f}) : Input ₹{:,.2f} == Net Paid ₹{:,.2f} (Gross ₹{:,.2f})".format(total_deductions, input_amt, net_amount, portal_total),
                    "details": details
                }
            elif is_within_tolerance:
                eff_dev = min(gross_dev, net_dev)
                return {
                    "status": "PASS",
                    "message": "Real-time Tally MATCHED (within 2% tolerance, Dev ₹{:,.2f}) : Input ₹{:,.2f} ~ Voucher ₹{:,.2f}".format(eff_dev, input_amt, portal_total),
                    "details": details
                }
            else:
                eff_dev = min(gross_dev, net_dev)
                eff_dev_pct = (eff_dev / portal_total * 100.0) if portal_total > 0 else 0.0
                details["eff_dev"] = eff_dev
                details["eff_dev_pct"] = eff_dev_pct

                if total_deductions > 0:
                    msg = "Real-time Tally MISMATCH! Input ₹{:,.2f} != Voucher Gross ₹{:,.2f} / Net ₹{:,.2f} (Deductions: ₹{:,.2f}, Dev: ₹{:,.2f} | {:.2f}%)".format(input_amt, portal_total, net_amount, total_deductions, eff_dev, eff_dev_pct)
                else:
                    msg = "Real-time Tally MISMATCH! Input ₹{:,.2f} != Voucher Gross ₹{:,.2f} (Dev: ₹{:,.2f} | {:.2f}%)".format(input_amt, portal_total, eff_dev, eff_dev_pct)
                return {
                    "status": "MISMATCH",
                    "message": msg,
                    "details": details
                }

        except Exception as e:
            return {
                "status": "FAIL",
                "message": "Error in Voucher Tally Check: {}".format(str(e)),
                "details": {}
            }
