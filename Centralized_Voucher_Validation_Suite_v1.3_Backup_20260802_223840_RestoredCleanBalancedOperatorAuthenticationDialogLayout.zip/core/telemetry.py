import time
# core/telemetry.py
# Centralized Voucher Validation Suite v3.2.2 — Remote telemetry and logging

import os
import sys
import json
import socket
import platform
import getpass
import re
import datetime
import threading
import urllib.request
import urllib.parse
from core.constants import TOOL_VERSION, RUN_ID

TELEMETRY_URL = "https://script.google.com/macros/s/AKfycbz3bZ6vhzPIZS8Wz3K3SGtyg-qAiHqfstkh4AJDQ2sQzCxlPidjKh9pe9eNcjJZGCGP/exec"

def get_system_info():
    try:
        return {
            "os": platform.platform(),
            "os_version": platform.version(),
            "architecture": platform.machine(),
            "windows_user": getpass.getuser(),
            "python_version": platform.python_version()
        }
    except Exception:
        return {}

def get_playwright_version():
    try:
        from importlib.metadata import version as pkg_version
        return pkg_version("playwright")
    except Exception:
        try:
            import pkg_resources
            return pkg_resources.get_distribution("playwright").version
        except Exception:
            return "UNKNOWN"

def get_ip_address():
    local_ip = "UNKNOWN_LOCAL"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception: pass

    public_ip = "BLOCKED_BY_FIREWALL"
    ip_apis = ["http://checkip.amazonaws.com", "https://icanhazip.com", "https://api.ipify.org"]
    for api in ip_apis:
        try:
            req = urllib.request.Request(api, headers={'User-Agent': 'Mozilla/5.0'})
            response = urllib.request.urlopen(req, timeout=4).read().decode('utf-8').strip()
            if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", response):
                public_ip = response
                break
        except Exception: continue

    return f"Pub:{public_ip} | Loc:{local_ip}"

def send_silent_log(username, combined_data):
    try:
        if TELEMETRY_URL and TELEMETRY_URL.strip():
            req = urllib.request.Request(
                TELEMETRY_URL.strip(),
                data=combined_data.encode("utf-8"),
                headers={"Content-Type": "application/json"}
            )
            urllib.request.urlopen(req, timeout=5)
            return

        google_form_url = "https://docs.google.com/forms/d/e/1FAIpQLSeStAIOE96quY9zPR4GkScQf1ZHAuoKfCHnas-37MEDHDJzkg/formResponse"
        form_data = {"entry.872389760": username, "entry.968476556": combined_data}
        data = urllib.parse.urlencode(form_data).encode("utf-8")
        req = urllib.request.Request(google_form_url, data=data)
        urllib.request.urlopen(req, timeout=3)
    except Exception: pass

def send_startup_telemetry(operator_name, my_hwid, key_str, valid, msg):
    try:
        system_info = get_system_info()
        telemetry_payload = {
            "run_id": RUN_ID,
            "tool_version": TOOL_VERSION,
            "event": "startup",
            "operator": operator_name,
            "pc_name": socket.gethostname(),
            "hwid": my_hwid,
            "ip": get_ip_address(),
            "os": system_info.get("os"),
            "os_version": system_info.get("os_version"),
            "architecture": system_info.get("architecture"),
            "windows_user": system_info.get("windows_user"),
            "python_version": system_info.get("python_version"),
            "playwright_version": get_playwright_version(),
            "license_key": key_str[:20] + "..." if key_str else "NONE",
            "license_status": "VALID" if valid else "INVALID",
            "license_expiry": msg if valid else "EXPIRED",
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        send_silent_log(operator_name, json.dumps(telemetry_payload))
    except Exception:
        pass
