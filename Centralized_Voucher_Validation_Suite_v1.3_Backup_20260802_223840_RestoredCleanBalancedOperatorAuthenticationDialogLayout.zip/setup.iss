; Inno Setup Script for Centralized Voucher Validation Suite v1.2
; Handles professional installation, uninstallation, desktop shortcuts, and browser dependencies.

#define MyAppName "Centralized Voucher Validation Suite"
#define MyAppVersion "1.2"
#define MyAppExeName "Centralized_Voucher_Validation_Suite.exe"
#define MyAppPublisher "Office of the Accountant General (A&E) MP"

[Setup]
AppId={{8A19F8D2-4C7B-4E3A-91D0-E9A284F3612B}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
LicenseFile=terms.txt
DefaultDirName={localappdata}\Programs\{#MyAppName}
DisableDirPage=no
DisableProgramGroupPage=yes
DefaultGroupName={#MyAppName}
OutputDir=output
OutputBaseFilename=Centralized_Voucher_Validation_Suite_Setup_v1.2
SetupIconFile=cag_logo.ico
PrivilegesRequired=lowest
CloseApplications=force
RestartApplications=no
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
DisableWelcomePage=no
UninstallDisplayIcon={app}\cag_logo.ico

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[InstallDelete]
Type: files; Name: "{app}\Centralized_Voucher_Validation_Suite.exe"
Type: files; Name: "{app}\ifmis_365_suite.exe"
Type: files; Name: "{autodesktop}\Centralized Voucher Validation Suite.lnk"
Type: files; Name: "{group}\Centralized Voucher Validation Suite.lnk"

[Files]
Source: "Centralized_Voucher_Validation_Suite.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "license_generator.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "ddo.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "terms.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "cag_logo.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "cag_logo.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "logo.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "logo.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "data\*"; DestDir: "{app}\data"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "pw-browsers\*"; DestDir: "{app}\pw-browsers"; Flags: ignoreversion recursesubdirs createallsubdirs

[Dirs]
Name: "{userdesktop}\CVVS Downloads"
Name: "{app}\USER_DATA"

[Icons]
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\cag_logo.ico"; Tasks: desktopicon
Name: "{userdesktop}\CVVS Downloads"; Filename: "{userdesktop}\CVVS Downloads"; Tasks: desktopicon
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\cag_logo.ico"
Name: "{group}\License Generator"; Filename: "{app}\license_generator.exe"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

