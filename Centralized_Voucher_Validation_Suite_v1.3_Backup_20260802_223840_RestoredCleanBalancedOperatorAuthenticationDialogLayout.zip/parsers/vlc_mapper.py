# parsers/vlc_mapper.py
# Voucher Level Classification (VLC) to POL Data Mapping & Enrichment Helper
# Centralized Voucher Validation Suite v1.2

import os
import re
import csv

class VLCMapper:
    """Helper to map and enrich POL data using VLC (Voucher Level Classification) data."""

    LABOUR_KEYWORDS = [
        "labour", "labor", "mazdoor", "majdur", "daily wages", "wages",
        "mustroll", "muster roll", "coolie", "beldar", "manpower"
    ]

    def __init__(self):
        self.vlc_index = {}  # composite_key -> list of VLC detail records

    @staticmethod
    def make_key(voucher_no, mh, treasury, month, year):
        """Construct normalized composite key for matching."""
        v = str(voucher_no or "").strip().lstrip("0")
        m = str(mh or "").strip().lstrip("0")
        t = str(treasury or "").strip().lstrip("0")
        mo = str(month or "").strip()
        yr = str(year or "").strip()
        return (v, m, t, mo, yr)

    def load_vlc_file(self, file_path: str) -> int:
        """Load VLC records from Excel or CSV file."""
        if not os.path.exists(file_path):
            return 0

        records_loaded = 0
        if file_path.endswith((".xlsx", ".xls")):
            try:
                import openpyxl
                wb = openpyxl.load_workbook(file_path, data_only=True)
                ws = wb.active
                headers = [str(ws.cell(row=1, column=c).value or "").strip().lower() for c in range(1, ws.max_column + 1)]
                
                for r in range(2, ws.max_row + 1):
                    row_dict = {}
                    for c, h in enumerate(headers, 1):
                        row_dict[h] = str(ws.cell(row=r, column=c).value or "").strip()
                    
                    self._add_record_to_index(row_dict)
                    records_loaded += 1
            except Exception as e:
                print(f"Error loading VLC Excel {file_path}: {e}")
        elif file_path.endswith(".csv"):
            try:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        clean_row = {str(k).strip().lower(): str(v).strip() for k, v in row.items()}
                        self._add_record_to_index(clean_row)
                        records_loaded += 1
            except Exception as e:
                print(f"Error loading VLC CSV {file_path}: {e}")

        return records_loaded

    def _add_record_to_index(self, row: dict):
        """Helper to index a VLC record by composite key."""
        v = row.get("voucher_no") or row.get("voucher") or row.get("vno") or row.get("sop_vch_no") or ""
        m = row.get("major_head") or row.get("mh") or row.get("mhcd") or ""
        t = row.get("treasury") or row.get("try_cd") or row.get("treasury_code") or ""
        mo = row.get("month") or ""
        yr = row.get("year") or ""

        key = self.make_key(v, m, t, mo, yr)
        if key not in self.vlc_index:
            self.vlc_index[key] = []
        self.vlc_index[key].append(row)

    def enrich_pol_row(self, pol_row: dict) -> dict:
        """Enrich a single POL data row with VLC classification details."""
        enriched = dict(pol_row)
        key = self.make_key(
            pol_row.get("voucher"),
            pol_row.get("mh"),
            pol_row.get("treasury"),
            pol_row.get("month"),
            pol_row.get("year")
        )

        vlc_matches = self.vlc_index.get(key, [])
        if vlc_matches:
            # Combine Detail_Head, Scheme_Head, Narration, Object_Head
            detail_heads = list(dict.fromkeys(r.get("detail_head", "") for r in vlc_matches if r.get("detail_head")))
            scheme_heads = list(dict.fromkeys(r.get("scheme_head", "") or r.get("scheme_code", "") for r in vlc_matches if r.get("scheme_head") or r.get("scheme_code")))
            narrations = list(dict.fromkeys(r.get("narration", "") or r.get("remarks", "") for r in vlc_matches if r.get("narration") or r.get("remarks")))
            object_heads = list(dict.fromkeys(r.get("object_head", "") or r.get("oh", "") for r in vlc_matches if r.get("object_head") or r.get("oh")))

            enriched["detail_head"] = ", ".join(detail_heads) if detail_heads else pol_row.get("detail_head", "")
            enriched["scheme_head"] = ", ".join(scheme_heads) if scheme_heads else pol_row.get("scheme_head", "")
            enriched["narration"] = " | ".join(narrations) if narrations else pol_row.get("narration", "")
            enriched["object_head"] = ", ".join(object_heads) if object_heads else pol_row.get("object_head", "")
            enriched["vlc_mapped"] = True
        else:
            enriched["vlc_mapped"] = False

        return enriched

    @classmethod
    def is_labour_payment(cls, narration: str, detail_head: str = "", object_head: str = "") -> bool:
        """Check if narration or classification keywords indicate labour/mazdoor payment."""
        n_lower = str(narration or "").lower()
        has_keyword = any(kw in n_lower for kw in cls.LABOUR_KEYWORDS)
        is_wages_head = str(detail_head).strip() in ("012", "12") or str(object_head).strip() in ("12", "012")
        return has_keyword or is_wages_head
