#!/usr/bin/env python3
# =========================================================
# IFMIS SUITE v3.5 — PySide6 ENTRY POINT
# =========================================================
# This is the main entry point for the PySide6 version. It:
#   1. Shows a Qt splash screen
#   2. Asks for operator identity (Qt dialog)
#   3. Checks license/security
#   4. Lazy-loads heavy engines
#   5. Launches the main window
# =========================================================

import os
import sys
import json
import multiprocessing

# ── Path setup ──────────────────────────────────────────
if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(sys.executable)
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)

PW_BROWSER_DIR = os.path.join(APP_DIR, "pw-browsers")
if os.path.isdir(PW_BROWSER_DIR):
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = PW_BROWSER_DIR
else:
    fallback_paths = [
        r"C:\Users\nitin\My Drive (ifmisdevelopment@gmail.com)\IFMIS_Suite_Source_Backup_v3.2.2\pw-browsers",
        r"D:\BUILDING and TESTING\IFMIS_Suite_Source_Backup_v3.2.2\pw-browsers",
        r"D:\BUILDING and TESTING\IFMIS_Suite_Source_Backup_3.1.3\pw-browsers",
        r"D:\BUILDING and TESTING\IFMIS_Suite_Source_Backup_v3.1.2\pw-browsers"
    ]
    for p in fallback_paths:
        if os.path.isdir(p):
            os.environ["PLAYWRIGHT_BROWSERS_PATH"] = p
            break


# ── DPI awareness (Windows) ────────────────────────────
if sys.platform == "win32":
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

# ── Import compatibility layer first ──────────────
import gui.qt_compat

# ── PySide6 imports ────────────────────────────────────
from PySide6.QtWidgets import (
    QApplication, QSplashScreen, QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QMessageBox, QCheckBox, QTextEdit
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap, QFont, QColor, QPainter, QIcon


def get_app_icon():
    """Return QIcon loaded from cag_logo.ico, logo.ico, cag_logo.png, or logo.png."""
    for filename in ["cag_logo.ico", "logo.ico", "cag_logo.png", "logo.png"]:
        if getattr(sys, "frozen", False):
            icon_path = os.path.join(getattr(sys, "_MEIPASS", APP_DIR), filename)
            if not os.path.exists(icon_path):
                icon_path = os.path.join(APP_DIR, filename)
        else:
            icon_path = os.path.join(APP_DIR, filename)
        if os.path.exists(icon_path):
            return QIcon(icon_path)
    return QIcon()

def get_saved_theme():
    """Read saved theme preference from config.json before main window launch."""
    config_path = os.path.join(APP_DIR, "config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("theme_accent", "Emerald Teal (Dark)")
        except Exception:
            pass
    return "Emerald Teal (Dark)"


# =========================================================
# SPLASH SCREEN
# =========================================================
class SplashScreen(QSplashScreen):
    """Theme-aware splash screen with progress feedback."""

    def __init__(self, theme_name=None):
        if not theme_name:
            theme_name = get_saved_theme()
        from gui.theme import THEMES
        from gui.qt_theme import resolve_color
        theme = THEMES.get(theme_name, THEMES["Emerald Teal (Dark)"])
        mode = theme.get("APPEARANCE_MODE", "dark")

        bg_col = resolve_color(theme["BG_WINDOW"], mode)
        title_col = resolve_color(theme["TEXT_HIGHLIGHT"], mode)
        sub_col = resolve_color(theme["TEXT_MAIN"], mode)
        self._status_col = resolve_color(theme["TEXT_MUTED"], mode)

        pix = QPixmap(400, 230)
        pix.fill(QColor(bg_col))
        painter = QPainter(pix)
        painter.setRenderHint(QPainter.Antialiasing)

        # Title
        painter.setPen(QColor(title_col))
        painter.setFont(QFont("Segoe UI", 16, QFont.Bold))
        painter.drawText(pix.rect().adjusted(0, 25, 0, -130), Qt.AlignHCenter, "Centralized Voucher Validation Suite")

        # Subtitle
        painter.setPen(QColor(sub_col))
        painter.setFont(QFont("Segoe UI", 8, QFont.Bold))
        painter.drawText(pix.rect().adjusted(0, 65, 0, -100), Qt.AlignHCenter,
                         "OFFICE OF THE ACCOUNTANT GENERAL (A&E)\nMadhya Pradesh, Gwalior")

        painter.end()
        super().__init__(pix)
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.SplashScreen | Qt.FramelessWindowHint)

    def update_status(self, text, value=None):
        self.showMessage(f"  {text}", Qt.AlignBottom | Qt.AlignLeft, QColor(getattr(self, "_status_col", "#8b949e")))
        QApplication.processEvents()


# =========================================================
# TERMS & CONDITIONS DIALOG
# =========================================================
class TermsDialog(QDialog):
    """Modal dialog displaying the full Terms and Conditions text."""

    def __init__(self, parent=None, theme_name=None):
        super().__init__(parent)
        if not theme_name:
            theme_name = get_saved_theme()
        from gui.theme import THEMES
        from gui.qt_theme import resolve_color
        theme = THEMES.get(theme_name, THEMES["Emerald Teal (Dark)"])
        mode = theme.get("APPEARANCE_MODE", "dark")

        bg_dialog = resolve_color(theme["BG_CARD"], mode)
        bg_entry = resolve_color(theme["BG_ENTRY"], mode)
        text_main = resolve_color(theme["TEXT_MAIN"], mode)
        text_muted = resolve_color(theme["TEXT_MUTED"], mode)
        border_col = resolve_color(theme["BORDER_COLOR"], mode)
        accent_col = resolve_color(theme["BTN_PRIMARY_BG"], mode)
        accent_hover = resolve_color(theme["BTN_PRIMARY_HOVER"], mode)
        btn_text = resolve_color(theme["BTN_PRIMARY_TEXT"], mode)

        self.setWindowTitle("Centralized Voucher Validation Suite - Terms & Conditions")
        icon = get_app_icon()
        if not icon.isNull():
            self.setWindowIcon(icon)
        self.setFixedSize(480, 360)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setStyleSheet(f"""
            QDialog {{ background-color: {bg_dialog}; border: 1px solid {border_col}; border-radius: 12px; }}
            QLabel {{ color: {text_main}; background: transparent; }}
            QTextEdit {{
                background-color: {bg_entry}; color: {text_main};
                border: 1px solid {border_col}; border-radius: 8px;
                padding: 10px; font-size: 11px; line-height: 1.4; font-weight: 500;
            }}
            QPushButton {{
                background-color: {accent_col}; color: {btn_text};
                border-radius: 8px; font-weight: bold;
                padding: 6px 18px; font-size: 12px;
            }}
            QPushButton:hover {{ background-color: {accent_hover}; }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        title = QLabel("📜 Terms & Conditions of Use")
        title.setFont(QFont("Segoe UI", 13, QFont.Bold))
        title.setStyleSheet(f"color: {accent_col};")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        text_edit = QTextEdit()
        text_edit.setReadOnly(True)
        terms_text = (
            "CENTRALIZED VOUCHER VALIDATION SUITE — TERMS AND CONDITIONS OF USE\n\n"
            "1. AUTHORIZED USE:\n"
            "This software is intended exclusively for authorized officers and personnel "
            "of the Indian Audit & Accounts Department (IA&AD) / Office of the Accountant General (A&E), "
            "Madhya Pradesh, Gwalior.\n\n"
            "2. OFFICIAL DATA RESPONSIBILITY:\n"
            "The operator is solely responsible for ensuring that all downloaded financial ledgers, "
            "vouchers, payroll records, and reports are handled, stored, and processed in strict compliance "
            "with official government data security and confidentiality guidelines.\n\n"
            "3. OPERATOR ACCOUNTABILITY:\n"
            "All automated portal operations, data downloads, and system tasks executed via this "
            "application are logged under the operator identity code provided at system startup.\n\n"
            "4. CONFIDENTIALITY & PROPRIETARY RIGHTS:\n"
            "Unauthorized sharing, distribution, reproduction, or reverse engineering of this software "
            "and its underlying components is strictly prohibited."
        )
        text_edit.setText(terms_text)
        layout.addWidget(text_edit)

        btn_close = QPushButton("I Understand & Close")
        btn_close.setFixedHeight(34)
        btn_close.clicked.connect(self.accept)
        layout.addWidget(btn_close, alignment=Qt.AlignCenter)

        screen = QApplication.primaryScreen().geometry()
        self.move((screen.width() - 480) // 2, (screen.height() - 360) // 2)


# =========================================================
# OPERATOR LOGIN DIALOG
# =========================================================
from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QCheckBox, QPushButton, QFrame, QApplication
class OperatorLoginDialog(QDialog):
    """Modal dialog for operator identity and Terms acceptance."""

    def __init__(self, parent=None, theme_name=None):
        super().__init__(parent)
        if not theme_name:
            theme_name = get_saved_theme()
        from gui.theme import THEMES
        from gui.qt_theme import resolve_color
        theme = THEMES.get(theme_name, THEMES["Emerald Teal (Dark)"])
        mode = theme.get("APPEARANCE_MODE", "dark")

        bg_dialog = resolve_color(theme["BG_CARD"], mode)
        bg_entry = resolve_color(theme["BG_ENTRY"], mode)
        text_main = resolve_color(theme["TEXT_MAIN"], mode)
        text_muted = resolve_color(theme["TEXT_MUTED"], mode)
        border_col = resolve_color(theme["BORDER_COLOR"], mode)
        accent_col = resolve_color(theme["BTN_PRIMARY_BG"], mode)
        accent_hover = resolve_color(theme["BTN_PRIMARY_HOVER"], mode)
        btn_text = resolve_color(theme["BTN_PRIMARY_TEXT"], mode)

        self.result = None
        self.telemetry_agreed = True
        self.setWindowTitle("Centralized Voucher Validation Suite - Login")
        icon = get_app_icon()
        if not icon.isNull():
            self.setWindowIcon(icon)
        self.setFixedSize(540, 380)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setStyleSheet("""
            QDialog {
                background-color: #0b1329;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 18px;
            }
            QLabel { color: #f8fafc; font-family: 'Segoe UI', sans-serif; background: transparent; }
            QLineEdit {
                background-color: #080e1b;
                border: 2px solid #00c9a7;
                border-radius: 12px;
                color: #ffffff;
                padding: 12px 18px;
                font-size: 16px;
                font-weight: 700;
            }
            QLineEdit:focus {
                border: 2.5px solid #00e5bf;
                background-color: #040812;
            }
            QCheckBox {
                color: #cbd5e1;
                font-size: 13px;
                font-weight: 600;
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 20px;
                height: 20px;
                border-radius: 6px;
                border: 1.5px solid #00c9a7;
                background-color: #00c9a7;
            }
            QCheckBox::indicator:checked {
                background-color: #00c9a7;
                border-color: #00c9a7;
            }
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00c9a7, stop:1 #008060);
                color: #0b1329;
                border: none;
                border-radius: 12px;
                font-weight: 800;
                padding: 13px 28px;
                font-size: 16px;
                letter-spacing: 0.5px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00e5bf, stop:1 #00c9a7);
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(36, 24, 36, 24)
        layout.setSpacing(12)

        # Top Badge Pill
        lbl_office_badge = QLabel("OFFICE OF THE ACCOUNTANT GENERAL (A&E) MP GWALIOR", self)
        lbl_office_badge.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        lbl_office_badge.setStyleSheet("color: #00c9a7; font-size: 10.5px; font-weight: 800; letter-spacing: 1px; background-color: rgba(0, 201, 167, 0.12); padding: 6px 16px; border-radius: 12px;")
        lbl_office_badge.setAlignment(Qt.AlignCenter)
        layout.addWidget(lbl_office_badge)

        # Prominent Software Tool Title — Large & Bold (Main Focus)
        lbl_software_title = QLabel("Centralized Voucher Validation Suite v1.3", self)
        lbl_software_title.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))
        lbl_software_title.setStyleSheet("color: #ffffff; font-size: 19px; font-weight: 800; padding: 4px 0px;")
        lbl_software_title.setAlignment(Qt.AlignCenter)
        layout.addWidget(lbl_software_title)

        # Operator Identity Subtitle
        title = QLabel("Operator Authentication", self)
        title.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        title.setStyleSheet("color: #94a3b8; font-size: 13px; font-weight: 600;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        self.entry = QLineEdit(self)
        self.entry.setPlaceholderText("e.g. Operator or Administrator")
        self.entry.setFixedHeight(46)
        self.entry.returnPressed.connect(self.confirm)
        layout.addWidget(self.entry)

        # Terms and conditions checkbox row
        terms_row = QHBoxLayout()
        terms_row.setContentsMargins(0, 4, 0, 4)
        terms_row.setSpacing(6)
        terms_row.setAlignment(Qt.AlignCenter)

        self.cb_terms = QCheckBox("I agree to the", self)
        self.cb_terms.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        self.cb_terms.setChecked(True)
        terms_row.addWidget(self.cb_terms)

        self.lbl_terms_link = QLabel(f'<a href="#" style="color: #00c9a7; font-size: 13px; font-weight: bold; text-decoration: underline;">Terms & Conditions</a>', self)
        self.lbl_terms_link.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        self.lbl_terms_link.setOpenExternalLinks(False)
        self.lbl_terms_link.linkActivated.connect(self._show_terms_popup)
        terms_row.addWidget(self.lbl_terms_link)

        layout.addLayout(terms_row)

        btn = QPushButton("Proceed", self)
        btn.setFixedHeight(46)
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(self.confirm)
        layout.addWidget(btn)

        self._center()
        QTimer.singleShot(100, self.entry.setFocus)

    def _center(self):
        screen = QApplication.primaryScreen().geometry()
        x = (screen.width() - self.width()) // 2
        y = (screen.height() - self.height()) // 2
        self.move(x, y)

    def _show_terms_popup(self, _link=None):
        dlg = TermsDialog(self)
        dlg.exec()

    def confirm(self):
        name = self.entry.text().strip()
        if not name:
            QMessageBox.critical(self, "Error", "Operator identity cannot be empty.")
            return
        if not self.cb_terms.isChecked():
            QMessageBox.warning(self, "Agreement Required", "You must agree to the Terms & Conditions to proceed.")
            return
        self.result = name
        self.telemetry_agreed = True
        self.accept()


# =========================================================
# ACTIVATION DIALOG
# =========================================================
class ActivationDialogQt(QDialog):
    """License activation dialog."""

    def __init__(self, machine_id):
        super().__init__()
        self.machine_id = machine_id
        self.activated = False
        self.setWindowTitle("Centralized Voucher Validation Suite - Activation")
        icon = get_app_icon()
        if not icon.isNull():
            self.setWindowIcon(icon)
        self.setFixedSize(540, 380)
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setStyleSheet("""
            QDialog { background-color: #0d1117; }
            QLabel { color: #f8fafc; }
            QLineEdit {
                background-color: #161b22; color: #00c9a7;
                border: 1px solid #30363d; border-radius: 8px;
                padding: 6px 10px; font-family: Consolas; font-size: 11px;
            }
            QPushButton#activate {
                background-color: #00c9a7; color: #0d1117;
                border-radius: 8px; font-weight: bold;
                padding: 10px; font-size: 12px;
            }
            QPushButton#activate:hover { background-color: #00e5bf; }
            QPushButton#cancel {
                background-color: transparent; color: #8b949e;
                border: 1px solid #30363d; border-radius: 8px;
                padding: 10px; font-size: 12px;
            }
            QPushButton#cancel:hover { background-color: #161b22; }
            QFrame { background-color: #161b22; border: 1px solid #30363d; border-radius: 12px; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 25, 40, 25)

        title = QLabel("🛡️ Product Activation Required")
        title.setFont(QFont("Segoe UI", 20, QFont.Bold))
        title.setStyleSheet("color: #00c9a7;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        sub = QLabel("Please register this software with a valid license key generated by Nitin Arya.")
        sub.setFont(QFont("Segoe UI", 11))
        sub.setStyleSheet("color: #8b949e;")
        sub.setAlignment(Qt.AlignCenter)
        sub.setWordWrap(True)
        layout.addWidget(sub)

        hwid_label = QLabel("Your Machine Hardware ID (HWID):")
        hwid_label.setFont(QFont("Segoe UI", 11, QFont.Bold))
        layout.addWidget(hwid_label)

        from PySide6.QtWidgets import QHBoxLayout
        hwid_row = QHBoxLayout()
        self.entry_hwid = QLineEdit(machine_id)
        self.entry_hwid.setReadOnly(True)
        hwid_row.addWidget(self.entry_hwid, 1)

        btn_copy = QPushButton("📋 Copy")
        btn_copy.setFixedWidth(80)
        btn_copy.clicked.connect(self.copy_hwid)
        hwid_row.addWidget(btn_copy)
        layout.addLayout(hwid_row)

        key_label = QLabel("Enter Activation Key:")
        key_label.setFont(QFont("Segoe UI", 11, QFont.Bold))
        layout.addWidget(key_label)

        self.entry_key = QLineEdit()
        self.entry_key.setPlaceholderText("Paste your base64-encoded license key here...")
        self.entry_key.setFixedHeight(35)
        layout.addWidget(self.entry_key)

        from PySide6.QtWidgets import QHBoxLayout as HL2
        btn_row = HL2()
        btn_activate = QPushButton("⚡ Activate Software")
        btn_activate.setObjectName("activate")
        btn_activate.clicked.connect(self.activate_license)
        btn_row.addWidget(btn_activate, 1)

        btn_cancel = QPushButton("Cancel")
        btn_cancel.setObjectName("cancel")
        btn_cancel.setFixedWidth(100)
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_cancel)
        layout.addLayout(btn_row)

        screen = QApplication.primaryScreen().geometry()
        self.move((screen.width() - 540) // 2, (screen.height() - 380) // 2)

    def copy_hwid(self):
        QApplication.clipboard().setText(self.machine_id)
        QMessageBox.information(self, "Copied", "Hardware ID copied to clipboard.")

    def activate_license(self):
        from core.security import verify_key, save_license_key
        key = self.entry_key.text().strip()
        valid, msg = verify_key(key, self.machine_id)
        if valid:
            save_license_key(key)
            QMessageBox.information(self, "Success", "Centralized Voucher Validation Suite activated successfully!")
            self.activated = True
            self.accept()
        else:
            QMessageBox.critical(self, "Activation Failed", f"Invalid activation key:\n{msg}")


# =========================================================
# SECURITY CHECK
# =========================================================
def check_security_qt(operator_name, splash=None, telemetry_agreed=True):
    """License verification and remote kill-switch check."""
    import urllib.request
    from core.security import get_machine_id, verify_key, save_license_key, read_license_key

    my_hwid = get_machine_id()

    # Read keys from registry + file
    reg_key = None
    if sys.platform == "win32":
        try:
            import winreg
            key_reg = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\IFMIS_Suite")
            reg_key, _ = winreg.QueryValueEx(key_reg, "LicenseKey")
            winreg.CloseKey(key_reg)
            if reg_key:
                reg_key = reg_key.strip()
        except Exception:
            pass

    file_key = None
    try:
        key_path = os.path.join(APP_DIR, "license.key")
        if os.path.exists(key_path):
            with open(key_path, "r", encoding="utf-8") as f:
                file_key = f.read().strip()
    except Exception:
        pass

    reg_valid, reg_msg = verify_key(reg_key, my_hwid)
    file_valid, file_msg = verify_key(file_key, my_hwid)

    if reg_valid and not file_valid:
        save_license_key(reg_key)
    elif file_valid and not reg_valid:
        save_license_key(file_key)

    valid = reg_valid or file_valid
    key_str = reg_key if reg_valid else file_key
    msg = reg_msg if reg_valid else file_msg

    if not valid:
        if splash:
            splash.hide()
        dialog = ActivationDialogQt(my_hwid)
        dialog.exec()
        if not dialog.activated:
            sys.exit()
        key_str = read_license_key()
        valid, msg = verify_key(key_str, my_hwid)
        if not valid:
            sys.exit()
        if splash:
            splash.show()

    # Remote kill-switch check
    try:
        from core.constants import GIST_REMOTE_CONFIG_URL
        kill_switch_url = GIST_REMOTE_CONFIG_URL
        req = urllib.request.Request(kill_switch_url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=5).read().decode('utf-8')
        config = json.loads(response)

        if not config.get("global_enabled", True):
            QMessageBox.critical(None, "Access Denied",
                                 "The Centralized Voucher Validation Suite has been globally disabled by Administrator.")
            sys.exit()
        if my_hwid in config.get("blocked_hardware_ids", []):
            QMessageBox.critical(None, "License Revoked",
                                 "Security Violation: This machine has been blocked.")
            sys.exit()

        # Update version check
        min_ver = config.get("min_version")
        latest_ver = config.get("latest_version")
        update_url = config.get("update_url")

        if update_url:
            from core.constants import TOOL_VERSION
            target_ver_str = latest_ver if latest_ver is not None else min_ver
            if target_ver_str is not None:
                import re
                def parse_version(ver_str):
                    try:
                        m = re.search(r'(\d+(?:\.\d+)*)', str(ver_str))
                        if m:
                            parts = [int(x) for x in m.group(1).split('.')]
                            # Legacy versioning scheme (v3.x) is prior to the v1.0 release reset
                            if parts[0] == 3:
                                return (0, parts[1] if len(parts) > 1 else 0)
                            return tuple(parts)
                    except Exception:
                        pass
                    return (0,)

                local_ver = parse_version(TOOL_VERSION)
                target_ver = parse_version(target_ver_str)

                if target_ver > local_ver:
                    if splash:
                        splash.hide()
                    ans = QMessageBox.question(
                        None,
                        "Update Available",
                        f"A new update (v{target_ver_str}) of Centralized Voucher Validation Suite is available.\n\n"
                        f"Current Version: {TOOL_VERSION}\n"
                        f"New Version: v{target_ver_str}\n\n"
                        f"Would you like to download and install this update now?",
                        QMessageBox.Yes | QMessageBox.No
                    )
                    if ans == QMessageBox.Yes:
                        from gui.qt_dialogs import UpdateDownloadDialog
                        from PySide6.QtWidgets import QDialog
                        dl_dialog = UpdateDownloadDialog(update_url, target_ver_str)
                        if dl_dialog.exec() == QDialog.Accepted:
                            installer_path = dl_dialog.downloaded_path
                            if installer_path and os.path.exists(installer_path):
                                import subprocess
                                try:
                                    subprocess.Popen([installer_path])
                                    os._exit(0)
                                except Exception as launch_err:
                                    QMessageBox.critical(
                                        None, "Update Error",
                                        f"Failed to start installer: {launch_err}"
                                    )
                        else:
                            if dl_dialog.failed_reason:
                                QMessageBox.critical(
                                    None, "Update Error",
                                    f"Download failed: {dl_dialog.failed_reason}"
                                )
                    if splash:
                        splash.show()
    except Exception:
        pass  # Network errors are non-fatal for kill-switch / update check

    # Send startup telemetry asynchronously
    if telemetry_agreed:
        try:
            import threading
            from core.telemetry import send_startup_telemetry
            threading.Thread(
                target=send_startup_telemetry,
                args=(operator_name, my_hwid, key_str, valid, msg),
                daemon=True
            ).start()
        except Exception:
            pass


# =========================================================
# LOAD HEAVY ENGINES
# =========================================================
def load_engines(splash=None):
    """Lazy-load heavy modules with splash progress updates."""
    if splash:
        splash.update_status("Loading Excel utilities...", 55)
    from openpyxl import load_workbook  # noqa: F401

    if splash:
        splash.update_status("Loading PDF Plumber extraction...", 65)
    import pdfplumber  # noqa: F401

    if splash:
        splash.update_status("Loading Playwright automation...", 75)
    from playwright.sync_api import sync_playwright, TimeoutError as PWTimeoutError  # noqa: F401

    if splash:
        splash.update_status("Loading data analysis modules...", 95)
    try:
        import pandas  # noqa: F401
        import xlrd  # noqa: F401
        import lxml  # noqa: F401
        import bs4  # noqa: F401
    except ImportError:
        pass

    if splash:
        splash.update_status("Engines loaded successfully!", 100)


# =========================================================
# MAIN ENTRY POINT
# =========================================================
if __name__ == "__main__":
    multiprocessing.freeze_support()

    # Fix taskbar & titlebar icon on Windows
    if sys.platform == "win32":
        try:
            from ctypes import windll
            windll.shell32.SetCurrentProcessExplicitAppUserModelID("AGMP.IFMIS365Suite.v33")
        except Exception:
            pass

    # ── Command-Line Routing for Combined Executable ─────
    if "--ti-studio" in sys.argv:
        if getattr(sys, "frozen", False):
            import app as ti_app
            sys.exit(ti_app.main())
        else:
            sys.path.insert(0, os.path.join(APP_DIR, "TI Studio Pro"))
            import app as ti_app
            sys.exit(ti_app.main())

    elif "--epay-verifier" in sys.argv:
        if getattr(sys, "frozen", False):
            import epay_verifier
            sys.exit(epay_verifier.main())
        else:
            sys.path.insert(0, os.path.join(APP_DIR, "TI Studio Pro"))
            import epay_verifier
            sys.exit(epay_verifier.main())

    # Create the Qt Application
    app = QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 10))

    saved_theme = get_saved_theme()
    try:
        from gui.qt_theme import generate_qss
        app.setStyleSheet(generate_qss(saved_theme))
    except Exception:
        pass

    app_icon = get_app_icon()
    if not app_icon.isNull():
        app.setWindowIcon(app_icon)

    # Handle --updated flag
    if "--updated" in sys.argv:
        QMessageBox.information(None, "Update Successful",
                                "Centralized Voucher Validation Suite has been successfully updated!")

    # Show splash
    splash = SplashScreen()
    splash.show()
    splash.update_status("Initializing environment...", 10)
    QApplication.processEvents()

    # Operator login
    splash.update_status("Awaiting operator identity...", 25)
    QApplication.processEvents()

    dialog = OperatorLoginDialog()
    result = dialog.exec()
    operator_name = dialog.result

    if not operator_name:
        sys.exit()

    # Security check
    splash.update_status("Checking license & security...", 40)
    QApplication.processEvents()
    check_security_qt(operator_name, splash, telemetry_agreed=getattr(dialog, 'telemetry_agreed', True))

    # Load engines
    splash.update_status("Loading engines...", 50)
    QApplication.processEvents()
    load_engines(splash)

    # Create downloads shortcut silently
    try:
        from create_downloads_shortcut import create_shortcut
        create_shortcut()
    except Exception:
        pass

    from gui.qt_app import IFMISSuiteApp
    main_window = IFMISSuiteApp(operator_name=operator_name)
    if hasattr(dialog, 'telemetry_agreed') and hasattr(main_window, 'var_telemetry_enabled'):
        main_window.var_telemetry_enabled.set(dialog.telemetry_agreed)
        main_window.save_config(show_popup=False)

    main_window.show()
    main_window.showMaximized()

    splash.finish(main_window)

    sys.exit(app.exec())
