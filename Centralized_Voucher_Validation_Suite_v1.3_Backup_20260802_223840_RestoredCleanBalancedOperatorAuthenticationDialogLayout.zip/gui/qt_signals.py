"""
qt_signals.py - Central signal hub and Tk variable compatibility layer for Centralized Voucher Validation Suite.

Provides:
    SignalBridge  - QObject with all signals for thread-safe backend→GUI communication.
    TkVarCompat   - Drop-in replacement for tk.StringVar / BooleanVar / IntVar / DoubleVar.
"""

import sys
from PySide6.QtCore import QObject, Signal


# ---------------------------------------------------------------------------
# SignalBridge
# ---------------------------------------------------------------------------

class SignalBridge(QObject):
    """Central signal hub for thread-safe communication between backend workers and the Qt GUI.

    All background threads (browser worker, log_receiver, keep-alive daemon) emit these signals
    instead of directly calling GUI methods.  The main thread connects slots to these signals.
    """

    # ------------------------------------------------------------------
    # Console logging – emitted by self.log() from any thread
    # ------------------------------------------------------------------
    log_message = Signal(str, str)  # (message, tag)  tag ∈ {'info','success','error','warning','skip'}

    # ------------------------------------------------------------------
    # Progress & statistics
    # ------------------------------------------------------------------
    stats_updated = Signal(str, float)        # (current_operation_label, progress_fraction 0.0-1.0)
    counter_incremented = Signal(str, int)    # (counter_type='success'|'fail'|'skip', diff)

    # ------------------------------------------------------------------
    # UI state control
    # ------------------------------------------------------------------
    ui_lock_changed = Signal(bool)   # True = locked (task running), False = unlocked
    run_finished = Signal()          # Emitted when automation task completes
    heartbeat_update = Signal(str, str)  # (text, color_hex)

    # ------------------------------------------------------------------
    # VLC-COMPAY Linker events
    # ------------------------------------------------------------------
    vlc_linker_finished = Signal(dict, str)   # (stats_dict, output_csv_path)
    vlc_linker_failed = Signal(str)         # (error_message)

    # ------------------------------------------------------------------
    # DDO list refresh (POL tab)
    # ------------------------------------------------------------------
    ddo_list_refresh = Signal(str)   # treasury_code to refresh

    # ------------------------------------------------------------------
    # Browser status
    # ------------------------------------------------------------------
    browser_status = Signal(str)     # status message for browser status bar

    # ------------------------------------------------------------------
    # Auto-throttle from ConcurrencyAutoTuner
    # ------------------------------------------------------------------
    worker_count_changed = Signal(int)  # new worker count

    # ------------------------------------------------------------------
    # Session events
    # ------------------------------------------------------------------
    session_expired = Signal()                  # triggers re-authentication flow
    captcha_required = Signal(bytes, object)    # (captcha_image_bytes, result_queue)

    # ------------------------------------------------------------------
    # File dialog requests from non-GUI threads
    # ------------------------------------------------------------------
    file_dialog_request = Signal(str, object)   # (dialog_type, result_queue) – thread-safe file dialogs

    # ------------------------------------------------------------------
    # Console title update
    # ------------------------------------------------------------------
    console_status_changed = Signal(str)        # new status text for console title

    # ------------------------------------------------------------------
    # Thread-safe callback execution on main GUI thread
    # ------------------------------------------------------------------
    execute_callable = Signal(object, tuple, dict)  # (callable, args, kwargs)


# ---------------------------------------------------------------------------
# TkVarCompat
# ---------------------------------------------------------------------------

class TkVarCompat(QObject):
    """Drop-in replacement for tk.StringVar / BooleanVar / IntVar / DoubleVar.

    Allows backend code that calls ``self.var_something.get()`` / ``.set(value)`` /
    ``.trace_add()`` to work without modification on PySide6.
    """

    def __init__(self, value=None, widget=None, getter=None, setter=None):
        super().__init__()
        self._value = value
        self._widgets = []
        self._getter = getter
        self._setter = setter
        self._traces = []
        self._updating = False

        if widget:
            self.bind_to_widget(widget)

    @property
    def _widget(self):
        # For compatibility with any code that expects self._widget
        return self._widgets[0] if self._widgets else None

    @_widget.setter
    def _widget(self, value):
        if value and value not in self._widgets:
            self._widgets.append(value)

    def get(self):
        """Return the current value."""
        if self._getter:
            return self._getter()
        return self._value

    def set(self, value):
        """Store *value* and push it to all bound widgets / setter."""
        if self._updating:
            return
        
        old = self._value
        self._value = value

        if self._setter:
            self._setter(value)
        
        # Thread-safe widget update using dynamic signal dispatch
        from PySide6.QtCore import QThread
        from PySide6.QtWidgets import QApplication
        if QThread.currentThread() != QApplication.instance().thread():
            main_win = None
            for w in QApplication.topLevelWidgets():
                if w.__class__.__name__ == 'IFMISSuiteApp':
                    main_win = w
                    break
            if main_win and hasattr(main_win, 'signals'):
                main_win.signals.execute_callable.emit(self._update_widgets, (value,), {})
            else:
                self._update_widgets(value)
        else:
            self._update_widgets(value)

        if old != value:
            self._fire_traces()

    def _update_widgets(self, value):
        if self._updating:
            return
        self._updating = True
        try:
            from PySide6.QtWidgets import QLineEdit, QCheckBox, QSlider, QComboBox, QSpinBox, QDoubleSpinBox
            for widget in self._widgets:
                widget.blockSignals(True)
                if isinstance(widget, QCheckBox):
                    widget.setChecked(bool(value))
                elif isinstance(widget, QSlider):
                    widget.setValue(int(value))
                elif isinstance(widget, QSpinBox):
                    widget.setValue(int(value))
                elif isinstance(widget, QDoubleSpinBox):
                    widget.setValue(float(value))
                elif isinstance(widget, QComboBox):
                    widget.setCurrentText(str(value))
                elif isinstance(widget, QLineEdit):
                    widget.setText(str(value))
                widget.blockSignals(False)
        finally:
            self._updating = False

    def bind_to_widget(self, widget):
        """Late-bind this variable to a *widget* after widget creation."""
        if widget in self._widgets:
            return
        self._widgets.append(widget)

        from PySide6.QtWidgets import QLineEdit, QCheckBox, QSlider, QComboBox, QSpinBox, QDoubleSpinBox

        # Push the current stored value into the widget
        if self._value is not None:
            widget.blockSignals(True)
            if isinstance(widget, QCheckBox):
                widget.setChecked(bool(self._value))
            elif isinstance(widget, QSlider):
                widget.setValue(int(self._value))
            elif isinstance(widget, QSpinBox):
                widget.setValue(int(self._value))
            elif isinstance(widget, QDoubleSpinBox):
                widget.setValue(float(self._value))
            elif isinstance(widget, QComboBox):
                widget.setCurrentText(str(self._value))
            elif isinstance(widget, QLineEdit):
                widget.setText(str(self._value))
            widget.blockSignals(False)

        # Widget value changed handler
        def on_widget_changed():
            if self._updating:
                return
            self._updating = True
            try:
                # Read new value from the sender widget
                sender = widget
                new_val = None
                if isinstance(sender, QCheckBox):
                    new_val = sender.isChecked()
                elif isinstance(sender, QSlider):
                    new_val = sender.value()
                elif isinstance(sender, QSpinBox):
                    new_val = sender.value()
                elif isinstance(sender, QDoubleSpinBox):
                    new_val = sender.value()
                elif isinstance(sender, QComboBox):
                    new_val = sender.currentText()
                elif isinstance(sender, QLineEdit):
                    new_val = sender.text()

                self._value = new_val

                # Propagate to all other bound widgets
                for w in self._widgets:
                    if w is sender:
                        continue
                    w.blockSignals(True)
                    if isinstance(w, QCheckBox):
                        w.setChecked(bool(new_val))
                    elif isinstance(w, QSlider):
                        w.setValue(int(new_val))
                    elif isinstance(w, QSpinBox):
                        w.setValue(int(new_val))
                    elif isinstance(w, QDoubleSpinBox):
                        w.setValue(float(new_val))
                    elif isinstance(w, QComboBox):
                        w.setCurrentText(str(new_val))
                    elif isinstance(w, QLineEdit):
                        w.setText(str(new_val))
                    w.blockSignals(False)
            finally:
                self._updating = False
            
            self._fire_traces()

        # Connect the appropriate widget signal
        if isinstance(widget, QLineEdit):
            widget.textChanged.connect(lambda _text: on_widget_changed())
        elif isinstance(widget, QCheckBox):
            widget.toggled.connect(lambda _checked: on_widget_changed())
        elif isinstance(widget, QSlider):
            widget.valueChanged.connect(lambda _val: on_widget_changed())
        elif isinstance(widget, QSpinBox):
            widget.valueChanged.connect(lambda _val: on_widget_changed())
        elif isinstance(widget, QDoubleSpinBox):
            widget.valueChanged.connect(lambda _val: on_widget_changed())
        elif isinstance(widget, QComboBox):
            widget.currentTextChanged.connect(lambda _text: on_widget_changed())

    def trace_add(self, mode, callback):
        """Register *callback* to be invoked whenever the value changes."""
        def wrapper(*args):
            try:
                callback()
            except TypeError:
                try:
                    callback(None, None, None)
                except Exception:
                    pass
        self._traces.append(wrapper)

    def _fire_traces(self):
        """Execute all registered trace callbacks."""
        for cb in self._traces:
            try:
                cb()
            except Exception:
                pass

    def __repr__(self):
        return f"TkVarCompat(value={self._value!r}, widgets={self._widgets!r})"


# ---------------------------------------------------------------------------
# NetworkMonitorThread
# ---------------------------------------------------------------------------

from PySide6.QtCore import QThread

class NetworkMonitorThread(QThread):
    """Background thread to monitor and report network bandwidth speed dynamically."""
    speed_updated = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._running = True

    def run(self):
        import time
        try:
            import psutil
            old_io = psutil.net_io_counters()
        except Exception:
            old_io = None

        while self._running:
            time.sleep(1.0)
            if not self._running:
                break
            try:
                import psutil
                new_io = psutil.net_io_counters()
                if old_io and new_io:
                    bytes_recv = new_io.bytes_recv - old_io.bytes_recv
                    bytes_sent = new_io.bytes_sent - old_io.bytes_sent

                    def format_speed(bytes_per_sec):
                        if bytes_per_sec >= 1024 * 1024:
                            return f"{bytes_per_sec / (1024 * 1024):.1f} MB/s"
                        elif bytes_per_sec >= 1024:
                            return f"{bytes_per_sec / 1024:.1f} KB/s"
                        else:
                            return f"{bytes_per_sec} B/s"

                    down_str = format_speed(bytes_recv)
                    up_str = format_speed(bytes_sent)
                    self.speed_updated.emit(f"⬇ {down_str} | ⬆ {up_str}")
                old_io = new_io
            except Exception:
                self.speed_updated.emit("⬇ 0.0 B/s | ⬆ 0.0 B/s")
                try:
                    import psutil
                    old_io = psutil.net_io_counters()
                except Exception:
                    old_io = None

    def stop(self):
        self._running = False
        self.wait()


# ---------------------------------------------------------------------------
# PortalLatencyMonitorThread
# ---------------------------------------------------------------------------

class PortalLatencyMonitorThread(QThread):
    """Background thread to monitor and report network latency to IFMS portal dynamically."""
    latency_updated = Signal(int, str)  # (latency_ms, label_text)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._running = True

    def run(self):
        import socket
        import time
        
        host = "ifmisprod.mptreasury.gov.in"
        port = 443
        
        while self._running:
            try:
                # Resolve host (quickly) to all available IPs
                infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
                ips = list(set([info[4][0] for info in infos]))
                
                success = False
                min_latency = 999999
                
                # Check each IP, use the one that is active/responsive
                for ip in ips:
                    if not self._running:
                        break
                    try:
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        s.settimeout(2.0)
                        s_start = time.time()
                        s.connect((ip, port))
                        latency = int((time.time() - s_start) * 1000)
                        s.close()
                        
                        if latency < min_latency:
                            min_latency = latency
                        success = True
                    except Exception:
                        pass
                
                if success and self._running:
                    # Format label text and emit
                    if min_latency < 250:
                        self.latency_updated.emit(min_latency, f"IFMS Portal: {min_latency}ms (Good)")
                    elif min_latency < 750:
                        self.latency_updated.emit(min_latency, f"IFMS Portal: {min_latency}ms (Moderate)")
                    else:
                        self.latency_updated.emit(min_latency, f"IFMS Portal: {min_latency}ms (Slow)")
                else:
                    if self._running:
                        self.latency_updated.emit(-1, "IFMS Portal: Slow/Offline (Timeout)")
            except Exception:
                if self._running:
                    # Server is offline or timeout
                    self.latency_updated.emit(-1, "IFMS Portal: Slow/Offline (Timeout)")
            
            # Wait for 10 seconds before next check
            for _ in range(10):
                if not self._running:
                    break
                time.sleep(1.0)

    def stop(self):
        self._running = False
        self.wait()


