def clean_formula_val(val):
    if val is None:
        return ""
    val_str = str(val).strip()
    if val_str.startswith('="') and val_str.endswith('"'):
        val_str = val_str[2:-1].strip()
    elif val_str.startswith('='):
        val_str = val_str[1:].strip().strip('"')
    return val_str

import time
import os
import re
import datetime
import calendar
import openpyxl

# Helper to extract amount values robustly
def _extract_amount(val):
    """Return a clean amount value.
    If `val` is already numeric (int/float), return it directly.
    Otherwise, use `clean_amount_string` to sanitize the string.
    """
    if isinstance(val, (int, float)):
        return val
    return clean_amount_string(val)

def clean_amount_string(val):
    if val is None:
        return "0"
    val_str = str(val).strip()
    if not val_str:
        return "0"
    # Keep only digits and decimal point
    cleaned = re.sub(r'[^\d\.]', '', val_str)
    if not cleaned:
        return "0"
    try:
        val_float = float(cleaned)
        if val_float.is_integer():
            return str(int(val_float))
        return f"{val_float:.2f}".rstrip('0').rstrip('.')
    except Exception:
        return cleaned

def standardize_date(date_str):
    if not date_str:
        return ""
    date_str = str(date_str).strip()
    import datetime
    
    # Strip time component if present
    if " " in date_str:
        date_str = date_str.split(" ")[0].strip()
        
    # Try parsing ISO YYYY-MM-DD or YYYY/MM/DD format first
    for fmt in ('%Y-%m-%d', '%Y/%m/%d'):
        try:
            return datetime.datetime.strptime(date_str, fmt).strftime('%d/%m/%Y')
        except ValueError:
            pass
            
    # Custom separator handling
    if '-' in date_str:
        # Hyphens: prefer day first (DD-MM-YYYY)
        for fmt in ('%d-%m-%Y', '%m-%d-%Y', '%d-%b-%Y', '%d-%B-%Y'):
            try:
                return datetime.datetime.strptime(date_str, fmt).strftime('%d/%m/%Y')
            except ValueError:
                pass
    elif '/' in date_str:
        # Slashes: prefer month first (MM/DD/YYYY)
        for fmt in ('%d/%m/%Y', '%m/%d/%Y', '%d/%m/%y', '%m/%d/%y'):
            try:
                return datetime.datetime.strptime(date_str, fmt).strftime('%d/%m/%Y')
            except ValueError:
                pass
                
    # Fallback to dateutil with separator-based preference
    try:
        from dateutil.parser import parse
        df_pref = True
        return parse(date_str, dayfirst=df_pref).strftime('%d/%m/%Y')
    except Exception:
        return date_str

def standardize_date_range(range_str):
    if not range_str:
        return ""
    range_str = str(range_str).strip()
    if " - " in range_str:
        parts = range_str.split(" - ")
        if len(parts) == 2:
            return f"{standardize_date(parts[0])} - {standardize_date(parts[1])}"
    return range_str

def split_date_range_by_months(from_date_str, to_date_str):
    from_date_str = standardize_date(from_date_str)
    to_date_str = standardize_date(to_date_str)
    try:
        fd, fm, fy = map(int, from_date_str.split('/'))
        td, tm, ty = map(int, to_date_str.split('/'))
        start_date = datetime.date(fy, fm, fd)
        end_date = datetime.date(ty, tm, td)
    except Exception:
        return [(from_date_str, to_date_str)]
        
    if start_date > end_date:
        return []
        
    intervals = []
    current_start = start_date
    while current_start <= end_date:
        last_day_of_month = calendar.monthrange(current_start.year, current_start.month)[1]
        month_end_date = datetime.date(current_start.year, current_start.month, last_day_of_month)
        current_end = min(month_end_date, end_date)
        intervals.append((
            current_start.strftime("%d/%m/%Y"),
            current_end.strftime("%d/%m/%Y")
        ))
        current_start = current_end + datetime.timedelta(days=1)
    return intervals

class MockCsvSheet:
    def __init__(self, csv_rows):
        self.rows = csv_rows
        self.max_row = len(csv_rows)
        self.max_column = max(len(r) for r in csv_rows) if csv_rows else 0
        
    def cell(self, row, column):
        class Cell:
            def __init__(self, val):
                self.value = val
        r_idx = row - 1
        c_idx = column - 1
        val = None
        if 0 <= r_idx < len(self.rows):
            r = self.rows[r_idx]
            if 0 <= c_idx < len(r):
                val = r[c_idx]
                if val == '':
                    val = None
        return Cell(val)
        
    def iter_rows(self, min_row, values_only=True):
        out = []
        r_start = min_row - 1
        for r_idx in range(r_start, len(self.rows)):
            out.append(tuple(val if val != '' else None for val in self.rows[r_idx]))
        return out

class MockXlrdSheet:
    def __init__(self, xlrd_sheet):
        self.sheet = xlrd_sheet
        self.max_row = xlrd_sheet.nrows
        self.max_column = xlrd_sheet.ncols
        
    def cell(self, row, column):
        class Cell:
            def __init__(self, val):
                self.value = val
        r_idx = row - 1
        c_idx = column - 1
        val = None
        if 0 <= r_idx < self.sheet.nrows and 0 <= c_idx < self.sheet.ncols:
            val = self.sheet.cell_value(r_idx, c_idx)
            if val == '':
                val = None
        return Cell(val)
        
    def iter_rows(self, min_row, values_only=True):
        out = []
        r_start = min_row - 1
        for r_idx in range(r_start, self.sheet.nrows):
            row_vals = []
            for c_idx in range(self.sheet.ncols):
                val = self.sheet.cell_value(r_idx, c_idx)
                row_vals.append(val if val != '' else None)
            out.append(tuple(row_vals))
        return out

class MockPolarsSheet:
    """Wrapper around Polars DataFrame to expose openpyxl worksheet interface."""
    def __init__(self, df):
        cols = list(df.columns)
        raw_rows = df.rows()
        self.rows = [cols] + [list(r) for r in raw_rows]
        self.max_row = len(self.rows)
        self.max_column = len(cols) if self.max_row > 0 else 0

    def cell(self, row, column):
        class Cell:
            def __init__(self, val):
                self.value = val
        r_idx = row - 1
        c_idx = column - 1
        val = None
        if 0 <= r_idx < len(self.rows):
            r = self.rows[r_idx]
            if 0 <= c_idx < len(r):
                val = r[c_idx]
                if val == '' or (isinstance(val, float) and val != val):
                    val = None
        return Cell(val)

    def iter_rows(self, min_row=1, values_only=True):
        out = []
        r_start = max(0, min_row - 1)
        for r_idx in range(r_start, len(self.rows)):
            row_tuple = tuple(
                val if (val != '' and not (isinstance(val, float) and val != val)) else None
                for val in self.rows[r_idx]
            )
            out.append(row_tuple)
        return out

def read_csv_rows(path):
    import csv
    rows = []
    encodings = ['utf-8', 'utf-8-sig', 'latin-1', 'cp1252']
    for enc in encodings:
        try:
            with open(path, mode='r', encoding=enc) as f:
                sample = f.read(2048)
                f.seek(0)
                try:
                    dialect = csv.Sniffer().sniff(sample, delimiters=[',', ';', '\t'])
                except Exception:
                    dialect = 'excel'
                
                reader = csv.reader(f, dialect)
                for r in reader:
                    rows.append(r)
            break
        except Exception:
            continue
    return rows

def resolve_treasury_code(code, treasury_map=None, treasury_ids=None):
    if not code:
        return ""
    code = str(code).strip().upper()
    if code.endswith(".0"):
        code = code[:-2]
        
    # Remove any leading zeros and test if it matches keys/values in treasury_map
    if treasury_map:
        if code in treasury_map:
            return treasury_map[code]
        # Check if code is already a 3-digit number or matches values
        for k, v in treasury_map.items():
            if code == v:
                return v
            try:
                if int(code) == int(v):
                    return v
            except Exception:
                pass
                
    if treasury_ids:
        for k, v in treasury_ids.items():
            if code in k.upper():
                parts = v.split("~")
                if len(parts) > 1:
                    return parts[1].strip()
                return parts[0].strip()
                
    # Fallback to digits padding
    if code.isdigit():
        if len(code) == 2:
            return "0" + code
        elif len(code) == 1:
            return "00" + code
        return code
        
    # Check if there is a number at the start, e.g. "10-BAL"
    import re
    m = re.match(r"^(\d+)", code)
    if m:
        num = m.group(1)
        if len(num) == 2:
            return "0" + num
        elif len(num) == 1:
            return "00" + num
        return num
        
    return code

def parse_excel_sheet(app_instance, path, sheet_name=None, audit_mode_enabled=True):
    if path.lower().endswith(".csv"):
        app_instance.log(f"📖 Opening CSV file: {os.path.basename(path)}")
        csv_rows = read_csv_rows(path)
        if not csv_rows:
            app_instance.log("❌ Error: CSV file is empty or could not be parsed.")
            return []
        ws = MockCsvSheet(csv_rows)
    elif path.lower().endswith(".xls"):
        import xlrd
        app_instance.log(f"📖 Opening Excel sheet (xls) using xlrd: '{sheet_name}' from {os.path.basename(path)}")
        try:
            wb = xlrd.open_workbook(path)
            if sheet_name in wb.sheet_names():
                sheet = wb.sheet_by_name(sheet_name)
            else:
                sheet = wb.sheet_by_index(0)
            ws = MockXlrdSheet(sheet)
        except Exception as e:
            app_instance.log(f"❌ Failed to read Excel workbook via xlrd: {e}")
            return []
    else:
        app_instance.log(f"📖 Opening Excel sheet: '{sheet_name}' from {os.path.basename(path)}")
        df = None
        try:
            import polars as pl
            try:
                df = pl.read_excel(path, sheet_name=sheet_name, engine="calamine", read_options={"header_row": None})
            except Exception as e_cal:
                app_instance.log(f"⚠️ Calamine engine unavailable/failed ({e_cal}), trying fastexcel...")
                try:
                    df = pl.read_excel(path, sheet_name=sheet_name, engine="fastexcel", read_options={"header_row": None})
                except Exception as e_fast:
                    app_instance.log(f"⚠️ fastexcel engine failed ({e_fast}), falling back to openpyxl...")
                    df = None
        except Exception as e_pol:
            app_instance.log(f"⚠️ Polars unavailable/failed ({e_pol}), falling back to openpyxl...")
            df = None

        if df is not None:
            ws = MockPolarsSheet(df)
        else:
            from openpyxl import load_workbook
            wb = load_workbook(path, data_only=True, keep_links=False)
            if sheet_name and sheet_name not in wb.sheetnames:
                sheet_name = wb.sheetnames[0]
            ws = wb[sheet_name]

    # Auto-find headers
    header_row_idx = 1
    col_map = {}
    found_headers = False
    
    # Read first 15 rows to find the headers block
    for row_idx in range(1, 16):
        row_vals = [ws.cell(row=row_idx, column=c).value for c in range(1, min(ws.max_column + 1, 30))]
        if not any(row_vals): continue
        
        # Test if this row looks like a header
        cmap = {}
        cmap_priority = {}
        for c_idx, val in enumerate(row_vals):
            if val is None: continue
            val_clean = str(val).strip().lower()
            
            # Helper to check match and set based on keyword specificity (index in header list)
            def check_and_set(key, headers_list):
                for idx, h in enumerate(headers_list):
                    if h in val_clean:
                        if key not in cmap or idx < cmap_priority[key]:
                            cmap[key] = c_idx
                            cmap_priority[key] = idx
                        return True
                return False
            
            def _combine_headers(attr, default_list):
                app_list = getattr(app_instance, attr, []) or []
                res = []
                for item in app_list + default_list:
                    if item not in res:
                        res.append(item)
                return res

            headers_mh = _combine_headers('headers_mh', ['mh', 'major head', 'major_head', 'majorhead', 'head'])
            headers_treasury = _combine_headers('headers_treasury', ['treasury', 'try', 'trs', 'treasury_code', 'district'])
            headers_voucher = _combine_headers('headers_voucher', ['voucher', 'vou', 'vch', 'v_no', 'vno', 'voucher_number', 'voucher number', 'bill_no', 'bill no', 'token', 's_no', 's.no'])
            headers_amount = _combine_headers('headers_amount', [
                'sop_vch_amt', 'sop_vch_amount', 'sop_vch', 'sop_amt', 'vch_amt', 'vch_amount',
                'voucher_amount', 'voucher amount', 'amount_paid', 'amount paid', 'paid_amount',
                'paid amount', 'gross_amt', 'gross_amount', 'net_amt', 'net_amount', 'claim_amt',
                'claim_amount', 'amount', 'amt', 'total', 'claim', 'value', 'val'
            ])
            headers_from_date = _combine_headers('headers_from_date', ['from_date', 'from date', 'fromdate', 'start_date', 'date_of_payment', 'date of payment', 'payment_date'])
            headers_month = _combine_headers('headers_month', ['month', 'mon'])
            headers_year = _combine_headers('headers_year', ['year', 'yr'])
            headers_ddo = _combine_headers('headers_ddo', ['ddo', 'ddo_code'])
            headers_to_date = _combine_headers('headers_to_date', ['to_date', 'to date', 'todate', 'end_date'])
            headers_bill_type = _combine_headers('headers_bill_type', ['bill_type', 'bill type', 'type'])

            # Check maps sequentially (prioritizing amount check if header contains 'amt' or 'amount')
            if any(x in val_clean for x in ('amt', 'amount')) and check_and_set('amount', headers_amount): pass
            elif check_and_set('mh', headers_mh): pass
            elif check_and_set('treasury', headers_treasury): pass
            elif check_and_set('voucher', headers_voucher): pass
            elif check_and_set('amount', headers_amount): pass
            elif check_and_set('month', headers_month): pass
            elif check_and_set('year', headers_year): pass
            elif check_and_set('ddo', headers_ddo): pass
            elif check_and_set('from_date', headers_from_date): pass
            elif check_and_set('to_date', headers_to_date): pass
            elif check_and_set('bill_type', headers_bill_type): pass

        # We consider it a header row if:
        # 1. We have both voucher and treasury columns
        # 2. Or we have both voucher and amount columns (common for smart combined voucher sheets)
        # 3. Or we have at least 3 useful columns (voucher, amount, ddo, major head, month, year, treasury)
        matching_keys = [k for k in ['voucher', 'amount', 'treasury', 'mh', 'month', 'year', 'ddo'] if k in cmap]
        if ('voucher' in cmap and 'treasury' in cmap) or ('voucher' in cmap and 'amount' in cmap) or len(matching_keys) >= 3:
            col_map = cmap
            header_row_idx = row_idx
            found_headers = True
            break

    if not found_headers:
        app_instance.log("⚠️ Could not automatically detect header row columns. Trying default first row...")
        col_map = {'treasury': 0, 'mh': 1, 'voucher': 2, 'amount': 3, 'month': 4, 'year': 5}
        # Fallback: try to locate the actual amount column by scanning headers or numeric values > 100
        if not found_headers:
            for r_idx in range(2, min(ws.max_row, 30)):
                for c_idx in range(1, ws.max_column + 1):
                    cell_val = ws.cell(row=r_idx, column=c_idx).value
                    # Skip month (1-12), year (2020-2035), and small integer codes
                    if isinstance(cell_val, (int, float)) and cell_val > 100 and cell_val not in range(2000, 2035):
                        hdr_val = str(ws.cell(row=1, column=c_idx).value or "").lower()
                        if not any(k in hdr_val for k in ('month', 'year', 'yr', 'mon', 'try', 'treasury', 's_no', 's.no', 'sr')):
                            col_map['amount'] = c_idx - 1  # zero-based index
                            app_instance.log(f"🔎 Fallback detected amount column at index {c_idx} ({hdr_val}).")
                            break
                else:
                    continue
                break
                break
        header_row_idx = 1

    # Smart Voucher mapping checker (Row 4 format like: '420/8011/022025-26/0065')
    smart_voucher_idx = None
    for c_idx in range(ws.max_column):
        sample_cell = ws.cell(row=header_row_idx + 1, column=c_idx + 1).value
        if sample_cell:
            s_val = str(sample_cell).strip()
            # Match Treasury/MH/MonthYear/Voucher
            if re.match(r'^\d{3}/\d{4}/\d{8}-\d{2}/\d{4}$', s_val) or re.match(r'^\d{3}/\d{4}/\d{6}-\d{2}/\d{4}$', s_val) or re.match(r'^\d{3}/\d{4}/\d+/\d+$', s_val):
                smart_voucher_idx = c_idx
                app_instance.log(f"🧠 Detected Smart Combined Voucher Column: Column {c_idx+1} ({ws.cell(row=header_row_idx, column=c_idx+1).value})")
                break

    # Multi-Column Voucher Layout Checker (Sequential Columns: Treasury | Major Head | Voucher No | MonthYear)
    multi_col_tuple = None
    if smart_voucher_idx is None:
        sample_r2 = [ws.cell(row=header_row_idx + 1, column=c + 1).value for c in range(min(ws.max_column, 25))]
        for c in range(len(sample_r2) - 3):
            v_tr = str(sample_r2[c] or '').strip()
            v_mh = str(sample_r2[c+1] or '').strip()
            v_vc = str(sample_r2[c+2] or '').strip()
            v_my = str(sample_r2[c+3] or '').strip()
            if re.match(r'^\d{3}$', v_tr) and re.match(r'^\d{4}$', v_mh) and re.match(r'^\d+$', v_vc) and re.search(r'\d{6,8}', v_my):
                multi_col_tuple = (c, c+1, c+2, c+3)
                col_map['treasury'] = c
                col_map['mh'] = c + 1
                col_map['voucher'] = c + 2
                col_map['month_year_block'] = c + 3
                app_instance.log(f"🧠 Detected Multi-Column Voucher Layout: Treasury=Col {c+1}, MH=Col {c+2}, Voucher=Col {c+3}, MonthYear=Col {c+4}")
                break

    rows = []
    s_no_counter = 1
    
    for row in list(ws.iter_rows(min_row=header_row_idx + 1, values_only=True)):
        if not any(val is not None for val in row): continue
        
        row_data = {}
        parsed_smart = None
        
        if smart_voucher_idx is not None and smart_voucher_idx < len(row):
            smart_val = row[smart_voucher_idx]
            if smart_val:
                val_str = str(smart_val).strip()
                parts = val_str.split('/')
                if len(parts) >= 3:
                    try_code = parts[0].strip()
                    mh_code = parts[1].strip()
                    month_yr_part = parts[2].strip()
                    vch_no = parts[3].strip() if len(parts) > 3 else ""
                    
                    # Resolve month and year from financial month-year block like 022025-26
                    m_val = None
                    y_val = None
                    
                    m_match = re.match(r'^(\d{2})', month_yr_part)
                    if m_match:
                        m_val = int(m_match.group(1))
                    
                    fy_match = re.search(r'(\d{4})\s*-\s*(\d{2})', month_yr_part)
                    if fy_match:
                        fy_start = int(fy_match.group(1))
                        fy_end = 2000 + int(fy_match.group(2))
                        if m_val is not None and 1 <= m_val <= 3:
                            y_val = fy_end
                        else:
                            y_val = fy_start
                    else:
                        yr_match = re.search(r'\d{4}', month_yr_part)
                        if yr_match:
                            y_val = int(yr_match.group(0))
                            
                    parsed_smart = {
                        "treasury": try_code,
                        "mh": mh_code,
                        "month": m_val if (m_val and 1 <= m_val <= 12) else datetime.datetime.now().month,
                        "year": y_val if y_val else datetime.datetime.now().year,
                        "voucher": vch_no
                    }

        if parsed_smart:
            row_data['treasury'] = resolve_treasury_code(parsed_smart["treasury"], app_instance.TREASURY_MAP, app_instance.TREASURY_IDS)
            row_data['mh'] = parsed_smart["mh"]
            row_data['month'] = parsed_smart["month"]
            row_data['year'] = parsed_smart["year"]
            row_data['voucher'] = parsed_smart["voucher"]
            
            # Extract actual amount if column is mapped, handling numeric cells
            amt_idx = col_map.get('amount')
            if amt_idx is not None and amt_idx < len(row):
                val = row[amt_idx]
                row_data['amount'] = str(_extract_amount(val))
            else:
                row_data['amount'] = "0"
            
            # Resolve DDO code if column exists
            ddo_idx = col_map.get('ddo')
            if ddo_idx is not None and ddo_idx < len(row) and row[ddo_idx] is not None:
                row_data['ddo'] = str(row[ddo_idx]).strip().split(".")[0]
            else:
                row_data['ddo'] = ""
        elif multi_col_tuple is not None:
            try_idx, mh_idx, vch_idx, my_idx = multi_col_tuple
            row_data['treasury'] = resolve_treasury_code(str(row[try_idx]).strip() if try_idx < len(row) and row[try_idx] is not None else "", app_instance.TREASURY_MAP, app_instance.TREASURY_IDS)
            row_data['mh'] = str(row[mh_idx]).strip() if mh_idx < len(row) and row[mh_idx] is not None else ""
            row_data['voucher'] = str(row[vch_idx]).strip().split(".")[0] if vch_idx < len(row) and row[vch_idx] is not None else ""
            
            my_str = str(row[my_idx]).strip() if my_idx < len(row) and row[my_idx] is not None else ""
            m_match = re.match(r'^(\d{2})', my_str)
            m_val = int(m_match.group(1)) if m_match else datetime.datetime.now().month
            
            fy_match = re.search(r'(\d{4})\s*-\s*(\d{2})', my_str)
            if fy_match:
                fy_start = int(fy_match.group(1))
                fy_end = 2000 + int(fy_match.group(2))
                y_val = fy_end if 1 <= m_val <= 3 else fy_start
            else:
                yr_match = re.search(r'\d{4}', my_str)
                y_val = int(yr_match.group(0)) if yr_match else datetime.datetime.now().year
                
            row_data['month'] = m_val
            row_data['year'] = y_val
            
            amt_idx = col_map.get('amount')
            if amt_idx is not None and amt_idx < len(row):
                row_data['amount'] = str(_extract_amount(row[amt_idx]))
            else:
                row_data['amount'] = "0"

            ddo_idx = col_map.get('ddo')
            if ddo_idx is not None and ddo_idx < len(row) and row[ddo_idx] is not None:
                row_data['ddo'] = str(row[ddo_idx]).strip().split(".")[0]
            else:
                row_data['ddo'] = ""
        else:

            try_idx = col_map.get('treasury')
            mh_idx = col_map.get('mh')
            vch_idx = col_map.get('voucher')
            amt_idx = col_map.get('amount')
            month_idx = col_map.get('month')
            year_idx = col_map.get('year')
            ddo_idx = col_map.get('ddo')
            
            if try_idx is not None and try_idx < len(row):
                val = row[try_idx]
                row_data['treasury'] = resolve_treasury_code(str(val).strip() if val is not None else "", app_instance.TREASURY_MAP, app_instance.TREASURY_IDS)
            else:
                row_data['treasury'] = ""
                
            if mh_idx is not None and mh_idx < len(row):
                val = row[mh_idx]
                row_data['mh'] = str(val).strip() if val is not None else ""
            else:
                row_data['mh'] = ""
                
            if vch_idx is not None and vch_idx < len(row):
                val = row[vch_idx]
                vch_str = str(val).strip().split(".")[0] if val is not None else ""
                row_data['voucher'] = vch_str.lstrip('0') if vch_str else ""
                if vch_str and not row_data['voucher']:
                    row_data['voucher'] = "0"
            else:
                row_data['voucher'] = ""
                
            if amt_idx is not None and amt_idx < len(row):
                val = row[amt_idx]
                row_data['amount'] = str(_extract_amount(val))
            else:
                row_data['amount'] = "0"
                
            if ddo_idx is not None and ddo_idx < len(row):
                val = row[ddo_idx]
                row_data['ddo'] = str(val).strip().split(".")[0] if val is not None else ""
            else:
                row_data['ddo'] = ""

            # Month and Year resolver
            m_val = datetime.datetime.now().month
            y_val = datetime.datetime.now().year
            
            if month_idx is not None and month_idx < len(row) and row[month_idx] is not None:
                m_str = str(row[month_idx]).strip().split(".")[0]
                if not m_str.isdigit():
                    try:
                        m_val = datetime.datetime.strptime(m_str, '%B').month
                    except ValueError:
                        try:
                            m_val = datetime.datetime.strptime(m_str, '%b').month
                        except ValueError:
                            pass
                else:
                    m_val = int(m_str)
                    
            if year_idx is not None and year_idx < len(row) and row[year_idx] is not None:
                y_str = str(row[year_idx]).strip().split(".")[0]
                if y_str.isdigit():
                    y_val = int(y_str)
                    
            row_data['month'] = m_val
            row_data['year'] = y_val

        # Fallback Amount Extraction if mapped amount is missing, empty, or zero
        amt_val = row_data.get('amount')
        if not amt_val or str(amt_val).strip() in ("0", "0.0", "0.00", ""):
            for cell_idx, cell_val in enumerate(row):
                if cell_val is not None:
                    try:
                        # Direct numeric values are accepted immediately
                        if isinstance(cell_val, (int, float)):
                            if cell_val > 0:
                                if smart_voucher_idx is None or cell_idx != smart_voucher_idx:
                                    row_data['amount'] = str(cell_val)
                                    break
                        else:
                            c_str = str(cell_val).strip()
                            if c_str and c_str.lower() not in ("none", "null") and '/' not in c_str:
                                c_amt = float(_extract_amount(c_str))
                                if c_amt > 0:
                                    if smart_voucher_idx is None or cell_idx != smart_voucher_idx:
                                        row_data['amount'] = str(_extract_amount(c_str))
                                        break
                    except Exception:
                        pass
        row_data['s_no'] = str(s_no_counter)
        s_no_counter += 1
        
        # Sanitize all fields: strip Excel formula wrappers ="..." from linked CSV exports
        for _fkey in ('voucher', 'treasury', 'mh', 'ddo'):
            row_data[_fkey] = clean_formula_val(row_data.get(_fkey, ''))
        
        # Folder mapping name
        try:
            m_lbl = f"{int(row_data['month']):02d}_{int(row_data['year'])}"
        except Exception:
            m_lbl = "UNKNOWN_DATE"
            
        clean_fn = getattr(app_instance, "clean_folder_name", lambda s: re.sub(r'[\\/*?:"<>|]', "", str(s)))
        clean_tr = clean_fn(str(row_data['treasury']))
        clean_vch = clean_fn(str(row_data['voucher']))
        clean_amt = clean_fn(str(row_data['amount'])) if row_data.get('amount') is not None else ""
        
        folder_parts = [
            str(row_data['s_no']),
            clean_tr,
            str(row_data['mh']),
            m_lbl,
            clean_vch
        ]
        if clean_amt and clean_amt != "None":
            folder_parts.append(clean_amt)
        row_data['folder_name'] = "_".join(folder_parts)
        
        # Validations: Require voucher, major head, and treasury to be present
        if row_data['voucher'] and row_data['mh'] and row_data['treasury']:
            rows.append(row_data)

    app_instance.log(f"✅ Excel parsing completed: Found {len(rows)} voucher rows.")
    return rows

def parse_pol_excel_sheet(app_instance, path, sheet_name):
    if path.lower().endswith(".csv"):
        app_instance.log(f"📖 Opening POL CSV file: {os.path.basename(path)}")
        csv_rows = read_csv_rows(path)
        if not csv_rows:
            app_instance.log("❌ Error: CSV file is empty or could not be parsed.")
            return []
        ws = MockCsvSheet(csv_rows)
    elif path.lower().endswith(".xls"):
        import xlrd
        app_instance.log(f"📖 Opening POL Excel sheet (xls) using xlrd: '{sheet_name}'")
        try:
            wb = xlrd.open_workbook(path)
            if sheet_name in wb.sheet_names():
                sheet = wb.sheet_by_name(sheet_name)
            else:
                sheet = wb.sheet_by_index(0)
            ws = MockXlrdSheet(sheet)
        except Exception as e:
            app_instance.log(f"❌ Failed to read POL Excel workbook via xlrd: {e}")
            return []
    else:
        app_instance.log(f"📖 Opening POL Excel sheet: '{sheet_name}'")
        df = None
        try:
            import polars as pl
            try:
                df = pl.read_excel(path, sheet_name=sheet_name, engine="calamine", read_options={"header_row": None})
            except Exception as e_cal:
                app_instance.log(f"⚠️ Calamine engine unavailable/failed ({e_cal}), trying fastexcel...")
                try:
                    df = pl.read_excel(path, sheet_name=sheet_name, engine="fastexcel", read_options={"header_row": None})
                except Exception as e_fast:
                    app_instance.log(f"⚠️ fastexcel engine failed ({e_fast}), falling back to openpyxl...")
                    df = None
        except Exception as e_pol:
            app_instance.log(f"⚠️ Polars unavailable/failed ({e_pol}), falling back to openpyxl...")
            df = None

        if df is not None:
            ws = MockPolarsSheet(df)
        else:
            from openpyxl import load_workbook
            wb = load_workbook(path, data_only=True, keep_links=False)
            if sheet_name and sheet_name not in wb.sheetnames:
                sheet_name = wb.sheetnames[0]
            ws = wb[sheet_name]

    # Find headers
    col_map = {}
    header_row_idx = 1
    
    def is_header_match(val_clean, header_list):
        for h in header_list:
            if h == val_clean:
                return True
            if h in val_clean:
                if h in ('from', 'to'):
                    if any(x in val_clean for x in ('year', 'yr', 'amount', 'amt', 'vch', 'vou', 'no', 'num', 'code', 'cd', 'ddo')):
                        continue
                return True
        return False
    
    # Read first 15 rows to find the best headers block
    best_row_idx = 1
    best_cmap = {}
    max_matches = 0

    for row_idx in range(1, 16):
        row_vals = [ws.cell(row=row_idx, column=c).value for c in range(1, min(ws.max_column + 1, 30))]
        if not any(row_vals): continue
        
        cmap = {}
        vlc_amt_cidx = None
        compay_amt_cidx = None
        generic_amt_cidx = None

        for c_idx, val in enumerate(row_vals):
            if val is None: continue
            val_clean = str(val).strip().lower()

            # Always check specific VLC amount headers first for strict priority
            if any(h in val_clean for h in ['vlc voucher amount', 'amount (vlc)', 'vlc_amount', 'vlc_amt', 'amount_vlc']):
                if vlc_amt_cidx is None: vlc_amt_cidx = c_idx
            elif any(h in val_clean for h in ['compay voucher amount', 'sop_vch_amt', 'amount (pol)', 'sop_vch_amount']):
                if compay_amt_cidx is None: compay_amt_cidx = c_idx
            elif any(x in val_clean for x in ('amt', 'amount')) and is_header_match(val_clean, app_instance.headers_amount):
                if generic_amt_cidx is None: generic_amt_cidx = c_idx
            
            if is_header_match(val_clean, app_instance.headers_ddo): cmap['ddo'] = c_idx
            elif is_header_match(val_clean, app_instance.headers_treasury): cmap['treasury'] = c_idx
            elif is_header_match(val_clean, app_instance.headers_from_date): cmap['from_date'] = c_idx
            elif is_header_match(val_clean, app_instance.headers_to_date): cmap['to_date'] = c_idx
            elif is_header_match(val_clean, app_instance.headers_month): cmap['month'] = c_idx
            elif is_header_match(val_clean, app_instance.headers_year): cmap['year'] = c_idx
            elif is_header_match(val_clean, app_instance.headers_bill_type): cmap['bill_type'] = c_idx
            elif is_header_match(val_clean, app_instance.headers_voucher): cmap['voucher'] = c_idx
            elif is_header_match(val_clean, app_instance.headers_mh): cmap['mh'] = c_idx

        # Enforce strict priority: VLC Amount > Generic Amount > COMPAY Amount
        if vlc_amt_cidx is not None:
            cmap['amount'] = vlc_amt_cidx
        elif generic_amt_cidx is not None:
            cmap['amount'] = generic_amt_cidx
        elif compay_amt_cidx is not None:
            cmap['amount'] = compay_amt_cidx

        if len(cmap) > max_matches:
            max_matches = len(cmap)
            best_row_idx = row_idx
            best_cmap = cmap

    col_map = best_cmap
    header_row_idx = best_row_idx

    if 'ddo' not in col_map:
        col_map['ddo'] = 0

    # Ensure all headers in header_row_idx are scanned for amount, voucher, mh, treasury, etc.
    header_vals = [ws.cell(row=header_row_idx, column=c).value for c in range(1, ws.max_column + 1)]
    for c_idx, val in enumerate(header_vals):
        if val is None:
            continue
        val_clean = str(val).strip().lower()
        if 'vlc voucher amount' in val_clean or 'amount (vlc)' in val_clean:
            col_map['amount'] = c_idx
        elif 'amount' not in col_map and any(h in val_clean for h in app_instance.headers_amount):
            col_map['amount'] = c_idx
        if 'voucher' not in col_map and any(h in val_clean for h in app_instance.headers_voucher):
            col_map['voucher'] = c_idx
        if 'mh' not in col_map and any(h in val_clean for h in app_instance.headers_mh):
            col_map['mh'] = c_idx
        if 'treasury' not in col_map and any(h in val_clean for h in app_instance.headers_treasury):
            col_map['treasury'] = c_idx
        if 'month' not in col_map and any(h in val_clean for h in app_instance.headers_month):
            col_map['month'] = c_idx
        if 'year' not in col_map and any(h in val_clean for h in app_instance.headers_year):
            col_map['year'] = c_idx

    smart_voucher_idx = None
    for c_idx in range(ws.max_column):
        sample_cell = ws.cell(row=header_row_idx + 1, column=c_idx + 1).value
        if sample_cell:
            s_val = str(sample_cell).strip()
            if re.match(r'^\d{3}/\d{4}/\d{8}-\d{2}/\d{4}$', s_val) or re.match(r'^\d{3}/\d{4}/\d{6}-\d{2}/\d{4}$', s_val) or re.match(r'^\d{3}/\d{4}/\d+/\d+$', s_val):
                smart_voucher_idx = c_idx
                break

    if smart_voucher_idx is not None:
        col_map['smart_voucher'] = smart_voucher_idx

    rows = []
    
    for row in list(ws.iter_rows(min_row=header_row_idx + 1, values_only=True)):
        if not any(val is not None for val in row): continue
        
        row_data = {}
        ddo_idx = col_map.get('ddo')
        if ddo_idx is not None and ddo_idx < len(row):
            ddo_val = row[ddo_idx]
            if ddo_val is not None:
                row_data['ddo'] = str(ddo_val).strip().split(".")[0]
            else:
                continue
        else:
            continue
            
        smart_idx = col_map.get('smart_voucher')
        parsed_smart = None
        if smart_idx is not None and smart_idx < len(row):
            smart_val = row[smart_idx]
            if smart_val:
                val_str = str(smart_val).strip()
                parts = val_str.split('/')
                if len(parts) >= 3:
                    try_code = parts[0].strip()
                    month_yr_part = parts[2].strip()
                    
                    m_val = None
                    y_val = None
                    m_match = re.match(r'^(\d{2})', month_yr_part)
                    if m_match:
                        m_val = int(m_match.group(1))
                    
                    fy_match = re.search(r'(\d{4})\s*-\s*(\d{2})', month_yr_part)
                    if fy_match:
                        fy_start = int(fy_match.group(1))
                        fy_end = 2000 + int(fy_match.group(2))
                        if m_val is not None and 1 <= m_val <= 3:
                            y_val = fy_end
                        else:
                            y_val = fy_start
                    else:
                        yr_match = re.search(r'\d{4}', month_yr_part)
                        if yr_match:
                            y_val = int(yr_match.group(0))
                            
                    parsed_smart = {
                        "treasury": try_code,
                        "month": m_val if (m_val and 1 <= m_val <= 12) else datetime.datetime.now().month,
                        "year": y_val if y_val else datetime.datetime.now().year
                    }

        if parsed_smart:
            row_data['treasury'] = parsed_smart["treasury"]
            m = parsed_smart["month"]
            y = parsed_smart["year"]
            try:
                from_date_str = f"01/{m:02d}/{y}"
                last_day = calendar.monthrange(y, m)[1]
                to_date_str = f"{last_day:02d}/{m:02d}/{y}"
            except Exception as date_err:
                app_instance.log(f"⚠️ Failed to calculate dates from smart voucher: {date_err}")
                from_date_str = ""
                to_date_str = ""
        else:
            try_idx = col_map.get('treasury')
            if try_idx is not None and try_idx < len(row):
                try_val = row[try_idx]
                row_data['treasury'] = str(try_val).strip() if try_val is not None else ""
            else:
                row_data['treasury'] = ""
                
            from_idx = col_map.get('from_date')
            to_idx = col_map.get('to_date')
            month_idx = col_map.get('month')
            year_idx = col_map.get('year')
            
            from_date_str = ""
            to_date_str = ""
            
            if from_idx is not None and from_idx < len(row) and row[from_idx] is not None:
                val = row[from_idx]
                if isinstance(val, (datetime.datetime, datetime.date)):
                    from_date_str = val.strftime('%d/%m/%Y')
                else:
                    from_date_str = standardize_date(str(val).strip())
            
            if to_idx is not None and to_idx < len(row) and row[to_idx] is not None:
                val = row[to_idx]
                if isinstance(val, (datetime.datetime, datetime.date)):
                    to_date_str = val.strftime('%d/%m/%Y')
                else:
                    to_date_str = standardize_date(str(val).strip())
                    
            if (not from_date_str or not to_date_str) and month_idx is not None and year_idx is not None:
                month_val = row[month_idx]
                year_val = row[year_idx]
                if month_val is not None and year_val is not None:
                    try:
                        m_str = str(month_val).strip().split(".")[0]
                        y_str = str(year_val).strip().split(".")[0]
                        
                        if not m_str.isdigit():
                            try:
                                month_num = datetime.datetime.strptime(m_str, '%B').month
                            except ValueError:
                                month_num = datetime.datetime.strptime(m_str, '%b').month
                        else:
                            month_num = int(m_str)
                            
                        year_num = int(y_str)
                        
                        from_date_str = f"01/{month_num:02d}/{year_num}"
                        last_day = calendar.monthrange(year_num, month_num)[1]
                        to_date_str = f"{last_day:02d}/{month_num:02d}/{year_num}"
                    except Exception as date_err:
                        app_instance.log(f"⚠️ Failed to parse month/year: {date_err}")
                    
        row_data['from_date'] = from_date_str
        row_data['to_date'] = to_date_str
        
        bill_type_val = ""
        bt_idx = col_map.get('bill_type')
        if bt_idx is not None and bt_idx < len(row) and row[bt_idx] is not None:
            bt_raw = str(row[bt_idx]).strip().lower()
            if "non" in bt_raw:
                bill_type_val = "Non-SNA"
            elif "sna" in bt_raw:
                bill_type_val = "SNA"
        row_data['bill_type'] = bill_type_val
        
        # Override treasury with the first 3 digits of DDO code if available and valid
        if 'ddo' in row_data and len(row_data['ddo']) >= 3:
            ddo_digits = re.match(r"^(\d{3})", row_data['ddo'])
            if ddo_digits:
                row_data['treasury'] = ddo_digits.group(1)
                
        rows.append(row_data)

    app_instance.log(f"✅ POL Excel parsing completed: Found {len(rows)} DDO rows.")
    return rows
