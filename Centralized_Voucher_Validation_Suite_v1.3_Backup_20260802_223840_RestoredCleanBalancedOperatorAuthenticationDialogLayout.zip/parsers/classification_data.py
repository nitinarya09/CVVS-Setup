import os
import csv

# Form Number to Bill Type mapping (from user specification)
FORM_BILL_TYPE_MAP = {
    "24": {"bill_type": "Pay Bill", "form": "Form 203", "description": "Establishment Pay Bill"},
    "34": {"bill_type": "FVC", "form": "Form 103", "description": "Fully Vouched Contingent Bill"},
    "46": {"bill_type": "GIA Bill", "form": "Forms 104, 160", "description": "Grant-in-Aid Bill"},
    "63": {"bill_type": "GPF Withdrawal", "form": "Form 111", "description": "Provident Fund Withdrawal"},
    "40": {"bill_type": "Pension", "form": "Form 106", "description": "Pension Bill (to confirm from PCCR)"},
    "44": {"bill_type": "Refund", "form": "Form 109", "description": "Refund Bill"},
    "24A": {"bill_type": "Medical Bill", "form": "Form 105", "description": "Medical Reimbursement Bill"},
    "28": {"bill_type": "TA Bill", "form": "Form 110", "description": "Travelling Allowance Bill"},
}

# Standard deduction classification codes
DEDUCTION_CODES = {
    "0028": "Professional Tax",
    "0216": "HRA (House Rent Allowance)",
    "8658-139": "GST TDS",
    "8658-112": "IT TDS (Income Tax)",
}

class ClassificationLookup:
    def __init__(self, data_dir=None):
        if data_dir is None:
            data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
        self.data_dir = data_dir
        self.major_heads = {}  # code -> name
        self.object_heads = {} # code -> description
        self._load()
    
    def _load(self):
        major_head_path = os.path.join(self.data_dir, 'MP_Major_Heads.csv')
        object_head_path = os.path.join(self.data_dir, 'MP_Object_Heads.csv')
        
        if os.path.exists(major_head_path):
            try:
                with open(major_head_path, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        code = row.get('Major Head Code')
                        name = row.get('Major Head Name')
                        if code and name:
                            self.major_heads[code.strip()] = name.strip()
            except Exception as e:
                print(f"Error reading {major_head_path}: {e}")
                
        if os.path.exists(object_head_path):
            try:
                with open(object_head_path, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        code = row.get('Object Head Code')
                        desc = row.get('English Description')
                        if code and desc:
                            self.object_heads[code.strip()] = desc.strip()
            except Exception as e:
                print(f"Error reading {object_head_path}: {e}")
    
    def lookup_major_head(self, code):
        return self.major_heads.get(str(code).strip(), "Unknown Major Head")
    
    def lookup_object_head(self, code):
        return self.object_heads.get(str(code).strip(), "Unknown Object Head")
    
    def get_form_bill_type(self, form_number):
        return FORM_BILL_TYPE_MAP.get(str(form_number).strip().upper())
    
    def validate_classification(self, head_of_account_str):
        if not head_of_account_str:
            return {"valid": False, "errors": ["Head of account string is empty"]}
            
        parts = [p.strip() for p in str(head_of_account_str).split('-')]
        is_valid = True
        errors = []
        
        if len(parts) < 2:
            return {"valid": False, "errors": ["Invalid classification format"]}
            
        major_head = parts[1]
        if major_head and major_head not in self.major_heads:
            # We don't invalidate fully if the dict is empty, but we add an error message
            if self.major_heads: 
                is_valid = False
                errors.append(f"Major Head {major_head} not found")
            
        if len(parts) >= 9:
            object_head = parts[8]
            if object_head and object_head not in self.object_heads:
                if self.object_heads:
                    is_valid = False
                    errors.append(f"Object Head {object_head} not found")
                
        return {"valid": is_valid, "errors": errors}
