import re
import os
import sys
import time
import calendar
import traceback
import threading
import queue
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

# ── Ensure Suite directory & parent directory are in sys.path ──────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(SCRIPT_DIR)
for p in (SCRIPT_DIR, PARENT_DIR):
    if os.path.exists(p) and p not in sys.path:
        sys.path.insert(0, p)

PW_BROWSER_DIR = os.path.join(SCRIPT_DIR, "pw-browsers")
if os.path.isdir(PW_BROWSER_DIR):
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = PW_BROWSER_DIR

# Import helper modules
from tally_scraper import TallyScraper
from tally_excel_writer import TallyExcelWriter

try:
    from core.constants import TREASURY_MAP, TREASURY_IDS
except Exception:
    TREASURY_MAP = {}
    TREASURY_IDS = {}

# Import suite utilities
try:
    from parsers.excel_mapper import parse_excel_sheet, clean_amount_string
    from automation.scrapers.voucher_scraper import is_session_expired, resilient_goto, resilient_wait_for, wait_for_selector_with_retry
except Exception as e:
    print(f"Warning: Could not import some suite dependencies directly: {e}")



def _ensure_app_headers(app):
    """Ensures app instance has standard header lists attached if missing."""
    defaults = {
        "headers_voucher": ['voucher', 'vou', 'vch', 'v_no', 'vno', 'bill_no', 'bill no', 'token', 's_no', 's.no', 'sr_no', 'sr.no', 'serial'],
        "headers_treasury": ['treasury', 'try', 'trs', 'treasury_code', 'district'],
        "headers_mh": ['mh', 'major head', 'major_head', 'majorhead', 'head'],
        "headers_amount": ['amount', 'amt', 'net_amount', 'gross_amount', 'total', 'claim'],
        "headers_month": ['month', 'mon'],
        "headers_year": ['year', 'yr'],
        "headers_ddo": ['ddo', 'ddo_code'],
        "headers_from_date": ['from_date', 'from date', 'fromdate', 'start_date'],
        "headers_to_date": ['to_date', 'to date', 'todate', 'end_date'],
        "headers_bill_type": ['bill_type', 'bill type', 'type']
    }
    for attr, default_vals in defaults.items():
        if not hasattr(app, attr) or not getattr(app, attr):
            setattr(app, attr, default_vals)
    if not hasattr(app, "TREASURY_MAP") or not getattr(app, "TREASURY_MAP"):
        setattr(app, "TREASURY_MAP", TREASURY_MAP)
    if not hasattr(app, "TREASURY_IDS") or not getattr(app, "TREASURY_IDS"):
        setattr(app, "TREASURY_IDS", TREASURY_IDS)


class TallyEngine:
    """
    Orchestrates reading Excel vouchers, automating browser search,
    scraping Bill Details & FVC Bill tabs, and generating Green/Red workbooks.
    Uses Centralized Voucher Validation Suite's login sequence, storage_state, and stop safety.
    """

    def __init__(self, logger=None, progress_callback=None):
        self.logger = logger or (lambda msg, level="info": print(f"[{level.upper()}] {msg}"))
        self.progress_callback = progress_callback
        self.stop_requested = False
        self.is_running = False
        self.app_instance = None

        self.scraper = TallyScraper(logger=self.logger)
        self.writer = None
        self.counter_lock = threading.Lock()

        self.total_count = 0
        self.processed_count = 0
        self.matched_count = 0
        self.mismatched_count = 0
        self.error_count = 0
        self.TREASURY_MAP = TREASURY_MAP
        self.TREASURY_IDS = TREASURY_IDS

    def log(self, msg, level="info"):
        if self.logger:
            self.logger(msg, level)

    def select_dropdown(self, page, selector, code):
        """Standard dropdown selection matching Voucher Downloader logic."""
        if not code:
            return False
        code_str = str(code).strip().upper()
        resolved_num = None

        t_map = getattr(self, "TREASURY_MAP", TREASURY_MAP) or TREASURY_MAP
        t_ids = getattr(self, "TREASURY_IDS", TREASURY_IDS) or TREASURY_IDS

        if code_str in t_map:
            resolved_num = t_map[code_str]
        elif code_str in t_map.values():
            resolved_num = code_str

        if not resolved_num:
            for k, v in t_ids.items():
                if code_str in k.upper():
                    parts = v.split("~")
                    resolved_num = parts[0].strip()
                    break

        if not resolved_num and code_str.isdigit():
            clean_num = code_str.lstrip('0')
            for k, v in t_ids.items():
                parts = v.split("~")
                if len(parts) >= 2 and parts[1].strip().lstrip('0') == clean_num:
                    resolved_num = parts[0].strip()
                    break

        if not resolved_num:
            resolved_num = code_str

        dropdown = page.locator(f"#{selector}")
        dropdown.wait_for(state="attached")
        try:
            page.wait_for_function(f"document.querySelectorAll('#{selector} option').length > 1", timeout=5000)
        except Exception:
            pass

        options = dropdown.locator("option").all()
        for opt in options:
            val = (opt.get_attribute("value") or "").strip()
            txt = (opt.inner_text() or "").strip()
            if txt.startswith(resolved_num) or val == resolved_num:
                dropdown.select_option(value=val)
                self.log(f"✅ Selected Treasury: '{txt}' (ID: {val})")
                return True

        for opt in options:
            val = (opt.get_attribute("value") or "").strip()
            txt = (opt.inner_text() or "").strip()
            if code_str in txt.upper() or code_str in val.upper():
                dropdown.select_option(value=val)
                self.log(f"✅ Selected Treasury via fallback: '{txt}' (ID: {val})")
                return True

        self.log(f"⚠️ Could not find Treasury matching '{code}' (resolved: '{resolved_num}') in dropdown.", "warning")
        return False

    def request_stop(self):
        self.stop_requested = True
        if self.app_instance:
            self.app_instance.stop_requested = True
        self.log("🛑 Stop safety request received. Finishing active operations...", "warning")

    def is_stopped(self):
        if self.stop_requested:
            return True
        if self.app_instance and getattr(self.app_instance, "stop_requested", False):
            return True
        return False


    def run(self, excel_path, output_dir, deviation_enabled=False, headless=False, num_workers=1, app_instance=None, sheet_name=None):
        """
        Main execution entry point.
        """
        self.stop_requested = False
        self.is_running = True
        self.app_instance = app_instance

        self.processed_count = 0
        self.matched_count = 0
        self.mismatched_count = 0
        self.error_count = 0

        self.log(f"🚀 Starting Voucher Total Tally Tool...")
        self.log(f"📄 Reading Excel file: {os.path.basename(excel_path)}")
        self.log(f"⚙️ 2% Deviation Matching: {'ENABLED (±2%)' if deviation_enabled else 'DISABLED (Exact Match)'}")
        self.log(f"⚡ Parallel Workers: {num_workers}")

        if app_instance is None:
            class DummyApp:
                def log(s, m): pass
            app_instance = DummyApp()
        if not output_dir and app_instance and hasattr(app_instance, "get_tally_output_dir"):
            output_dir = app_instance.get_tally_output_dir()
        if not output_dir and app_instance and getattr(app_instance, "tally_output_dir", None):
            output_dir = app_instance.tally_output_dir
        if not output_dir:
            output_dir = os.path.normpath(os.path.join(getattr(app_instance, "download_dir", "downloads"), "Tally_Results"))
        output_dir = os.path.normpath(output_dir)
        os.makedirs(output_dir, exist_ok=True)

        # 1. Parse Excel Sheet using exact same parser as Voucher Downloader
        sheet = sheet_name or getattr(app_instance, "tally_selected_sheet", "") or getattr(app_instance, "voucher_selected_sheet", "") or None
        raw_rows = []

        if hasattr(app_instance, "parse_excel_sheet") and callable(app_instance.parse_excel_sheet):
            raw_rows = app_instance.parse_excel_sheet(excel_path, sheet, True)
        else:
            raw_rows = parse_excel_sheet(app_instance, excel_path, sheet, True)

        if not raw_rows:
            self.log("❌ Excel file is empty or headers could not be parsed.", "error")
            self.is_running = False
            return None

        # Group multiple beneficiary rows for the same voucher (by voucher, mh, treasury, month, year)
        grouped_vouchers = {}
        voucher_order = []
        for r in raw_rows:
            vou = str(r.get("voucher", "")).strip()
            mh = str(r.get("mh", "")).strip()
            treasury = str(r.get("treasury", "")).strip()
            month = str(r.get("month", "")).strip()
            year = str(r.get("year", "")).strip()
            v_key = (vou, mh, treasury, month, year) if (vou or mh or treasury) else id(r)

            from automation.scrapers.voucher_scraper import extract_row_amount
            amt_val = extract_row_amount(r)

            if v_key not in grouped_vouchers:
                m_row = dict(r)
                m_row["amount"] = amt_val
                m_row["payee_count"] = 1
                grouped_vouchers[v_key] = m_row
                voucher_order.append(v_key)
            else:
                grouped_vouchers[v_key]["amount"] += amt_val
                grouped_vouchers[v_key]["payee_count"] += 1

        grouped_rows = [grouped_vouchers[k] for k in voucher_order]

        self.total_count = len(grouped_rows)
        self.log(f"✅ Loaded {len(raw_rows)} rows grouped into {self.total_count} unique vouchers from Excel.")

        first_row = raw_rows[0]
        headers = list(first_row.keys())

        self.writer = TallyExcelWriter(original_headers=headers, output_dir=output_dir)

        task_queue = queue.Queue()
        for idx, r in enumerate(grouped_rows):
            task_queue.put((idx, r))


        actual_workers = min(max(1, num_workers), self.total_count)

        base_path = getattr(app_instance, "base_path", SCRIPT_DIR)
        state_file = os.path.join(base_path, "browser_state.json")

        def process_tasks_with_context(page, context, worker_id=1):
            resilient_goto(self, page, "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", base_timeout=60000)

            if is_session_expired(page):
                self.log(f"⚠️ Worker {worker_id}: Session expired or login required. Waiting for portal login...", "warning")
                for _ in range(60):
                    if self.is_stopped(): break
                    if not is_session_expired(page) and page.locator("#cmbTreasuryCodeName").count() > 0:
                        break
                    time.sleep(2)

            while not task_queue.empty() and not self.is_stopped():
                try:
                    idx, row = task_queue.get_nowait()
                except queue.Empty:
                    break

                vou = str(row.get("voucher", "")).strip()
                mh = str(row.get("mh", "")).strip()
                treasury = str(row.get("treasury", "")).strip()
                excel_amt_raw = row.get("amount", 0.0)

                try:
                    excel_amt = float(clean_amount_string(excel_amt_raw))
                except Exception:
                    excel_amt = 0.0

                w_tag = f"[W{worker_id}]" if actual_workers > 1 else ""
                self.log(f"🔍 {w_tag} [{idx+1}/{self.total_count}] Processing: MH={mh} Try={treasury} Vou={vou} | Excel Amt=₹{excel_amt:,.2f}")

                try:
                    res = self._process_single_voucher(page, context, row, excel_amt, deviation_enabled)
                    
                    with self.counter_lock:
                        self.processed_count += 1
                        if res["portal_total"] == 0.0:
                            res["portal_total"] = res["scraped_data"].get("gross_amount", 0.0) or res["scraped_data"].get("expenditure_amount", 0.0) or res["scraped_data"].get("net_amount", 0.0)
                        if res["overall_flag"] == "GREEN":
                            self.matched_count += 1
                            self.log(f"  ✅ {w_tag} MATCHED: Excel=₹{excel_amt:,.2f} | IFMIS Amt=₹{res['portal_total']:,.2f} | Dev=0.00%", "success")
                        else:
                            self.mismatched_count += 1
                            self.log(f"  ❌ {w_tag} MISMATCH: Excel=₹{excel_amt:,.2f} | IFMIS Amt=₹{res['portal_total']:,.2f} | Dev=₹{res['gross_dev']:,.2f} ({res['gross_dev_pct']:.2f}%)", "warning")

                    self.writer.add_result(row_data=row, scraped_data=res["scraped_data"], tally_result=res)

                except Exception as ve:
                    with self.counter_lock:
                        self.processed_count += 1
                        self.error_count += 1
                    err_msg = str(ve)
                    self.log(f"  ⚠️ {w_tag} Error processing voucher {vou}: {err_msg[:100]}", "error")
                    err_res = {
                        "excel_amount": excel_amt,
                        "portal_total": 0.0,
                        "gross_dev": excel_amt,
                        "gross_dev_pct": 100.0,
                        "gross_flag": "RED",
                        "overall_flag": "RED",
                        "remarks": f"Error: {err_msg[:80]}"
                    }
                    self.writer.add_result(row_data=row, scraped_data={}, tally_result=err_res)

                if self.progress_callback:
                    self.progress_callback(self.processed_count, self.total_count, self.matched_count, self.mismatched_count, self.error_count)

                task_queue.task_done()

        existing_page = getattr(app_instance, "browser_page", None)
        existing_context = getattr(app_instance, "browser_context", None)

        if actual_workers == 1 and existing_page and existing_context and not existing_page.is_closed():
            process_tasks_with_context(existing_page, existing_context, worker_id=1)
        else:
            if existing_context and not os.path.exists(state_file):
                try:
                    existing_context.storage_state(path=state_file)
                except Exception:
                    pass

            threads = []
            user_data_dir = os.path.join(SCRIPT_DIR, "USER_DATA")
            os.makedirs(user_data_dir, exist_ok=True)

            def worker_proc(w_id):
                pw_inst = None
                ctx_inst = None
                try:
                    pw_inst = sync_playwright().start()
                    c_dir = os.path.join(user_data_dir, f"tally_w_{w_id}")
                    os.makedirs(c_dir, exist_ok=True)

                    c_args = {
                        "user_data_dir": c_dir,
                        "headless": headless,
                        "args": ["--disable-blink-features=AutomationControlled", "--no-sandbox"],
                        "viewport": {"width": 1366, "height": 768}
                    }
                    if os.path.exists(state_file):
                        c_args["storage_state"] = state_file

                    ctx_inst = pw_inst.chromium.launch_persistent_context(**c_args)
                    p_inst = ctx_inst.pages[0] if ctx_inst.pages else ctx_inst.new_page()
                    process_tasks_with_context(p_inst, ctx_inst, worker_id=w_id)
                except Exception as ex:
                    self.log(f"❌ Worker {w_id} error: {ex}", "error")
                finally:
                    if ctx_inst:
                        try: ctx_inst.close()
                        except: pass
                    if pw_inst:
                        try: pw_inst.stop()
                        except: pass

            for w_id in range(1, actual_workers + 1):
                t = threading.Thread(target=worker_proc, args=(w_id,), daemon=True)
                threads.append(t)
                t.start()

            for t in threads:
                t.join()

        if self.writer:
            green_path, red_path = self.writer.save()
            self.log("─────────────────────────────────────────────────────────────")
            self.log("📊 TALLY EXECUTION COMPLETE SUMMARY:")
            self.log(f"  Total Processed: {self.processed_count}/{self.total_count}")
            self.log(f"  🟢 Matched Vouchers: {self.matched_count}")
            self.log(f"  🔴 Mismatched Vouchers: {self.mismatched_count}")
            self.log(f"  ⚠️ Errors / Not Found: {self.error_count}")
            self.log(f"  📂 Matched Excel: {green_path}")
            self.log(f"  📂 Mismatched Excel: {red_path}")

        self.is_running = False

    def _process_single_voucher(self, page, context, row_data, excel_amt, deviation_enabled):
        if self.is_stopped():
            raise Exception("Stop safety requested by user")

        s_no = row_data.get("s_no", "")
        mh = str(row_data.get("mh", "")).strip()
        treasury = str(row_data.get("treasury", "")).strip()
        vou = str(row_data.get("voucher", "")).strip()

        from_date = row_data.get("from_date", "")
        to_date = row_data.get("to_date", "")

        if not from_date or not to_date:
            month = int(row_data.get("month", 1))
            year = int(row_data.get("year", 2026))
            from_date = f"01/{month:02d}/{year}"
            to_date = f"{calendar.monthrange(year, month)[1]:02d}/{month:02d}/{year}"

        resilient_goto(self, page, "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", base_timeout=30000)

        if is_session_expired(page):
            raise Exception("Session expired during navigation")

        if treasury:
            self.select_dropdown(page, "cmbTreasuryCodeName", treasury)



        page.fill("#txtFrmBillDate", from_date)
        page.fill("#txtToBillDate", to_date)
        if mh:
            page.fill("#txtMajorHead", mh)
        if vou:
            page.fill("#txtSerialNo", vou)

        dialog_caught = {"msg": None}
        def on_dialog(d):
            dialog_caught["msg"] = d.message
            d.accept()
        page.on("dialog", on_dialog)

        page.click("#btnSearch")
        try: page.wait_for_load_state("networkidle", timeout=5000)
        except: pass

        if dialog_caught["msg"] and "no" in dialog_caught["msg"].lower():
            raise Exception("No Results Found on portal")

        content = page.content().lower()
        if "no record found" in content or "no records found" in content:
            raise Exception("No Results Found on portal")

        bill_link = page.locator("a[onclick*='showBillDtlByCtrlNo']").first
        if bill_link.count() == 0:
            raise Exception("Voucher details link not found in results grid")

        # Multi-attempt popup retry loop (up to 3 attempts with 25s timeout each to handle portal lag)
        bill_page = None
        for popup_attempt in range(1, 4):
            try:
                # Close any stale extra pages before opening popup
                for p in list(context.pages):
                    if p != page and not p.is_closed():
                        try: p.close(run_before_unload=False)
                        except Exception: pass

                with context.expect_page(timeout=25000) as new_page_info:
                    if popup_attempt == 1:
                        bill_link.click(force=True)
                    else:
                        bill_link.evaluate("el => { el.dispatchEvent(new Event('click', {bubbles:true})); if (typeof el.click === 'function') el.click(); }")
                
                bill_page = new_page_info.value
                try: bill_page.wait_for_load_state("domcontentloaded", timeout=12000)
                except Exception: pass
                break
            except Exception as ex_open:
                self.log(f"⚠️ Popup open attempt {popup_attempt}/3 timed out/failed due to IFMIS portal slowdown ({ex_open}). Retrying...")
                time.sleep(1.5)

        if not bill_page or bill_page == page:
            raise Exception("IFMIS Portal Lag: Details popup window failed to open after 3 attempts")

        # Ensure page fields are populated before scraping
        try:
            bill_page.wait_for_selector("#txtGrossTotal, #txtBillExpAmt, #lblGrossTotal, table#tblbillDetailHeadExp, input[name='txtExpAmount']", timeout=12000)
        except Exception: pass

        details_data = {}
        fvc_data = {}
        try:
            details_data = self.scraper.scrape_bill_details(bill_page)
            fvc_data = self.scraper.scrape_fvc_bill(bill_page)
        finally:
            # Always close any popup tabs in context so no popup window is left open
            for p in list(context.pages):
                if p != page and not p.is_closed():
                    try: p.close(run_before_unload=False)
                    except Exception: pass



        scraped = {**details_data, **fvc_data}
        return self._process_tally_data(excel_amt, scraped, deviation_enabled)

    def _process_tally_data(self, excel_amt, scraped_data, deviation_enabled=False):
        portal_total = scraped_data.get("portal_total", 0.0)
        if portal_total == 0.0:
            portal_total = scraped_data.get("gross_amount", 0.0) or scraped_data.get("expenditure_amount", 0.0) or scraped_data.get("net_amount", 0.0)

        # Safety Guard: If portal_total is 0.0 for a non-zero Excel voucher because the page failed to load fields
        if portal_total == 0.0 and excel_amt > 0:
            has_scraped_fields = bool(scraped_data.get("expenditure_heads") or scraped_data.get("deductions") or scraped_data.get("entries"))
            if not has_scraped_fields:
                raise Exception("IFMIS Portal Lag: Bill details page failed to load form data fields")

        tot_deductions = scraped_data.get("total_deductions", 0.0)
        net_amount = portal_total - tot_deductions
        if scraped_data.get("net_amount", 0.0) > 0:
            net_amount = scraped_data.get("net_amount", 0.0)


        gross_dev = excel_amt - portal_total
        gross_dev_pct = (gross_dev / portal_total * 100.0) if portal_total > 0 else (100.0 if excel_amt != 0 else 0.0)

        net_dev = excel_amt - net_amount
        net_dev_pct = (net_dev / net_amount * 100.0) if net_amount > 0 else (100.0 if excel_amt != 0 else 0.0)

        if abs(gross_dev) < 0.01:
            gross_flag = "GREEN"
            remarks = "Exact Gross Match"
        elif deviation_enabled and (abs(gross_dev) <= (portal_total * 0.02)):
            gross_flag = "GREEN"
            remarks = f"Matched within 2% tolerance (Dev: ₹{gross_dev:,.2f})"
        else:
            gross_flag = "RED"
            remarks = f"Gross Mismatch (Dev: ₹{gross_dev:,.2f})"

        overall_flag = gross_flag

        return {
            "excel_amount": excel_amt,
            "portal_total": portal_total,
            "gross_dev": gross_dev,
            "gross_dev_pct": gross_dev_pct,
            "net_dev": net_dev,
            "net_dev_pct": net_dev_pct,
            "gross_flag": gross_flag,
            "overall_flag": overall_flag,
            "remarks": remarks,
            "scraped_data": scraped_data
        }
