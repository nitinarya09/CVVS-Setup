import os
import shutil

SOURCE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "TI Studio Pro")
TARGET_DIR = r"D:\TI Studio Backup 2\TI Studio Pro"

IGNORE_FOLDERS = {"__pycache__", "test_folder", ".backups", ".git", ".agents"}
ALLOWED_EXTENSIONS = {".py", ".js", ".html", ".css", ".bat", ".iss", ".png", ".svg", ".ico", ".txt", ".json", ".spec"}

def main():
    print(f"[SYNC] Mirroring TI Studio Pro changes...")
    print(f"[SYNC] Source: {SOURCE_DIR}")
    print(f"[SYNC] Target: {TARGET_DIR}")
    
    if not os.path.exists(SOURCE_DIR):
        print(f"[SYNC] ERROR: Source directory {SOURCE_DIR} does not exist!")
        return
        
    if not os.path.exists(TARGET_DIR):
        try:
            os.makedirs(TARGET_DIR)
            print(f"[SYNC] Created target directory: {TARGET_DIR}")
        except Exception as e:
            print(f"[SYNC] ERROR: Could not create target directory: {e}")
            return
            
    synced_count = 0
    
    for root, dirs, files in os.walk(SOURCE_DIR):
        # Modify dirs in-place to ignore specified folders
        dirs[:] = [d for d in dirs if d not in IGNORE_FOLDERS]
        
        rel_path = os.path.relpath(root, SOURCE_DIR)
        
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in ALLOWED_EXTENSIONS:
                if file.endswith(".bak"):
                    continue
                    
                src_file = os.path.join(root, file)
                
                if rel_path == ".":
                    dest_dir = TARGET_DIR
                else:
                    dest_dir = os.path.join(TARGET_DIR, rel_path)
                    
                if not os.path.exists(dest_dir):
                    os.makedirs(dest_dir)
                    
                dest_file = os.path.join(dest_dir, file)
                
                # Check if file has changed (mtime or size) before copying
                should_copy = True
                if os.path.exists(dest_file):
                    src_stat = os.stat(src_file)
                    dest_stat = os.stat(dest_file)
                    # We check size first. If different, we copy. If same, we check if src is newer.
                    if src_stat.st_size == dest_stat.st_size and src_stat.st_mtime <= dest_stat.st_mtime:
                        should_copy = False
                        
                if should_copy:
                    # Copy file and preserve metadata (including st_mtime)
                    shutil.copy2(src_file, dest_file)
                    synced_count += 1
                    
    print(f"[SYNC] Sync complete! Mirrored {synced_count} updated file(s) to D:\\TI Studio Backup 2\\TI Studio Pro")

if __name__ == "__main__":
    main()
