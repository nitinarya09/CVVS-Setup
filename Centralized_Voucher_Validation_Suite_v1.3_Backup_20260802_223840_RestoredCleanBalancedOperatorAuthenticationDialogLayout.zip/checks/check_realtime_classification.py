import os
from checks.base_check import BaseValidationCheck
from parsers.mptc_parser import parse_mptc_pdf
from parsers.classification_data import ClassificationLookup


class ClassificationCheck(BaseValidationCheck):
    check_id = "check_realtime_classification"
    name = "Head Classification & Deduction Code Verification Check"
    description = "Extracts head_of_account from MPTC and validates major/object heads against reference data."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            mptc_file = os.path.join(download_folder, "Show_MPTC.pdf")
            if not os.path.exists(mptc_file):
                return {"status": "SKIPPED", "message": "No MPTC PDF found", "details": {}}

            mptc = parse_mptc_pdf(mptc_file)
            head_of_account = mptc.head_of_account
            major_head = mptc.major_head
            object_head = mptc.object_head

            if not head_of_account:
                # Fall back to voucher_data mh
                major_head = str(voucher_data.get("mh", ""))
                if not major_head:
                    return {"status": "SKIPPED", "message": "No Head of Account found in MPTC", "details": {}}

            lookup = ClassificationLookup()

            mh_name = lookup.lookup_major_head(major_head)
            oh_name = lookup.lookup_object_head(object_head)

            details = {
                "major_head": major_head,
                "major_head_name": mh_name or "Unknown",
                "object_head": object_head,
                "object_head_name": oh_name or "Unknown",
                "full_classification": head_of_account,
            }

            # Validate
            validation = lookup.validate_classification(head_of_account)
            errors = validation.get("errors", []) if validation else []

            if mh_name and oh_name and not errors:
                return {"status": "PASS",
                        "message": "Valid classification: MH %s (%s), OH %s (%s)" % (major_head, mh_name, object_head, oh_name),
                        "details": details}
            elif mh_name and not oh_name:
                details["warnings"] = ["Object head '%s' not in reference data" % object_head]
                return {"status": "WARNING", "message": "Object head '%s' not in reference data" % object_head, "details": details}
            elif not mh_name:
                details["warnings"] = ["Major head '%s' not in reference data" % major_head]
                return {"status": "WARNING", "message": "Major head '%s' not in reference data" % major_head, "details": details}
            else:
                return {"status": "WARNING", "message": "Classification validation issues", "details": details}

        except Exception as e:
            return {"status": "FAIL", "message": "Error during check: %s" % str(e), "details": {}}
