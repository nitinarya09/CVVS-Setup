import os
from checks.base_check import BaseValidationCheck
from parsers.mptc_parser import parse_mptc_pdf


class DigitalSignatureCheck(BaseValidationCheck):
    check_id = "check_realtime_digital_signature"
    name = "Digital Signature Verification Check"
    description = "Checks if DDO and TO digital signatures are present on the MPTC."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            mptc_file_path = os.path.join(download_folder, "Show_MPTC.pdf")
            if not os.path.exists(mptc_file_path):
                return {"status": "SKIPPED", "message": "No MPTC PDF found", "details": {}}

            parsed = parse_mptc_pdf(mptc_file_path)
            signatures = parsed.digital_signatures  # list of {signer, role, date}

            if not signatures:
                return {"status": "FAIL", "message": "No digital signatures found in MPTC", "details": {"signatures": []}}

            has_ddo = any(s.get("role") == "DDO" for s in signatures)
            has_to = any(s.get("role") == "TO" for s in signatures)

            sig_details = [{"signer": s.get("signer", ""), "role": s.get("role", ""), "date": s.get("date", "")} for s in signatures]

            if has_ddo and has_to:
                return {"status": "PASS", "message": "Both DDO and TO signatures found", "details": {"signatures": sig_details}}
            elif has_ddo and not has_to:
                return {"status": "WARNING", "message": "TO (Treasury Officer) signature missing", "details": {"signatures": sig_details}}
            elif has_to and not has_ddo:
                return {"status": "WARNING", "message": "DDO (Drawing & Disbursing Officer) signature missing", "details": {"signatures": sig_details}}
            else:
                return {"status": "FAIL", "message": "No valid DDO or TO signatures found", "details": {"signatures": sig_details}}

        except Exception as e:
            return {"status": "FAIL", "message": "Error during check: %s" % str(e), "details": {}}
