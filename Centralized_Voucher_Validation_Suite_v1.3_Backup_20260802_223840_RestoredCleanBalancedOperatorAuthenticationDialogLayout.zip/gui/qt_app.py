def kill_process_tree(pid):
    """Forcefully terminates a process and all its child subprocesses on Windows."""
    if not pid:
        return
    if sys.platform == "win32":
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=0x08000000
            )
        except Exception:
            pass
    else:
        try:
            os.kill(int(pid), 9)
        except Exception:
            pass

# =========================================================
# CENTRALIZED VOUCHER VALIDATION SUITE - PySide6 Main Application Class
# Strict 1:1 CTk → Qt migration with zero-blocking architecture
# =========================================================

import os
import sys

# Import compatibility layer first
import gui.qt_compat
import re
import time
import datetime
import base64
import threading
import json
import queue
import secrets

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QApplication, QMessageBox, QFileDialog,
    QLineEdit, QCheckBox, QComboBox, QSlider, QProgressBar,
    QLabel, QTextEdit, QFrame, QPushButton
)
from PySide6.QtCore import Qt, QTimer, Slot
from PySide6.QtGui import QFont, QTextCharFormat, QColor, QTextCursor, QShortcut, QKeySequence

from gui.qt_signals import SignalBridge, TkVarCompat
from gui.qt_theme import generate_qss, get_console_tag_colors, get_theme_names, resolve_color
from gui.theme import THEMES
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from core.constants import APP_DIR, TREASURY_IDS, TREASURY_MAP, TOOL_VERSION, RUN_ID, DDO_DATABASE

# Windows-specific
if sys.platform == "win32":
    try:
        import win32gui
        import win32con
    except ImportError:
        pass


# ── Native Dialog Compatibility Wrapper (Tkinter Messagebox Clone) ────
class MessageBoxCompat:
    def __init__(self, parent=None):
        self.parent = parent
    def showinfo(self, title, message):
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self.parent, title, message)
    def showerror(self, title, message):
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.critical(self.parent, title, message)
    def showwarning(self, title, message):
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.warning(self.parent, title, message)
    def askyesno(self, title, message):
        from PySide6.QtWidgets import QMessageBox
        ret = QMessageBox.question(self.parent, title, message, QMessageBox.Yes | QMessageBox.No)
        return ret == QMessageBox.Yes

messagebox = None


class IFMISSuiteApp(QMainWindow):
    """PySide6 version of IFMISSuiteApp — strict 1:1 clone of the CTk version.
    
    Key architectural change: All backend→GUI communication goes through
    SignalBridge signals instead of Tkinter's self.after() mechanism.
    """
    
    # =========================================================
    # CLASS-BODY IMPORTS — Backend methods bound at class definition time
    # These replace the old runtime monkey-patching in ifmis_suite_qt.py.
    # Any missing import will raise ImportError immediately at startup.
    # =========================================================
    
    # --- Database Operations ---
    from database.db_manager import sqlite3_connect_optimized
    
    # --- Excel Parsers ---
    from parsers.excel_mapper import parse_excel_sheet, parse_pol_excel_sheet
    
    # --- PDF Paybill Readers ---
    from parsers.pdf_paybill import clean_and_save_flat_paybill as _clean_and_save_flat_paybill
    from parsers.pdf_paybill import read_paybill_as_df as _read_paybill_as_df
    
    # --- GUI Layout Builders (Qt versions) ---
    from gui.qt_gui_manager import (
        _build_gui, _build_left_sidebar, _build_right_panel,
        _build_settings_tab, _build_voucher_tab, _build_vlc_linker_tab, _build_payroll_tab, _build_pol_tab,
        _build_vlc_tab, _build_tally_tab, _build_treasury_tab, _build_developer_tab,
        _build_checks_manager_tab, _build_validation_results_tab, make_scrollable_recursively,
        toggle_direct_dashboard, on_tab_switched, update_tab_visibilities, browse_download_dir, browse_batch_subfolder,
        update_timeout_labels, apply_theme_colors
    )
    
    # --- Browser Factory & Window Controls ---
    from automation.browser_factory import (
        _launch_browser, _launch_browser_with_failover, _cleanup_browser_session,
        safe_logout_and_close, manual_portal_logout, launch_web_portal, launch_ti_studio,
        launch_epay_verifier,
        _apply_stealth_mode_if_enabled, toggle_browser_visibility, update_browser_status,
        launch_shared_cdp_browser, set_browser_visibility, bring_browser_to_front,
        _get_valid_storage_state, get_stealth_context_args
    )
    from automation.browser_factory import apply_webdriver_mask
    apply_webdriver_mask = staticmethod(apply_webdriver_mask)
    
    # --- Voucher Scraper ---
    from automation.scrapers.voucher_scraper import (
        process_voucher_vch, process_voucher_pb, process_voucher_tally,
        _select_bill_type_paybill, _click_bill_ref_no_link,
        _download_paybill_for_voucher, _get_paybill_folder,
        resilient_click, resilient_goto,
        merge_and_rename_pdfs, download_voucher_browserless,
        process_salary_voucher_dropdown_loop, download_salary_voucher_excel,
        wait_for_all_vouchers_loaded_playwright, read_excel_first_logical_text_playwright,
        extract_ddo_code_playwright, create_blank_excel_file,
        create_small_file_log, move_to_different_department,
        rename_downloaded_file_playwright, open_report_page,
        wait_and_get_xpath_locator_in_frames, get_xpath_locator_in_frames,
        extract_voucher_no
    )
    
    # --- Scraper Engine ---
    from automation.scrapers.engine import (
        _run_automation_task, _run_excel_live_mode, _post_process,
        _run_dry_mode_excel, _run_dry_mode_pol, _run_dry_mode_pol_excel,
        _launch_browser_with_failover_headless, _log_run_failure,
        _run_dry_mode_payroll, _run_live_mode_payroll
    )
    
    # =========================================================
    # END CLASS-BODY IMPORTS
    # =========================================================
    
    TOOL_VERSION = TOOL_VERSION
    TREASURY_MAP = TREASURY_MAP
    TREASURY_IDS = TREASURY_IDS

    def __init__(self, operator_name):
        super().__init__()

        global messagebox
        messagebox = MessageBoxCompat(self)

        # ─── Log buffer lock (MUST BE INITIALIZED FIRST FOR LOGGING) ───
        self.log_buffer = []
        self.log_buffer_lock = threading.Lock()

        # ─── Signal Bridge (THE FIX) ───
        self.signals = SignalBridge()
        self._connect_signals()

        self.api_token = secrets.token_hex(16)
        self.dev_mode = False
        self.is_task_running = False
        self.stop_requested = False

        # Prevent sleep on Windows
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetThreadExecutionState(
                    0x80000000 | 0x00000001 | 0x00000002
                )
            except Exception:
                pass

        # ─── TkVarCompat variables (drop-in for tk.StringVar etc.) ───
        self.var_stealth = TkVarCompat(value=True)
        self.var_archive = TkVarCompat(value=False)
        self.var_dryrun = TkVarCompat(value=False)
        self.var_browser = TkVarCompat(value="Google Chrome / Chromium")
        self.var_direct_dashboard = TkVarCompat(value=False)
        self.var_theme_accent = TkVarCompat(value="Emerald Teal (Dark)")
        self.var_download_dir = TkVarCompat(value="")
        self.var_batch_subfolder = TkVarCompat(value="")
        self.var_timeout_login = TkVarCompat(value=60)
        self.var_timeout_pdf = TkVarCompat(value=600)
        self.var_timeout_attachment = TkVarCompat(value=600)
        self.var_timeout_xls = TkVarCompat(value=3600)
        self.var_voucher_download_paybills = TkVarCompat(value=True)
        self.var_paybill_only = TkVarCompat(value=False)
        self.var_tesseract_path = TkVarCompat(value="")
        self.var_auto_solve_captcha = TkVarCompat(value=False)
        self.var_detailed_logs = TkVarCompat(value=False)
        self.var_telegram_enabled = TkVarCompat(value=False)
        self.var_telegram_token = TkVarCompat(value="")
        self.var_telegram_chat_id = TkVarCompat(value="")
        self.var_pol_folder_structure = TkVarCompat(
            value="Option 1 (Default: Treasury_POL > Month_Year > All DDO Files)"
        )
        self.var_pol_file_naming = TkVarCompat(
            value="Option 4 (DDO_Code_DDO_Name): [DDO_Code]_[DDO_Name]"
        )
        self.var_pol_path_template = TkVarCompat(
            value="{Output_Folder}/POL/POL_{Treasury_Clean}/{Month_Year_Num}/{DDO_Code}_{DDO_Name}"
        )
        self.var_merge_pol_files = TkVarCompat(value=False)

        # POL dropdown auto-template traces
        def on_pol_dropdown_change(*args):
            if getattr(self, "_loading_config", False):
                return
            folder_opt = self.var_pol_folder_structure.get()
            file_opt = self.var_pol_file_naming.get()

            if "Option 1" in folder_opt or "Treasury_POL" in folder_opt or "Flat" in folder_opt:
                folder_tpl = "POL/POL_{Treasury_Clean}/{Month_Year_Num}"
            elif "Treasury > Date > DDO" in folder_opt or "Option 2" in folder_opt:
                folder_tpl = "POL/{Treasury}/{Month_Year}/{DDO_Code}_{DDO_Name}"
            elif "TryCode > Date > DDO" in folder_opt or "Option 3" in folder_opt:
                folder_tpl = "POL/{TRY_CODE}/{Month_Year}/{DDO_Code}_{DDO_Name}"
            elif "Date-Centric" in folder_opt or "Option 4" in folder_opt:
                folder_tpl = "POL/{Month_Year}/{TRY_CODE}/{DDO_Code}"
            elif "Option 5" in folder_opt or "Single Treasury Folder" in folder_opt:
                folder_tpl = "POL/POL_{Treasury_Clean}"
            elif "Option 6" in folder_opt or "Single Global POL Folder" in folder_opt:
                folder_tpl = "POL"
            else:
                folder_tpl = "POL/POL_{Treasury_Clean}_{Month_Year_Num}"

            if "Treasury_DDO_Date" in file_opt or "Option 1" in file_opt:
                file_tpl = "{Treasury_Clean}_{DDO_Name_Short}_{Month_Year_Num}"
            elif "Standard Raw Prefixed" in file_opt or "Option 2" in file_opt:
                file_tpl = "Raw_File_{TRY_CODE}_{DDO_Code}_{Month_Year}"
            elif "Option 3" in file_opt:
                file_tpl = "{TRY_CODE}_{Month_Year}_{DDO_Name}_{DDO_Code}"
            elif "Option 4" in file_opt:
                file_tpl = "{DDO_Name}_{DDO_Code}_{Month_Year}"
            else:
                file_tpl = "{Treasury_Clean}_{DDO_Name_Short}_{Month_Year_Num}"

            template = f"{{Output_Folder}}/{folder_tpl}/{file_tpl}"
            self.var_pol_path_template.set(template)

        self.var_pol_folder_structure.trace_add("write", on_pol_dropdown_change)
        self.var_pol_file_naming.trace_add("write", on_pol_dropdown_change)

        self.var_parallel = TkVarCompat(value=True)
        self.var_parallel_workers = TkVarCompat(value=3)
        self._prev_voucher_parallel_mode = True

        def save_parallel_pref(*args):
            if hasattr(self, "tabview"):
                tab_text = self.tabview.tabText(self.tabview.currentIndex())
                if "POL" not in tab_text and "Payroll" not in tab_text:
                    self._prev_voucher_parallel_mode = self.var_parallel.get()
        self.var_parallel.trace_add("write", save_parallel_pref)

        self.var_show_workers = TkVarCompat(value=False)
        self.var_headful_monitor = TkVarCompat(value=False)

        # Reactive headful monitor toggle
        def on_headful_monitor_change(*args):
            if getattr(self, "is_task_running", False) and getattr(self, "browser", None):
                visible = self.var_headful_monitor.get()
                self.set_browser_visibility(visible)
                self.log(f"🕵️ Reactively set Worker 1 window visibility to: {'visible' if visible else 'hidden'}")
        self.var_headful_monitor.trace_add("write", on_headful_monitor_change)

        self.var_path_template = TkVarCompat(
            value="{Output_Folder}/{S_No}_{Treasury}_{Major_Head}_{Month}_{Year}_{Voucher_No}_{Amount}"
        )
        self.var_audio_alerts = TkVarCompat(value=True)
        self.var_os_notifications = TkVarCompat(value=True)
        self.var_active_profile = TkVarCompat(value="Default")

        # Developer Mode settings
        self.var_dev_limit_rows = TkVarCompat(value=False)
        self.var_dev_limit_rows_val = TkVarCompat(value=5)
        self.var_dev_filter_range = TkVarCompat(value=False)
        self.var_dev_filter_range_val = TkVarCompat(value="")
        self.var_dev_retry_count = TkVarCompat(value=1)

        # VLC Downloader state & Telemetry consent
        self.var_vlc_from_date = TkVarCompat(value="01/04/2025")
        self.var_vlc_to_date = TkVarCompat(value="31/03/2026")
        self.var_vlc_list_type = TkVarCompat(value="All")
        self.var_telemetry_enabled = TkVarCompat(value=True)
        self.vlc_selected_treasuries = []
        self.vlc_selected_modules = []

        # Voucher / Paybill specific
        self.var_voucher_sno = TkVarCompat(value=False)
        self.var_paybill_sno = TkVarCompat(value=False)
        self.var_tally_deviation = TkVarCompat(value=False)
        self.var_scan_existing_vouchers = TkVarCompat(value=False)

        # Main Tab Display Visibility Toggles
        self.var_tab_vouchers_visible = TkVarCompat(value=True)
        self.var_tab_payroll_visible = TkVarCompat(value=True)
        self.var_tab_pol_visible = TkVarCompat(value=True)
        self.var_tab_vlc_visible = TkVarCompat(value=True)
        self.var_tab_tally_visible = TkVarCompat(value=True)
        self.var_tab_treasury_visible = TkVarCompat(value=True)

        # Timeout milliseconds
        self.TIMEOUT_LOGIN = 60000
        self.TIMEOUT_DOWNLOAD_PDF = 150000
        self.TIMEOUT_DOWNLOAD_ATTACHMENT = 150000
        self.TIMEOUT_DOWNLOAD_XLS = 1801000
        self.AUTO_OPEN_FOLDER = True

        # File path state
        self.voucher_excel_file_path = ""
        self.voucher_selected_sheet = ""
        self.tally_excel_file_path = ""
        self.tally_selected_sheet = ""
        self.paybill_excel_file_path = ""
        self.paybill_selected_sheet = ""
        self.pol_excel_file_path = ""
        self.pol_selected_sheet = ""
        self.current_treasury = sorted(list(TREASURY_IDS.keys()))[0] if TREASURY_IDS else ""
        self.current_treasuries = [self.current_treasury]
        self.ddo_to_treasury_map = {}

        self.operator_name = operator_name

        # Paths
        self.base_path = os.path.join(APP_DIR, 'USER_DATA', self.operator_name)
        self.log_dir = os.path.join(self.base_path, "logs")
        self.download_dir = os.path.join(self.base_path, "downloads")
        os.makedirs(self.log_dir, exist_ok=True)
        os.makedirs(self.download_dir, exist_ok=True)

        # Threading infrastructure
        self.stop_requested = False
        self.is_task_running = False
        self.browser_queue = queue.Queue()
        self.worker_thread = threading.Thread(target=self._browser_loop, daemon=True)
        self.worker_thread.start()
        self.downloaded_folders_this_run = []
        self.heartbeat_state = False
        self.post_process_done = False

        # Lazy-loaded engine flags
        self.PANDAS_AVAILABLE = False
        try:
            import pandas
            self.PANDAS_AVAILABLE = True
        except ImportError:
            pass

        # Browser state
        self.playwright = None
        self.browser = None
        self.browser_context = None
        self.browser_page = None
        self.browser_hidden = False
        self.browser_pid = None

        # Counters (thread-safe)
        self._counter_lock = threading.Lock()
        self.success_count = 0
        self.skip_count = 0
        self.fail_count = 0
        self.stats_total = 0

        # Runtime stats
        self.browser_used = "UNKNOWN"
        self.run_start_time = 0
        self.captcha_attempts = 0
        self.captcha_success = 0
        self.timeout_count = 0
        self.session_expiry_count = 0

        self.stats_current = "Idle"
        self.stats_progress = 0.0

        # Centralized Voucher Validation Suite - Plugin Registry
        self.checks_dir = os.path.join(APP_DIR, "checks")
        try:
            from checks.check_registry import CheckRegistry
            self.check_registry = CheckRegistry(checks_dir=self.checks_dir, logger=self.log)
        except Exception as e:
            self.log(f"⚠️ CheckRegistry init notice: {e}")
            self.check_registry = None

        self.last_excel_report = None
        self.last_html_report = None

        # Save last operator
        try:
            global_user_data = os.path.dirname(self.base_path)
            os.makedirs(global_user_data, exist_ok=True)
            with open(os.path.join(global_user_data, 'last_operator.json'), 'w', encoding='utf-8') as f:
                json.dump({"last_operator": self.operator_name}, f)
        except Exception:
            pass

        self.run_log_file = os.path.join(self.log_dir, f"run_{time.strftime('%Y%m%d_%H%M%S')}.txt")
        self.cred_file = os.path.join(self.base_path, "cred.txt")

        # Load config and init DB
        self.load_config()
        self._prev_voucher_parallel_mode = self.var_parallel.get()
        self.init_db()

        # Report file paths
        self.voucher_master_report = os.path.join(self.download_dir, "Downloaded_Vouchers_Report.txt")
        self.voucher_failed_file = os.path.join(self.download_dir, "Failed_Vouchers.txt")
        self.paybill_master_report = os.path.join(self.download_dir, "PayBill_Downloaded_Report.txt")
        self.paybill_failed_file = os.path.join(self.download_dir, "Failed_PayBills.txt")
        self.pol_failed_file = os.path.join(self.download_dir, "POL_Failed_Rows.txt")

        # DDO checklist data
        self.ddo_checkboxes = {}
        self.ddo_widgets = {}
        self.select_all_var = TkVarCompat(value=False)

        # Console filter state
        self.var_filter_worker = TkVarCompat(value="All")
        self.var_filter_status = TkVarCompat(value="All")
        self.var_filter_search = TkVarCompat(value="")

        # Set High-Res Window & Taskbar Icon
        self._set_window_and_taskbar_icon()

        # Build GUI
        self._build_gui()
        self._setup_smooth_progress_bar()
        self.load_credentials()
        self.load_profiles()
        self._animate_heartbeat()
        self._start_keep_alive_daemon()

    def _set_window_and_taskbar_icon(self):
        """Ensure high-resolution CAG logo icon is explicitly assigned to Window titlebar & Windows Taskbar."""
        try:
            if sys.platform == "win32":
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("AGMP.CentralizedVoucherValidationSuite.v1.3")
        except Exception:
            pass

        for name in ["cag_logo.ico", "logo.ico", "cag_logo.png", "logo.png"]:
            p = os.path.join(APP_DIR, name)
            if os.path.exists(p):
                from PySide6.QtGui import QIcon
                icon = QIcon(p)
                if not icon.isNull():
                    self.setWindowIcon(icon)
                    if QApplication.instance():
                        QApplication.instance().setWindowIcon(icon)
                    break

        # Apply initial theme
        self.apply_theme_colors()

        # Start background network monitor thread
        from gui.qt_signals import NetworkMonitorThread, PortalLatencyMonitorThread
        self.net_monitor = NetworkMonitorThread(self)
        self.net_monitor.speed_updated.connect(self._on_network_speed_updated)
        self.net_monitor.start()

        # Start background portal latency monitor thread
        self.latency_monitor = PortalLatencyMonitorThread(self)
        self.latency_monitor.latency_updated.connect(self._on_portal_latency_updated)
        self.latency_monitor.start()

        # Start silent background temp artifact auto-pruning (older than 24h)
        threading.Thread(target=self.auto_prune_stale_temp_files, daemon=True).start()

        # Startup log
        self.log("━" * 55)
        self.log("  🌟 CENTRALIZED VOUCHER VALIDATION SUITE AUTOMATION PORTAL LOADED SUCCESSFULLY 🌟")
        self.log(f"  Operator: {self.operator_name} | RUN_ID: {RUN_ID}")
        self.log("━" * 55)

        # Check captcha capabilities
        model_path_onnx = os.path.join(APP_DIR, "captcha_model.onnx")
        model_path_tflite = os.path.join(APP_DIR, "captcha_model.tflite")
        local_cnn_solver = False
        if os.path.exists(model_path_onnx):
            self.log("🤖 Local Captcha CNN Solver enabled (ONNX model loaded)")
            local_cnn_solver = True
        elif os.path.exists(model_path_tflite):
            self.log("🤖 Local Captcha CNN Solver enabled (TFLite model loaded)")
            local_cnn_solver = True

        ddddocr_available = False
        try:
            import ddddocr
            ddddocr_available = True
            self.log("✅ Local CAPTCHA OCR solver enabled (ddddocr)")
        except ImportError:
            pass

        if local_cnn_solver or ddddocr_available:
            self.log("🤖 Automatic CAPTCHA solver active.")

        # Start API server
        try:
            from server.api_server import start_api_server
            start_api_server(self)
        except Exception:
            pass

    # ─────────────────────────────────────────────
    # SIGNAL CONNECTIONS (The Core Fix)
    # ─────────────────────────────────────────────

    def _connect_signals(self):
        """Wire all SignalBridge signals to their GUI handler slots."""
        self.signals.log_message.connect(self._on_log_message)
        self.signals.stats_updated.connect(self._on_stats_updated)
        self.signals.counter_incremented.connect(self._on_counter_incremented)
        self.signals.ui_lock_changed.connect(self._on_ui_lock_changed)
        self.signals.run_finished.connect(self._on_run_finished)
        self.signals.heartbeat_update.connect(self._on_heartbeat_update)
        self.signals.ddo_list_refresh.connect(self._on_ddo_list_refresh)
        self.signals.worker_count_changed.connect(self._on_worker_count_changed)
        self.signals.console_status_changed.connect(self._on_console_status_changed)
        self.signals.execute_callable.connect(self._on_execute_callable)
        self.signals.vlc_linker_finished.connect(self._on_vlc_linker_finished)
        self.signals.vlc_linker_failed.connect(self._on_vlc_linker_failed)

    @Slot(str, str)
    def _on_log_message(self, message, tag):
        """Slot: append log message to console (runs on GUI thread)."""
        self._append_log_to_console(message, tag)

    @Slot(str, float)
    def _on_stats_updated(self, current, progress):
        """Slot: update stats labels and progress bar."""
        try:
            with self._counter_lock:
                self.lbl_stats.setText(
                    f"Success: {self.success_count}   Failed: {self.fail_count}   "
                    f"Skipped: {self.skip_count}   Total: {self.stats_total}"
                )
            if current:
                self.stats_current = current
                self.lbl_current.setText(f"Current Operation: {current}")
            if progress is not None and progress >= 0:
                self.stats_progress = progress
                self.progress_bar.setValue(int(progress * 100))
        except Exception:
            pass

    @Slot(str, int)
    def _on_counter_incremented(self, counter_type, diff):
        """Slot: increment a counter from worker thread."""
        with self._counter_lock:
            if counter_type == "success":
                self.success_count += diff
            elif counter_type == "fail":
                self.fail_count += diff
            elif counter_type == "skip":
                self.skip_count += diff

    def trigger_realtime_checks(self, voucher_data, download_folder):
        """Invoke enabled realtime checks for a downloaded voucher and update UI table."""
        if not hasattr(self, "check_registry") or not self.check_registry:
            return []
        
        context = {
            "app": self,
            "browser_page": getattr(self, "browser_page", None),
            "browser_context": getattr(self, "browser_context", None)
        }
        results = self.check_registry.run_realtime_checks(voucher_data, download_folder, context)
        
        # Save results into SQLite Audit Cache
        try:
            from database.db_manager import save_audit_results_batch
            db_path = getattr(self, "db_path", None)
            if db_path and results:
                save_audit_results_batch(db_path, results)
        except Exception as cache_err:
            pass

        # Update GUI validation table on main thread
        try:
            from gui.tabs_qt.validation_results_tab import add_realtime_result_to_table
            for res in results:
                self.safe_after(0, lambda r=res: add_realtime_result_to_table(self, r))
        except Exception as e:
            self.log(f"⚠️ Notice updating validation results table: {e}")
            
        return results

    def trigger_post_download_checks(self, all_vouchers_data=None, output_dir=None):
        """Invoke post-download batch checks and generate consolidated report."""
        if not hasattr(self, "check_registry") or not self.check_registry:
            return None

        if not all_vouchers_data:
            all_vouchers_data = getattr(self, "excel_rows", []) or getattr(self, "vouchers", []) or []

        if output_dir is None:
            output_dir = getattr(self, "download_dir", None) or os.path.join(self.base_path, "downloads")

        context = {"app": self}
        summary = self.check_registry.run_post_download_checks(all_vouchers_data, output_dir, context)
        self.last_excel_report = summary.get("excel_path")
        self.last_html_report = summary.get("html_path")
        return summary
        self._on_stats_updated("", -1)

    @Slot(bool)
    def _on_ui_lock_changed(self, is_locked):
        """Slot: lock/unlock UI during task execution."""
        self.set_ui_lock_state(is_locked)

    @Slot(object, tuple, dict)
    def _on_execute_callable(self, func, args, kwargs):
        """Slot: execute a Python callable on the GUI thread."""
        try:
            func(*args, **kwargs)
        except Exception as e:
            self.log(f"❌ Error in GUI dispatch callback: {e}")

    @Slot(str)
    def _on_network_speed_updated(self, speed_text):
        """Slot: update the network usage speed display."""
        if hasattr(self, "lbl_net_speed"):
            self.lbl_net_speed.setText(speed_text)

    @Slot(int, str)
    def _on_portal_latency_updated(self, latency_ms, latency_text):
        """Slot: update the portal latency display in the status bar/sidebar."""
        if hasattr(self, "lbl_latency"):
            self.lbl_latency.setText(latency_text)
            # Apply dynamic color-coding
            if latency_ms < 0:
                self.lbl_latency.setStyleSheet("color: #ef4444;") # Red
            elif latency_ms < 250:
                self.lbl_latency.setStyleSheet("color: #00c9a7;") # Green
            elif latency_ms < 750:
                self.lbl_latency.setStyleSheet("color: #f59e0b;") # Yellow
            else:
                self.lbl_latency.setStyleSheet("color: #ef4444;") # Red

        # Dynamic Real-Time Live IFMIS Session Status Verification
        if not getattr(self, "_is_reauthenticating", False):
            self.check_live_session_status()

    def check_live_session_status(self):
        """
        Dynamic, real-time IFMIS session status check.
        Evaluates active tasks, re-authentication status, and stored session cookies.
        """
        # 1. If re-authentication is currently running
        if getattr(self, "_is_reauthenticating", False):
            self.update_session_indicator("reauthenticating")
            return

        # 2. If workers reported session expiration / HTTP 302 login redirect
        if getattr(self, "_session_expired_event_hit", False):
            self.update_session_indicator("expired")
            return

        # 3. Check browser_state.json file on disk
        state_file = os.path.join(getattr(self, "base_path", "."), "browser_state.json")
        if not os.path.exists(state_file) or os.path.getsize(state_file) < 50:
            self.update_session_indicator("expired")
            return

        try:
            import json
            with open(state_file, "r", encoding="utf-8") as f:
                st_data = json.load(f)
            cookies = st_data.get("cookies", [])
            has_jsession = any(isinstance(c, dict) and c.get("name") == "JSESSIONID" for c in cookies)
            if cookies and (has_jsession or len(cookies) > 0):
                self.update_session_indicator("active")
                return
        except Exception:
            pass

        self.update_session_indicator("expired")

    @Slot(str, str)
    def update_session_indicator(self, status="checking", custom_msg=""):
        """Slot: update the session status indicator badge on the Task Operations Panel."""
        if not hasattr(self, "lbl_session_status") or not self.lbl_session_status:
            return

        status_clean = str(status).lower().strip()
        if status_clean in ("active", "logged_in", "online", "good"):
            msg = custom_msg or "Session: 🟢 Active (Logged In)"
            color = "#00c9a7" # Green
        elif status_clean in ("reauthenticating", "renewing", "authenticating", "pending"):
            msg = custom_msg or "Session: 🟡 Re-authenticating..."
            color = "#f59e0b" # Yellow
        else:
            msg = custom_msg or "Session: 🔴 Inactive (Logged Out)"
            color = "#ef4444" # Red

        try:
            self.lbl_session_status.setText(msg)
            self.lbl_session_status.setStyleSheet(f"color: {color};")
        except Exception:
            pass

    @Slot()
    def _on_run_finished(self):
        """Slot: cleanup after automation task completes."""
        self.is_task_running = False
        self.set_ui_lock_state(False)

        mode = "voucher"
        try:
            if hasattr(self, "tabview"):
                tab_text = self.tabview.tabText(self.tabview.currentIndex())
                if "Paybills" in tab_text:
                    mode = "paybill"
                elif "POL" in tab_text:
                    mode = "pol"
        except Exception:
            pass

        # Trigger Auto Archive to ZIP if enabled
        if hasattr(self, "var_archive") and self.var_archive.get():
            try:
                self.log(f"📦 Auto-Archive: Compressing completed {mode.upper()} batch to ZIP...")
                self._post_process(mode)
            except Exception as ze:
                self.log(f"⚠️ Auto-Archive to ZIP warning: {ze}")

        # Post-Batch Completion Prompt (Open Folder)
        from PySide6.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self,
            "Batch Completed",
            "Batch completed successfully. Do you want to open the downloads folder?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes
        )
        if reply == QMessageBox.Yes:
            folder = self.download_dir
            try:
                mode = "voucher"
                if hasattr(self, "tabview"):
                    tab_text = self.tabview.tabText(self.tabview.currentIndex())
                    if "Paybills" in tab_text:
                        mode = "paybill"
                    elif "POL" in tab_text:
                        mode = "pol"
                
                if mode == "pol":
                    folder = os.path.join(self.download_dir, "POL")
                else:
                    excel_path = self.voucher_excel_file_path if mode == "voucher" else self.paybill_excel_file_path
                    if excel_path:
                        rows = self.parse_excel_sheet(excel_path, mode)
                        if rows:
                            folder = os.path.dirname(self.resolve_download_path(rows[0], "Voucher" if mode == "voucher" else "Paybill"))
            except Exception:
                pass
                
            if not os.path.exists(folder):
                folder = self.download_dir
                
            os.makedirs(folder, exist_ok=True)
            try:
                if sys.platform == "win32":
                    os.startfile(folder)
                else:
                    import subprocess
                    subprocess.Popen(["xdg-open", folder])
            except Exception as e:
                self.log(f"⚠️ Failed to open folder: {e}")

    @Slot(str, str)
    def _on_heartbeat_update(self, text, color):
        """Slot: update heartbeat indicator."""
        try:
            self.lbl_heartbeat.setText(text)
            self.lbl_heartbeat.setStyleSheet(f"color: {color};")
        except Exception:
            pass

    @Slot(str)
    def _on_ddo_list_refresh(self, treasury):
        """Slot: refresh DDO checklist for POL tab."""
        self.refresh_ddo_list(treasury)

    @Slot(int)
    def _on_worker_count_changed(self, count):
        """Slot: auto-throttle worker count from ConcurrencyAutoTuner."""
        self.var_parallel_workers.set(count)

    @Slot(str)
    def _on_console_status_changed(self, status):
        """Slot: update console title."""
        try:
            self.lbl_console_title.setText(f"💻 Log Console | System Status: {status}")
        except Exception:
            pass

    # ─────────────────────────────────────────────
    # THREAD-SAFE LOG METHOD (replaces CTk version)
    # ─────────────────────────────────────────────

    def export_console_logs(self):
        """Export current log console contents to a plain text file."""
        widget = getattr(self, "output", None) or getattr(self, "txt_console", None)
        plain_text = ""
        if widget and hasattr(widget, "toPlainText"):
            plain_text = widget.toPlainText()
        elif hasattr(self, "log_buffer") and self.log_buffer:
            plain_text = "\n".join([f"{item.get('time','')} {item.get('msg','')}" for item in self.log_buffer])

        if not plain_text.strip():
            QMessageBox.warning(self, "Export Logs", "No log output available to export.")
            return

        timestamp = time.strftime("%Y%m%d_%H%M%S")
        default_filename = f"Voucher_Validation_Logs_{timestamp}.txt"
        default_path = os.path.join(getattr(self, "download_dir", os.getcwd()), default_filename)

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Export Log Console Output",
            default_path,
            "Text Files (*.txt);;Log Files (*.log);;All Files (*.*)"
        )

        if file_path:
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(plain_text)
                self.log(f"✅ Log console exported successfully ({len(plain_text):,} characters) to: {file_path}", tag="success")
                QMessageBox.information(self, "Logs Exported", f"Log console output saved successfully to:\n{file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Export Failed", f"Failed to export logs to file:\n{e}")

    def log(self, message, tag=None):
        """Thread-safe logging. Can be called from ANY thread.
        
        Messages are routed through SignalBridge to the GUI thread.
        """
        timestamp = time.strftime("[%H:%M:%S]")
        full_msg = f"{timestamp} {message}\n"
        try:
            print(full_msg, end="")
        except (UnicodeEncodeError, Exception):
            try:
                enc = sys.stdout.encoding or "utf-8"
                print(full_msg.encode(enc, errors="replace").decode(enc), end="")
            except Exception:
                pass

        # Parse worker ID
        worker_id = "Main"
        worker_match = re.search(r'(?:\[Worker\s+|worker\s+|Worker\s+)(\d+)', message)
        if worker_match:
            worker_id = f"Worker {worker_match.group(1)}"
        elif "Worker 1 - Main Window" in message or "Worker 1" in message:
            worker_id = "Worker 1"

        # Parse status
        status = "info"
        if tag and str(tag).lower() in ["success", "error", "warning", "skip", "header", "info"]:
            status = str(tag).lower()
        else:
            lower_msg = message.lower()
            if any(k in lower_msg for k in ["--- processing", "processing part", "starting treasury", "major head:"]):
                status = "header"
            elif any(k in lower_msg for k in ["error", "fail", "failed", "exception", "fatal", "denied", "stopped", "🔴", "❌", "💥"]):
                status = "error"
            elif any(k in lower_msg for k in ["saved pdf", "saved report", "saved", "success", "completed", "done", "verified", "ok", "✅", "☑", "🎉", "🌟"]):
                status = "success"
            elif any(k in lower_msg for k in ["warning", "retry", "reloading", "timeout", "expired", "re-login", "resetting", "⚠️", "🚨", "⏱️", "⏳"]):
                status = "warning"
            elif any(k in lower_msg for k in ["skip", "skipped", "exists", "already downloaded", "bypassed", "⏭️"]):
                status = "skip"

        with self.log_buffer_lock:
            self.log_buffer.append({
                "msg": message,
                "tag": tag,
                "time": timestamp,
                "worker": worker_id,
                "status": status
            })
            if len(self.log_buffer) > 1000:
                self.log_buffer.pop(0)

        # Write to log file
        try:
            with open(self.run_log_file, "a", encoding="utf-8") as lf:
                lf.write(full_msg)
        except Exception:
            pass

        # Emit signal → GUI thread will handle the append
        self.signals.log_message.emit(message, tag or status)

    def _append_log_to_console(self, message, tag):
        """Append a log message to the QTextEdit console with colored tags.
        MUST run on the GUI thread (called via signal).
        """
        try:
            if not hasattr(self, "output"):
                return

            timestamp = time.strftime("[%H:%M:%S]")
            full_msg = f"{timestamp} {message}\n"

            # Check active filters
            matches_filter = True
            f_worker = self.var_filter_worker.get()
            f_status = self.var_filter_status.get()
            f_search = self.var_filter_search.get()

            # Parse worker from message for filter
            worker_id = "Main"
            worker_match = re.search(r'(?:\[Worker\s+|worker\s+|Worker\s+)(\d+)', message)
            if worker_match:
                worker_id = f"Worker {worker_match.group(1)}"
            elif "Worker 1" in message:
                worker_id = "Worker 1"

            if f_worker != "All":
                if f_worker == "Main" and worker_id not in ["Main", "Worker 1"]:
                    matches_filter = False
                elif f_worker != "Main" and worker_id != f_worker:
                    matches_filter = False

            # Derive semantic status (must match how log_message stores it)
            if f_status != "All":
                msg_status = "info"
                if tag in ("success", "error", "warning", "skip", "info"):
                    msg_status = tag
                else:
                    lower_msg = message.lower()
                    if "error" in lower_msg or "fail" in lower_msg or "🔴" in lower_msg or "❌" in lower_msg:
                        msg_status = "error"
                    elif "success" in lower_msg or "completed" in lower_msg or "done" in lower_msg or "✅" in lower_msg:
                        msg_status = "success"
                    elif "warning" in lower_msg or "retry" in lower_msg or "⚠️" in lower_msg or "🚨" in lower_msg:
                        msg_status = "warning"
                    elif "skip" in lower_msg or "⏭️" in lower_msg:
                        msg_status = "skip"
                if msg_status != f_status.lower():
                    matches_filter = False

            if f_search and f_search.lower() not in message.lower():
                matches_filter = False

            if not matches_filter:
                return

            # Get tag color
            theme_name = self.var_theme_accent.get()
            tag_colors = get_console_tag_colors(theme_name)
            
            eff_tag = tag if tag in tag_colors else msg_status
            msg_color = tag_colors.get(eff_tag, tag_colors.get("info", "#93c5fd"))
            time_color = tag_colors.get("timestamp", "#8b949e")

            cursor = self.output.textCursor()
            cursor.movePosition(QTextCursor.End)

            # Insert Timestamp in Slate Gray
            time_fmt = QTextCharFormat()
            time_fmt.setForeground(QColor(time_color))
            cursor.insertText(f"{timestamp} ", time_fmt)

            # Insert Message in Category Color
            msg_fmt = QTextCharFormat()
            msg_fmt.setForeground(QColor(msg_color))
            cursor.insertText(f"{message}\n", msg_fmt)

            # Auto-scroll
            self.output.setTextCursor(cursor)
            self.output.ensureCursorVisible()
        except Exception:
            pass

    def redraw_filtered_logs(self):
        """Re-render all buffered logs through the active filters."""
        try:
            if not hasattr(self, "output"):
                return

            self.output.clear()

            f_worker = self.var_filter_worker.get()
            f_status = self.var_filter_status.get()
            f_search = self.var_filter_search.get()

            theme_name = self.var_theme_accent.get()
            tag_colors = get_console_tag_colors(theme_name)

            with self.log_buffer_lock:
                for entry in self.log_buffer:
                    msg = entry["msg"]
                    t = entry.get("tag")
                    time_str = entry["time"]
                    w_id = entry.get("worker", "Main")
                    st = entry.get("status", "info")

                    if f_worker != "All":
                        if f_worker == "Main" and w_id not in ["Main", "Worker 1"]:
                            continue
                        elif f_worker != "Main" and w_id != f_worker:
                            continue

                    if f_status != "All" and st != f_status.lower():
                        continue

                    if f_search and f_search.lower() not in msg.lower():
                        continue

                    eff_tag = t if t in tag_colors else st
                    msg_color = tag_colors.get(eff_tag, tag_colors.get("info", "#93c5fd"))
                    time_color = tag_colors.get("timestamp", "#8b949e")

                    cursor = self.output.textCursor()
                    cursor.movePosition(QTextCursor.End)

                    time_fmt = QTextCharFormat()
                    time_fmt.setForeground(QColor(time_color))
                    cursor.insertText(f"{time_str} ", time_fmt)

                    msg_fmt = QTextCharFormat()
                    msg_fmt.setForeground(QColor(msg_color))
                    cursor.insertText(f"{msg}\n", msg_fmt)

            self.output.moveCursor(QTextCursor.End)
            self.output.ensureCursorVisible()
        except Exception as e:
            print(f"Error redrawing logs: {e}")

    # ─────────────────────────────────────────────
    # THREAD-SAFE UPDATE_STATS (replaces CTk version)
    # ─────────────────────────────────────────────

    def update_stats(self, current=None, progress=None):
        """Thread-safe stats update. Can be called from ANY thread."""
        self.signals.stats_updated.emit(current or "", progress if progress is not None else -1.0)

    # ─────────────────────────────────────────────
    # SAFE_AFTER REPLACEMENT (QTimer.singleShot)
    # ─────────────────────────────────────────────

    def safe_after(self, ms, func, *args, **kwargs):
        """Drop-in replacement for Tkinter's self.after().
        Schedules func to run on the GUI thread after ms milliseconds.
        """
        from PySide6.QtCore import QThread
        from PySide6.QtWidgets import QApplication
        if QThread.currentThread() != QApplication.instance().thread():
            self.signals.execute_callable.emit(self.safe_after, (ms, func) + args, kwargs)
            return

        if ms <= 0:
            try:
                func(*args, **kwargs)
            except Exception as e:
                self.log(f"❌ Error in safe_after: {e}")
        else:
            QTimer.singleShot(ms, lambda: func(*args, **kwargs))

    def after(self, ms, func, *args, **kwargs):
        """Compatibility alias for safe_after."""
        return self.safe_after(ms, func, *args, **kwargs)

    def winfo_exists(self):
        """Compatibility shim for Tkinter's winfo_exists()."""
        return self.isVisible()

    # ─────────────────────────────────────────────
    # THEME MANAGEMENT
    # ─────────────────────────────────────────────

    def get_theme_color(self, color_name):
        """Resolve a theme color token to its value for the current theme."""
        active_theme = self.var_theme_accent.get()
        if active_theme not in THEMES:
            if active_theme == "Emerald Teal (Default)":
                active_theme = "Emerald Teal (Dark)"
            else:
                active_theme = "Emerald Teal (Dark)"
        
        theme = THEMES.get(active_theme, THEMES["Emerald Teal (Dark)"])
        color_val = theme.get(color_name, THEMES["Emerald Teal (Dark)"].get(color_name, "#ffffff"))
        mode = theme.get("APPEARANCE_MODE", "dark")
        return resolve_color(color_val, mode)

    def change_theme_accent(self, choice):
        """Switch theme accent palette and refresh all styles."""
        self.var_theme_accent.set(choice)
        self.apply_theme_colors()
        self.save_operator_config()

    # ─────────────────────────────────────────────
    # UI LOCK / UNLOCK
    # ─────────────────────────────────────────────

    def set_ui_lock_state(self, is_locked):
        """Enable or disable GUI controls depending on whether a task is running.
        
        Uses a resilient block-by-block update pattern to avoid throwing exceptions
        if some widgets are uninitialized or dynamically restructured.
        """
        enabled = not is_locked

        # Restore cached GUI variables on unlock
        if not is_locked:
            for attr_name, orig_get in getattr(self, "_orig_gets", {}).items():
                try:
                    obj = getattr(self, attr_name)
                    obj.get = orig_get
                    if hasattr(obj, "_orig_get"):
                        del obj._orig_get
                except Exception:
                    pass
            self._orig_gets = {}

        # 1. Sidebar components
        sidebar_widgets = [
            'entry_user', 'entry_pass', 'btn_save_cred', 'sw_dryrun',
            'opt_profile', 'btn_save_profile', 'btn_delete_profile',
            'sw_parallel_sidebar', 'sw_stealth', 'sw_archive'
        ]
        for name in sidebar_widgets:
            widget = getattr(self, name, None)
            if widget is not None:
                try:
                    widget.setEnabled(enabled)
                except Exception:
                    pass

        # 2. Voucher Tab components
        voucher_widgets = [
            'btn_voucher_excel', 'btn_voucher_start', 'btn_voucher_retry',
            'sw_voucher_sno', 'sw_voucher_paybills', 'sw_paybill_only', 'btn_edit_headers'
        ]
        for name in voucher_widgets:
            widget = getattr(self, name, None)
            if widget is not None:
                try:
                    widget.setEnabled(enabled)
                except Exception:
                    pass

        # 3. Voucher Search Tab components
        vsearch_widgets = [
            'btn_vsearch_start', 'btn_vsearch_treasury',
            'entry_vsearch_from', 'entry_vsearch_to',
            'btn_vsearch_from', 'btn_vsearch_to',
        ]
        for name in vsearch_widgets:
            widget = getattr(self, name, None)
            if widget is not None:
                try:
                    widget.setEnabled(enabled)
                except Exception:
                    pass

        # 4. POL Tab components
        pol_widgets = [
            'entry_pol_from', 'entry_pol_to', 'btn_pol_from', 'btn_pol_to',
            'btn_pol_treasury', 'pol_bill_dropdown', 'btn_pol_excel',
            'btn_pol_start', 'btn_pol_retry', 'btn_pol_update_ddo',
            'select_all_cb', 'pol_search_entry'
        ]
        for name in pol_widgets:
            widget = getattr(self, name, None)
            if widget is not None:
                try:
                    widget.setEnabled(enabled)
                except Exception:
                    pass

        # 5. DDO list checkboxes (POL tab)
        if hasattr(self, 'ddo_widgets') and isinstance(self.ddo_widgets, dict):
            for cb in self.ddo_widgets.values():
                try:
                    cb.setEnabled(enabled)
                except Exception:
                    pass

        # 5.5. Payroll components
        salary_widgets = [
            'btn_salary_start', 'btn_salary_treasury',
            'entry_salary_dept', 'entry_salary_mh',
            'entry_salary_start_month', 'entry_salary_start_year',
            'entry_salary_end_month', 'entry_salary_end_year'
        ]
        for name in salary_widgets:
            widget = getattr(self, name, None)
            if widget is not None:
                try:
                    widget.setEnabled(enabled)
                except Exception:
                    pass

        # 5.6. VLC Downloader components
        vlc_widgets = [
            'entry_vlc_from', 'entry_vlc_to', 'btn_vlc_from', 'btn_vlc_to',
            'vlc_list_dropdown', 'btn_vlc_start', 'vlc_search_entry',
            'vlc_select_all_cb', 'vlc_select_all_modules_cb'
        ]
        for name in vlc_widgets:
            widget = getattr(self, name, None)
            if widget is not None:
                try:
                    widget.setEnabled(enabled)
                except Exception:
                    pass

        if hasattr(self, 'vlc_treasury_checkboxes') and isinstance(self.vlc_treasury_checkboxes, dict):
            for cb in self.vlc_treasury_checkboxes.values():
                try:
                    cb.setEnabled(enabled)
                except Exception:
                    pass

        if hasattr(self, 'vlc_module_checkboxes') and isinstance(self.vlc_module_checkboxes, dict):
            for cb in self.vlc_module_checkboxes.values():
                try:
                    cb.setEnabled(enabled)
                except Exception:
                    pass

        # 5.7. Treasury Downloader components
        treasury_widgets = [
            'opt_treasury_report_type', 'treasury_combo',
            'opt_treasury_year', 'opt_treasury_month',
            'entry_treasury_from', 'entry_treasury_to',
            'btn_treasury_from', 'btn_treasury_to',
            'entry_treasury_dir', 'btn_treasury_browse',
            'btn_treasury_start', 'btn_treasury_retry', 'btn_treasury_fetch_heads',
            'entry_major_search', 'btn_major_select_all', 'btn_major_clear_all',
            'opt_treasury_submajor', 'opt_treasury_minor'
        ]
        for name in treasury_widgets:
            widget = getattr(self, name, None)
            if widget is not None:
                try:
                    widget.setEnabled(enabled)
                except Exception:
                    pass

        if hasattr(self, 'major_head_checkboxes') and isinstance(self.major_head_checkboxes, dict):
            for cb in self.major_head_checkboxes.values():
                try:
                    cb.setEnabled(enabled)
                except Exception:
                    pass

        # 6. Stop buttons - should be enabled ONLY when is_locked is True
        stop_buttons = ['btn_voucher_stop', 'btn_vsearch_stop', 'btn_pol_stop', 'btn_salary_stop', 'btn_vlc_stop', 'btn_treasury_stop']
        for name in stop_buttons:
            widget = getattr(self, name, None)
            if widget is not None:
                try:
                    widget.setEnabled(is_locked)
                except Exception:
                    pass


    # ─────────────────────────────────────────────
    # BROWSER WORKER THREAD (Actor Pattern - unchanged)
    # ─────────────────────────────────────────────

    def _browser_loop(self):
        """Background thread that processes browser commands from the queue.
        This pattern is preserved from the CTk version — the queue-based
        actor model is already correct and non-blocking.
        """
        self.browser_thread_id = threading.get_ident()
        import asyncio
        try:
            asyncio.set_event_loop(None)
        except Exception:
            pass
        while True:
            got_item = False
            try:
                try:
                    task = self.browser_queue.get(timeout=90)
                    got_item = True
                except queue.Empty:
                    # Idle keep-alive heartbeat
                    try:
                        if self.browser_page and not self.browser_page.is_closed():
                            if self._is_logged_in(self.browser_page):
                                self.log("💓 Idle Heartbeat: keeping main browser session alive...")
                                self.browser_page.evaluate(
                                    "fetch('ifms.htm?actionFlag=rnd-paymentOrderListForAG&elementId=10072358').catch(() => {})"
                                )
                                self.update_browser_status(
                                    "💤 Centralized Voucher Validation Suite: Session kept alive. System ready.",
                                    bg_color="#111827", text_color="#10b981"
                                )
                            else:
                                self.log("ℹ️ Open browser session has expired. Cleaning up browser context.")
                                self._cleanup_browser_session()
                    except Exception:
                        pass
                    continue

                if task is None:
                    break

                self.is_task_running = True
                task_type, args = task

                if task_type == "RUN_BATCH":
                    mode, run_failed = args
                    self._run_automation_task(mode, run_failed)
                elif task_type == "DDO_UPDATE":
                    username, password = args
                    self._run_ddo_update(username, password)
                elif task_type == "LOGOUT":
                    page = args
                    self.safe_logout_and_close(page)
            except Exception as e:
                self.log(f"❌ Browser loop error: {e}")
            finally:
                self.is_task_running = False
                if got_item:
                    try:
                        self.browser_queue.task_done()
                    except ValueError:
                        pass

    # ─────────────────────────────────────────────
    # GUI VARIABLE CACHING (freeze var values during task)
    # ─────────────────────────────────────────────

    def cache_gui_variables(self):
        """Cache current GUI variable values so they don't change during a running task."""
        self._orig_gets = {}
        for attr_name in dir(self):
            if attr_name in ("var_filter_worker", "var_filter_status", "var_filter_search"):
                continue
            if attr_name.startswith("var_") or attr_name in ("entry_user", "entry_pass"):
                obj = getattr(self, attr_name)
                if hasattr(obj, "get") and not hasattr(obj, "_orig_get"):
                    try:
                        val = obj.get()
                        orig_get = obj.get
                        obj._orig_get = orig_get
                        obj.get = lambda v=val: v
                        self._orig_gets[attr_name] = orig_get
                    except Exception:
                        pass

    # ─────────────────────────────────────────────
    # NETWORK BANDWIDTH MONITOR
    # ─────────────────────────────────────────────

    def start_bandwidth_monitor(self):
        """Start a background thread to monitor network bandwidth."""
        def monitor_loop():
            import psutil
            import socket as sock_mod

            def check_ping():
                try:
                    sock_mod.setdefaulttimeout(1.5)
                    s = sock_mod.socket(sock_mod.AF_INET, sock_mod.SOCK_STREAM)
                    s.connect(("8.8.8.8", 53))
                    s.close()
                    return "Online (Connected)"
                except Exception:
                    return "Offline (Disconnected)"

            try:
                io1 = psutil.net_io_counters()
                t1 = time.time()
            except Exception:
                return

            while True:
                time.sleep(1.5)
                try:
                    io2 = psutil.net_io_counters()
                    t2 = time.time()
                    dt = t2 - t1
                    if dt <= 0:
                        continue

                    dl_bytes = io2.bytes_recv - io1.bytes_recv
                    ul_bytes = io2.bytes_sent - io1.bytes_sent
                    dl_speed = dl_bytes / dt
                    ul_speed = ul_bytes / dt

                    def to_speed_str(bytes_sec):
                        if bytes_sec >= 1024 * 1024:
                            return f"{bytes_sec / (1024 * 1024):.2f} MB/s"
                        elif bytes_sec >= 1024:
                            return f"{bytes_sec / 1024:.1f} KB/s"
                        else:
                            return f"{bytes_sec:.0f} B/s"

                    dl_str = to_speed_str(dl_speed)
                    ul_str = to_speed_str(ul_speed)
                    status_str = check_ping()

                    if hasattr(self, "lbl_net_speed") and self.lbl_net_speed:
                        self.safe_after(0, lambda d=dl_str, u=ul_str: self.lbl_net_speed.setText(f"DL: {d} | UL: {u}"))
                    if hasattr(self, "lbl_net_status") and self.lbl_net_status:
                        self.safe_after(0, lambda s=status_str: self.lbl_net_status.setText(f"Status: {s}"))

                    io1 = io2
                    t1 = t2
                except Exception:
                    pass

        threading.Thread(target=monitor_loop, daemon=True).start()

    # ─────────────────────────────────────────────
    # LOG FILTER CALLBACKS
    # ─────────────────────────────────────────────

    def on_filter_worker_changed(self, choice=None):
        if hasattr(self, "redraw_filtered_logs"):
            self.redraw_filtered_logs()

    def on_filter_status_changed(self, choice=None):
        if hasattr(self, "redraw_filtered_logs"):
            self.redraw_filtered_logs()

    def on_filter_search_changed(self, *args):
        if hasattr(self, "redraw_filtered_logs"):
            self.redraw_filtered_logs()

    # ─────────────────────────────────────────────
    # START_THREAD (CTk → Qt conversion)
    # ─────────────────────────────────────────────

    def start_thread(self, mode, run_failed=False):
        """Validate inputs and enqueue a batch task to the browser worker."""
        if hasattr(self, "engine_loading_thread") and self.engine_loading_thread.is_alive():
            QMessageBox.information(self, "Engines Loading", "Automation engines are still loading in the background. Please wait a few seconds and try again.")
            return

        if self.is_task_running:
            return

        username = self.entry_user.text().strip()
        password = self.entry_pass.text().strip()

        if not username or not password:
            QMessageBox.critical(self, "Missing Input",
                "Please enter your IFMS Username and Password in the sidebar.")
            return

        if mode == "voucher" and not run_failed:
            if not self.voucher_excel_file_path:
                QMessageBox.critical(self, "Missing Input",
                    "Please select a Voucher Excel spreadsheet before starting.")
                return

            # Smart prompt if COMPAY file is selected but not linked yet
            if getattr(self, "vlc_compay_file_path", None) and not getattr(self, "active_linked_file_path", None):
                res = QMessageBox.question(
                    self, "Run VLC-COMPAY Linking?",
                    "A COMPAY CSV file is selected.\n\n"
                    "Would you like to run VLC-COMPAY Linking before starting validation?\n\n"
                    "• Yes: Links datasets and uses enriched data for Checks 32 & 33.\n"
                    "• No: Proceeds with standard validation on current Excel file.",
                    QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
                )
                if res == QMessageBox.Cancel:
                    return
                if res == QMessageBox.Yes:
                    self.execute_vlc_linking_interactive(
                        on_finish_callback=lambda ok: self.start_thread(mode, run_failed=run_failed)
                    )
                    return

        if mode == "payroll":
            # Validation is handled by the Payroll tab's _start_payroll()
            pass

        if mode == "pol" and not run_failed:
            if self.pol_excel_file_path:
                reply = QMessageBox.question(self, "POL Run Mode",
                    "An Excel file is selected.\n\n"
                    "Click YES to run POL downloads row-by-row using parameters from Excel.\n"
                    "Click NO to run using the checklist DDOs and GUI dates.",
                    QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
                if reply == QMessageBox.Cancel:
                    return
                self.pol_run_from_excel = (reply == QMessageBox.Yes)
            else:
                self.pol_run_from_excel = False

            if not self.pol_run_from_excel:
                from_val = self.entry_pol_from.text().strip()
                to_val = self.entry_pol_to.text().strip()
                if not from_val or not to_val:
                    QMessageBox.critical(self, "Missing Input",
                        "Please specify both 'From' and 'To' dates for POL.")
                    return

                valid_from, err_from = self.validate_date_string(from_val)
                if not valid_from:
                    QMessageBox.critical(self, "Invalid Date Format", f"From Date Error: {err_from}")
                    return

                valid_to, err_to = self.validate_date_string(to_val)
                if not valid_to:
                    QMessageBox.critical(self, "Invalid Date Format", f"To Date Error: {err_to}")
                    return

                selected_ddos = [name for name, var in self.ddo_checkboxes.items() if var.get()]
                if not selected_ddos:
                    QMessageBox.critical(self, "Missing Input",
                        "Please select at least one DDO from the checklist.")
                    return
                self.pol_selected_ddos = selected_ddos

                ans_update = QMessageBox.question(self, "Update DDO List Online?",
                    "Do you want to fetch and update the DDO list online first?\n\n"
                    "• Click YES to refresh the DDO list from the portal before downloading.\n"
                    "• Click NO to skip online refresh.",
                    QMessageBox.Yes | QMessageBox.No)
                self.pol_update_ddos_online = (ans_update == QMessageBox.Yes)

        if mode == "vlc" and not run_failed:
            from_val = self.entry_vlc_from.text().strip()
            to_val = self.entry_vlc_to.text().strip()
            if not from_val or not to_val:
                QMessageBox.critical(self, "Missing Input",
                    "Please specify both 'From' and 'To' dates for VLC Text Files.")
                return

            valid_from, err_from = self.validate_date_string(from_val)
            if not valid_from:
                QMessageBox.critical(self, "Invalid Date Format", f"From Date Error: {err_from}")
                return

            valid_to, err_to = self.validate_date_string(to_val)
            if not valid_to:
                QMessageBox.critical(self, "Invalid Date Format", f"To Date Error: {err_to}")
                return

            self.var_vlc_from_date.set(from_val)
            self.var_vlc_to_date.set(to_val)
            if hasattr(self, 'vlc_list_dropdown'):
                self.var_vlc_list_type.set(self.vlc_list_dropdown.currentText())

            from core.constants import VLC_MODULES
            selected_mods = [mod for mod in VLC_MODULES if getattr(self, "vlc_module_checkboxes", {}).get(mod["name"], None) and self.vlc_module_checkboxes[mod["name"]].isChecked()]
            if not selected_mods:
                QMessageBox.critical(self, "Missing Input",
                    "Please select at least one VLC report module from the list.")
                return
            self.vlc_selected_modules = selected_mods

            selected_tsries = [name for name, cb in getattr(self, "vlc_treasury_checkboxes", {}).items() if cb.isChecked()]
            if not selected_tsries:
                QMessageBox.critical(self, "Missing Input",
                    "Please select at least one VLC treasury from the checklist.")
                return
            self.vlc_selected_treasuries = selected_tsries

        if mode == "treasury" and not run_failed:
            from_val = self.entry_treasury_from.text().strip() if hasattr(self, "entry_treasury_from") else ""
            to_val = self.entry_treasury_to.text().strip() if hasattr(self, "entry_treasury_to") else ""
            
            self.treasury_split_by_month = False
            if from_val and to_val:
                try:
                    d1 = datetime.strptime(from_val, "%d/%m/%Y").date()
                    d2 = datetime.strptime(to_val, "%d/%m/%Y").date()
                    if d1.year != d2.year or d1.month != d2.month:
                        reply = QMessageBox.question(
                            self,
                            "Split Date Range?",
                            "The selected date range spans multiple months.\n\nDo you want to split this range into single months and download them month-wise?",
                            QMessageBox.Yes | QMessageBox.No,
                            QMessageBox.Yes
                        )
                        if reply == QMessageBox.Yes:
                            self.treasury_split_by_month = True
                except Exception:
                    pass

        # Check for session auto-resume checkpoint
        state_file = os.path.join(self.base_path, ".run_state.json")
        if not run_failed and os.path.exists(state_file):
            try:
                with open(state_file, "r", encoding="utf-8") as f:
                    state = json.load(f)
                completed_count = len(state.get("completed", []))
            except Exception:
                completed_count = 0

            ans = QMessageBox.question(self, "Resume Session Checkpoint",
                f"An existing run state was found with {completed_count} completed items.\n\n"
                "Do you want to use the checkpoint from the previous run?\n\n"
                "• YES: Use checkpoint (skip already processed items).\n"
                "• NO: Start fresh (clear checkpoint).",
                QMessageBox.Yes | QMessageBox.No)
            if ans == QMessageBox.No:
                try:
                    os.remove(state_file)
                    self.log("🗑️ Cleared session auto-resume checkpoint database (starting fresh run).")
                except Exception as err:
                    self.log(f"⚠️ Failed to clear checkpoint file: {err}")

        self.update_download_dir_paths(self.var_download_dir.get())
        self.stop_requested = False
        self.post_process_done = False
        self.run_start_time = time.time()

        self.captcha_attempts = 0
        self.captcha_success = 0
        self.timeout_count = 0
        self.session_expiry_count = 0

        with self._counter_lock:
            self.success_count = self.skip_count = self.fail_count = 0
        self.downloaded_folders_this_run = []

        self.update_stats(progress=0.0)
        self.cache_gui_variables()
        self.set_ui_lock_state(is_locked=True)

        self.is_task_running = True
        self.browser_queue.put(("RUN_BATCH", (mode, run_failed)))

    def update_download_dir_paths(self, new_dir):
        if not new_dir:
            return
        self.download_dir = os.path.normpath(new_dir.strip())
        os.makedirs(self.download_dir, exist_ok=True)
        self.voucher_master_report = os.path.join(self.download_dir, "Downloaded_Vouchers_Report.txt")
        self.voucher_failed_file = os.path.join(self.download_dir, "Failed_Vouchers.txt")
        self.paybill_master_report = os.path.join(self.download_dir, "PayBill_Downloaded_Report.txt")
        self.paybill_failed_file = os.path.join(self.download_dir, "Failed_PayBills.txt")
        self.pol_failed_file = os.path.join(self.download_dir, "POL_Failed_Rows.txt")

    # ─────────────────────────────────────────────
    # DDO UPDATE THREAD
    # ─────────────────────────────────────────────

    def start_ddo_update_thread(self):
        if self.is_task_running:
            return
        username = self.entry_user.text().strip()
        password = self.entry_pass.text().strip()
        if not username or not password:
            QMessageBox.critical(self, "Missing Input",
                "Please enter your IFMS Username and Password.")
            return
        self.is_task_running = True
        self.set_ui_lock_state(is_locked=True)
        self.browser_queue.put(("DDO_UPDATE", (username, password)))

    # ─────────────────────────────────────────────
    # HEARTBEAT ANIMATION
    # ─────────────────────────────────────────────

    def _animate_heartbeat(self):
        """Toggle heartbeat indicator color every 600ms."""
        try:
            self.heartbeat_state = not self.heartbeat_state
            if self.is_task_running:
                color = self.get_theme_color("TEXT_HIGHLIGHT") if self.heartbeat_state else "gray"
                text = "● Thread Active [Running]"
            else:
                color = "gray"
                text = "● Thread Active [Idle]"

            if hasattr(self, 'lbl_heartbeat'):
                self.lbl_heartbeat.setText(text)
                self.lbl_heartbeat.setStyleSheet(f"color: {color}; font-weight: bold;")
        except Exception:
            pass
        QTimer.singleShot(600, self, self._animate_heartbeat)

    # ─────────────────────────────────────────────
    # SMOOTH PROGRESS BAR
    # ─────────────────────────────────────────────

    def _setup_smooth_progress_bar(self):
        """Configure smooth animated progress bar transitions."""
        if not hasattr(self, "progress_bar"):
            return
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)

    # ─────────────────────────────────────────────
    # KEEP-ALIVE DAEMON
    # ─────────────────────────────────────────────

    def _start_keep_alive_daemon(self):
        def keep_alive_loop():
            time.sleep(60)
            while not getattr(self, "_stop_keep_alive", False):
                try:
                    if hasattr(self, "browser_page") and self.browser_page and not self.browser_page.is_closed():
                        is_expired = False
                        try:
                            is_expired = self.browser_page.evaluate("""() => {
                                return fetch("ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", {method: "GET"})
                                    .then(res => {
                                        if (res.redirected && res.url.includes("login.jsp")) {
                                            return true;
                                        }
                                        return false;
                                    })
                                    .catch(() => true);
                            }""")
                        except Exception:
                            pass

                        if is_expired:
                            self.log("🛡️ [Keep-Alive Daemon] Active session has expired.")
                            username = self.entry_user.text().strip()
                            password = self.entry_pass.text().strip()
                            state_file = os.path.join(self.base_path, "session_state.json")
                            pause_event = getattr(self, "active_pause_event", None)
                            if not pause_event:
                                import multiprocessing
                                pause_event = multiprocessing.Event()
                            self.reauthenticate_portal(username, password, state_file, pause_event)
                            try:
                                pause_event.clear()
                            except Exception:
                                pass
                except Exception as e:
                    self.log(f"⚠️ [Keep-Alive Daemon] Loop exception: {e}")

                for _ in range(300):
                    if getattr(self, "_stop_keep_alive", False):
                        break
                    time.sleep(1)

        self._stop_keep_alive = False
        self.keep_alive_thread = threading.Thread(target=keep_alive_loop, daemon=True)
        self.keep_alive_thread.start()

    # ─────────────────────────────────────────────
    # REQUEST STOP
    # ─────────────────────────────────────────────

    def request_stop(self):
        self.log("🛑 Stop safety request received. Awaiting graceful shutdown of threads...")
        self.stop_requested = True

    # ─────────────────────────────────────────────
    # WINDOW CLOSE
    # ─────────────────────────────────────────────

    def closeEvent(self, event):
        """Override QMainWindow close event (replaces on_closing)."""
        if hasattr(self, "net_monitor"):
            try:
                self.net_monitor.stop()
            except Exception:
                pass

        if hasattr(self, "latency_monitor"):
            try:
                self.latency_monitor.stop()
            except Exception:
                pass

        if self.is_task_running:
            reply = QMessageBox.question(
                self, "Quit Running Task?",
                "An active automation task is running.\nAre you sure you want to stop it and exit?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.No:
                event.ignore()
                return
        # Stop active tasks & background monitors
        try: self.request_stop()
        except Exception: pass

        # Silent logout
        try:
            if getattr(self, "browser_page", None) and self.browser_page:
                self.log("🚪 Performing silent logout to release portal lock block...")
                t = threading.Thread(target=self.safe_logout_and_close, args=(self.browser_page,), daemon=True)
                t.start()
                t.join(timeout=3.0)
        except Exception:
            pass

        # Cleanup browser session & Playwright instances
        try: self._cleanup_browser_session()
        except Exception: pass

        # Terminate any spawned background worker process trees
        try:
            if hasattr(self, "worker_processes") and self.worker_processes:
                for proc in self.worker_processes:
                    try:
                        p_pid = getattr(proc, 'pid', None)
                        if p_pid: kill_process_tree(p_pid)
                        else: proc.terminate()
                    except Exception: pass
        except Exception: pass

        # Terminate shared CDP process tree if running
        try:
            if hasattr(self, "shared_cdp_process") and self.shared_cdp_process:
                try:
                    c_pid = getattr(self.shared_cdp_process, 'pid', None)
                    if c_pid: kill_process_tree(c_pid)
                    else: self.shared_cdp_process.terminate()
                except Exception: pass
        except Exception: pass

        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
            except Exception:
                pass

        event.accept()

    # Compatibility alias
    def on_closing(self):
        self.close()

    # ─────────────────────────────────────────────
    # CREDENTIALS
    # ─────────────────────────────────────────────

    def load_credentials(self):
        if os.path.exists(self.cred_file):
            try:
                with open(self.cred_file, "r") as f:
                    content = f.read().strip()
                if content:
                    padding_needed = len(content) % 4
                    if padding_needed:
                        content += '=' * (4 - padding_needed)
                    decoded = base64.b64decode(content).decode("utf-8")
                    if "|" in decoded:
                        user, pwd = decoded.split("|", 1)
                        self.entry_user.setText(user)
                        self.entry_pass.setText(pwd)
            except Exception as e:
                print(f"Error loading credentials: {e}")

    def save_credentials(self):
        user = self.entry_user.text().strip()
        pwd = self.entry_pass.text().strip()
        if not user or not pwd:
            QMessageBox.warning(self, "Warning", "Username and password cannot be empty.")
            return
        try:
            encoded = base64.b64encode(f"{user}|{pwd}".encode("utf-8")).decode("utf-8")
            with open(self.cred_file, "w") as f:
                f.write(encoded)
            self.log("✅ Credentials saved successfully.")
        except Exception as e:
            self.log(f"❌ Failed to save credentials: {e}")

    # ─────────────────────────────────────────────
    # PROFILES
    # ─────────────────────────────────────────────

    def load_profiles(self):
        """Load saved profiles from profiles.json."""
        profile_file = os.path.join(self.base_path, "profiles.json")
        self._profiles = {"Default": {}}
        if os.path.exists(profile_file):
            try:
                with open(profile_file, "r", encoding="utf-8") as f:
                    self._profiles = json.load(f)
            except Exception:
                pass
        if hasattr(self, 'opt_profile'):
            self.opt_profile.blockSignals(True)
            self.opt_profile.clear()
            self.opt_profile.addItems(sorted(list(self._profiles.keys())))
            self.opt_profile.blockSignals(False)

    def save_current_profile(self):
        """Save current settings as a named profile."""
        name = self.var_active_profile.get().strip()
        if not name:
            QMessageBox.warning(self, "Warning", "Profile name cannot be empty.")
            return
        
        pwd_raw = self.entry_pass.text().strip()
        pwd_enc = ""
        if pwd_raw:
            pwd_enc = base64.b64encode(pwd_raw.encode('utf-8')).decode('utf-8')

        self._profiles[name] = {
            "username": self.entry_user.text().strip(),
            "password_enc": pwd_enc,
            "download_dir": self.var_download_dir.get(),
            "stealth_mode": self.var_stealth.get(),
            "auto_archive": self.var_archive.get(),
            "dry_run": self.var_dryrun.get(),
            "preferred_browser": self.var_browser.get(),
            "timeout_login": self.var_timeout_login.get(),
            "timeout_pdf": self.var_timeout_pdf.get(),
            "timeout_attachment": self.var_timeout_attachment.get(),
            "timeout_xls": self.var_timeout_xls.get(),
            "parallel_mode": self.var_parallel.get(),
            "parallel_workers": self.var_parallel_workers.get(),
            "show_workers": self.var_show_workers.get(),
            "headful_monitor": self.var_headful_monitor.get(),
            "path_template": self.var_path_template.get(),
            "pol_path_template": self.var_pol_path_template.get(),
            "audio_alerts": self.var_audio_alerts.get(),
            "os_notifications": self.var_os_notifications.get(),
            "salary_treasury": self.var_salary_treasury.get() if hasattr(self, "var_salary_treasury") else "",
            "salary_dept": self.var_salary_dept.get() if hasattr(self, "var_salary_dept") else "",
            "salary_mh": self.var_salary_mh.get() if hasattr(self, "var_salary_mh") else "",
            "salary_gpf_idx": self.var_salary_gpf_idx.get() if hasattr(self, "var_salary_gpf_idx") else "",
            "salary_start_month": self.var_salary_start_month.get() if hasattr(self, "var_salary_start_month") else "",
            "salary_start_year": self.var_salary_start_year.get() if hasattr(self, "var_salary_start_year") else "",
            "salary_end_month": self.var_salary_end_month.get() if hasattr(self, "var_salary_end_month") else "",
            "salary_end_year": self.var_salary_end_year.get() if hasattr(self, "var_salary_end_year") else ""
        }
        profile_file = os.path.join(self.base_path, "profiles.json")
        try:
            with open(profile_file, "w", encoding="utf-8") as f:
                json.dump(self._profiles, f, indent=4)
            self.log(f"💾 Profile '{name}' saved successfully.")
            self.load_profiles()
            self.var_active_profile.set(name)
            QMessageBox.information(self, "Saved", f"Profile '{name}' Saved Successfully!")
        except Exception as e:
            self.log(f"❌ Failed to save profile: {e}")
            QMessageBox.critical(self, "Error", f"Failed to save profile:\n{e}")

    def on_profile_selected(self, selected_profile):
        """Load a profile's settings."""
        if selected_profile in self._profiles:
            p = self._profiles[selected_profile]
            
            if "username" in p:
                self.entry_user.setText(p.get("username", ""))
            
            pwd_raw = ""
            if "password" in p:
                pwd_raw = p["password"]
            elif "password_enc" in p:
                pwd_enc = p["password_enc"]
                if pwd_enc:
                    try:
                        pwd_raw = base64.b64decode(pwd_enc.encode('utf-8')).decode('utf-8')
                    except Exception:
                        pwd_raw = ""
            self.entry_pass.setText(pwd_raw)
            
            # Upgrade download_dir from legacy path if needed
            d_dir = p.get("download_dir", "").strip() if p.get("download_dir") else ""
            if not d_dir or "v2.8" in d_dir or "3.4" in d_dir or "USER_DATA" in d_dir:
                d_dir = os.path.normpath(os.path.join(APP_DIR, "downloads"))
            d_dir = os.path.normpath(d_dir)
            if d_dir == os.path.normpath(APP_DIR):
                d_dir = os.path.normpath(os.path.join(APP_DIR, "downloads"))
            self.download_dir = d_dir
            self.var_download_dir.set(d_dir)

            self.var_stealth.set(p.get("stealth_mode", True))
            self.var_archive.set(p.get("auto_archive", False))
            self.var_dryrun.set(p.get("dry_run", False))
            self.var_browser.set(p.get("preferred_browser", "Google Chrome / Chromium"))
            
            # Auto-migrate/upgrade profile timeouts to new defaults
            login_val = p.get("timeout_login", 60)
            if login_val < 60: login_val = 60
            self.var_timeout_login.set(login_val)
            
            pdf_val = p.get("timeout_pdf", 600)
            if pdf_val < 600: pdf_val = 600
            self.var_timeout_pdf.set(pdf_val)
            
            att_val = p.get("timeout_attachment", 600)
            if att_val < 600: att_val = 600
            self.var_timeout_attachment.set(att_val)
            
            xls_val = p.get("timeout_xls", 3600)
            if xls_val < 3600: xls_val = 3600
            self.var_timeout_xls.set(xls_val)
            self.var_parallel.set(p.get("parallel_mode", True))
            self.var_parallel_workers.set(p.get("parallel_workers", 3))
            self.var_show_workers.set(p.get("show_workers", False))
            self.var_headful_monitor.set(p.get("headful_monitor", False))
            self.var_path_template.set(p.get("path_template", "{Output_Folder}/{S_No}_{Treasury}_{Major_Head}_{Month}_{Year}_{Voucher_No}_{Amount}"))
            self.var_pol_path_template.set(p.get("pol_path_template", "{Output_Folder}/POL/{Treasury}_{DDO}_{From_Date}_{To_Date}"))
            self.var_audio_alerts.set(p.get("audio_alerts", True))
            self.var_os_notifications.set(p.get("os_notifications", True))
            
            if hasattr(self, "var_salary_treasury"):
                self.var_salary_treasury.set(p.get("salary_treasury", ""))
                self.var_salary_dept.set(p.get("salary_dept", ""))
                self.var_salary_mh.set(p.get("salary_mh", ""))
                self.var_salary_gpf_idx.set(p.get("salary_gpf_idx", ""))
                self.var_salary_start_month.set(p.get("salary_start_month", ""))
                self.var_salary_start_year.set(p.get("salary_start_year", ""))
                self.var_salary_end_month.set(p.get("salary_end_month", ""))
                self.var_salary_end_year.set(p.get("salary_end_year", ""))
            
            self.log(f"👤 Profile '{selected_profile}' loaded into UI.")

    def delete_current_profile(self):
        """Delete the currently selected profile."""
        name = self.var_active_profile.get()
        if name == "Default":
            QMessageBox.warning(self, "Warning", "Cannot delete the Default profile.")
            return
        if name in self._profiles:
            del self._profiles[name]
            profile_file = os.path.join(self.base_path, "profiles.json")
            try:
                with open(profile_file, "w", encoding="utf-8") as f:
                    json.dump(self._profiles, f, indent=4)
                self.log(f"🗑️ Profile '{name}' deleted.")
                self.load_profiles()
            except Exception as e:
                self.log(f"❌ Failed to delete profile: {e}")

    # ─────────────────────────────────────────────
    # CONFIG PERSISTENCE
    # ─────────────────────────────────────────────

    def load_config(self):
        self._loading_config = True
        config_path = os.path.join(self.base_path, "config.json")
        defaults = {
            "download_dir": os.path.join(APP_DIR, "downloads"),
            "stealth_mode": True, "auto_archive": False, "dry_run": False,
            "preferred_browser": "Google Chrome / Chromium",
            "direct_dashboard": False, "theme_accent": "Emerald Teal (Dark)",
            "timeout_login": 60, "timeout_pdf": 600, "timeout_attachment": 600, "timeout_xls": 3600,
            "download_paybills_in_vouchers": True,
            "merge_pol_files": False,
            "pol_folder_structure": "Option 1 (Default: Treasury_POL > Month_Year > All DDO Files)",
            "pol_file_naming": "Option 4 (DDO_Code_DDO_Name): [DDO_Code]_[DDO_Name]",
            "pol_path_template": "{Output_Folder}/POL/POL_{Treasury_Clean}/{Month_Year_Num}/{DDO_Code}_{DDO_Name}",
            "auto_solve_captcha": False, "parallel_mode": True, "parallel_workers": 3,
            "show_workers": False, "headful_monitor": False,
            "path_template": "{Output_Folder}/{S_No}_{Treasury}_{Major_Head}_{Month}_{Year}_{Voucher_No}_{Amount}",
            "audio_alerts": True, "os_notifications": True,
            "header_voucher": ['sop_vch_no', 'voucher no', 'voucher_no', 'voucher_number', 'voucher number', 'vch no', 'vchno', 'vou_no', 'vch', 'voucher', 'vou', 's_no', 's.no'],
            "header_treasury": ['try_cd', 'try_cdn', 'try code', 'treasury code', 'treasury name', 'treasury_name', 'try_name', 'treasury_cd', 'treasury', 'try'],
            "header_mh": ['major head (mhcd)', 'mhcd', 'major head', 'major_head', 'major', 'mh', 'm.h', 'head'],
            "header_month": ['month', 'month_in'],
            "header_year": ['year', 'year_in', 'yr'],
            "header_amount": ['vlc voucher amount', 'amount (vlc)', 'vlc_amount', 'vlc_amt', 'compay voucher amount', 'amount (pol)', 'sop_vch_amt', 'sop_vch_amount', 'sop_vch', 'sop_amt', 'vch_amt', 'vch_amount', 'voucher_amount', 'voucher amount', 'amount_paid', 'amount paid', 'paid_amount', 'paid amount', 'gross_amt', 'gross_amount', 'net_amt', 'net_amount', 'claim_amt', 'claim_amount', 'amount', 'amt', 'gross', 'net', 'total', 'claim', 'value', 'val'],
            "header_ddo": ['ddo (vlc)', 'ddo_cd', 'ddo_code', 'ddo code', 'ddocd', 'ddo'],
            "header_from_date": ['from', 'from_date', 'start_date', 'from date', 'date_of_payment', 'date of payment', 'payment_date'],
            "header_to_date": ['to', 'to_date', 'end_date', 'to date'],
            "header_bill_type": ['bill type', 'bill_type', 'billtype', 'sna', 'sna/non-sna', 'sna_flag', 'sna flag']
        }
        config = defaults.copy()
        if os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                    # Enforce timeout minimums from config
                    if "timeout_login" in saved and saved["timeout_login"] < 60:
                        saved["timeout_login"] = 60
                    if "timeout_pdf" in saved and saved["timeout_pdf"] < 600:
                        saved["timeout_pdf"] = 600
                    if "timeout_attachment" in saved and saved["timeout_attachment"] < 600:
                        saved["timeout_attachment"] = 600
                    if "timeout_xls" in saved and saved["timeout_xls"] < 3600:
                        saved["timeout_xls"] = 3600
                    config.update(saved)
            except Exception as e:
                print(f"Error reading config: {e}")

        # Enforce dynamic version-aligned download directory auto-migration
        self.download_dir = config.get("download_dir", "").strip() if config.get("download_dir") else ""
        curr_app_dir = os.path.normpath(APP_DIR)
        expected_downloads_dir = os.path.normpath(os.path.join(curr_app_dir, "downloads"))
        
        # If download_dir is empty, invalid, or points to an older suite folder version, auto-migrate to current folder's downloads!
        if not self.download_dir or not self.download_dir.startswith(curr_app_dir):
            self.download_dir = expected_downloads_dir
            
        self.download_dir = os.path.normpath(self.download_dir)
        self.var_download_dir.set(self.download_dir)

        self.var_stealth.set(config.get("stealth_mode", True))
        self.var_archive.set(config.get("auto_archive", False))
        self.var_dryrun.set(config.get("dry_run", False))
        self.var_browser.set(config.get("preferred_browser", "Google Chrome / Chromium"))
        self.var_direct_dashboard.set(config.get("direct_dashboard", True))
        theme_val = config.get("theme_accent", "Emerald Teal (Dark)")
        if theme_val == "Emerald Teal (Default)":
            theme_val = "Emerald Teal (Dark)"
        self.var_theme_accent.set(theme_val)
        self.var_timeout_login.set(config.get("timeout_login", 60))
        self.var_timeout_pdf.set(config.get("timeout_pdf", 600))
        self.var_timeout_attachment.set(config.get("timeout_attachment", 600))
        self.var_timeout_xls.set(config.get("timeout_xls", 3600))
        self.var_voucher_download_paybills.set(config.get("download_paybills_in_vouchers", True))
        self.var_paybill_only.set(config.get("paybill_only", False))
        self.var_scan_existing_vouchers.set(config.get("scan_existing_vouchers", False))
        self.var_auto_solve_captcha.set(config.get("auto_solve_captcha", True))
        self.var_telegram_enabled.set(config.get("telegram_enabled", False))
        self.var_telegram_token.set(config.get("telegram_token", ""))
        self.var_telegram_chat_id.set(config.get("telegram_chat_id", ""))
        self.var_pol_folder_structure.set(config.get("pol_folder_structure", defaults["pol_folder_structure"]))
        self.var_pol_file_naming.set(config.get("pol_file_naming", defaults["pol_file_naming"]))
        self.var_merge_pol_files.set(config.get("merge_pol_files", True))
        self.var_parallel.set(True)
        self.var_parallel_workers.set(config.get("parallel_workers", 3))
        self.var_show_workers.set(config.get("show_workers", False))
        self.var_headful_monitor.set(config.get("headful_monitor", False))

        path_tpl = config.get("path_template", "").strip() if config.get("path_template") else ""
        if not path_tpl:
            path_tpl = defaults["path_template"]
        self.var_path_template.set(path_tpl)

        pol_path_tpl = config.get("pol_path_template", "").strip() if config.get("pol_path_template") else ""
        if not pol_path_tpl:
            pol_path_tpl = defaults["pol_path_template"]
        self.var_pol_path_template.set(pol_path_tpl)

        self.var_audio_alerts.set(config.get("audio_alerts", defaults["audio_alerts"]))
        self.var_os_notifications.set(config.get("os_notifications", defaults["os_notifications"]))

        # Tab visibility settings
        self.var_tab_vouchers_visible.set(config.get("tab_vouchers_visible", True))
        self.var_tab_payroll_visible.set(config.get("tab_payroll_visible", True))
        self.var_tab_pol_visible.set(config.get("tab_pol_visible", True))
        self.var_tab_vlc_visible.set(config.get("tab_vlc_visible", True))
        self.var_tab_tally_visible.set(config.get("tab_tally_visible", True))
        self.var_tab_treasury_visible.set(config.get("tab_treasury_visible", True))

        self.var_telemetry_enabled.set(config.get("telemetry_enabled", True))
        self.var_vlc_from_date.set(config.get("vlc_from_date", "01/04/2025"))
        self.var_vlc_to_date.set(config.get("vlc_to_date", "31/03/2026"))
        self.var_vlc_list_type.set(config.get("vlc_list_type", "All"))

        self.headers_voucher = list(dict.fromkeys(config.get("header_voucher", defaults["header_voucher"]) + ['voucher_number', 'voucher number', 'voucher_no', 'voucher no', 's_no', 's.no']))
        self.headers_treasury = config.get("header_treasury", defaults["header_treasury"])
        self.headers_mh = config.get("header_mh", defaults["header_mh"])
        self.headers_month = config.get("header_month", defaults["header_month"])
        self.headers_year = config.get("header_year", defaults["header_year"])
        self.headers_amount = list(dict.fromkeys(config.get("header_amount", defaults["header_amount"]) + ['amount_paid', 'amount paid', 'paid_amount', 'paid amount', 'claim_amount', 'net_amount', 'gross_amount', 'total']))
        self.headers_ddo = config.get("header_ddo", defaults["header_ddo"])
        self.headers_from_date = list(dict.fromkeys(config.get("header_from_date", defaults["header_from_date"]) + ['date_of_payment', 'date of payment', 'payment_date', 'from_date', 'from date']))
        self.headers_to_date = config.get("header_to_date", defaults["header_to_date"])
        self.headers_bill_type = config.get("header_bill_type", defaults["header_bill_type"])

        self.TIMEOUT_LOGIN = config.get("timeout_login", 60) * 1000
        self.TIMEOUT_DOWNLOAD_PDF = config.get("timeout_pdf", 180) * 1000
        self.TIMEOUT_DOWNLOAD_ATTACHMENT = config.get("timeout_attachment", 180) * 1000
        self.TIMEOUT_DOWNLOAD_XLS = config.get("timeout_xls", 2160) * 1000
        self._loading_config = False

    def init_db(self):
        from database.db_manager import init_db
        init_db(self)

    def save_config(self, show_popup=True):
        config_path = os.path.join(self.base_path, "config.json")
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        config = {
            "download_dir": self.var_download_dir.get(),
            "stealth_mode": self.var_stealth.get(),
            "auto_archive": self.var_archive.get(),
            "dry_run": self.var_dryrun.get(),
            "preferred_browser": self.var_browser.get(),
            "direct_dashboard": False,  # Security Override: Always False on disk
            "theme_accent": self.var_theme_accent.get(),
            "timeout_login": self.var_timeout_login.get(),
            "timeout_pdf": self.var_timeout_pdf.get(),
            "timeout_attachment": self.var_timeout_attachment.get(),
            "timeout_xls": self.var_timeout_xls.get(),
            "download_paybills_in_vouchers": self.var_voucher_download_paybills.get(),
            "paybill_only": self.var_paybill_only.get(),
            "scan_existing_vouchers": self.var_scan_existing_vouchers.get(),
            "parallel_mode": self.var_parallel.get(),
            "parallel_workers": self.var_parallel_workers.get(),
            "show_workers": self.var_show_workers.get(),
            "headful_monitor": self.var_headful_monitor.get(),
            "path_template": self.var_path_template.get(),
            "pol_path_template": self.var_pol_path_template.get(),
            "audio_alerts": self.var_audio_alerts.get(),
            "os_notifications": self.var_os_notifications.get(),
            "tab_vouchers_visible": self.var_tab_vouchers_visible.get(),
            "tab_payroll_visible": self.var_tab_payroll_visible.get(),
            "tab_pol_visible": self.var_tab_pol_visible.get(),
            "tab_vlc_visible": self.var_tab_vlc_visible.get(),
            "tab_tally_visible": self.var_tab_tally_visible.get(),
            "tab_treasury_visible": self.var_tab_treasury_visible.get(),
            "auto_solve_captcha": False,  # Security Override: Always False on disk
            "telegram_enabled": self.var_telegram_enabled.get(),
            "telegram_token": self.var_telegram_token.get(),
            "telegram_chat_id": self.var_telegram_chat_id.get(),
            "pol_folder_structure": self.var_pol_folder_structure.get(),
            "pol_file_naming": self.var_pol_file_naming.get(),
            "merge_pol_files": self.var_merge_pol_files.get(),
            "telemetry_enabled": self.var_telemetry_enabled.get(),
            "vlc_from_date": self.var_vlc_from_date.get(),
            "vlc_to_date": self.var_vlc_to_date.get(),
            "vlc_list_type": self.var_vlc_list_type.get(),
            "header_voucher": getattr(self, "headers_voucher", []),
            "header_treasury": getattr(self, "headers_treasury", []),
            "header_mh": getattr(self, "headers_mh", []),
            "header_month": getattr(self, "headers_month", []),
            "header_year": getattr(self, "headers_year", []),
            "header_amount": getattr(self, "headers_amount", []),
            "header_ddo": getattr(self, "headers_ddo", []),
            "header_from_date": getattr(self, "headers_from_date", []),
            "header_to_date": getattr(self, "headers_to_date", []),
            "header_bill_type": getattr(self, "headers_bill_type", [])
        }

        try:
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4)
            self.download_dir = config["download_dir"]
            os.makedirs(self.download_dir, exist_ok=True)

            self.voucher_master_report = os.path.join(self.download_dir, "Downloaded_Vouchers_Report.txt")
            self.voucher_failed_file = os.path.join(self.download_dir, "Failed_Vouchers.txt")
            self.paybill_master_report = os.path.join(self.download_dir, "PayBill_Downloaded_Report.txt")
            self.paybill_failed_file = os.path.join(self.download_dir, "Failed_PayBills.txt")
            self.pol_failed_file = os.path.join(self.download_dir, "POL_Failed_Rows.txt")

            self.TIMEOUT_LOGIN = config["timeout_login"] * 1000
            self.TIMEOUT_DOWNLOAD_PDF = config["timeout_pdf"] * 1000
            self.TIMEOUT_DOWNLOAD_ATTACHMENT = config["timeout_attachment"] * 1000
            self.TIMEOUT_DOWNLOAD_XLS = config["timeout_xls"] * 1000

            self.log("💾 Application configuration saved successfully.")
            if show_popup:
                QMessageBox.information(self, "Saved", "Settings Saved Successfully!")
        except Exception as e:
            self.log(f"❌ Failed to save configuration: {e}")
            if show_popup:
                QMessageBox.critical(self, "Error", f"Failed to save configuration:\n{e}")

    def save_operator_config(self):
        self.save_config(show_popup=False)

    def clear_delta_resume_session(self):
        import sqlite3
        from PySide6.QtWidgets import QMessageBox
        
        reply = QMessageBox.question(
            self,
            "Clear Delta Resume Session",
            "Are you sure you want to clear the Delta Resume session history?\n\nThis will clear the database logs of completed tasks and delete all success/skipped marker files, forcing a fresh download of all reports.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return
            
        db_path = os.path.join(self.base_path, "ifmis_workspace.db")
        db_cleared = False
        if os.path.exists(db_path):
            try:
                conn = sqlite3.connect(db_path, timeout=10.0)
                cursor = conn.cursor()
                cursor.execute("DELETE FROM downloads")
                conn.commit()
                conn.execute("VACUUM")
                conn.close()
                db_cleared = True
            except Exception as e:
                self.log(f"⚠️ Error clearing SQLite database: {e}")
                
        deleted_markers_count = 0
        try:
            output_dir = os.path.join(self.base_path, "output")
            if os.path.exists(output_dir):
                for root, dirs, files in os.walk(output_dir):
                    for f in files:
                        if f.lower() in ("success.marker", "skipped.marker"):
                            try:
                                os.remove(os.path.join(root, f))
                                deleted_markers_count += 1
                            except Exception:
                                pass
        except Exception as e:
            self.log(f"⚠️ Error cleaning marker files: {e}")
            
        msg = "Delta Resume Session cleared successfully!"
        if db_cleared:
            msg += "\n- Database history cleared."
        if deleted_markers_count > 0:
            msg += f"\n- Deleted {deleted_markers_count} marker file(s)."
            
        QMessageBox.information(self, "Success", msg)
        self.log(f"✅ Delta Resume Session cleared (DB: {db_cleared}, Markers Deleted: {deleted_markers_count})")

    # ─────────────────────────────────────────────
    # FILE DIALOGS (CTk filedialog → QFileDialog)
    # ─────────────────────────────────────────────

    def pick_vlc_compay_file(self):
        """Open file dialog for optional COMPAY / VLC CSV selection."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Select COMPAY / VLC CSV File (Optional)",
            self.download_dir,
            "CSV Files (*.csv);;All Files (*.*)"
        )
        if path:
            norm_path = os.path.normpath(path)
            filename = os.path.basename(norm_path)
            self.vlc_compay_file_path = norm_path
            if hasattr(self, "btn_vlc_compay_opt") and self.btn_vlc_compay_opt:
                self.btn_vlc_compay_opt.setText(f"✅ STEP 2: {filename} (Click to Change)")
                self.btn_vlc_compay_opt.setStyleSheet("""
                    QPushButton {
                        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3b82f6, stop:1 #1d4ed8);
                        color: #ffffff;
                        border: 2px solid #60a5fa;
                        border-radius: 10px;
                        font-weight: 800;
                        font-size: 12px;
                        padding: 8px 16px;
                    }
                    QPushButton:hover {
                        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #60a5fa, stop:1 #3b82f6);
                    }
                """)
            if hasattr(self, "lbl_vlc_compay_opt") and self.lbl_vlc_compay_opt:
                self.lbl_vlc_compay_opt.setText(f"✅ COMPAY Dataset Loaded: {filename}")
                self.lbl_vlc_compay_opt.setStyleSheet("color: #60a5fa; font-size: 11px; font-weight: 700; background-color: rgba(96, 165, 250, 0.12); padding: 4px 8px; border-radius: 6px;")
            self.log(f"🔗 Optional COMPAY/VLC dataset loaded: {filename}")

    def execute_vlc_linking_interactive(self, on_finish_callback=None):
        """Execute Polars dataset linking on selected Excel & COMPAY files and display result dialog."""
        pol_path = getattr(self, "voucher_excel_file_path", None)
        vlc_path = getattr(self, "vlc_compay_file_path", None)

        if not pol_path or not os.path.exists(pol_path):
            QMessageBox.warning(self, "Missing Input File", "Please select a valid Voucher Excel List first.")
            return
        if not vlc_path or not os.path.exists(vlc_path):
            QMessageBox.warning(self, "Missing COMPAY File", "Please select a valid COMPAY / VLC CSV file first.")
            return

        self._pending_vlc_finish_callback = on_finish_callback

        out_dir = os.path.join(self.download_dir, "downloads")
        os.makedirs(out_dir, exist_ok=True)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        out_path = os.path.join(out_dir, f"Linked_Vouchers_COMPAY_{timestamp}.csv")

        # Update button state immediately for user feedback
        if hasattr(self, "btn_execute_vlc_link"):
            self.btn_execute_vlc_link.setText("⏳ Linking Datasets (Polars)...")
            self.btn_execute_vlc_link.setEnabled(False)

        self.log(f"⚡ Starting Polars VLC-COMPAY dataset linking engine...")
        self.log(f"  POL File: {os.path.basename(pol_path)}")
        self.log(f"  COMPAY File: {os.path.basename(vlc_path)}")

        start_time = time.time()

        def worker():
            try:
                from link_vlc_polars import run_linker_engine
                run_linker_engine(
                    pol_path, vlc_path, out_path,
                    log_callback=self.log,
                    progress_callback=lambda p: None
                )
                elapsed = time.time() - start_time

                # Inspect output stats & extract unmatched records
                import polars as pl
                res_df = pl.read_csv(out_path, infer_schema_length=0, ignore_errors=True)
                total_rows = res_df.height
                matched_df = res_df.filter(pl.col("VLC_Linked").cast(pl.String).str.to_uppercase() == "YES")
                unmatched_df = res_df.filter(pl.col("VLC_Linked").cast(pl.String).str.to_uppercase() != "YES")

                matched_rows = matched_df.height
                unmatched_rows = unmatched_df.height
                pct_linked = (matched_rows / total_rows * 100.0) if total_rows > 0 else 0.0

                unmatched_records = unmatched_df.head(200).to_dicts()

                stats = {
                    "total_rows": total_rows,
                    "matched_rows": matched_rows,
                    "unmatched_rows": unmatched_rows,
                    "pct_linked": pct_linked,
                    "elapsed": elapsed,
                    "unmatched_records": unmatched_records
                }

                # Store active linked file path and emit Qt signal to main thread
                self.active_linked_file_path = out_path
                self.signals.vlc_linker_finished.emit(stats, out_path)

            except Exception as e:
                self.log(f"[ERROR] VLC-COMPAY Linking failed: {e}")
                self.signals.vlc_linker_failed.emit(str(e))

        threading.Thread(target=worker, daemon=True).start()

    @Slot(dict, str)
    def _on_vlc_linker_finished(self, stats: dict, out_path: str):
        """Slot executed on GUI thread when background VLC linking succeeds."""
        if hasattr(self, "btn_execute_vlc_link"):
            self.btn_execute_vlc_link.setText("⚡ Execute VLC-COMPAY Linking Now")
            self.btn_execute_vlc_link.setEnabled(True)

        callback = getattr(self, "_pending_vlc_finish_callback", None)
        self._pending_vlc_finish_callback = None
        self._show_vlc_link_result_dialog(stats, out_path, callback)

    @Slot(str)
    def _on_vlc_linker_failed(self, error_msg: str):
        """Slot executed on GUI thread when background VLC linking fails."""
        if hasattr(self, "btn_execute_vlc_link"):
            self.btn_execute_vlc_link.setText("⚡ Execute VLC-COMPAY Linking Now")
            self.btn_execute_vlc_link.setEnabled(True)

        QMessageBox.critical(self, "Linking Error", f"Dataset linking failed:\n{error_msg}")
        callback = getattr(self, "_pending_vlc_finish_callback", None)
        self._pending_vlc_finish_callback = None
        if callback:
            callback(False)

    def _show_vlc_link_result_dialog(self, stats: dict, linked_file_path: str, on_finish_callback=None):
        from gui.qt_dialogs import VLCLinkResultDialog
        dlg = VLCLinkResultDialog(stats, linked_file_path, parent=self)
        dlg.exec()

        if dlg.user_choice == "use":
            self.voucher_excel_file_path = linked_file_path
            self.voucher_selected_sheet = "Default"
            self.active_linked_file_path = linked_file_path
            filename = os.path.basename(linked_file_path)
            pct = stats.get("pct_linked", 0.0)

            if hasattr(self, "lbl_voucher_excel"):
                self.lbl_voucher_excel.setText(f"📄 {filename} [VLC LINKED: {pct:.1f}%]")
                self.lbl_voucher_excel.setStyleSheet("color: #00c9a7; font-weight: bold;")
            self.log(f"✅ Active voucher input set to Linked File: {filename} ({stats['matched_rows']:,} rows linked)")

            if on_finish_callback:
                on_finish_callback(True)

        elif dlg.user_choice == "save":
            self.export_active_linked_file(linked_file_path)
            if on_finish_callback:
                on_finish_callback(False)
        else:
            self.log(f"ℹ️ User skipped using linked file. Continuing with original Excel list.")
            if on_finish_callback:
                on_finish_callback(False)

    def export_active_linked_file(self, file_to_export=None):
        target = file_to_export or getattr(self, "active_linked_file_path", None) or getattr(self, "voucher_excel_file_path", None)
        if not target or not os.path.exists(target):
            QMessageBox.warning(self, "No File to Export", "Please execute linking first or select a file to export.")
            return

        default_save_path = os.path.join(self.download_dir, os.path.basename(target))
        dest_path, _ = QFileDialog.getSaveFileName(
            self, "Save / Export Linked File",
            default_save_path,
            "CSV Files (*.csv);;Excel Files (*.xlsx);;All Files (*.*)"
        )
        if dest_path:
            import shutil
            shutil.copy2(target, dest_path)
            self.log(f"💾 Exported linked file to: {dest_path}")
            QMessageBox.information(self, "Export Successful", f"Linked file saved successfully to:\n{dest_path}")

    def pick_excel_file(self, mode):
        """Open file dialog for Excel/CSV selection with sheet picker."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Excel or CSV File",
            self.download_dir,
            "Excel or CSV Files (*.xlsx *.xls *.csv);;Excel Files (*.xlsx *.xls);;CSV Files (*.csv)"
        )
        if path:
            from gui.qt_dialogs import SheetSelectorDialog

            def select_sheet(sheet):
                norm_path = os.path.normpath(path)
                filename = os.path.basename(norm_path)
                if mode == "voucher":
                    self.voucher_excel_file_path = norm_path
                    self.voucher_selected_sheet = sheet
                    if hasattr(self, "btn_voucher_excel") and self.btn_voucher_excel:
                        self.btn_voucher_excel.setText(f"✅ STEP 1: {filename} [{sheet}] (Click to Change)")
                        self.btn_voucher_excel.setStyleSheet("""
                            QPushButton {
                                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #10b981, stop:1 #059669);
                                color: #ffffff;
                                border: 2px solid #34d399;
                                border-radius: 10px;
                                font-weight: 800;
                                font-size: 12px;
                                padding: 8px 16px;
                            }
                            QPushButton:hover {
                                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #34d399, stop:1 #10b981);
                            }
                        """)
                    if hasattr(self, "lbl_voucher_excel") and self.lbl_voucher_excel:
                        self.lbl_voucher_excel.setText(f"✅ Voucher List Loaded: {filename} [{sheet}]")
                        self.lbl_voucher_excel.setStyleSheet("color: #34d399; font-size: 11px; font-weight: 700; background-color: rgba(52, 211, 153, 0.12); padding: 4px 8px; border-radius: 6px;")
                elif mode == "tally":
                    self.tally_excel_file_path = norm_path
                    self.tally_selected_sheet = sheet
                    self.lbl_tally_excel.setText(f"📄 {filename} [{sheet}]")
                    self.lbl_tally_excel.setStyleSheet("color: #00c9a7;")
                else:
                    self.paybill_excel_file_path = norm_path
                    self.paybill_selected_sheet = sheet
                    self.lbl_paybill_excel.setText(f"📄 {filename} [{sheet}]")
                    self.lbl_paybill_excel.setStyleSheet("color: #00c9a7;")

            if path.lower().endswith(".csv"):
                select_sheet("Default")
                return

            from openpyxl import load_workbook
            try:
                wb = load_workbook(path, read_only=True)
                sheets = wb.sheetnames
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load Excel sheets list:\n{e}")
                return

            if not sheets:
                QMessageBox.critical(self, "Error", "Workbook contains no sheets.")
                return

            dialog = SheetSelectorDialog(self, sheets)
            if dialog.exec() and dialog.result:
                select_sheet(dialog.result)

    def pick_pol_excel_file(self):
        """Open file dialog for POL Excel/CSV selection."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Excel or CSV File",
            self.download_dir,
            "Excel or CSV Files (*.xlsx *.xls *.csv);;Excel Files (*.xlsx *.xls);;CSV Files (*.csv)"
        )
        if path:
            from gui.qt_dialogs import SheetSelectorDialog

            def select_sheet(sheet):
                norm_path = os.path.normpath(path)
                filename = os.path.basename(norm_path)
                self.pol_excel_file_path = norm_path
                self.pol_selected_sheet = sheet
                self.lbl_pol_excel.setText(f"📄 {filename} [{sheet}]")
                self.lbl_pol_excel.setStyleSheet("color: #00c9a7;")

            if path.lower().endswith(".csv"):
                select_sheet("Default")
                return

            from openpyxl import load_workbook
            try:
                wb = load_workbook(path, read_only=True)
                sheets = wb.sheetnames
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load Excel sheets list:\n{e}")
                return

            if not sheets:
                QMessageBox.critical(self, "Error", "Workbook contains no sheets.")
                return

            dialog = SheetSelectorDialog(self, sheets)
            if dialog.exec() and dialog.result:
                select_sheet(dialog.result)

    # ─────────────────────────────────────────────
    # DATE VALIDATION
    # ─────────────────────────────────────────────

    def validate_date_string(self, date_str):
        match = re.match(r"^(\d{2})/(\d{2})/(\d{4})$", date_str)
        if not match:
            return False, "Date must be in format DD/MM/YYYY"
        day, month, year = int(match.group(1)), int(match.group(2)), int(match.group(3))
        if month < 1 or month > 12:
            return False, f"Invalid month: {month:02d} (must be 01-12)"
        if year < 1900 or year > 2100:
            return False, f"Invalid year: {year} (must be between 1900 and 2100)"
        days_in_months = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        is_leap = (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)
        if is_leap:
            days_in_months[2] = 29
        if day < 1 or day > days_in_months[month]:
            return False, f"Invalid day: {day:02d} for month {month:02d} in year {year}"
        return True, ""

    # ─────────────────────────────────────────────
    # TREASURY & DDO MANAGEMENT
    # ─────────────────────────────────────────────

    def resolve_treasury_key(self, name):
        name_clean = str(name).strip().upper()
        for key, val in TREASURY_IDS.items():
            code = key.split("-")[0].strip()
            if name_clean == code:
                return key
        m = re.match(r'^(\d+)', name_clean)
        if m:
            prefix = m.group(1)
            for key in TREASURY_IDS.keys():
                if key.startswith(prefix):
                    return key
        for key in TREASURY_IDS.keys():
            if name_clean in key.upper():
                return key
        return None

    def open_treasury_picker(self):
        from gui.qt_dialogs import TreasuryPickerDialog
        current_val = getattr(self, "current_treasuries", [self.current_treasury])
        dialog = TreasuryPickerDialog(self, TREASURY_IDS, current_val=current_val, multi_select=True)
        if dialog.exec() and dialog.selected_treasuries:
            self.set_pol_treasury(dialog.selected_treasuries)

    def open_date_picker(self, target_entry):
        from gui.qt_dialogs import DatePickerDialog
        dialog = DatePickerDialog(parent=self, target_entry=target_entry)
        dialog.exec()

    def set_pol_treasury(self, treasury):
        if isinstance(treasury, (list, tuple, set)):
            self.current_treasuries = list(treasury)
            if len(self.current_treasuries) == 1:
                self.current_treasury = self.current_treasuries[0]
                btn_text = self.current_treasury
            elif len(self.current_treasuries) == len(TREASURY_IDS):
                self.current_treasury = sorted(list(TREASURY_IDS.keys()))[0]
                btn_text = "All Treasuries"
            else:
                self.current_treasury = self.current_treasuries[0]
                btn_text = f"Selected ({len(self.current_treasuries)} Treasuries)"
        else:
            self.current_treasury = treasury
            self.current_treasuries = [treasury]
            btn_text = treasury

        if hasattr(self, 'btn_pol_treasury'):
            self.btn_pol_treasury.setText(btn_text)

        # Auto-detect CTB (054) and switch Bill Type to SNA
        tr_list = getattr(self, "current_treasuries", [self.current_treasury])
        is_ctb = any("054" in str(t) or "ctb" in str(t).lower() for t in tr_list)
        if is_ctb and hasattr(self, "pol_bill_dropdown") and self.pol_bill_dropdown:
            try:
                self.pol_bill_dropdown.set("SNA")
                self.log("ℹ️ CTB Treasury (054) selected. Automatically switched Bill Type to SNA.")
            except Exception: pass

        self.refresh_ddo_list(self.current_treasuries)

    def open_salary_treasury_picker(self):
        from gui.qt_dialogs import TreasuryPickerDialog
        current_val = self.current_treasury
        if hasattr(self, "var_salary_treasury") and self.var_salary_treasury.get():
            current_val = self.var_salary_treasury.get()
        dialog = TreasuryPickerDialog(self, TREASURY_IDS, current_val=current_val, multi_select=False)
        if dialog.exec() and dialog.selected_treasuries:
            selected = dialog.selected_treasuries[0] if isinstance(dialog.selected_treasuries, list) else dialog.selected_treasuries
            self.set_salary_treasury(selected)

    def set_salary_treasury(self, treasury):
        if hasattr(self, "var_salary_treasury"):
            self.var_salary_treasury.set(treasury)
        if hasattr(self, "btn_salary_treasury") and self.btn_salary_treasury:
            self.btn_salary_treasury.setText(treasury)

    def refresh_ddo_list(self, treasury):
        """Rebuild the DDO checklist for the given treasury (or list of treasuries) without freezing UI."""
        checked_ddos = set()
        if hasattr(self, "ddo_checkboxes") and self.ddo_checkboxes:
            checked_ddos = {ddo for ddo, var in self.ddo_checkboxes.items() if var.get()}

        # 1. Properly delete previous widgets from layout to prevent Qt layout lag
        if hasattr(self, 'checklist_layout') and self.checklist_layout:
            while self.checklist_layout.count():
                item = self.checklist_layout.takeAt(0)
                w = item.widget()
                if w:
                    w.deleteLater()

        self.ddo_checkboxes = {}
        self.ddo_widgets = {}

        if isinstance(treasury, (list, tuple, set)):
            treasuries = sorted(list(treasury))
        elif treasury == "All":
            treasuries = sorted(list(TREASURY_IDS.keys()))
        else:
            treasuries = [treasury]

        ddos = []
        self.ddo_to_treasury_map = {}
        for t_name in treasuries:
            official_t = self.resolve_treasury_key(t_name) or t_name
            prefix = ""
            if t_name:
                m = re.match(r"^(\d{3})", str(t_name))
                if m:
                    prefix = m.group(1) + "-"

            t_ddos = []
            if prefix:
                for k, v in DDO_DATABASE.items():
                    if k.startswith(prefix):
                        t_ddos = v
                        break
            if not t_ddos:
                t_ddos = DDO_DATABASE.get(t_name, [])

            for d in t_ddos:
                ddos.append(d)
                self.ddo_to_treasury_map[d] = official_t

        checklist_layout = getattr(self, 'checklist_layout', None)
        select_all_active = self.select_all_var.get()

        # 2. Populate memory data structure for ALL DDOs instantly (0.003s)
        for ddo in ddos:
            is_checked = (ddo in checked_ddos) or select_all_active
            var = TkVarCompat(value=is_checked)
            self.ddo_checkboxes[ddo] = var

        # 3. Create physical QCheckBox widgets in UI (cap at 600 for instant UI rendering)
        max_ui_widgets = 600
        render_ddos = ddos[:max_ui_widgets]

        for ddo in render_ddos:
            var = self.ddo_checkboxes[ddo]
            cb = QCheckBox(ddo)
            cb.setFont(QFont("Segoe UI", 11))
            cb.setChecked(var.get())
            var.bind_to_widget(cb)
            cb.stateChanged.connect(self.update_selected_count)
            self.ddo_widgets[ddo] = cb
            if checklist_layout:
                checklist_layout.addWidget(cb)

        if len(ddos) > max_ui_widgets and checklist_layout:
            info_lbl = QLabel(f"💡 Showing top {max_ui_widgets} DDOs out of {len(ddos):,} total. (Use search box above to filter any specific DDO)")
            info_lbl.setStyleSheet("color: #3b82f6; font-style: italic; font-size: 11px; padding: 4px;")
            checklist_layout.addWidget(info_lbl)

        self.update_selected_count()

    def toggle_all_ddos(self, state=None):
        state_val = self.select_all_var.get()
        for ddo, var in self.ddo_checkboxes.items():
            var.set(state_val)
            widget = self.ddo_widgets.get(ddo)
            if widget:
                widget.setChecked(state_val)
        self.update_selected_count()

    def filter_ddos(self, text=None):
        query = ""
        if hasattr(self, 'pol_search_entry'):
            query = self.pol_search_entry.text().strip().lower()

        if not query:
            for ddo, widget in self.ddo_widgets.items():
                widget.setVisible(True)
            return

        checklist_layout = getattr(self, 'checklist_layout', None)
        matches = [d for d in self.ddo_checkboxes.keys() if query in d.lower()][:300]
        for ddo in matches:
            if ddo not in self.ddo_widgets:
                var = self.ddo_checkboxes[ddo]
                cb = QCheckBox(ddo)
                cb.setFont(QFont("Segoe UI", 11))
                cb.setChecked(var.get())
                var.bind_to_widget(cb)
                cb.stateChanged.connect(self.update_selected_count)
                self.ddo_widgets[ddo] = cb
                if checklist_layout:
                    checklist_layout.addWidget(cb)

        for ddo, widget in self.ddo_widgets.items():
            if query in ddo.lower():
                widget.setVisible(True)
            else:
                widget.setVisible(False)

    def update_selected_count(self):
        selected_count = sum(1 for var in self.ddo_checkboxes.values() if var.get())
        if hasattr(self, 'lbl_pol_selected_count'):
            self.lbl_pol_selected_count.setText(f"({selected_count} selected)")

    def auto_check_ddos_from_excel(self, ddo_names):
        self.select_all_var.set(False)
        self.toggle_all_ddos()
        matched_count = 0
        for name in ddo_names:
            name_clean = str(name).strip().lower()
            for ddo_key, var in self.ddo_checkboxes.items():
                if name_clean in ddo_key.lower():
                    var.set(True)
                    matched_count += 1
                    break
        self.update_selected_count()
        self.log(f"🧠 Smart checklist mapper matched {matched_count} out of {len(ddo_names)} DDOs from Excel.")

    # ─────────────────────────────────────────────
    # DEVELOPER MODE TOGGLE
    # ─────────────────────────────────────────────

    def toggle_developer_mode(self, event=None):
        if not getattr(self, "dev_mode", False):
            # Prompt PIN dialog
            from PySide6.QtWidgets import QInputDialog, QLineEdit
            pin, ok = QInputDialog.getText(
                self, "Developer Authentication", "Enter Developer Security PIN:",
                QLineEdit.Password
            )
            if not ok or pin != "1991":
                QMessageBox.warning(self, "Unauthorized", "Incorrect Developer Security PIN.")
                return
            
            self.dev_mode = True
            
            # Auto-enable security overrides in memory
            self.var_auto_solve_captcha.set(True)
            self.var_direct_dashboard.set(True)
            self.log("🔓 Developer Overrides Active: Auto-Solve CAPTCHA & OTP Bypass enabled.")

            if hasattr(self, "opt_profile"):
                self.opt_profile.setVisible(True)
            if hasattr(self, "btn_save_profile"):
                self.btn_save_profile.setVisible(True)
            if hasattr(self, "btn_delete_profile"):
                self.btn_delete_profile.setVisible(True)

            # Add Developer Tab
            if hasattr(self, "tabview"):
                try:
                    dev_tab = QWidget()
                    self._build_developer_tab(dev_tab)
                    self.tabview.addTab(dev_tab, "🛠️ Developer")
                except Exception as e:
                    self.log(f"⚠️ Failed to add Developer tab: {e}")

            self.log("🔧 Developer Mode enabled. Profiles & Developer Tab unlocked.")
            QMessageBox.information(self, "Developer Mode",
                "Developer Mode Enabled: Saved Profiles & Developer Tab are now visible.")
        else:
            self.dev_mode = False
            # Auto-reset overrides to False
            self.var_auto_solve_captcha.set(False)
            self.var_direct_dashboard.set(False)
            self.log("🔒 Developer Security Overrides disabled and reset.")

            if hasattr(self, "opt_profile"):
                self.opt_profile.setVisible(False)
            if hasattr(self, "btn_save_profile"):
                self.btn_save_profile.setVisible(False)
            if hasattr(self, "btn_delete_profile"):
                self.btn_delete_profile.setVisible(False)

            # Remove Developer Tab
            if hasattr(self, "tabview"):
                for i in range(self.tabview.count()):
                    if "Developer" in self.tabview.tabText(i):
                        self.tabview.removeTab(i)
                        break

            self.log("🔒 Developer Mode disabled. Profiles & Developer Tab hidden.")
            QMessageBox.information(self, "Developer Mode",
                "Developer Mode Disabled: Developer options are hidden.")

    def open_cdp_devtools(self):
        """Query the active local debugging port and open Chrome DevTools inspector in system browser."""
        if not hasattr(self, "cdp_port") or not self.cdp_port:
            self.log("⚠️ No active browser with remote debugging port detected.")
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Inspector", "No active browser session with remote debugging port found.")
            return

        self.log(f"🌐 Querying DevTools targets on port {self.cdp_port}...")
        import urllib.request
        import json
        import webbrowser
        try:
            # Query the targets JSON from the local debugging port
            req = urllib.request.Request(f"http://127.0.0.1:{self.cdp_port}/json")
            with urllib.request.urlopen(req, timeout=3) as conn:
                targets = json.loads(conn.read().decode('utf-8'))
            
            # Find the first target that is the IFMIS app
            inspect_target = None
            for target in targets:
                url = target.get("url", "").lower()
                if "ifmis" in url or "mptreasury" in url or "login.jsp" in url:
                    inspect_target = target
                    break
            
            # Fallback to the first target of type 'page'
            if not inspect_target:
                for target in targets:
                    if target.get("type") == "page":
                        inspect_target = target
                        break
            
            if inspect_target and "devtoolsFrontendUrl" in inspect_target:
                dev_url = inspect_target["devtoolsFrontendUrl"]
                # Ensure correct domain prefix for relative frontend paths
                if dev_url.startswith("/"):
                    dev_url = f"http://127.0.0.1:{self.cdp_port}{dev_url}"
                elif not dev_url.startswith("http"):
                    ws_url = inspect_target.get("webSocketDebuggerUrl")
                    if ws_url:
                        ws_clean = ws_url.replace("ws://", "")
                        dev_url = f"https://chrome-devtools-frontend.appspot.com/serve_file/@78d2b2de04620f4c026027ab10b429d20c5d012e/inspector.html?ws={ws_clean}"
                
                self.log(f"🚀 Opening DevTools Inspector: {dev_url[:75]}...")
                webbrowser.open(dev_url)
            else:
                self.log(f"🚀 Opening target list page directly at http://127.0.0.1:{self.cdp_port}...")
                webbrowser.open(f"http://127.0.0.1:{self.cdp_port}")
                
        except Exception as e:
            self.log(f"⚠️ Failed to query DevTools targets: {e}. Opening fallback targets list page...")
            try:
                webbrowser.open(f"http://127.0.0.1:{self.cdp_port}")
            except Exception as we:
                self.log(f"❌ Failed to open fallback URL: {we}")

    # ─────────────────────────────────────────────
    # HEADER CONFIG MODAL
    # ─────────────────────────────────────────────

    def open_header_config_modal(self):
        from gui.qt_dialogs import HeaderConfigDialog
        dialog = HeaderConfigDialog(self, self)
        dialog.exec()

    # ─────────────────────────────────────────────
    # SOUND & NOTIFICATION HELPERS
    # ─────────────────────────────────────────────

    def play_sound(self, sound_type="asterisk"):
        if self.var_audio_alerts.get():
            try:
                import winsound
                if sound_type == "error":
                    winsound.MessageBeep(winsound.MB_ICONHAND)
                else:
                    winsound.MessageBeep(winsound.MB_OK)
            except Exception:
                pass

    def show_notification(self, title, message):
        if self.var_os_notifications.get():
            threading.Thread(
                target=lambda: self._show_toast(title, message),
                daemon=True
            ).start()

    def _show_toast(self, title, message):
        try:
            from plyer import notification
            notification.notify(title=title, message=message, timeout=5)
        except Exception:
            pass

    def send_telegram_alert(self, message):
        if not self.var_telegram_enabled.get():
            return
        token = self.var_telegram_token.get().strip()
        chat_id = self.var_telegram_chat_id.get().strip()
        if not token or not chat_id:
            self.log("⚠️ Telegram Bot Token or Chat ID not configured.")
            return

        def send_req():
            try:
                import urllib.request
                import urllib.parse
                clean_msg = f"🔔 *Centralized Voucher Validation Suite Alert* 🔔\n\n{message}"
                encoded_msg = urllib.parse.quote(clean_msg)
                url = f"https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={encoded_msg}&parse_mode=Markdown"
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                resp = urllib.request.urlopen(req, timeout=8)
                resp.read()
                self.log("✅ Telegram progress notification alert sent successfully.")
            except Exception as e:
                self.log(f"⚠️ Failed to send Telegram alert: {e}")

        threading.Thread(target=send_req, daemon=True).start()

    def bring_to_front(self):
        from PySide6.QtCore import QThread
        from PySide6.QtWidgets import QApplication
        if QThread.currentThread() != QApplication.instance().thread():
            self.safe_after(0, self.bring_to_front)
            return

        try:
            # Preserve current window state (maximized/fullscreen) — only restore if minimized
            from PySide6.QtCore import Qt as QtCoreQt
            if self.windowState() & QtCoreQt.WindowState.WindowMinimized:
                # Restore to whatever state it was in before being minimized
                self.setWindowState(self.windowState() & ~QtCoreQt.WindowState.WindowMinimized)
            self.activateWindow()
            self.raise_()
            
            import sys
            if sys.platform == 'win32':
                try:
                    import win32gui
                    hwnd = int(self.winId())
                    if win32gui.IsIconic(hwnd):
                        win32gui.ShowWindow(hwnd, 9)  # SW_RESTORE = 9
                    win32gui.SetForegroundWindow(hwnd)
                except Exception:
                    pass
        except Exception:
            pass


    # ─────────────────────────────────────────────
    # COMPATIBILITY SHIMS for backend code that
    # accesses CTk widget methods directly
    # ─────────────────────────────────────────────

    def select_dropdown(self, page, selector, code):
        """Playwright dropdown selection helper — no GUI dependency."""
        code = str(code).strip().upper()
        resolved_num = None
        if code in self.TREASURY_MAP:
            resolved_num = self.TREASURY_MAP[code]
        elif code in self.TREASURY_MAP.values():
            resolved_num = code
        else:
            resolved_key = self.resolve_treasury_key(code)
            if resolved_key:
                resolved_num = resolved_key.split("-")[0].strip()

        if not resolved_num:
            return False

        dropdown = page.locator(f"#{selector}")
        dropdown.wait_for(state="attached")
        try:
            page.wait_for_function(
                f"document.querySelectorAll('#{selector} option').length > 1",
                timeout=5000
            )
        except PlaywrightTimeoutError:
            return False

        for opt in dropdown.locator("option").all():
            if opt.inner_text().strip().startswith(resolved_num):
                dropdown.select_option(value=opt.get_attribute("value"))
                return True
        return False



    def _is_on_otp_page(self, page):
        try:
            current_url = page.url.lower()
            if "validatelogin" in current_url or "ifms.htm" in current_url:
                if "getuseridforotp" not in current_url:
                    return False
            otp_url_keywords = ['otp', 'verify', 'verification', 'twofactor', '2fa', 'mfa', 'authenticate']
            if any(keyword in current_url for keyword in otp_url_keywords):
                return True
            
            otp_input_selectors = [
                "input[name*='otp']", "input[name*='OTP']", "input[id*='otp']", "input[id*='OTP']",
                "input[placeholder*='OTP']", "input[placeholder*='otp']", "input[placeholder*='One Time']",
                "input[placeholder*='one time']", "input[placeholder*='Enter OTP']", "input[placeholder*='Enter code']",
                "input[type='tel'][maxlength='6']", "input[type='number'][maxlength='6']", "#txtOTP", "#otp",
                "#otpInput", "#verificationCode",
            ]
            for selector in otp_input_selectors:
                try:
                    if page.locator(selector).count() > 0: return True
                except Exception: pass
            
            try:
                page_text = page.inner_text("body").lower()
                otp_text_indicators = [
                    "enter otp", "enter the otp", "otp sent", "otp has been sent", "verification code",
                    "one time password", "one-time password", "enter verification code", "mobile verification",
                    "sms verification", "otp verification", "verify your mobile", "verify mobile number",
                ]
                if any(indicator in page_text for indicator in otp_text_indicators): return True
            except Exception: pass
            
            otp_button_selectors = [
                "button:has-text('Verify OTP')", "button:has-text('Submit OTP')", "button:has-text('Verify')",
                "input[value*='Verify OTP']", "input[value*='Submit OTP']", "a:has-text('Resend OTP')",
                "button:has-text('Resend OTP')",
            ]
            for selector in otp_button_selectors:
                try:
                    if page.locator(selector).count() > 0: return True
                except Exception: pass
            
            for frame in page.frames:
                try:
                    for selector in otp_input_selectors[:5]:
                        if frame.locator(selector).count() > 0: return True
                except Exception: pass
            return False
        except Exception: return False

    def _is_on_login_page(self, page):
        try:
            current_url = page.url.lower()
            if "validatelogin" in current_url or "ifms.htm" in current_url:
                if "getuseridforotp" not in current_url:
                    if "logout" not in current_url and "expired" not in current_url and "timeout" not in current_url:
                        return False
            if self._is_on_otp_page(page):
                return False
            
            # Check for standard login page and session expiry/logout keywords in URL
            login_url_indicators = [
                "login.jsp", "sessionexpired", "session_expired", "sessiontimeout", 
                "logout", "getuseridforotp", "login", "timeout", "signout", "expired"
            ]
            if any(indicator in current_url for indicator in login_url_indicators):
                # Ensure we don't treat the active validateLogin or ifms htm as login page
                if "validatelogin" in current_url or "ifms.htm" in current_url:
                    # Unless it specifically has an error message or logout keyword
                    if "logout" not in current_url and "expired" not in current_url and "timeout" not in current_url:
                        return False
                return True
            
            # If the username input field is present, we are definitely on the login page or logged out
            if page.locator("input[name='j_username']").count() > 0: return True
            if page.locator("input[name='j_password']").count() > 0: return True
            if page.locator("input[id*='username']").count() > 0: return True
            if page.locator("input[id*='password']").count() > 0: return True
            
            # Check for body text indicating session expiration or logout
            try:
                page_text = page.inner_text("body").lower()
                expired_indicators = [
                    "session expired", "session has expired", "session timeout", 
                    "logged out", "please login again", "re-login", "login again",
                    "always make proper logout", "proper logout", "logout.jsp"
                ]
                if any(ind in page_text for ind in expired_indicators):
                    return True
            except Exception:
                pass
                
            return False
        except Exception: return False

    def _is_logged_in(self, page):
        try:
            current_url = page.url.lower()
            if "logout.jsp" in current_url or "getuseridforotp" in current_url:
                return False

            if self._is_on_login_page(page):
                return False
            if self._is_on_otp_page(page):
                return False
                
            if "validatelogin" in current_url or "ifms.htm" in current_url:
                if "getuseridforotp" not in current_url and "login.jsp" not in current_url:
                    return True
                
            logged_in_selectors = [
                "a[href*='logout']", "text='Logout'", "text='Log Out'", "text='Sign Out'", "#logout", ".logout",
                "text='Welcome'", "text='Dashboard'", "text='Home'", "#menuContainer", "#mainMenu", ".main-menu",
                "nav", "#header", ".header", "text='Receipt'", "text='Disbursement'", "text='Reports'",
                "text='Administration'", "frame[name]",
            ]
            for selector in logged_in_selectors:
                try:
                    if page.locator(selector).count() > 0: return True
                except Exception: pass
            
            # Frame checks for nested portals
            if len(page.frames) > 1:
                return True
            for frame in page.frames:
                try:
                    for selector in logged_in_selectors[:12]:
                        if frame.locator(selector).count() > 0: return True
                except Exception: pass
                
            return False
        except Exception: return False


    # =========================================================
    # PORTED HELPER & AUTOMATION METHODS FROM ifmis_suite.py
    # =========================================================

    def safe_fill(self, page, selector, value):
        loc = page.locator(selector)
        loc.wait_for(state="visible")
        loc.fill(str(value))

    def get_locator_in_frames(self, p_page, selector):
        if p_page.locator(selector).count() > 0: return p_page.locator(selector).first
        for frame in p_page.frames:
            if frame.locator(selector).count() > 0: return frame.locator(selector).first
        return p_page.locator(selector).first

    def logout_session(self, page):
        if not page or page.is_closed(): return False
        self.log("🔓 Logging out from IFMS portal...")
        try:
            for selector in ["a[href*='logout']", "a:has-text('Logout')", "text='Logout'"]:
                try:
                    if page.locator(selector).count() > 0:
                        page.locator(selector).first.click(timeout=3000)
                        page.wait_for_load_state("networkidle", timeout=5000)
                        self.log("✅ Logged out successfully.")
                        return True
                except Exception: continue
            try:
                page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/logout", timeout=5000)
                self.log("✅ Logged out via direct URL.")
                return True
            except Exception: pass
            return False
        except Exception:
            return False

    def _cleanup_browser_session(self):
        """Safely closes active page, context, and browser instance to prevent window stacking."""
        try:
            if getattr(self, 'browser_page', None):
                try:
                    if not self.browser_page.is_closed():
                        self.browser_page.close()
                except Exception: pass
                self.browser_page = None

            if getattr(self, 'browser_context', None):
                try:
                    self.browser_context.close()
                except Exception: pass
                self.browser_context = None

            if getattr(self, 'browser', None):
                try:
                    if self.browser.is_connected():
                        self.browser.close()
                except Exception: pass
                self.browser = None

            if getattr(self, 'playwright', None):
                try:
                    self.playwright.stop()
                except Exception: pass
                self.playwright = None
        except Exception: pass

    def _perform_portal_login(self, page, context, username, password):
        state_file_path = os.path.join(self.base_path, "browser_state.json")
        
        # 1. Check if session is already valid
        self.log("🔍 Checking if existing session in browser_state.json is active...")
        if os.path.exists(state_file_path) and os.path.getsize(state_file_path) > 10:
            try:
                page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", wait_until="domcontentloaded", timeout=15000)
                if self._is_logged_in(page) and not self._is_on_login_page(page):
                    self.log("✅ Session active! Bypassing login completely.")
                    self._apply_stealth_mode_if_enabled()
                    self.safe_after(0, self.bring_to_front)
                    return page
                else:
                    self.log("ℹ️ Session expired or invalid. Proceeding to login...")
            except Exception as e:
                self.log(f"ℹ️ Session verify failed: {e}. Proceeding to login...")
        
        # Check if the page/browser is closed before proceeding to raw login
        is_closed = False
        try:
            is_closed = page.is_closed() or not context.browser or not context.browser.is_connected()
        except Exception:
            is_closed = True
            
        if is_closed:
            self.log("⚠️ Browser session crashed or closed during check. Clearing cookies/session state and re-launching...")
            if os.path.exists(state_file_path):
                try:
                    os.remove(state_file_path)
                    self.log("🧹 Cleared corrupted browser_state.json.")
                except Exception as de:
                    self.log(f"⚠️ Failed to delete browser_state.json: {de}")
            
            self._cleanup_browser_session()
            use_chrome = self.var_browser.get().startswith("Google Chrome")
            browser, self.browser_used = self._launch_browser_with_failover(use_chrome)
            
            context_args = {"accept_downloads": True}
            if use_chrome:
                context_args["no_viewport"] = True
            context_args = self.get_stealth_context_args(context_args)
            context = browser.new_context(**context_args)
            page = context.new_page()
            self.apply_webdriver_mask(page)
            self.browser = browser
            self.browser_context = context
            self.browser_page = page

        # 2. Call the raw login sequence
        res_page = None
        try:
            res_page = self._perform_portal_login_raw(page, context, username, password)
        except Exception as e:
            use_chrome_current = self.browser_used == "chromium" if getattr(self, "browser_used", None) else self.var_browser.get().startswith("Google Chrome")
            if not use_chrome_current:
                self.log(f"⚠️ Firefox login/connection failed: {e}. Automatically falling back to Google Chrome / Chromium...")
                self._cleanup_browser_session()
                use_chrome = True
                
                # Clear potentially corrupted session state
                if os.path.exists(state_file_path):
                    try:
                        os.remove(state_file_path)
                        self.log("🧹 Cleared session state file.")
                    except:
                        pass
                
                try:
                    browser, self.browser_used = self._launch_browser_with_failover(use_chrome)
                    context_args = {"accept_downloads": True, "no_viewport": True}
                    context_args = self.get_stealth_context_args(context_args)
                    context = browser.new_context(**context_args)
                    page = context.new_page()
                    self.apply_webdriver_mask(page)
                    self.browser = browser
                    self.browser_context = context
                    self.browser_page = page
                    
                    self.log("🔄 Retrying login sequence with Google Chrome / Chromium...")
                    res_page = self._perform_portal_login_raw(page, context, username, password)
                except Exception as fallback_err:
                    self.log(f"❌ Fallback Chrome login also failed: {fallback_err}")
                    raise fallback_err
            else:
                err_str = str(e).lower()
                if "closed" in err_str or "connection" in err_str or "detached" in err_str:
                    self.log(f"⚠️ Browser crashed or closed during login: {e}")
                    self._cleanup_browser_session()
                    
                    # If we were using Firefox, fall back to Chrome
                    use_chrome = self.var_browser.get().startswith("Google Chrome")
                    if not use_chrome:
                        self.log("🔄 Firefox was unstable. Falling back to Google Chrome / Chromium...")
                        use_chrome = True
                        
                    # Clear potentially corrupted session state
                    if os.path.exists(state_file_path):
                        try:
                            os.remove(state_file_path)
                            self.log("🧹 Cleared session state file.")
                        except:
                            pass
                    
                    browser, self.browser_used = self._launch_browser_with_failover(use_chrome)
                    context_args = {"accept_downloads": True}
                    if use_chrome:
                        context_args["no_viewport"] = True
                    context_args = self.get_stealth_context_args(context_args)
                    context = browser.new_context(**context_args)
                    page = context.new_page()
                    self.apply_webdriver_mask(page)
                    self.browser = browser
                    self.browser_context = context
                    self.browser_page = page
                    
                    self.log("🔄 Retrying login sequence with the fallback browser...")
                    res_page = self._perform_portal_login_raw(page, context, username, password)
                else:
                    raise e
        
        # 3. Save state on successful login
        if res_page:
            try:
                time.sleep(2) # Let cookies settle
                context.storage_state(path=state_file_path)
                self.log("💾 Session cookies saved successfully for future bypass.")
                self.safe_after(0, self.bring_to_front)
            except Exception as e:
                self.log(f"⚠️ Failed to save session state: {e}")
                
        return res_page

    def _solve_captcha_with_local_onnx(self, region_bytes):
        model_path = os.path.join(APP_DIR, "captcha_model.onnx")
        if not os.path.exists(model_path):
            return None
            
        try:
            import onnxruntime as ort
            import numpy as np
            from PIL import Image
            import io
            
            sess = ort.InferenceSession(model_path)
            input_name = sess.get_inputs()[0].name
            input_shape = sess.get_inputs()[0].shape
            
            img = Image.open(io.BytesIO(region_bytes))
            h, w, c = 60, 200, 1
            if len(input_shape) == 4:
                if input_shape[1] in [1, 3, 4]:
                    c = input_shape[1]
                    h = input_shape[2]
                    w = input_shape[3]
                    channels_first = True
                else:
                    h = input_shape[1]
                    w = input_shape[2]
                    c = input_shape[3]
                    channels_first = False
            else:
                channels_first = False
                
            img = img.resize((w, h))
            if c == 1:
                img = img.convert("L")
                img_np = np.array(img, dtype=np.float32) / 255.0
                img_np = np.expand_dims(img_np, axis=-1)
            else:
                img = img.convert("RGB")
                img_np = np.array(img, dtype=np.float32) / 255.0
                
            img_np = np.expand_dims(img_np, axis=0)
            if channels_first and c > 1:
                img_np = np.transpose(img_np, (0, 3, 1, 2))
                
            outputs = sess.run(None, {input_name: img_np})
            preds = outputs[0]
            
            # Simple argmax decoding placeholder (often CTC output)
            if len(preds.shape) == 3:
                if preds.shape[1] == 1:
                    best_path = np.argmax(preds, axis=-1).flatten()
                else:
                    best_path = np.argmax(preds, axis=-1)[0]
                
                # We need a char dict to decode. Since we don't have it, we just return the raw logits/argmax prediction
                # converted to string if the characters are printable or we log it.
                # If there's a character dictionary, the user will supply it. We log output shape.
                self.log(f"🤖 [Local CNN] Decoded argmax path: {best_path}. A character dict mapping is required.")
                return None
            else:
                # If the shape is [batch, num_classes] (unlikely for full text CAPTCHA, but possible for classification)
                best_class = np.argmax(preds, axis=-1)[0]
                self.log(f"🤖 [Local CNN] Best class index: {best_class}")
                return str(best_class)
        except Exception as e:
            self.log(f"⚠️ Local CNN captcha solver error: {e}")
            return None

    def _read_captcha_from_page(self, login_page):
        """Read the CAPTCHA value from the login page.
        
        The IFMS portal generates CAPTCHAs via JavaScript's createCaptcha()
        function, which draws random characters on a <canvas> element and
        stores the answer in a global JS variable called 'code'.
        We simply read window.code to get the exact answer instantly.
        
        Returns: (captcha_text: str or None, method: str)
        """
        # ── Strategy 1: Read the global JS variable 'code' directly ──
        try:
            captcha_text = login_page.evaluate("() => { try { return window.code || code; } catch(e) { return null; } }")
            if captcha_text and len(captcha_text) >= 4:
                self.log(f"🎯 CAPTCHA read from JS variable 'code': '{captcha_text}'")
                return captcha_text, "js_variable"
        except Exception as e:
            self.log(f"⚠️ JS variable read failed: {e}")
        
        # ── Strategy 2: Read CAPTCHA text from DOM text nodes near the input ──
        try:
            captcha_text = login_page.evaluate("""() => {
                const input = document.querySelector("input[name='cpatchaTextBox']")
                             || document.querySelector("input[id='cpatchaTextBox']")
                             || document.querySelector("input[name='captcha']")
                             || document.querySelector("input[placeholder*='captcha']")
                             || document.querySelector("input[placeholder*='Captcha']");
                if (!input) return null;
                
                const inputRect = input.getBoundingClientRect();
                const skipPrefixes = ['captch', 'login', 'submit', 'reset', 'passw', 'usern', 'forgot', 'ifmis', 'ifms', 'please', 'enter'];
                
                // Walk up the DOM tree to find a container holding the captcha text
                let container = input.parentElement;
                for (let level = 0; level < 8 && container; level++) {
                    const allElements = container.querySelectorAll('*');
                    for (const el of allElements) {
                        const tag = el.tagName.toUpperCase();
                        if (['INPUT', 'BUTTON', 'IMG', 'SCRIPT', 'STYLE', 'A', 'LABEL', 'CANVAS'].includes(tag)) continue;
                        
                        let directText = '';
                        for (const child of el.childNodes) {
                            if (child.nodeType === 3) directText += child.textContent;
                        }
                        directText = directText.trim();
                        
                        if (/^[A-Za-z0-9]{4,8}$/.test(directText)) {
                            const lower = directText.toLowerCase();
                            if (skipPrefixes.some(p => lower.startsWith(p))) continue;
                            return directText;
                        }
                    }
                    container = container.parentElement;
                }
                return null;
            }""")
            
            if captcha_text and len(captcha_text) >= 4:
                self.log(f"🎯 CAPTCHA text read from DOM: '{captcha_text}'")
                return captcha_text, "dom_text"
        except Exception as e:
            self.log(f"⚠️ DOM text reading failed: {e}")
        
        # ── Strategy 2: Find the CAPTCHA text element and screenshot it for OCR ──
        try:
            # Find the element that contains the captcha text visually
            captcha_el_info = login_page.evaluate("""() => {
                const input = document.querySelector("input[name='cpatchaTextBox']")
                             || document.querySelector("input[id='cpatchaTextBox']")
                             || document.querySelector("input[name='captcha']");
                if (!input) return null;
                
                const inputRect = input.getBoundingClientRect();
                
                // Look for elements near the input that might be the captcha display
                const allElements = document.querySelectorAll('span, div, td, font, b, i, em, strong, p');
                let best = null;
                let bestDist = 9999;
                
                for (const el of allElements) {
                    const rect = el.getBoundingClientRect();
                    if (rect.width < 30 || rect.height < 10) continue;
                    if (rect.width > 400 || rect.height > 200) continue;
                    
                    // Check if element has direct text that looks like a captcha
                    let directText = '';
                    for (const child of el.childNodes) {
                        if (child.nodeType === 3) directText += child.textContent;
                    }
                    directText = directText.trim();
                    if (!/[A-Za-z0-9]{3,}/.test(directText)) continue;
                    // Skip known labels
                    const lower = directText.toLowerCase();
                    if (['captcha', 'login', 'submit', 'reset'].includes(lower)) continue;
                    
                    // Distance from captcha input
                    const dist = Math.abs(rect.top - inputRect.top) + Math.abs(rect.left - inputRect.left);
                    if (dist < bestDist) {
                        bestDist = dist;
                        best = { text: directText, tag: el.tagName, x: rect.x, y: rect.y, w: rect.width, h: rect.height };
                    }
                }
                return best;
            }""")
            
            if captcha_el_info and captcha_el_info.get('text'):
                txt = captcha_el_info['text'].strip()
                import re
                match = re.search(r'[A-Za-z0-9]{4,8}', txt)
                if match:
                    captcha_text = match.group(0)
                    if captcha_text.lower() not in ["captcha", "login", "submit", "reset", "please", "enter", "code", "text"]:
                        self.log(f"🎯 CAPTCHA text found via proximity search: '{captcha_text}' (in <{captcha_el_info['tag']}> at {captcha_el_info['x']:.0f},{captcha_el_info['y']:.0f})")
                        return captcha_text, "dom_proximity"
        except Exception as e:
            self.log(f"⚠️ DOM proximity search failed: {e}")
        
        # ── Strategy 3: Screenshot the region around captcha input and use OCR ──
        try:
            captcha_input_loc = login_page.locator("input[name='cpatchaTextBox'], input[id='cpatchaTextBox'], input[name='captcha']").first
            box = captcha_input_loc.bounding_box()
            if box:
                # The captcha text is typically to the LEFT of the input field
                clip = {
                    'x': max(0, box['x'] - 200),
                    'y': max(0, box['y'] - 40),
                    'width': 200,
                    'height': 60
                }
                region_bytes = login_page.screenshot(clip=clip)
                
                # Save debug screenshot
                try:
                    debug_path = os.path.join(self.log_dir, "captcha_debug_region.png")
                    with open(debug_path, 'wb') as f:
                        f.write(region_bytes)
                    self.log(f"📸 Debug: Saved CAPTCHA region screenshot to {debug_path}")
                except Exception:
                    pass
                
                # Try local CNN model first!
                try:
                    local_val = self._solve_captcha_with_local_onnx(region_bytes)
                    if local_val:
                        return local_val, "local_cnn"
                except Exception as local_ex:
                    self.log(f"⚠️ Local CNN solver failed: {local_ex}")
                
                import ddddocr
                ocr = ddddocr.DdddOcr(show_ad=False)
                captcha_val = ocr.classification(region_bytes)
                if captcha_val:
                    captcha_val = captcha_val.strip()
                    self.log(f"🎯 CAPTCHA read via region OCR: '{captcha_val}'")
                    return captcha_val, "region_ocr"
        except Exception as e:
            if not isinstance(e, ImportError):
                self.log(f"⚠️ Region OCR fallback failed: {e}")
        
        return None, "none"

    def _perform_portal_login_raw(self, page, context, username, password):
        page.add_init_script("Object.defineProperty(window, 'opener', { get: () => ({}) });")
        self.log("Opening IFMS portal landing page...")
        try:
            page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/", wait_until="domcontentloaded", timeout=60000)
            page.wait_for_load_state("networkidle", timeout=15000)
        except PlaywrightTimeoutError:
            self.timeout_count += 1
            self.log("⚠️ Page load time limits exceeded - attempting takeover...")
        except Exception as e:
            self.log(f"❌ Portal Connection Failed: {e}")
            raise e

        # Check if we were automatically redirected to the dashboard (already logged in)
        try:
            if self._is_logged_in(page):
                self.log("✅ Detected active session (auto-redirect to dashboard)! Taking over download process...")
                self._apply_stealth_mode_if_enabled()
                return page
        except Exception:
            pass

        # Detect login page (could be the main page or a popup)
        login_page = None
        for _ in range(20):
            if self.stop_requested: return None
            for context_page in context.pages:
                try:
                    if context_page.locator("input[name='j_username']").count() > 0:
                        login_page = context_page
                        break
                except Exception: pass
            if login_page: break
            time.sleep(1)

        # If login or manual intervention is required, ensure browser window is visible
        if hasattr(self, "var_stealth") and self.var_stealth.get():
            self.set_browser_visibility(True)

        if not login_page:
            self.log("⚠️ Could not detect login fields. Please login manually in the browser window...")
            self.set_browser_visibility(True)
            self.bring_browser_to_front()
            login_page = page

        # Check if "User is already Logged-in" or "Always make proper logout" is visible
        is_locked = False
        try:
            body_txt = login_page.inner_text("body").lower() if login_page else ""
            if (login_page.locator("text='User is already Logged-in.'").count() > 0 or 
                login_page.locator("text='User is already Logged-in'").count() > 0 or 
                "user is already logged-in" in body_txt or
                "always make proper logout" in body_txt):
                is_locked = True
        except Exception:
            pass

        if is_locked:
            self.log("⚡ Portal notice detected ('User is already Logged-in' / 'Always make proper logout').")
            self.log("🔍 Testing direct dashboard access to verify active server session...")
            try:
                login_page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=getHomePage", timeout=15000, wait_until="domcontentloaded")
                login_page.wait_for_timeout(1000)
                if self._is_logged_in(login_page):
                    self.log("✅ Active server session verified! Bypassing login & reusing existing session.")
                    self._apply_stealth_mode_if_enabled()
                    return login_page
            except Exception:
                pass

            self.log("🧹 Executing instant forced server logout & clearing session state...")
            try:
                # 1. Click page logout links if present
                for selector in ["a:has-text('Logout')", "a:has-text('logout')", "input[value*='Logout']", "button:has-text('Logout')"]:
                    try:
                        if login_page.locator(selector).count() > 0:
                            login_page.locator(selector).first.click(timeout=3000)
                            login_page.wait_for_timeout(1000)
                            break
                    except Exception: pass

                # 2. Force hit IFMIS logout action endpoints to release server lock
                for logout_url in [
                    "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=logout",
                    "https://ifmisprod.mptreasury.gov.in/IFMS/login.jsp?actionFlag=logout",
                    "https://ifmisprod.mptreasury.gov.in/IFMS/logout.jsp"
                ]:
                    try:
                        login_page.goto(logout_url, timeout=15000, wait_until="domcontentloaded")
                        login_page.wait_for_timeout(1000)
                    except Exception: pass

                # 3. Clear browser cookies and stored state files
                try: context.clear_cookies()
                except Exception: pass

                for sf_name in ["browser_state.json", "session_state.json", "session_state.json.tmp"]:
                    st_path = os.path.join(self.base_path, sf_name)
                    if os.path.exists(st_path):
                        try: os.remove(st_path)
                        except Exception: pass

                self.log("✅ Server lock cleared! Re-navigating to fresh login landing page...")
                login_page.wait_for_timeout(1500)
                login_page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/", wait_until="domcontentloaded", timeout=45000)
                login_page.wait_for_timeout(1500)
            except Exception as unlock_err:
                self.log(f"⚠️ Session unlock procedure notice: {unlock_err}")

        # Fallback username & password to GUI inputs if missing or empty
        if not username and hasattr(self, "entry_user"):
            try: username = self.entry_user.text().strip()
            except Exception: pass
        if not password and hasattr(self, "entry_pass"):
            try: password = self.entry_pass.text().strip()
            except Exception: pass

        # Autofill credentials directly across main page & frames
        try:
            user_box = self.get_locator_in_frames(login_page, "input[name='j_username'], input[id*='username']")
            user_box.wait_for(state="visible", timeout=10000)
            if username:
                user_box.fill(username)

            pass_box = self.get_locator_in_frames(login_page, "input[name='j_password'], input[id*='password']")
            pass_box.wait_for(state="visible", timeout=5000)
            if password:
                pass_box.fill(password)
            self.log("✅ Credentials (User ID & Password) autofilled into login form.")
        except Exception as e:
            self.log(f"⚠️ Credential checking/filling notice: {e}")

        # Focus captcha input across main page & frames
        captcha_input = None
        try:
            captcha_input = self.get_locator_in_frames(login_page, "input[name='cpatchaTextBox'], input[id='cpatchaTextBox'], input[name='captcha'], input[placeholder*='captcha'], input[placeholder*='Captcha']")
            captcha_input.wait_for(state="visible", timeout=5000)
            captcha_input.click()
            captcha_input.focus()
        except Exception as fe:
            self.log(f"⚠️ Failed to focus on CAPTCHA field: {fe}")

        captcha_solved_via_dialog = False
        
        # Always attempt fast JS-variable CAPTCHA reading (or full auto-solve if enabled)
        if True:  # Attempt automatic CAPTCHA fill from JS variable or model
            self.log("🤖 Auto-Solve CAPTCHA is active. Reading CAPTCHA from page...")
            try:
                for attempt in range(1, 4):
                    if self.stop_requested: break
                    
                    time.sleep(0.5)  # Brief pause for page to settle
                    
                    # SMART CHECK: If we navigated away from login page already, stop!
                    if not self._is_on_login_page(login_page) or self._is_on_otp_page(login_page) or self._is_logged_in(login_page):
                        self.log("✅ Already moved past login page. Bypassing CAPTCHA auto-solve loop.")
                        captcha_solved_via_dialog = True
                        break
                    
                    captcha_val, method = self._read_captcha_from_page(login_page)
                    
                    if captcha_val:
                        # Clear and type the captcha (type() triggers onkeyup which calls enableSub)
                        try:
                            captcha_input.fill("")
                            captcha_input.evaluate("node => node.value = ''")
                        except Exception:
                            pass
                        
                        captcha_input.type(captcha_val, delay=50)
                        self.log(f"🤖 CAPTCHA auto-solved: '{captcha_val}' via {method} (Attempt {attempt}/3)")
                        
                        # Enable submit button and trigger login via JS
                        login_page.evaluate("""() => {
                            const btn = document.getElementById('bnSub');
                            if (btn) btn.disabled = false;
                            if (typeof startLogin === 'function') startLogin();
                            else if (btn) btn.click();
                        }""")
                        
                        # Poll to see if login succeeds or fails (up to 30 seconds for slow networks)
                        login_succeeded = False
                        session_locked = False
                        for poll in range(60): # 60 * 0.5s = 30s
                            if self.stop_requested: break
                            time.sleep(0.5)
                            
                            # Check for "User is already Logged-in" error (using faster evaluate to prevent blocks)
                            try:
                                body_text = login_page.evaluate("() => { try { return document.body ? document.body.innerText.toLowerCase() : ''; } catch(e) { return ''; } }")
                                if "user is already logged-in" in body_text or "already logged" in body_text:
                                    session_locked = True
                                    break
                            except Exception:
                                pass

                            # If we moved away from the login page, or arrived at OTP / dashboard, we succeeded!
                            if not self._is_on_login_page(login_page) or self._is_on_otp_page(login_page) or self._is_logged_in(login_page):
                                login_succeeded = True
                                break
                                
                            # Early exit if CAPTCHA regenerated (login failed)
                            try:
                                current_code = login_page.evaluate("() => { try { return window.code || code; } catch(e) { return null; } }")
                                if current_code and current_code != captcha_val:
                                    break
                            except Exception:
                                pass
                                
                        if login_succeeded:
                            captcha_solved_via_dialog = True
                            break
                        elif session_locked:
                            self.log("⚡ Portal session lock detected ('User is already Logged-in').")
                            self.log("🧹 Executing instant forced server logout & clearing session state...")
                            try:
                                for logout_url in [
                                    "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=logout",
                                    "https://ifmisprod.mptreasury.gov.in/IFMS/login.jsp?actionFlag=logout",
                                    "https://ifmisprod.mptreasury.gov.in/IFMS/logout.jsp"
                                ]:
                                    try:
                                        login_page.goto(logout_url, timeout=10000, wait_until="domcontentloaded")
                                        time.sleep(0.5)
                                    except Exception: pass

                                try: context.clear_cookies()
                                except Exception: pass

                                for sf_name in ["browser_state.json", "session_state.json", "session_state.json.tmp"]:
                                    st_path = os.path.join(self.base_path, sf_name)
                                    if os.path.exists(st_path):
                                        try: os.remove(st_path)
                                        except Exception: pass

                                self.log("✅ Server lock cleared! Re-navigating to fresh landing page...")
                                time.sleep(1)
                                login_page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/", wait_until="domcontentloaded", timeout=30000)
                                time.sleep(1)
                            except Exception as unlock_err:
                                self.log(f"⚠️ Session unlock notice: {unlock_err}")
                            continue
                        else:
                            self.log(f"⚠️ CAPTCHA '{captcha_val}' rejected or login failed. Retrying...")
                            
                            # Clear input field
                            try:
                                captcha_input.fill("")
                                captcha_input.evaluate("node => node.value = ''")
                            except Exception:
                                pass
                            
                            # Wait a moment for the page to regenerate a new captcha
                            time.sleep(1.5)
                    else:
                        self.log(f"⚠️ Could not read CAPTCHA text (attempt {attempt}/3). Retrying...")
                        time.sleep(1)
            except Exception as e:
                self.log(f"⚠️ CAPTCHA auto-solve failed/skipped: {e}")
                
        # Fallback to manual dialog prompt if auto-solve is disabled or failed
        if not captcha_solved_via_dialog and self.var_stealth.get():
            self.log("🕵️ Browser is hidden. Reading CAPTCHA for manual prompt...")
            try:
                captcha_val, method = self._read_captcha_from_page(login_page)
                
                if captcha_val and (method.startswith("dom") or method == "js_variable"):
                    # We already have the text — type it and submit
                    captcha_input.fill("")
                    captcha_input.type(captcha_val, delay=50)
                    self.log(f"🤖 CAPTCHA auto-filled: '{captcha_val}'")
                    login_page.evaluate("""() => {
                        const btn = document.getElementById('bnSub');
                        if (btn) btn.disabled = false;
                        if (typeof startLogin === 'function') startLogin();
                        else if (btn) btn.click();
                    }""")
                    captcha_solved_via_dialog = True
                else:
                    # Take a screenshot of the captcha region for manual input
                    captcha_region_bytes = None
                    try:
                        captcha_input_loc = login_page.locator("input[name='cpatchaTextBox'], input[id='cpatchaTextBox'], input[name='captcha']").first
                        box = captcha_input_loc.bounding_box()
                        if box:
                            clip = {
                                'x': max(0, box['x'] - 200),
                                'y': max(0, box['y'] - 50),
                                'width': 250,
                                'height': 70
                            }
                            captcha_region_bytes = login_page.screenshot(clip=clip)
                    except Exception:
                        pass
                    
                    if captcha_region_bytes:
                        import queue
                        q = queue.Queue()
                        def show_captcha():
                            dialog = CaptchaInputDialog(self, captcha_region_bytes)
                            q.put(dialog.result)
                        
                        self.after(0, show_captcha)
                        manual_val = q.get(timeout=60)
                        
                        if manual_val:
                            captcha_input.fill("")
                            captcha_input.type(manual_val, delay=50)
                            self.log(f"⌨️ Filled CAPTCHA code: {manual_val}")
                            login_page.evaluate("""() => {
                                const btn = document.getElementById('bnSub');
                                if (btn) btn.disabled = false;
                                if (typeof startLogin === 'function') startLogin();
                                else if (btn) btn.click();
                            }""")
                            captcha_solved_via_dialog = True
            except Exception as e:
                self.log(f"⚠️ Failed to prompt manual CAPTCHA dialog: {e}")

        if not captcha_solved_via_dialog:
            self.log("👉 Solve the CAPTCHA manually in the browser window...")
        
        self.log("⏳ Waiting for user login completion (Solve CAPTCHA + OTP)...")
        
        # Direct Dashboard Mode vs Complex State Tracker
        if self.var_direct_dashboard.get():
            self.log("ℹ️ Direct Dashboard Mode active. Polling for portal landing page directly...")
            while True:
                if self.stop_requested: return None
                
                # Check all pages and frames for dashboard
                for cp in context.pages:
                    try:
                        current_url = cp.url.lower()
                        # If we have logged in (we are on ifms.htm and not on login page, or _is_logged_in is True)
                        if ("ifms.htm" in current_url and "login.jsp" not in current_url) or self._is_logged_in(cp):
                            self.log(f"✅ Dashboard Detected (URL: {cp.url[:60]})! Taking over...")
                            self._apply_stealth_mode_if_enabled()
                            return cp
                            
                        # Search in page frames
                        for frame in cp.frames:
                            try:
                                frame_url = frame.url.lower()
                                if "ifms.htm" in frame_url and "login.jsp" not in frame_url:
                                    self.log(f"✅ Dashboard Detected in frame URL! Taking over...")
                                    self._apply_stealth_mode_if_enabled()
                                    return cp
                                if frame.locator("text='Welcome', text='Receipt', text='Disbursement', text='Logout'").count() > 0:
                                    self.log("✅ Dashboard Elements Detected in frame! Taking over...")
                                    self._apply_stealth_mode_if_enabled()
                                    return cp
                            except Exception: pass
                    except Exception: pass
                time.sleep(1)
        else:
            # Full OTP tracking flow
            otp_page_detected = False
            otp_message_shown = False
            login_page_message_shown = False
            last_status = None
            post_otp_wait_start = None
            POST_OTP_TIMEOUT = 30  # seconds to wait after OTP page disappears
            
            while True:
                if self.stop_requested: return None
                
                try:
                    # Scan all pages in the context to determine current state and handle redirects/popups
                    is_login = False
                    is_otp = False
                    is_logged_in = False
                    active_login_page = login_page
                    
                    # 1. Check if any page is logged in
                    for cp in context.pages:
                        try:
                            if self._is_logged_in(cp):
                                is_logged_in = True
                                active_login_page = cp
                                break
                        except Exception: pass
                    
                    # 2. Check if any page is on OTP screen (if not already logged in)
                    if not is_logged_in:
                        for cp in context.pages:
                            try:
                                if self._is_on_otp_page(cp):
                                    is_otp = True
                                    active_login_page = cp
                                    break
                            except Exception: pass
                    
                    # 3. Check if any page is on Login screen (if not logged in or on OTP)
                    if not is_logged_in and not is_otp:
                        for cp in context.pages:
                            try:
                                if self._is_on_login_page(cp):
                                    is_login = True
                                    active_login_page = cp
                                    break
                            except Exception: pass
                    
                    # Fallback status if none of the above matches
                    if is_login:
                        current_status = "login"
                    elif is_otp:
                        current_status = "otp"
                    elif is_logged_in:
                        current_status = "logged_in"
                    else:
                        current_status = "unknown"
                        # Fallback page reference
                        active_login_page = login_page
                    
                    # Cooldown lock check (only on login page)
                    if is_login:
                        try:
                            body_text = active_login_page.inner_text("body").lower()
                            if "user is already logged-in" in body_text or "already logged" in body_text:
                                self.log("⚡ Portal session lock detected ('User is already Logged-in').")
                                self.log("🧹 Executing instant forced server logout & clearing session state...")
                                for logout_url in [
                                    "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=logout",
                                    "https://ifmisprod.mptreasury.gov.in/IFMS/login.jsp?actionFlag=logout",
                                    "https://ifmisprod.mptreasury.gov.in/IFMS/logout.jsp"
                                ]:
                                    try:
                                        active_login_page.goto(logout_url, timeout=10000, wait_until="domcontentloaded")
                                        time.sleep(0.5)
                                    except Exception: pass

                                try: context.clear_cookies()
                                except Exception: pass

                                for sf_name in ["browser_state.json", "session_state.json", "session_state.json.tmp"]:
                                    st_path = os.path.join(self.base_path, sf_name)
                                    if os.path.exists(st_path):
                                        try: os.remove(st_path)
                                        except Exception: pass

                                self.log("✅ Server lock cleared! Re-navigating to fresh landing page...")
                                time.sleep(1)
                                active_login_page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/", wait_until="domcontentloaded", timeout=30000)
                                time.sleep(1)
                                continue
                        except Exception:
                            pass
                    
                    if current_status != last_status:
                        self.log(f"📍 Page Status: {current_status} | URL: {active_login_page.url[:65]}...")
                        
                        if current_status == "login" and not login_page_message_shown:
                            self.log("📋 On Login Page - Please enter CAPTCHA and click Login")
                            login_page_message_shown = True
                            post_otp_wait_start = None
                            
                        elif current_status == "otp":
                            if not otp_page_detected:
                                self.log("\n" + "🔔"*20)
                                self.log("📱 OTP PAGE DETECTED!")
                                self.log("👉 Please enter the OTP sent to your registered mobile")
                                self.log("👉 Tool will wait until OTP is verified...")
                                self.log("🔔"*20 + "\n")
                                otp_page_detected = True
                                otp_message_shown = True
                            post_otp_wait_start = None
                                
                        elif current_status == "logged_in":
                            if otp_page_detected:
                                self.log("✅ OTP Verified Successfully!")
                            self.log("✅ Login Complete! Taking over download process...")
                            self._apply_stealth_mode_if_enabled()
                            return active_login_page
                            
                        elif current_status == "unknown":
                            if otp_page_detected and post_otp_wait_start is None:
                                self.log("⏳ OTP submitted, waiting for page to load...")
                                post_otp_wait_start = time.time()
                                
                        last_status = current_status
                    
                    if is_otp:
                        time.sleep(1)
                        continue
                    
                    if is_logged_in:
                        if otp_page_detected:
                            self.log("✅ OTP Verified Successfully!")
                        self.log("✅ Login Complete! Taking over download process...")
                        self._apply_stealth_mode_if_enabled()
                        return active_login_page
                    
                    if otp_page_detected and current_status == "unknown":
                        if post_otp_wait_start is None:
                            post_otp_wait_start = time.time()
                        elapsed = time.time() - post_otp_wait_start
                        try: active_login_page.wait_for_load_state("networkidle", timeout=2000)
                        except: pass
                        
                        if self._is_logged_in(active_login_page):
                            self.log("✅ OTP Verified Successfully!")
                            self.log("✅ Login Complete! Taking over download process...")
                            self._apply_stealth_mode_if_enabled()
                            return active_login_page
                        
                        if elapsed > POST_OTP_TIMEOUT:
                            self.log(f"⏱️ Timeout after {POST_OTP_TIMEOUT}s - assuming login successful")
                            self.log("✅ Proceeding with download process...")
                            self._apply_stealth_mode_if_enabled()
                            return active_login_page
                        
                        if int(elapsed) % 5 == 0 and int(elapsed) > 0:
                            remaining = POST_OTP_TIMEOUT - int(elapsed)
                            self.log(f"⏳ Waiting for page... ({remaining}s remaining)")
                    
                except Exception as e:
                    self.log(f"⚠️ Login detection warning: {str(e)[:60]}")
                time.sleep(1)

    # =========================================================
    # PORTED REMAINING METHODS FROM ifmis_suite.py
    # =========================================================



    def _run_ddo_update(self, username, password):
        from automation.browser_factory import _launch_browser_with_failover
        from playwright.sync_api import sync_playwright
        use_chrome = self.var_browser.get().startswith("Google Chrome")
        
        self._cleanup_browser_session()

        self.log(f"🌐 Launching Playwright browser interface for DDO update...")
        if not self.playwright:
            self.playwright = sync_playwright().start()

        try:
            browser, self.browser_used = self._launch_browser_with_failover(use_chrome)
        except Exception as e:
            self.log(f"❌ Critical Error: {e}")
            self.safe_after(0, lambda: self.set_ui_lock_state(is_locked=False))
            return

        state_file_path = os.path.join(self.base_path, "browser_state.json")
        if os.path.exists(state_file_path):
            try:
                file_age = time.time() - os.path.getmtime(state_file_path)
                if file_age > 900: # 15 minutes
                    self.log(f"🧹 Stale browser session detected (modified {int(file_age/60)}m ago). Clearing browser_state.json to prevent double-launch...")
                    os.remove(state_file_path)
            except Exception as e:
                self.log(f"⚠️ Warning: Could not clean stale browser_state.json: {e}")
                
        context_args = {"accept_downloads": True}
        if use_chrome:
            context_args["no_viewport"] = True
        if os.path.exists(state_file_path) and os.path.getsize(state_file_path) > 10:
            context_args["storage_state"] = state_file_path
        context_args = self.get_stealth_context_args(context_args)
        context = browser.new_context(**context_args)
        page = context.new_page()
        self.apply_webdriver_mask(page)

        self.browser = browser
        self.browser_context = context
        self.browser_page = page

        try:
            logged_in_page = self._perform_portal_login(page, context, username, password)
            if not logged_in_page:
                self._cleanup_browser_session()
                self.safe_after(0, lambda: self.set_ui_lock_state(is_locked=False))
                return
            page = logged_in_page
            self.browser_page = page

            self.log("⏳ Navigating directly to report parameters page...")
            self.resilient_goto(page, "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-paymentOrderListForAG&elementId=10072358", base_timeout=60000)
            try: page.wait_for_load_state("networkidle", timeout=10000)
            except Exception: pass

            save_paths = []
            save_paths.append(os.path.join(APP_DIR, "ddo.txt"))
            
            dev_path = os.path.expanduser(r"~\.gemini\antigravity\scratch\IFMIS_Suite\ddo.txt")
            if os.path.exists(os.path.dirname(dev_path)) and dev_path not in save_paths:
                save_paths.append(dev_path)

            self.log(f"✍️ Updating DDO database at: {', '.join(save_paths)}")

            total_treasuries = len(TREASURY_IDS)
            ddo_buffer = []

            for idx, (t_name, t_val) in enumerate(TREASURY_IDS.items(), 1):
                if self.stop_requested: break
                
                self.log(f"🔎 [{idx}/{total_treasuries}] Fetching DDOs for: {t_name}")
                self.update_stats(current=f"Updating {t_name}", progress=(idx / total_treasuries))
                
                try:
                    page.select_option("#tsryList", value=t_val)
                    page.wait_for_timeout(3000)
                    
                    ddo_options = page.locator("#ddoCode option").all()
                    ddo_list = []
                    for opt in ddo_options:
                        val = opt.get_attribute("value")
                        txt = opt.inner_text().strip()
                        if val != "-1" and txt:
                            ddo_list.append(txt)
                    
                    ddo_buffer.append(f"=== {t_name} ===\n")
                    if not ddo_list:
                        ddo_buffer.append("No DDOs found or failed to load.\n")
                    else:
                        for ddo in ddo_list:
                            ddo_buffer.append(f"{ddo}\n")
                    ddo_buffer.append("\n")
                    
                    self.log(f"  Successfully found {len(ddo_list)} DDOs.")
                    
                except Exception as e:
                    self.log(f"  ❌ Error fetching {t_name}: {str(e)[:80]}")
                    ddo_buffer.append(f"=== {t_name} ===\nError fetching DDOs.\n\n")

            if not self.stop_requested and ddo_buffer:
                for spath in save_paths:
                    try:
                        with open(spath, "w", encoding="utf-8") as f:
                            f.writelines(ddo_buffer)
                        self.log(f"✅ Successfully wrote database to: {spath}")
                    except Exception as e:
                        self.log(f"⚠️ Failed to write to {spath}: {e}")

                self.log("🎯 DDO list database update complete!")
                self.safe_after(0, self.refresh_ddo_list, self.current_treasury)
                
            self._cleanup_browser_session()

        except Exception as e:
            self.log(f"❌ DDO Update Thread failed: {e}")
            self._cleanup_browser_session()
        finally:
            self.stop_requested = False
            self.safe_after(0, lambda: self.set_ui_lock_state(is_locked=False))
            self.safe_after(0, lambda: self.update_stats(current="Idle", progress=1.0))



    def reauthenticate_portal(self, username, password, state_file, pause_event):
        """
        Attempts background headless session renewal using stored credentials first.
        If it reaches OTP or fails, it falls back to the main headful browser
        window and guides the user through manual re-authentication.
        """
        from PySide6.QtCore import QThread
        from PySide6.QtWidgets import QApplication
        
        # Guarantee execution on Main GUI Thread (where Playwright/Greenlet was initialized)
        if QApplication.instance() and QThread.currentThread() != QApplication.instance().thread():
            import threading
            done_evt = threading.Event()
            result = [False]
            
            def _runner():
                try:
                    result[0] = self.reauthenticate_portal(username, password, state_file, pause_event)
                except Exception as ex:
                    self.log(f"⚠️ Re-authentication main thread exception: {ex}")
                    result[0] = False
                finally:
                    done_evt.set()
                    
            self.safe_after(0, _runner)
            done_evt.wait(timeout=180)
            return result[0]

        import threading
        if not hasattr(self, "_reauth_lock"):
            self._reauth_lock = threading.Lock()

        # Single-flight guard: If re-authentication is ALREADY running in another thread, wait for it!
        if getattr(self, "_is_reauthenticating", False):
            self.log("⏳ Re-authentication already in progress in another thread. Waiting for session renewal...")
            while getattr(self, "_is_reauthenticating", False):
                if getattr(self, "stop_requested", False):
                    return False
                time.sleep(0.5)
            return not getattr(self, "_session_expired_event_hit", False)

        with self._reauth_lock:
            self._is_reauthenticating = True
            try:
                if not pause_event.is_set():
                    pause_event.set()
        
                self.log("🔑 Re-authentication required: Portal session expired or server disconnect. Pausing background workers...")
                self.update_session_indicator("reauthenticating")
        
                # 1. Attempt Headless Auto-Renewal in background
                self.log("🤖 Attempting background headless session renewal...")
                headless_success = False
                headless_browser = None
                headless_context = None
        
                try:
                    # Check portal health first
                    is_healthy, health_msg = self.verify_portal_and_network_health()
                    if is_healthy:
                        if not getattr(self, "playwright", None):
                            from playwright.sync_api import sync_playwright
                            self.playwright = sync_playwright().start()
                
                        use_chrome = self.var_browser.get().startswith("Google Chrome")
                        browser_name = "chromium" if use_chrome else "firefox"
                
                        # Setup kwargs for headless launch
                        kwargs = {"headless": True}
                        if not use_chrome:
                            kwargs["firefox_user_prefs"] = {
                                "network.trr.mode": 5,
                                "network.dns.disableIPv6": True,
                                "widget.windows.window_occlusion_tracking.enabled": False,
                                "dom.min_background_timeout_value": 10000,
                                "privacy.reduceTimerPrecision": False,
                                "network.proxy.type": 5,
                                "network.proxy.no_proxies_on": "localhost, 127.0.0.1, .mptreasury.gov.in, mptreasury.gov.in"
                            }
                        else:
                            kwargs["args"] = [
                                "--no-first-run",
                                "--no-default-browser-check",
                                "--disable-backgrounding-occluded-windows",
                                "--disable-background-timer-throttling",
                                "--disable-renderer-backgrounding",
                                "--disable-background-networking"
                            ]
# Use bundled Playwright Chromium from pw-browsers
                                
                        self.log(f"🌐 Launching headless browser ({browser_name.capitalize()}) for background renewal...")
                        launcher = getattr(self.playwright, browser_name)
                        headless_browser = launcher.launch(**kwargs)
                
                        context_args = self.get_stealth_context_args({
                            "accept_downloads": True,
                            "user_agent": getattr(self, "main_user_agent", None)
                        })
                        headless_context = headless_browser.new_context(**context_args)
                        headless_page = headless_context.new_page()
                        self.apply_webdriver_mask(headless_page)
                
                        # Navigate to Approved Bills page
                        self.resilient_goto(headless_page, "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", base_timeout=45000)
                
                        if self._is_on_login_page(headless_page):
                            self.log("🤖 Headless context is on login page. Performing auto-login...")
                            # Perform portal login raw
                            logged_in_page = self._perform_portal_login_raw(headless_page, headless_context, username, password)
                    
                            if logged_in_page:
                                # Check if it requires OTP
                                if self._is_on_otp_page(logged_in_page) or not self._is_logged_in(logged_in_page):
                                    self.log("⚠️ Headless renewal reached OTP page or is not fully logged in. OTP verification required.")
                                else:
                                    # Success! Headless session logged in successfully!
                                    self.log("🎉 Headless background login successful! Saving session state...")
                                    headless_context.storage_state(path=state_file)
                                    # Also save it to browser_state.json if it exists
                                    state_file_path = os.path.join(self.base_path, "browser_state.json")
                                    try:
                                        headless_context.storage_state(path=state_file_path)
                                    except Exception:
                                        pass
                            
                                    # Transfer storage state to the main headful browser context if it is active!
                                    if hasattr(self, "browser_context") and self.browser_context:
                                        try:
                                            import json
                                            if os.path.exists(state_file_path):
                                                with open(state_file_path, "r", encoding="utf-8") as f:
                                                    state_data = json.load(f)
                                                cookies = state_data.get("cookies", [])
                                                if cookies:
                                                    self.browser_context.add_cookies(cookies)
                                                    self.log("🤖 Synchronized new session cookies to active browser context.")
                                        except Exception as cookie_err:
                                            self.log(f"⚠️ Failed to sync cookies to main browser context: {cookie_err}")
                                    
                                    headless_success = True
                        else:
                            # Already logged in in this headless context?
                            if self._is_logged_in(headless_page):
                                self.log("🎉 Headless context is already logged in! Saving state...")
                                headless_context.storage_state(path=state_file)
                                state_file_path = os.path.join(self.base_path, "browser_state.json")
                                try:
                                    headless_context.storage_state(path=state_file_path)
                                except Exception: pass
                                headless_success = True
                    else:
                        self.log(f"⚠️ Portal network health check failed during headless renewal: {health_msg}")
                except Exception as headless_err:
                    self.log(f"⚠️ Headless background auto-renewal failed: {headless_err}")
                finally:
                    # Clean up headless browser
                    if headless_context:
                        try: headless_context.close()
                        except Exception: pass
                    if headless_browser:
                        try: headless_browser.close()
                        except Exception: pass
                
                if headless_success:
                    self.log("✅ Headless session auto-renewal completed successfully! Resuming active download queues...")
                    pause_event.clear()
                    # If main page exists, let's reload it so it picks up the new logged in session
                    if hasattr(self, "browser_page") and self.browser_page and not self.browser_page.is_closed():
                        try:
                            self.browser_page.goto("https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", wait_until="domcontentloaded", timeout=30000)
                        except Exception:
                            pass
                    return True
            
                # 2. Fallback to Headful/Main Browser Window if headless renewal failed or OTP is required
                self.log("⚠️ Background headless renewal could not complete. Falling back to headful browser window...")
        
                # Bring main browser window to foreground
                self.set_browser_visibility(True)
                self.bring_browser_to_front()
        
                # Display warning to user
                self.play_sound("exclamation")
                self.show_notification("IFMS Session Expired", "Please re-authenticate in the browser window.")
        
                start_time = time.time()
                max_duration = 7200  # 2 hours
                attempt_no = 0
        
                while time.time() - start_time < max_duration:
                    if self.stop_requested:
                        self.log("⚠️ Re-authentication cancelled due to Stop request.")
                        return False
                
                    attempt_no += 1
                    self.log(f"🔄 Re-authentication Attempt {attempt_no}...")
            
                    # Check portal health first
                    is_healthy, health_msg = self.verify_portal_and_network_health()
                    if not is_healthy:
                        self.log(f"⚠️ Portal or Network Health Check FAILED: {health_msg}")
                        self.log("⏳ Advanced Self-Healing Supervisor: Waiting 60 seconds before retrying...")
                
                        for _ in range(60):
                            if self.stop_requested:
                                return False
                            time.sleep(1)
                        continue
                
                    self.log(f"🟢 Portal and Network Health Check PASSED: {health_msg}")
            
                    try:
                        page = self.browser_page
                        context = self.browser_context
                
                        if not page or page.is_closed():
                            self.log("⚠️ Browser page was closed. Recreating page...")
                            if not self.browser or not self.browser.is_connected():
                                self.log("⚠️ Browser process is dead. Attempting to launch new browser...")
                                use_chrome = self.var_browser.get().startswith("Google Chrome")
                                self.browser, self.browser_used = self._launch_browser_with_failover_headless(self.playwright, use_chrome)
                            context_args = self.get_stealth_context_args({
                                "accept_downloads": True,
                                "user_agent": getattr(self, "main_user_agent", None)
                            })
                            self.browser_context = self.browser.new_context(**context_args)
                            self.browser_page = self.browser_context.new_page()
                            self.apply_webdriver_mask(self.browser_page)
                            page = self.browser_page
                            context = self.browser_context
                
                        # Navigate to approved bills page (will redirect to login if session expired)
                        self.resilient_goto(page, "https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=rnd-toApprovedBillsTreasuryWise", base_timeout=45000)
                
                        # Check if login is needed
                        if self._is_on_login_page(page):
                            self.log("🔑 Session is indeed expired. Prompting automated OTP bypass login...")
                            logged_in_page = self._perform_portal_login(page, context, username, password)
                            if logged_in_page:
                                page = logged_in_page
                                context = self.browser_context
                                self.browser_page = page
                
                        # Wait for user to bypass OTP if needed
                        if self._is_on_otp_page(page) or not self._is_logged_in(page):
                            self.log("⏳ Awaiting OTP completion on main browser window...")
                            while self._is_on_otp_page(page) or not self._is_logged_in(page):
                                if self.stop_requested:
                                    return False
                                time.sleep(1)
                
                        # Success!
                        self._session_expired_event_hit = False
                        self.update_session_indicator("active")
                        context.storage_state(path=state_file)
                        self.log("✅ Re-authentication successful! Resuming active download queues...")
                
                        # Hide the window if settings dictate
                        if not self.var_show_workers.get() and not self.var_headful_monitor.get():
                            self.set_browser_visibility(False)
                    
                        pause_event.clear()
                        return True
                
                    except Exception as e:
                        self.log(f"⚠️ Re-authentication attempt {attempt_no} encountered error: {e}")
                        self.log("⏳ Waiting 60 seconds before supervisor retries...")
                        for _ in range(60):
                            if self.stop_requested:
                                return False
                            time.sleep(1)
                    
                self.log("❌ Advanced Self-Healing Supervisor: Re-authentication timed out after 2 hours.")
                self._session_expired_event_hit = True
                self.update_session_indicator("expired")
                return False



            finally:
                self._is_reauthenticating = False
    def dev_reset_folder_and_db_cache(self):
        mode = "voucher"
        if hasattr(self, "tabview") and self.tabview.get() == "💼 Paybills":
            mode = "paybill"

        excel_path = self.voucher_excel_file_path if mode == "voucher" else self.paybill_excel_file_path
        if not excel_path:
            messagebox.showerror("Error", "Please select an Excel sheet first to determine the target folder.")
            return

        ans = messagebox.askyesno("Confirm Reset", "Are you sure you want to delete all SUCCESS.marker files in the current download folder AND clear their records from the database?")
        if not ans: return

        try:
            marker_count = 0
            rows = self.parse_excel_sheet(excel_path, mode)

            db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
            import sqlite3
            conn = sqlite3.connect(db_path, timeout=10.0)
            cursor = conn.cursor()

            for row in rows:
                target_dir = self.resolve_download_path(row, "Voucher" if mode == "voucher" else "Paybill")
                marker_file = os.path.join(target_dir, "SUCCESS.marker")
                if os.path.exists(marker_file):
                    try:
                        os.remove(marker_file)
                        marker_count += 1
                    except Exception: pass

                tr = str(row.get('treasury', '')).strip()
                mh = str(row.get('mh', '')).strip()
                mo = str(row.get('month', '')).strip()
                try: yr = int(row.get('year'))
                except: yr = None
                vo = str(row.get('voucher', '')).strip()

                cursor.execute("""
                    DELETE FROM downloads
                    WHERE treasury = ? AND major_head = ? AND month = ? AND year = ? AND voucher_no = ?
                """, (tr, mh, mo, yr, vo))

            conn.commit()
            conn.close()

            self.log(f"🧹 Developer Reset: Cleared {marker_count} SUCCESS.marker files and database records.")
            messagebox.showinfo("Reset Complete", f"Successfully cleared {marker_count} SUCCESS.marker files and database records.")
        except Exception as e:
            self.log(f"❌ Developer Reset failed: {e}")
            messagebox.showerror("Error", f"Failed to reset: {e}")



    def dev_prune_incomplete_folders(self):
        mode = "voucher"
        if hasattr(self, "tabview") and self.tabview.get() == "💼 Paybills":
            mode = "paybill"

        excel_path = self.voucher_excel_file_path if mode == "voucher" else self.paybill_excel_file_path
        if not excel_path:
            messagebox.showerror("Error", "Please select an Excel sheet first to determine the target folder.")
            return

        ans = messagebox.askyesno("Confirm Prune", "Are you sure you want to delete all folders inside the active output folder that do not contain a SUCCESS.marker file?")
        if not ans: return

        try:
            rows = self.parse_excel_sheet(excel_path, mode)
            pruned_count = 0

            for row in rows:
                target_dir = self.resolve_download_path(row, "Voucher" if mode == "voucher" else "Paybill")
                if os.path.exists(target_dir):
                    marker_file = os.path.join(target_dir, "SUCCESS.marker")
                    if not os.path.exists(marker_file):
                        import shutil
                        try:
                            shutil.rmtree(target_dir, ignore_errors=True)
                            pruned_count += 1
                        except Exception: pass

            self.log(f"🧹 Developer Prune: Deleted {pruned_count} incomplete folders (missing SUCCESS.marker).")
            messagebox.showinfo("Prune Complete", f"Successfully deleted {pruned_count} incomplete folders.")
        except Exception as e:
            self.log(f"❌ Developer Prune failed: {e}")
            messagebox.showerror("Error", f"Failed to prune: {e}")

    def auto_prune_stale_temp_files(self):
        """
        Background maintenance task: silently prunes temporary download artifacts
        (.tmp, .crdownload, .download, .pdf.tmp) and orphaned Playwright profile folders older than 24 hours.
        """
        import time, tempfile, shutil
        now = time.time()
        max_age_sec = 24 * 3600 # 24 hours
        pruned_files = 0
        pruned_bytes = 0

        temp_dir = tempfile.gettempdir()
        target_dirs = [temp_dir, getattr(self, "base_path", ".")]

        for tdir in target_dirs:
            if not os.path.exists(tdir):
                continue
            try:
                for root, dirs, files in os.walk(tdir):
                    # Clean temporary files older than 24 hours
                    for fname in files:
                        l_name = fname.lower()
                        if l_name.endswith(('.tmp', '.crdownload', '.download', '.pdf.tmp')) or l_name.startswith('session_state.json.tmp'):
                            fpath = os.path.join(root, fname)
                            try:
                                if os.path.exists(fpath):
                                    mtime = os.path.getmtime(fpath)
                                    if now - mtime > max_age_sec:
                                        sz = os.path.getsize(fpath)
                                        os.remove(fpath)
                                        pruned_files += 1
                                        pruned_bytes += sz
                            except Exception:
                                pass

                    # Clean orphaned Playwright profile directories older than 24 hours
                    for dname in list(dirs):
                        l_dname = dname.lower()
                        if l_dname.startswith(('chromium_user_data_worker_', 'pw_profile_')) or 'playwright_tmp' in l_dname:
                            dpath = os.path.join(root, dname)
                            try:
                                if os.path.exists(dpath):
                                    mtime = os.path.getmtime(dpath)
                                    if now - mtime > max_age_sec:
                                        shutil.rmtree(dpath, ignore_errors=True)
                                        pruned_files += 1
                            except Exception:
                                pass
            except Exception:
                pass

        if pruned_files > 0:
            mb = pruned_bytes / (1024 * 1024)
            self.log(f"🧹 Auto-Maintenance: Pruned {pruned_files} stale temporary artifacts ({mb:.1f} MB freed).")



    def dev_open_active_folder(self):
        mode = "voucher"
        if hasattr(self, "tabview") and self.tabview.get() == "💼 Paybills":
            mode = "paybill"

        excel_path = self.voucher_excel_file_path if mode == "voucher" else self.paybill_excel_file_path
        folder = self.download_dir
        if excel_path:
            try:
                rows = self.parse_excel_sheet(excel_path, mode)
                if rows:
                    folder = os.path.dirname(self.resolve_download_path(rows[0], "Voucher" if mode == "voucher" else "Paybill"))
            except Exception:
                pass

        if os.path.exists(folder):
            try:
                os.startfile(folder)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open folder: {e}")
        else:
            messagebox.showerror("Error", "Download folder does not exist yet.")



    def dev_manual_zip_archive(self):
        mode = "voucher"
        if hasattr(self, "tabview") and self.tabview.get() == "💼 Paybills":
            mode = "paybill"

        ans = messagebox.askyesno("Confirm ZIP", f"Do you want to manually pack all completed downloads in the {mode.upper()} output folder into a ZIP archive right now?")
        if not ans: return

        self.log(f"📦 Manual ZIP Triggered for {mode}...")
        try:
            self._post_process(mode)
            messagebox.showinfo("ZIP Archive Created", "Manual ZIP packaging finished successfully.")
        except Exception as e:
            self.log(f"❌ Manual ZIP failed: {e}")
            messagebox.showerror("Error", f"Failed to zip: {e}")



    def dev_wipe_browser_profiles(self):
        ans = messagebox.askyesno("Confirm Wipe", "This will delete browser_state.json and clean local session cookies/storage. Proceed?")
        if not ans: return

        try:
            state_file = os.path.join(self.base_path, "browser_state.json")
            if os.path.exists(state_file):
                os.remove(state_file)
            self.log("🧹 Browser session states wiped successfully.")
            messagebox.showinfo("Success", "Browser session states cleared.")
        except Exception as e:
            self.log(f"❌ Failed to clear browser state: {e}")
            messagebox.showerror("Error", f"Failed to clear browser state: {e}")



    def dev_reset_single_voucher(self, voucher_no):
        voucher_no = str(voucher_no).strip()
        if not voucher_no:
            messagebox.showerror("Error", "Please enter a valid Voucher Number.")
            return

        mode = "voucher"
        if hasattr(self, "tabview") and self.tabview.get() == "💼 Paybills":
            mode = "paybill"

        excel_path = self.voucher_excel_file_path if mode == "voucher" else self.paybill_excel_file_path
        if not excel_path:
            messagebox.showerror("Error", "Please select an Excel sheet first to determine target folders.")
            return

        try:
            rows = self.parse_excel_sheet(excel_path, mode)
            matched_row = None
            for row in rows:
                if str(row.get('voucher', '')).strip() == voucher_no:
                    matched_row = row
                    break

            if not matched_row:
                messagebox.showerror("Error", f"Voucher '{voucher_no}' not found in the currently loaded Excel sheet.")
                return

            ans = messagebox.askyesno("Confirm Reset", f"Are you sure you want to reset database records and delete local folder for voucher '{voucher_no}'?")
            if not ans: return

            target_dir = self.resolve_download_path(matched_row, "Voucher" if mode == "voucher" else "Paybill")
            if os.path.exists(target_dir):
                import shutil
                shutil.rmtree(target_dir, ignore_errors=True)

            db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
            import sqlite3
            conn = sqlite3.connect(db_path, timeout=10.0)
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM downloads
                WHERE voucher_no = ?
            """, (voucher_no,))
            conn.commit()
            conn.close()

            self.log(f"🧹 Developer Reset: Cleared database record and deleted folder for voucher {voucher_no}.")
            messagebox.showinfo("Success", f"Voucher '{voucher_no}' successfully reset.")
        except Exception as e:
            self.log(f"❌ Failed to reset voucher '{voucher_no}': {e}")
            messagebox.showerror("Error", f"Failed to reset: {e}")



    def dev_run_diagnostics(self):
        self.log("🔍 Running system diagnostics...")
        try:
            report_path = os.path.join(self.base_path, "diagnostics_report.txt")
            with open(report_path, "w", encoding="utf-8") as f:
                f.write("=========================================\n")
                f.write("       CENTRALIZED VOUCHER VALIDATION SUITE SYSTEM DIAGNOSTICS   \n")
                f.write("=========================================\n")
                import datetime, platform, sys
                f.write(f"Timestamp: {datetime.datetime.now()}\n")
                f.write(f"OS: {platform.platform()}\n")
                f.write(f"Python: {sys.version}\n")
                f.write(f"Executable Mode: {'Frozen (compiled)' if getattr(sys, 'frozen', False) else 'Script mode'}\n")
                f.write(f"Base Directory: {self.base_path}\n")
                f.write("\n--- Directory Checks ---\n")
                f.write(f"Downloads Root: {self.download_dir} (Exists: {os.path.exists(self.download_dir)})\n")
                db_path = getattr(self, "db_path", os.path.join(self.base_path, "ifmis_workspace.db"))
                f.write(f"SQLite DB Path: {db_path} (Exists: {os.path.exists(db_path)})\n")

                f.write("\n--- Python Library Checks ---\n")
                libs = ["customtkinter", "playwright", "pandas", "pypdf", "openpyxl", "requests", "bs4"]
                for lib in libs:
                    try:
                        __import__(lib)
                        f.write(f"  {lib}: AVAILABLE\n")
                    except ImportError:
                        f.write(f"  {lib}: MISSING\n")

                f.write("\n--- Browser Paths ---\n")
                chrome_paths = [
                    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
                ]
                for p in chrome_paths:
                    f.write(f"  Chrome Path '{p}': Exists={os.path.exists(p)}\n")

            self.log(f"✅ Diagnostics report saved to {report_path}")
            os.startfile(report_path)
        except Exception as e:
            self.log(f"❌ Failed to run diagnostics: {e}")
            messagebox.showerror("Error", f"Failed to run diagnostics: {e}")



    def _save_ddo_database(self):
        from core.constants import DDO_DATABASE
        save_paths = [os.path.join(self.base_path, "ddo.txt")]
        dev_path = os.path.expanduser(r"~\.gemini\antigravity\scratch\IFMIS_Suite\ddo.txt")
        if os.path.exists(os.path.dirname(dev_path)) and dev_path not in save_paths:
            save_paths.append(dev_path)
            
        ddo_buffer = []
        for t_name in sorted(DDO_DATABASE.keys()):
            ddo_buffer.append(f"=== {t_name} ===\n")
            for ddo in DDO_DATABASE[t_name]:
                ddo_buffer.append(f"{ddo}\n")
            ddo_buffer.append("\n")
            
        for spath in save_paths:
            try:
                with open(spath, "w", encoding="utf-8") as f:
                    f.writelines(ddo_buffer)
                self.log(f"✅ Updated offline DDO database saved to: {spath}")
            except Exception as e:
                self.log(f"⚠️ Failed to write DDO database to {spath}: {e}")



    def load_failed_vouchers(self, mode):
        failed_file = self.voucher_failed_file if mode == "voucher" else self.paybill_failed_file
        if not os.path.exists(failed_file): return []
        failed_data = []
        try:
            with open(failed_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"): continue
                    parts = line.split("|")
                    if len(parts) == 5: 
                        mh, treasury, voucher, month, year = parts
                        s_no_str, amount_str = "Retry", ""
                    elif len(parts) == 7: 
                        s_no_str, mh, treasury, voucher, amount_str, month, year = parts
                    else: continue
                        
                    try:
                        m_lbl = f"{int(month):02d}_{int(year)}"
                    except:
                        m_lbl = "UNKNOWN_DATE"
                    clean_tr = self.clean_folder_name(str(treasury).strip())
                    clean_vch = self.clean_folder_name(str(voucher).strip())
                    clean_amt = self.clean_folder_name(str(amount_str).strip()) if amount_str else ""
                    
                    folder_parts = [
                        str(s_no_str),
                        clean_tr,
                        str(mh),
                        m_lbl,
                        clean_vch
                    ]
                    if clean_amt and clean_amt != "None":
                        folder_parts.append(clean_amt)
                    folder_name = "_".join(folder_parts)
                    
                    failed_data.append({
                        "s_no": s_no_str, "mh": mh, "treasury": treasury, "voucher": voucher, "amount": amount_str,
                        "month": int(month), "year": int(year), "folder_name": folder_name,
                    })
        except Exception: pass
        return failed_data



    def load_failed_pol_rows(self):
        failed_file = self.pol_failed_file
        if not os.path.exists(failed_file): return []
        failed_rows = []
        try:
            with open(failed_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"): continue
                    parts = line.split("|")
                    if len(parts) == 4:
                        ddo, treasury, from_date, to_date = parts
                        bill_type = ""
                    elif len(parts) == 5:
                        ddo, treasury, from_date, to_date, bill_type = parts
                    else: continue
                    failed_rows.append({
                        "ddo": ddo,
                        "treasury": treasury,
                        "from_date": from_date,
                        "to_date": to_date,
                        "bill_type": bill_type
                    })
        except Exception: pass
        return failed_rows



    def clean_folder_name(self, name):
        if not name: return "UNKNOWN"
        return "".join(c for c in str(name) if c.isalnum() or c in (" ", "_", "-", ".")).strip()



    def get_tally_output_dir(self):
        """Retrieve the resolved tally output directory (custom folder or default Tally_Results)."""
        path = ""
        if hasattr(self, "entry_tally_output") and self.entry_tally_output:
            try:
                path = self.entry_tally_output.text().strip()
            except Exception: pass
        if not path and getattr(self, "tally_output_dir", None):
            path = self.tally_output_dir
        if path:
            path = os.path.normpath(path)
            try:
                os.makedirs(path, exist_ok=True)
                return path
            except Exception: pass
        default_dir = os.path.normpath(os.path.join(getattr(self, "download_dir", getattr(self, "base_path", ".")), "Tally_Results"))
        os.makedirs(default_dir, exist_ok=True)
        return default_dir

    def resolve_download_path(self, row_data, default_subfolder="Voucher"):
        sub_lower = str(default_subfolder).strip().lower()
        if "paybill" in sub_lower:
            category = "Paybills"
        elif "tally" in sub_lower:
            category = "TALLY_VOUCHERS"
        elif "voucher" in sub_lower:
            category = "VOUCHERS"
        elif "pol" in sub_lower:
            category = "POL"
        else:
            category = default_subfolder.upper()
            
        if hasattr(self, "var_batch_subfolder") and self.var_batch_subfolder.get().strip() and category not in ("Paybills", "TALLY_VOUCHERS"):
            category = os.path.normpath(os.path.join(category, self.var_batch_subfolder.get().strip()))
            
        if category == "TALLY_VOUCHERS":
            output_dir = self.get_tally_output_dir()

            t_raw = str(row_data.get('treasury', '')).strip()
            tr_short = t_raw
            if hasattr(self, "TREASURY_MAP"):
                for k, v in self.TREASURY_MAP.items():
                    if v == t_raw:
                        tr_short = k
                        break
            clean_tr = self.clean_folder_name(tr_short)
            clean_mh = self.clean_folder_name(str(row_data.get('mh', '')))
            clean_vch = self.clean_folder_name(str(row_data.get('voucher', '')))
            amt_val = row_data.get('amount')
            clean_amt = self.clean_folder_name(str(amt_val)) if amt_val not in (None, "", "None") else ""
            try: m_lbl = f"{int(row_data.get('month', 1)):02d}_{int(row_data.get('year', 2026))}"
            except Exception: m_lbl = "UNKNOWN_DATE"
            folder_parts = [str(row_data.get('s_no', '1')), clean_tr, clean_mh, m_lbl, clean_vch]
            if clean_amt: folder_parts.append(clean_amt)
            folder_name = "_".join(folder_parts)
            return os.path.normpath(os.path.join(output_dir, "Vouchers", folder_name))

            
        if category == "Paybills":
            t_raw = str(row_data.get('treasury', '')).strip()
            clean_tr = self.clean_folder_name(t_raw)
            clean_mh = self.clean_folder_name(str(row_data.get('mh', '')))
            try:
                m_lbl = f"{int(row_data.get('month', 1)):02d}"
            except Exception:
                m_lbl = "01"
            try:
                y_lbl = str(int(row_data.get('year', 2026)))
            except Exception:
                y_lbl = "2026"
            sub_dir = f"{t_raw}_{clean_tr}_{clean_mh}_{m_lbl}_{y_lbl}"
            return os.path.normpath(os.path.join(self.download_dir, "Paybills", sub_dir))

        if category == "SALARY BILL":
            t_raw = str(row_data.get('treasury', '')).strip()
            clean_tr = self.clean_folder_name(t_raw)
            clean_mh = self.clean_folder_name(str(row_data.get('mh', '')))
            try:
                m_lbl = f"{int(row_data.get('month', 1)):02d}"
            except Exception:
                m_lbl = "01"
            try:
                y_lbl = str(int(row_data.get('year', 2026)))
            except Exception:
                y_lbl = "2026"
            sub_dir = f"{clean_tr}_{clean_mh}_{m_lbl}_{y_lbl}"
            return os.path.normpath(os.path.join(self.download_dir, "SALARY BILL", sub_dir))

        if category == "POL":
            clean_tr = self.clean_folder_name(str(row_data.get('treasury', '')))
            clean_ddo_code = self.clean_folder_name(str(row_data.get('ddo_code', '')))
            clean_ddo_name = self.clean_folder_name(str(row_data.get('ddo_name', '')))
            
            if clean_ddo_code and clean_ddo_name and clean_ddo_code != clean_ddo_name:
                ddo_folder = f"{clean_ddo_code}_{clean_ddo_name}"
            else:
                ddo_folder = clean_ddo_code or clean_ddo_name or "UNKNOWN_DDO"
                
            return os.path.normpath(os.path.join(self.download_dir, category, f"{clean_tr}_POL", ddo_folder))

        template = self.var_path_template.get().strip()
        if not template:
            folder_name = row_data.get("folder_name")
            if not folder_name:
                try:
                    m_lbl = f"{int(row_data.get('month', 1)):02d}_{int(row_data.get('year', 2026))}"
                except Exception:
                    m_lbl = "UNKNOWN_DATE"
                clean_tr = self.clean_folder_name(str(row_data.get('treasury', '')))
                clean_vch = self.clean_folder_name(str(row_data.get('voucher', '')))
                amt_val = row_data.get('amount')
                clean_amt = self.clean_folder_name(str(amt_val)) if amt_val not in (None, "", "None") else ""
                folder_parts = [
                    str(row_data.get('s_no', '1')),
                    clean_tr,
                    str(row_data.get('mh', '')),
                    m_lbl,
                    clean_vch
                ]
                if clean_amt and clean_amt not in ("None", "UNKNOWN"):
                    folder_parts.append(clean_amt)
                folder_name = "_".join(folder_parts)
            return os.path.join(self.download_dir, category, folder_name)
        
        clean_tr = self.clean_folder_name(str(row_data.get('treasury', '')))
        clean_vch = self.clean_folder_name(str(row_data.get('voucher', '')))
        clean_amt = self.clean_folder_name(str(row_data.get('amount', '')))
        clean_mh = self.clean_folder_name(str(row_data.get('mh', '')))
        clean_ddo = self.clean_folder_name(str(row_data.get('ddo', '')))
        try:
            m_lbl = f"{int(row_data.get('month', 1)):02d}"
        except Exception:
            m_lbl = "01"
        try:
            y_lbl = str(int(row_data.get('year', 2026)))
        except Exception:
            y_lbl = "2026"
        s_no = str(row_data.get('s_no', ''))

        path = template
        # Handle Output_Folder replacement first
        if "{Output_Folder}" in path:
            path = path.replace("{Output_Folder}", os.path.join(self.download_dir, category))
        else:
            path = os.path.join(self.download_dir, category, path)
            
        path = path.replace("{Treasury}", clean_tr)
        path = path.replace("{Year}", y_lbl)
        path = path.replace("{Month}", m_lbl)
        path = path.replace("{DDO_Name}", clean_ddo)
        path = path.replace("{DDO}", clean_ddo)
        path = path.replace("{Voucher_No}", clean_vch)
        path = path.replace("{Voucher}", clean_vch)
        path = path.replace("{Amount}", clean_amt)
        path = path.replace("{Major_Head}", clean_mh)
        path = path.replace("{MH}", clean_mh)
        path = path.replace("{S_No}", s_no)

        # Ensure path uses correct system separators
        path = os.path.normpath(path)
        return path



    def verify_portal_and_network_health(self):
        import urllib.request
        import ssl
        import socket

        # Unverified SSL context for legacy government portal SSL ciphers
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        internet_ok = False
        internet_endpoints = ["https://www.google.com", "https://api.ipify.org", "https://icanhazip.com"]
        for endpoint in internet_endpoints:
            try:
                req = urllib.request.Request(endpoint, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, context=ctx, timeout=5) as conn:
                    if conn.getcode() == 200:
                        internet_ok = True
                        break
            except Exception:
                continue
                
        if not internet_ok:
            return False, "Local Network/Internet connection is down."
            
        try:
            req = urllib.request.Request("https://ifmisprod.mptreasury.gov.in/IFMS/", headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, context=ctx, timeout=10) as conn:
                code = conn.getcode()
                if code in [200, 302, 301]:
                    return True, "Internet and IFMIS Portal are online."
                else:
                    return False, f"IFMIS Portal returned HTTP status: {code}"
        except Exception:
            # Fallback to direct TCP socket connection check on port 443
            try:
                with socket.create_connection(("ifmisprod.mptreasury.gov.in", 443), timeout=5):
                    return True, "Internet and IFMIS Portal are online (TCP 443 verified)."
            except Exception as sock_err:
                return False, f"IFMIS Portal is unreachable: {sock_err}"


    def open_downloads_folder(self, subfolder=None):
        """Open main downloads directory or subfolder in OS File Explorer."""
        target_dir = self.download_dir
        if subfolder:
            target_dir = os.path.join(self.download_dir, subfolder)
        os.makedirs(target_dir, exist_ok=True)
        try:
            if sys.platform == "win32":
                os.startfile(target_dir)
            else:
                import subprocess
                subprocess.Popen(["xdg-open", target_dir])
        except Exception as e:
            self.log(f"⚠️ Failed to open downloads directory ({target_dir}): {e}")

    def open_vlc_downloads(self):
        """Open the VLC downloads subfolder in Windows File Explorer."""
        self.open_downloads_folder("VLC")

    def start_fetching_heads_thread(self):
        """Fetch live Major/Minor head details from IFMIS in background thread."""
        import threading
        from automation.scrapers.treasury_runner import fetch_treasury_heads_live
        t = threading.Thread(target=fetch_treasury_heads_live, args=(self,), daemon=True)
        t.start()

# =========================================================
