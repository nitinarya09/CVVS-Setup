import os
import json
import sys

def create_shortcut():
    # 1. Resolve paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Try reading from config.json first
    config_path = os.path.join(base_dir, "config.json")
    downloads_path = ""
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
                downloads_path = config.get("download_dir", "")
        except Exception:
            pass
            
    # Fallback default if config doesn't specify or exist
    if not downloads_path or not os.path.exists(downloads_path):
        user_profile = os.environ.get("USERPROFILE", "")
        downloads_path = os.path.join(user_profile, "Downloads", "IFMIS_Downloads")
        
    os.makedirs(downloads_path, exist_ok=True)
    
    desktop = os.path.join(os.environ["USERPROFILE"], "Desktop")
    shortcut_path = os.path.join(desktop, "IFMIS Downloads.lnk")
    
    print(f"Creating shortcut pointing to: {downloads_path}")
    print(f"Shortcut location: {shortcut_path}")
    
    try:
        import win32com.client
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = downloads_path
        shortcut.WorkingDirectory = downloads_path
        shortcut.Description = "Shortcut to Centralized Voucher Validation Suite Downloads Folder"
        shortcut.IconLocation = "shell32.dll, 3" # folder icon
        shortcut.save()
        print("Shortcut created successfully using win32com!")
        return True
    except Exception as e:
        print(f"win32com failed: {e}. Trying alternative PowerShell method...")
        try:
            # Fallback to PowerShell script execution to avoid pywin32 dependency issues in clean environments
            import subprocess
            ps_script = f'''
            $WshShell = New-Object -ComObject WScript.Shell
            $Shortcut = $WshShell.CreateShortcut("{shortcut_path}")
            $Shortcut.TargetPath = "{downloads_path}"
            $Shortcut.WorkingDirectory = "{downloads_path}"
            $Shortcut.Description = "Shortcut to Centralized Voucher Validation Suite Downloads Folder"
            $Shortcut.IconLocation = "shell32.dll, 3"
            $Shortcut.Save()
            '''
            subprocess.run(["powershell", "-Command", ps_script], capture_output=True, check=True)
            print("Shortcut created successfully using PowerShell!")
            return True
        except Exception as ex:
            print(f"PowerShell shortcut creation failed: {ex}")
            return False

if __name__ == "__main__":
    create_shortcut()
