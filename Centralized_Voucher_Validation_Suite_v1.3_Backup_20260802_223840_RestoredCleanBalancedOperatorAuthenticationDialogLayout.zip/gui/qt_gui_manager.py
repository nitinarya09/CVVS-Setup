# ---------------------------------------------------------------------------
# qt_gui_manager.py — PySide6 GUI layout builder for Centralized Voucher Validation Suite
# ---------------------------------------------------------------------------
# Contains FREE FUNCTIONS (not methods) that accept `self` as first parameter.
# They are monkey-patched onto the IFMISSuiteApp class at startup.
# ---------------------------------------------------------------------------

import os
import sys

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QIcon, QFont, QKeySequence, QColor, QShortcut
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QSplitter, QScrollArea, QTabWidget,
    QLabel, QLineEdit, QComboBox, QCheckBox, QPushButton,
    QProgressBar, QTextEdit, QFileDialog, QFrame, QSizePolicy,
)

from gui.qt_theme import generate_qss, THEMES
from gui.toggle_switch import ToggleSwitch, update_all_toggles


# ── Helpers ────────────────────────────────────────────────────────────────

def _resolve_asset(filename: str) -> str:
    """Return the absolute path of a bundled asset (works frozen & dev)."""
    if getattr(sys, "frozen", False):
        path = os.path.join(sys._MEIPASS, filename)
        if not os.path.exists(path):
            path = os.path.join(os.path.dirname(sys.executable), filename)
    else:
        path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            filename,
        )
    return path


def _make_card_frame(parent) -> QFrame:
    """Return a QFrame styled with the 'card-frame' class for QSS."""
    frame = QFrame(parent)
    frame.setObjectName("cardFrame")
    frame.setProperty("cssClass", "card")
    return frame


def _make_section_label(parent, text: str, *, highlight=False, muted=False,
                        bold=False, italic=False, size=11,
                        object_name=None, warning=False, danger=False) -> QLabel:
    """Return a QLabel pre-configured with Segoe UI and optional CSS class."""
    lbl = QLabel(text, parent)
    font = QFont("Segoe UI", size)
    if bold:
        font.setBold(True)
    if italic:
        font.setItalic(True)
    lbl.setFont(font)

    css_classes = []
    if highlight:
        css_classes.append("highlight")
    if muted:
        css_classes.append("muted")
    if warning:
        css_classes.append("warning")
    if danger:
        css_classes.append("danger")
    if css_classes:
        lbl.setProperty("cssClass", " ".join(css_classes))
    if object_name:
        lbl.setObjectName(object_name)
    return lbl


def _make_outline_button(parent, text: str, callback=None, *,
                         object_name=None, width=None, height=30) -> QPushButton:
    """Return a QPushButton styled as an outline button."""
    btn = QPushButton(text, parent)
    btn.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    btn.setProperty("cssClass", "outline")
    btn.setFixedHeight(height)
    if width:
        btn.setFixedWidth(width)
    if callback:
        btn.clicked.connect(callback)
    if object_name:
        btn.setObjectName(object_name)
    return btn


# ══════════════════════════════════════════════════════════════════════════
# 1. _build_gui  — main entry point
# ══════════════════════════════════════════════════════════════════════════

def _build_gui(self):
    """Build the complete application GUI inside the QMainWindow."""

    # ── Window chrome ──────────────────────────────────────────────────
    # ── Window chrome ──────────────────────────────────────────────────
    self.setWindowTitle(
        f"CENTRALIZED VOUCHER VALIDATION SUITE v{self.TOOL_VERSION} - Developed by AG(A&E) MP Gwalior"
    )
    self.resize(1100, 680)
    self.setMinimumSize(1000, 600)

    icon_path = _resolve_asset("logo.png")
    if not os.path.exists(icon_path):
        icon_path = _resolve_asset("cag_logo.ico")
    if os.path.exists(icon_path):
        self.setWindowIcon(QIcon(icon_path))

    # ── Central widget & main layout ───────────────────────────────────
    central = QWidget(self)
    central.setObjectName("centralWidget")
    self.setCentralWidget(central)
    main_layout = QHBoxLayout(central)
    main_layout.setContentsMargins(0, 0, 0, 0)

    self.main_splitter = QSplitter(Qt.Orientation.Horizontal, central)
    main_layout.addWidget(self.main_splitter)

    # ── Build both panels ──────────────────────────────────────────────
    self._build_left_sidebar()
    self._build_right_panel()


    # Grid compat hint (not applicable in Qt, kept for parity)
    # self.grid_columnconfigure(1, weight=1)
    # self.grid_rowconfigure(0, weight=1)

    # ── Hide profile widgets by default if not developer mode ──────────
    if not getattr(self, "dev_mode", False):
        for attr in ("opt_profile", "btn_save_profile", "btn_delete_profile"):
            w = getattr(self, attr, None)
            if w is not None:
                w.setVisible(False)

    # ── Developer-mode hotkey: Ctrl+Shift+D ────────────────────────────
    shortcut = QShortcut(QKeySequence("Ctrl+Shift+D"), self)
    shortcut.activated.connect(lambda: self.toggle_developer_mode())
    self._dev_shortcut = shortcut  # prevent GC

    # ── Start maximized ────────────────────────────────────────────────
    self.showMaximized()


# ══════════════════════════════════════════════════════════════════════════
# 2. _build_left_sidebar
# ══════════════════════════════════════════════════════════════════════════

def _build_left_sidebar(self):
    """Create the left sidebar with scroll, logo, credentials, toggles, stats."""

    # ── Scroll-area wrapper ────────────────────────────────────────────
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    scroll.setFixedWidth(345)
    scroll.setObjectName("sidebarScroll")
    scroll.setProperty("cssClass", "sidebar")

    sidebar = QWidget()
    sidebar.setObjectName("sidebarContent")
    sidebar.setProperty("cssClass", "sidebar")
    layout = QVBoxLayout(sidebar)
    layout.setContentsMargins(10, 10, 10, 10)
    layout.setSpacing(8)

    self.sidebar_frame = sidebar
    scroll.setWidget(sidebar)
    self.main_splitter.addWidget(scroll)
    self.sidebar_scroll = scroll

    # ── 1. Logo ────────────────────────────────────────────────────────
    logo_path = _resolve_asset("logo.png")
    if not os.path.exists(logo_path):
        logo_path = _resolve_asset("cag_logo.png")
    if os.path.exists(logo_path):
        try:
            pix = QPixmap(logo_path).scaled(
                80, 80,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            logo_label = QLabel(sidebar)
            logo_label.setPixmap(pix)
            logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            logo_label.setContentsMargins(10, 15, 10, 5)
            layout.addWidget(logo_label)
        except Exception as e:
            print(f"Error loading logo: {e}")

    # ── 2. Titles ──────────────────────────────────────────────────────
    self.lbl_sidebar_title = QLabel("Centralized Voucher Validation Suite", sidebar)
    self.lbl_sidebar_title.setFont(QFont("Segoe UI", 19, QFont.Weight.Bold))
    self.lbl_sidebar_title.setWordWrap(True)
    self.lbl_sidebar_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_sidebar_title.setStyleSheet("color: #00c9a7; font-size: 19px; font-weight: 800; padding: 2px 0px;")
    self.lbl_sidebar_title.setContentsMargins(8, 10, 8, 4)
    layout.addWidget(self.lbl_sidebar_title)

    self.lbl_sidebar_version = QLabel("v1.3 (Release Build)", sidebar)
    self.lbl_sidebar_version.setFont(QFont("Segoe UI", 9))
    self.lbl_sidebar_version.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_sidebar_version.setStyleSheet("color: #38bdf8; font-size: 9px; font-weight: 600; background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.25); border-radius: 6px; padding: 2px 8px; max-width: 150px;")
    
    ver_layout = QHBoxLayout()
    ver_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
    ver_layout.addWidget(self.lbl_sidebar_version)
    layout.addLayout(ver_layout)

    self.lbl_sidebar_office = QLabel(
        "OFFICE OF THE ACCOUNTANT GENERAL (A&E)", sidebar
    )
    self.lbl_sidebar_office.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    self.lbl_sidebar_office.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_sidebar_office.setProperty("cssClass", "main")
    self.lbl_sidebar_office.setContentsMargins(10, 4, 10, 0)
    layout.addWidget(self.lbl_sidebar_office)

    self.lbl_sidebar_city = QLabel("Madhya Pradesh, Gwalior", sidebar)
    self.lbl_sidebar_city.setFont(QFont("Segoe UI", 10))
    self.lbl_sidebar_city.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_sidebar_city.setProperty("cssClass", "muted")
    self.lbl_sidebar_city.setContentsMargins(10, 0, 10, 6)
    layout.addWidget(self.lbl_sidebar_city)

    # ── 3. Credentials box (card frame) ────────────────────────────────
    self.cred_box = _make_card_frame(sidebar)
    cred_lay = QVBoxLayout(self.cred_box)
    cred_lay.setContentsMargins(10, 6, 10, 6)
    cred_lay.setSpacing(4)

    self.lbl_cred_title = _make_section_label(
        self.cred_box, "\U0001f511 ACCOUNTS & PROFILE",
        highlight=True, bold=True, size=11,
    )
    self.lbl_cred_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
    cred_lay.addWidget(self.lbl_cred_title)

    self.entry_user = QLineEdit(self.cred_box)
    self.entry_user.setPlaceholderText("Username")
    self.entry_user.setFixedHeight(30)
    self.entry_user.setFont(QFont("Segoe UI", 11))
    self.entry_user.setProperty("cssClass", "entry")
    cred_lay.addWidget(self.entry_user)

    pass_container = QWidget(self.cred_box)
    pass_layout = QHBoxLayout(pass_container)
    pass_layout.setContentsMargins(0, 0, 0, 0)
    pass_layout.setSpacing(4)

    self.entry_pass = QLineEdit(pass_container)
    self.entry_pass.setPlaceholderText("Password")
    self.entry_pass.setEchoMode(QLineEdit.EchoMode.Password)
    self.entry_pass.setFixedHeight(30)
    self.entry_pass.setFont(QFont("Segoe UI", 11))
    self.entry_pass.setProperty("cssClass", "entry")
    pass_layout.addWidget(self.entry_pass, 1)

    self.btn_toggle_pass = QPushButton("👁", pass_container)
    self.btn_toggle_pass.setFixedSize(32, 30)
    self.btn_toggle_pass.setFont(QFont("Segoe UI Emoji", 11))
    self.btn_toggle_pass.setToolTip("Show / Hide Password")
    self.btn_toggle_pass.setProperty("cssClass", "outline")
    self.btn_toggle_pass.setStyleSheet(
        "QPushButton { padding: 0px; margin: 0px; text-align: center; font-size: 13px; }"
    )

    def _toggle_password_visibility():
        if self.entry_pass.echoMode() == QLineEdit.EchoMode.Password:
            self.entry_pass.setEchoMode(QLineEdit.EchoMode.Normal)
            self.btn_toggle_pass.setText("🙈")
        else:
            self.entry_pass.setEchoMode(QLineEdit.EchoMode.Password)
            self.btn_toggle_pass.setText("👁")

    self.btn_toggle_pass.clicked.connect(_toggle_password_visibility)
    pass_layout.addWidget(self.btn_toggle_pass)

    cred_lay.addWidget(pass_container)

    self.opt_profile = QComboBox(self.cred_box)
    self.opt_profile.setEditable(True)
    self.opt_profile.addItems(["Default"])
    self.opt_profile.setFixedHeight(30)
    self.opt_profile.setFont(QFont("Segoe UI", 11))
    self.opt_profile.setProperty("cssClass", "entry")
    self.opt_profile.setVisible(False)
    if hasattr(self, "var_active_profile"):
        self.var_active_profile.bind_to_widget(self.opt_profile)
    if hasattr(self, "on_profile_selected"):
        self.opt_profile.currentTextChanged.connect(self.on_profile_selected)
    cred_lay.addWidget(self.opt_profile)

    # Buttons row
    btn_frame = QWidget(self.cred_box)
    btn_lay = QVBoxLayout(btn_frame)
    btn_lay.setContentsMargins(0, 2, 0, 6)
    btn_lay.setSpacing(4)

    self.btn_save_cred = _make_outline_button(
        btn_frame, "Save Credentials",
        callback=getattr(self, "save_credentials", None),
        object_name="btnSaveCred",
    )
    btn_lay.addWidget(self.btn_save_cred)

    profile_btn_row = QHBoxLayout()
    profile_btn_row.setSpacing(4)

    self.btn_save_profile = QPushButton("Save Profile", btn_frame)
    self.btn_save_profile.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    self.btn_save_profile.setFixedHeight(30)
    self.btn_save_profile.setProperty("cssClass", "primary")
    self.btn_save_profile.setVisible(False)
    if hasattr(self, "save_current_profile"):
        self.btn_save_profile.clicked.connect(self.save_current_profile)
    profile_btn_row.addWidget(self.btn_save_profile)

    self.btn_delete_profile = QPushButton("Delete Profile", btn_frame)
    self.btn_delete_profile.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    self.btn_delete_profile.setFixedHeight(30)
    self.btn_delete_profile.setProperty("cssClass", "danger")
    self.btn_delete_profile.setVisible(False)
    if hasattr(self, "delete_current_profile"):
        self.btn_delete_profile.clicked.connect(self.delete_current_profile)
    profile_btn_row.addWidget(self.btn_delete_profile)

    btn_lay.addLayout(profile_btn_row)
    cred_lay.addWidget(btn_frame)

    layout.addWidget(self.cred_box)

    # ── 4. Config Toggles ──────────────────────────────────────────────
    self.profile_box = QWidget(sidebar)
    toggle_lay = QVBoxLayout(self.profile_box)
    toggle_lay.setContentsMargins(14, 3, 14, 3)
    toggle_lay.setSpacing(2)

    self.sw_stealth = ToggleSwitch("Hybrid Stealth Mode (Hide Window)", self.profile_box)
    self.sw_stealth.setFont(QFont("Segoe UI", 10))
    if hasattr(self, "var_stealth"):
        self.var_stealth.bind_to_widget(self.sw_stealth)
    toggle_lay.addWidget(self.sw_stealth)

    self.sw_archive = ToggleSwitch("Auto-Archive Downloads to Zip", self.profile_box)
    self.sw_archive.setFont(QFont("Segoe UI", 10))
    if hasattr(self, "var_archive"):
        self.var_archive.bind_to_widget(self.sw_archive)
    toggle_lay.addWidget(self.sw_archive)

    self.sw_dryrun = ToggleSwitch("Dry Run (Bypass IFMS Site/Demo)", self.profile_box, variant="warning")
    self.sw_dryrun.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    if hasattr(self, "var_dryrun"):
        self.var_dryrun.bind_to_widget(self.sw_dryrun)
    toggle_lay.addWidget(self.sw_dryrun)

    self.sw_parallel_sidebar = ToggleSwitch("Multi-Worker Parallel Mode", self.profile_box)
    self.sw_parallel_sidebar.setFont(QFont("Segoe UI", 10))
    if hasattr(self, "var_parallel"):
        self.var_parallel.bind_to_widget(self.sw_parallel_sidebar)
    toggle_lay.addWidget(self.sw_parallel_sidebar)

    self.lbl_parallel_disclaimer = QLabel(
        "(only for high end machines)", self.profile_box
    )
    self.lbl_parallel_disclaimer.setProperty("cssClass", "disclaimer")
    self.lbl_parallel_disclaimer.setContentsMargins(26, 0, 0, 2)
    toggle_lay.addWidget(self.lbl_parallel_disclaimer)

    layout.addWidget(self.profile_box)



    # ── 6. Stats Box (card frame) ──────────────────────────────────────
    self.stats_box = _make_card_frame(sidebar)
    stats_lay = QVBoxLayout(self.stats_box)
    stats_lay.setContentsMargins(10, 4, 10, 6)
    stats_lay.setSpacing(0)

    stats_title = _make_section_label(
        self.stats_box, "Task Operations Panel",
        muted=True, bold=True, size=11,
    )
    stats_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
    stats_lay.addWidget(stats_title)

    self.lbl_stats = QLabel(
        "Success: 0   Failed: 0   Skipped: 0   Total: 0", self.stats_box
    )
    self.lbl_stats.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    self.lbl_stats.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_stats.setProperty("cssClass", "main")
    stats_lay.addWidget(self.lbl_stats)

    self.lbl_current = QLabel("Current Operation: Idle", self.stats_box)
    self.lbl_current.setFont(QFont("Segoe UI", 10))
    self.lbl_current.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_current.setProperty("cssClass", "muted")
    stats_lay.addWidget(self.lbl_current)

    self.progress_bar = QProgressBar(self.stats_box)
    self.progress_bar.setFixedHeight(6)
    self.progress_bar.setTextVisible(False)
    self.progress_bar.setMinimum(0)
    self.progress_bar.setMaximum(100)
    self.progress_bar.setValue(0)
    self.progress_bar.setProperty("cssClass", "progress")
    stats_lay.addWidget(self.progress_bar)

    heartbeat_frame = QWidget(self.stats_box)
    hb_lay = QHBoxLayout(heartbeat_frame)
    hb_lay.setContentsMargins(0, 0, 0, 2)
    hb_lay.setSpacing(0)
    hb_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

    hb_label = QLabel("Active Thread Status: ", heartbeat_frame)
    hb_label.setFont(QFont("Segoe UI", 10))
    hb_label.setProperty("cssClass", "muted")
    hb_lay.addWidget(hb_label)

    self.lbl_heartbeat = QLabel("\u25cf Thread Active", heartbeat_frame)
    self.lbl_heartbeat.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    self.lbl_heartbeat.setStyleSheet("color: gray;")
    hb_lay.addWidget(self.lbl_heartbeat)

    stats_lay.addWidget(heartbeat_frame)

    net_speed_frame = QWidget(self.stats_box)
    ns_lay = QHBoxLayout(net_speed_frame)
    ns_lay.setContentsMargins(0, 0, 0, 2)
    ns_lay.setSpacing(0)
    ns_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

    ns_label = QLabel("Network Usage: ", net_speed_frame)
    ns_label.setFont(QFont("Segoe UI", 10))
    ns_label.setProperty("cssClass", "muted")
    ns_lay.addWidget(ns_label)

    self.lbl_net_speed = QLabel("⬇ 0.0 KB/s | ⬆ 0.0 KB/s", net_speed_frame)
    self.lbl_net_speed.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    self.lbl_net_speed.setProperty("cssClass", "main")
    ns_lay.addWidget(self.lbl_net_speed)

    stats_lay.addWidget(net_speed_frame)

    net_status_frame = QWidget(self.stats_box)
    nst_lay = QHBoxLayout(net_status_frame)
    nst_lay.setContentsMargins(0, 0, 0, 2)
    nst_lay.setSpacing(0)
    nst_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_net_status = QLabel("Status: Online (Connected)", net_status_frame)
    self.lbl_net_status.setFont(QFont("Segoe UI", 9))
    self.lbl_net_status.setProperty("cssClass", "muted")
    nst_lay.addWidget(self.lbl_net_status)
    stats_lay.addWidget(net_status_frame)

    latency_frame = QWidget(self.stats_box)
    lat_lay = QHBoxLayout(latency_frame)
    lat_lay.setContentsMargins(0, 0, 0, 2)
    lat_lay.setSpacing(0)
    lat_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_latency = QLabel("IFMS Portal: Measuring...", latency_frame)
    self.lbl_latency.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
    self.lbl_latency.setStyleSheet("color: #8b949e;")
    lat_lay.addWidget(self.lbl_latency)
    stats_lay.addWidget(latency_frame)

    session_frame = QWidget(self.stats_box)
    sess_lay = QHBoxLayout(session_frame)
    sess_lay.setContentsMargins(0, 0, 0, 2)
    sess_lay.setSpacing(0)
    sess_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_session_status = QLabel("Session: ⚪ Checking...", session_frame)
    self.lbl_session_status.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
    self.lbl_session_status.setStyleSheet("color: #8b949e;")
    sess_lay.addWidget(self.lbl_session_status)
    stats_lay.addWidget(session_frame)

    layout.addWidget(self.stats_box)

    # ── 7. Developer Details ───────────────────────────────────────────
    self.lbl_dev_details = QLabel(
        "Developed for - Indian Audit & Accounts Department", sidebar
    )
    self.lbl_dev_details.setFont(QFont("Segoe UI", 9))
    self.lbl_dev_details.setAlignment(Qt.AlignmentFlag.AlignCenter)
    self.lbl_dev_details.setProperty("cssClass", "muted")
    self.lbl_dev_details.setContentsMargins(8, 15, 8, 2)
    layout.addWidget(self.lbl_dev_details)

    # Push everything to top
    layout.addStretch(1)


# ══════════════════════════════════════════════════════════════════════════
# 3. _build_right_panel
# ══════════════════════════════════════════════════════════════════════════

def _build_right_panel(self):
    """Build the right panel: tab widget + unified console output."""

    right_container = QWidget()
    right_container.setObjectName("rightPanel")
    right_layout = QVBoxLayout(right_container)
    right_layout.setContentsMargins(10, 10, 10, 10)
    right_layout.setSpacing(6)

    from PySide6.QtWidgets import QSplitter
    self.right_splitter = QSplitter(Qt.Vertical, right_container)
    self.right_splitter.setObjectName("rightSplitter")
    right_layout.addWidget(self.right_splitter)
    self.main_splitter.addWidget(right_container)

    # ── 1. Tab widget ──────────────────────────────────────────────────
    self.tabview = QTabWidget(self.right_splitter)
    self.tabview.setObjectName("mainTabWidget")
    self.tabview.setFont(QFont("Segoe UI", 11))
    self.tabview.tabBar().setExpanding(True)

    self.tab_vouchers = self._build_voucher_tab()
    self.tab_checks_manager = self._build_checks_manager_tab()
    self.tab_validation_results = self._build_validation_results_tab()
    self.tab_settings = self._build_settings_tab()

    self.update_tab_visibilities()

    # Developer tab added later via toggle_developer_mode

    self.tabview.currentChanged.connect(self.on_tab_switched)
    self.right_splitter.addWidget(self.tabview)

    # ── 2. Console Frame ──────────────────────────────────────────────
    self.console_frame = QFrame(self.right_splitter)
    self.console_frame.setObjectName("consoleFrame")
    self.console_frame.setProperty("cssClass", "sidebar")
    console_lay = QVBoxLayout(self.console_frame)
    console_lay.setContentsMargins(12, 4, 12, 10)
    console_lay.setSpacing(4)

    # Row 0: title + action buttons
    title_row = QHBoxLayout()
    title_row.setSpacing(4)

    self.lbl_console_title = QLabel(
        "\U0001f4bb Log Console | System Status: Idle", self.console_frame
    )
    self.lbl_console_title.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
    self.lbl_console_title.setProperty("cssClass", "highlight")
    title_row.addWidget(self.lbl_console_title, stretch=1)

    self.btn_toggle_browser = _make_outline_button(
        self.console_frame, "\U0001f441 Toggle Browser",
        callback=getattr(self, "toggle_browser_visibility", None),
        object_name="btnToggleBrowser",
    )
    title_row.addWidget(self.btn_toggle_browser)

    self.btn_export_logs = _make_outline_button(
        self.console_frame, "📥 Export Logs",
        callback=lambda: self.export_console_logs() if hasattr(self, "export_console_logs") else None,
        object_name="btnExportLogs",
    )
    title_row.addWidget(self.btn_export_logs)

    self.btn_logout_portal = QPushButton(
        "\U0001f513 Logout Portal", self.console_frame
    )
    self.btn_logout_portal.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    self.btn_logout_portal.setFixedHeight(30)
    self.btn_logout_portal.setProperty("cssClass", "danger")
    if hasattr(self, "manual_portal_logout"):
        self.btn_logout_portal.clicked.connect(self.manual_portal_logout)
    title_row.addWidget(self.btn_logout_portal)

    console_lay.addLayout(title_row)

    # Row 1: Filter frame
    self.filter_frame = QWidget(self.console_frame)
    filter_lay = QHBoxLayout(self.filter_frame)
    filter_lay.setContentsMargins(0, 2, 0, 6)
    filter_lay.setSpacing(4)

    lbl_worker = QLabel("Worker:", self.filter_frame)
    lbl_worker.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    lbl_worker.setProperty("cssClass", "main")
    filter_lay.addWidget(lbl_worker)

    workers_cnt = 5
    try:
        workers_cnt = self.var_parallel_workers.get()
    except Exception:
        pass

    self.opt_filter_worker = QComboBox(self.filter_frame)
    self.opt_filter_worker.addItems(
        ["All", "Main"] + [f"Worker {i}" for i in range(1, int(workers_cnt) + 1)]
    )
    self.opt_filter_worker.setFixedWidth(100)
    self.opt_filter_worker.setFixedHeight(26)
    self.opt_filter_worker.setFont(QFont("Segoe UI", 10))
    filter_lay.addWidget(self.opt_filter_worker)

    lbl_status = QLabel("Status:", self.filter_frame)
    lbl_status.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    lbl_status.setProperty("cssClass", "main")
    filter_lay.addWidget(lbl_status)

    self.opt_filter_status = QComboBox(self.filter_frame)
    self.opt_filter_status.addItems(["All", "Success", "Error", "Warning", "Skip", "Header", "Info"])
    self.opt_filter_status.setFixedWidth(100)
    self.opt_filter_status.setFixedHeight(26)
    self.opt_filter_status.setFont(QFont("Segoe UI", 10))
    filter_lay.addWidget(self.opt_filter_status)

    lbl_search = QLabel("Search:", self.filter_frame)
    lbl_search.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    lbl_search.setProperty("cssClass", "main")
    filter_lay.addWidget(lbl_search)

    self.entry_filter_search = QLineEdit(self.filter_frame)
    self.entry_filter_search.setPlaceholderText("Filter logs...")
    self.entry_filter_search.setFixedHeight(26)
    self.entry_filter_search.setFont(QFont("Segoe UI", 10))
    filter_lay.addWidget(self.entry_filter_search, stretch=1)

    # Connect filter widgets to redraw
    def _trigger_redraw(*_args):
        if hasattr(self, "redraw_filtered_logs"):
            self.redraw_filtered_logs()

    # Bind filter widgets to their TkVarCompat variables so the filtering
    # logic in qt_app.py reads the actual widget values instead of stale defaults.
    if hasattr(self, "var_filter_worker"):
        self.var_filter_worker.bind_to_widget(self.opt_filter_worker)
    if hasattr(self, "var_filter_status"):
        self.var_filter_status.bind_to_widget(self.opt_filter_status)
    if hasattr(self, "var_filter_search"):
        self.var_filter_search.bind_to_widget(self.entry_filter_search)

    self.opt_filter_worker.currentTextChanged.connect(_trigger_redraw)
    self.opt_filter_status.currentTextChanged.connect(_trigger_redraw)
    self.entry_filter_search.textChanged.connect(_trigger_redraw)

    console_lay.addWidget(self.filter_frame)

    # Row 2: Console text output
    self.output = QTextEdit(self.console_frame)
    self.txt_console = self.output
    self.output.setReadOnly(True)
    self.output.setFont(QFont("Consolas", 10))
    self.output.setObjectName("consoleOutput")
    self.output.setProperty("cssClass", "console")
    console_lay.addWidget(self.output)

    # ── Console tag color helper (used by log coloring) ────────────────
    def _update_console_tag_colors():
        """Store tag-color map for log insertion logic."""
        theme_name = getattr(self, "var_theme_accent", None)
        active = theme_name.get() if theme_name else "Emerald Teal (Dark)"
        is_dark = "Dark" in active or "dark" in THEMES.get(active, {}).get("APPEARANCE_MODE", "dark")

        if is_dark:
            self._console_tag_colors = {
                "success": "#00c9a7",
                "skip":    "#3b82f6",
                "warning": "#fbbf24",
                "error":   "#f87171",
                "info":    "#8b949e",
            }
        else:
            self._console_tag_colors = {
                "success": "#008060",
                "skip":    "#1d4ed8",
                "warning": "#b45309",
                "error":   "#dc2626",
                "info":    "#57606a",
            }

    self.output_console_tag_colors = _update_console_tag_colors
    _update_console_tag_colors()

    self.console_frame.setMinimumHeight(150)
    self.right_splitter.addWidget(self.console_frame)

    # Distribute initial sizes: 420px for tabview, 320px for console
    self.right_splitter.setSizes([420, 320])
    right_layout.addWidget(self.right_splitter)

    self.main_splitter.addWidget(right_container)
    # Let right panel stretch; sidebar is fixed
    self.main_splitter.setStretchFactor(0, 0)
    self.main_splitter.setStretchFactor(1, 1)


# ══════════════════════════════════════════════════════════════════════════
# 4. Tab wrapper functions
# ══════════════════════════════════════════════════════════════════════════

def _build_voucher_tab(self, tab=None):
    from gui.tabs_qt.voucher_tab import build_voucher_tab
    if tab is None:
        tab = QWidget()
    build_voucher_tab(self, tab)
    return tab


def _build_payroll_tab(self, tab=None):
    return tab or QWidget()

def _build_pol_tab(self, tab=None):
    return tab or QWidget()

def _build_vlc_tab(self, tab=None):
    return tab or QWidget()

def _build_tally_tab(self, tab=None):
    return tab or QWidget()

def _build_treasury_tab(self, tab=None):
    return tab or QWidget()

def _build_developer_tab(self, tab=None):
    from gui.tabs_qt.developer_tab import build_developer_tab
    if tab is None:
        tab = QWidget()
    build_developer_tab(self, tab)
    return tab


def _build_settings_tab(self, tab=None):
    from gui.tabs_qt.settings_tab import build_settings_tab
    if tab is None:
        tab = QWidget()

    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    scroll.setFrameShape(QFrame.Shape.NoFrame)

    inner = QWidget()
    build_settings_tab(self, inner)
    scroll.setWidget(inner)

    wrapper_layout = QVBoxLayout(tab)
    wrapper_layout.setContentsMargins(0, 0, 0, 0)
    wrapper_layout.addWidget(scroll)
    return tab


def _build_checks_manager_tab(self, tab=None):
    from gui.tabs_qt.checks_manager_tab import build_checks_manager_tab
    if tab is None:
        tab = QWidget()
    build_checks_manager_tab(self, tab)
    return tab


def _build_validation_results_tab(self, tab=None):
    from gui.tabs_qt.validation_results_tab import build_validation_results_tab
    if tab is None:
        tab = QWidget()
    build_validation_results_tab(self, tab)
    return tab


# ══════════════════════════════════════════════════════════════════════════
# 5. on_tab_switched
# ══════════════════════════════════════════════════════════════════════════

def on_tab_switched(self, index=None):
    """React to tab changes by auto-selecting browser mode and dynamically showing/hiding console log frame."""
    if index is None:
        index = self.tabview.currentIndex()

    tab_text = self.tabview.tabText(index)

    # Show Log Console ONLY on Voucher Downloader / Vouchers tab to maximize height for all other tabs!
    if hasattr(self, "console_frame"):
        if "Voucher Downloader" in tab_text or "Vouchers" in tab_text:
            self.console_frame.show()
        else:
            self.console_frame.hide()

    # Save Vouchers parallel mode state when leaving Vouchers tab
    prev_tab = getattr(self, "_prev_selected_tab", "Vouchers")
    if hasattr(self, "var_parallel") and "Vouchers" in prev_tab:
        self._prev_voucher_parallel_mode = self.var_parallel.get()

    self._prev_selected_tab = tab_text

    if "Payroll" in tab_text:
        if hasattr(self, "var_browser"):
            self.var_browser.set("Mozilla Firefox (Paybill/POL)")
        if hasattr(self, "var_parallel"):
            self.var_parallel.set(False)
        if hasattr(self, "sw_parallel_sidebar"):
            self.sw_parallel_sidebar.setEnabled(False)
    elif "Vouchers" in tab_text or "Checks Manager" in tab_text or "Validation Results" in tab_text:
        if hasattr(self, "var_browser"):
            self.var_browser.set("Google Chrome / Chromium")
        if hasattr(self, "var_parallel"):
            self.var_parallel.set(True)  # Auto-toggle ON for Vouchers tab
        if hasattr(self, "sw_parallel_sidebar"):
            self.sw_parallel_sidebar.setEnabled(True)
    elif "POL" in tab_text:
        if hasattr(self, "var_browser"):
            self.var_browser.set("Google Chrome / Chromium")
        if hasattr(self, "var_parallel"):
            self.var_parallel.set(True)  # Auto-toggle ON for POL tab
        if hasattr(self, "sw_parallel_sidebar"):
            self.sw_parallel_sidebar.setEnabled(True)
    elif "VLC" in tab_text:
        if hasattr(self, "var_browser"):
            self.var_browser.set("Google Chrome / Chromium")
        if hasattr(self, "var_parallel"):
            self.var_parallel.set(False)
        if hasattr(self, "sw_parallel_sidebar"):
            self.sw_parallel_sidebar.setEnabled(False)
    elif "Tally" in tab_text:
        if hasattr(self, "var_browser"):
            self.var_browser.set("Google Chrome / Chromium")
        if hasattr(self, "var_parallel"):
            self.var_parallel.set(True)
        if hasattr(self, "sw_parallel_sidebar"):
            self.sw_parallel_sidebar.setEnabled(True)
    elif "Treasury" in tab_text:
        if hasattr(self, "var_browser"):
            self.var_browser.set("Google Chrome / Chromium")
        if hasattr(self, "var_parallel"):
            self.var_parallel.set(False)
        if hasattr(self, "sw_parallel_sidebar"):
            self.sw_parallel_sidebar.setEnabled(False)


def _build_vlc_linker_tab(self, tab=None):
    from gui.tabs_qt.vlc_linker_tab import build_vlc_linker_tab
    if tab is None:
        tab = QWidget()
    build_vlc_linker_tab(self, tab)
    return tab


def update_tab_visibilities(self):
    """Dynamically hide or show main tabs for Centralized Voucher Validation Suite."""
    if not hasattr(self, "tabview"):
        return

    curr_widget = self.tabview.currentWidget()

    tab_defs = [
        ("vouchers", "📥 Voucher Downloader & Realtime Tally", getattr(self, "tab_vouchers", None)),
        ("checks_manager", "⚙️ Checks Manager", getattr(self, "tab_checks_manager", None)),
        ("validation_results", "📊 Validation Results & Reports", getattr(self, "tab_validation_results", None)),
        ("settings", "⚙️ Settings", getattr(self, "tab_settings", None)),
    ]

    if getattr(self, "dev_mode", False):
        if not hasattr(self, "tab_developer") or self.tab_developer is None:
            self.tab_developer = self._build_developer_tab()
        tab_defs.append(("developer", "🛠️ Developer", self.tab_developer))

    self.tabview.blockSignals(True)

    while self.tabview.count() > 0:
        self.tabview.removeTab(0)

    for key, title, widget in tab_defs:
        if widget is not None:
            self.tabview.addTab(widget, title)

    if curr_widget:
        idx = self.tabview.indexOf(curr_widget)
        if idx >= 0:
            self.tabview.setCurrentIndex(idx)

    self.tabview.blockSignals(False)




# ══════════════════════════════════════════════════════════════════════════
# 5.5. toggle_direct_dashboard
# ══════════════════════════════════════════════════════════════════════════

def toggle_direct_dashboard(self):
    """Log state change when Direct Dashboard Mode is toggled."""
    if self.var_direct_dashboard.get():
        self.log("ℹ️ Direct Dashboard Mode enabled.")
    else:
        self.log("ℹ️ Direct Dashboard Mode disabled.")


# ══════════════════════════════════════════════════════════════════════════
# 6. browse_download_dir
# ══════════════════════════════════════════════════════════════════════════

def browse_download_dir(self):
    """Open a directory picker for the download root."""
    initial = getattr(self, "download_dir", "")
    if hasattr(self, "var_download_dir"):
        initial = self.var_download_dir.get() or initial
    path = QFileDialog.getExistingDirectory(
        self, "Select Download Directory", initial
    )
    if path:
        if hasattr(self, "var_download_dir"):
            self.var_download_dir.set(os.path.normpath(path))


# ══════════════════════════════════════════════════════════════════════════
# 7. browse_batch_subfolder
# ══════════════════════════════════════════════════════════════════════════

def browse_batch_subfolder(self):
    """Open a directory picker for the batch sub-folder."""
    initial = getattr(self, "download_dir", "")
    if hasattr(self, "var_download_dir"):
        initial = self.var_download_dir.get() or initial
    path = QFileDialog.getExistingDirectory(
        self, "Select Batch Subfolder", initial
    )
    if path:
        if hasattr(self, "var_batch_subfolder"):
            self.var_batch_subfolder.set(os.path.normpath(path))


# ══════════════════════════════════════════════════════════════════════════
# 8. update_timeout_labels
# ══════════════════════════════════════════════════════════════════════════

def update_timeout_labels(self, *args):
    """Refresh all timeout / worker-count display labels from slider values."""
    try:
        def format_seconds(val):
            if val >= 60:
                m = val // 60
                s = val % 60
                return f"{m}m {s:02d}s"
            return f"{val}s"

        if hasattr(self, "lbl_login_timeout") and hasattr(self, "var_timeout_login"):
            self.lbl_login_timeout.setText(format_seconds(self.var_timeout_login.get()))

        if hasattr(self, "lbl_pdf_timeout") and hasattr(self, "var_timeout_pdf"):
            self.lbl_pdf_timeout.setText(format_seconds(self.var_timeout_pdf.get()))

        if hasattr(self, "lbl_attachment_timeout") and hasattr(self, "var_timeout_attachment"):
            self.lbl_attachment_timeout.setText(format_seconds(self.var_timeout_attachment.get()))

        if hasattr(self, "lbl_xls_timeout") and hasattr(self, "var_timeout_xls"):
            self.lbl_xls_timeout.setText(format_seconds(self.var_timeout_xls.get()))

        if hasattr(self, "lbl_parallel_workers") and hasattr(self, "var_parallel_workers"):
            workers = self.var_parallel_workers.get()
            self.lbl_parallel_workers.setText(f"{workers} workers")
            if hasattr(self, "sw_parallel_sidebar"):
                self.sw_parallel_sidebar.setText(f"Multi-Worker Parallel Mode ({workers} Workers)")
            if hasattr(self, "opt_filter_worker"):
                worker_list = (
                    ["All", "Main"]
                    + [f"Worker {i}" for i in range(1, int(workers) + 1)]
                )
                current_val = self.opt_filter_worker.currentText()
                self.opt_filter_worker.blockSignals(True)
                self.opt_filter_worker.clear()
                self.opt_filter_worker.addItems(worker_list)
                if current_val in worker_list:
                    self.opt_filter_worker.setCurrentText(current_val)
                else:
                    self.opt_filter_worker.setCurrentText("All")
                self.opt_filter_worker.blockSignals(False)
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════
# 9. apply_theme_colors
# ══════════════════════════════════════════════════════════════════════════

def apply_theme_colors(self):
    """Regenerate QSS from qt_theme and re-apply to the entire application."""
    try:
        theme_name = "Emerald Teal (Dark)"
        if hasattr(self, "var_theme_accent"):
            theme_name = self.var_theme_accent.get()
            if theme_name not in THEMES:
                if theme_name == "Emerald Teal (Default)":
                    theme_name = "Emerald Teal (Dark)"
                else:
                    theme_name = "Emerald Teal (Dark)"

        qss = generate_qss(theme_name)
        from PySide6.QtWidgets import QApplication
        QApplication.instance().setStyleSheet(qss)
        # Refresh all custom-painted toggle switches with new theme colours
        update_all_toggles(self)
    except Exception as e:
        print(f"Error applying theme: {e}")

    # Update console tag colors
    if hasattr(self, "output_console_tag_colors"):
        try:
            self.output_console_tag_colors()
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════
# 10. make_scrollable_recursively  (No-op for Qt)
# ══════════════════════════════════════════════════════════════════════════

def make_scrollable_recursively(self, widget):
    """No-op in the PySide6 build — Qt handles scroll propagation natively."""
    pass
