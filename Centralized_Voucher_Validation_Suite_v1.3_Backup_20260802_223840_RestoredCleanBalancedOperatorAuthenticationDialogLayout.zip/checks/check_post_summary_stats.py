# checks/check_post_summary_stats.py
# Post-Download Batch Audit & VLC Mapping Preparation Check Plugin

import os
from checks.base_check import BaseValidationCheck

class CheckPostSummaryStats(BaseValidationCheck):
    check_id = "check_post_summary_stats"
    name = "Batch Post-Download Audit & VLC Data Mapping Check"
    description = "Executes batch-wide audit statistics, Major Head aggregation, missing document detection, and VLC data mapping preparation (Check 32 & Check 33)."
    check_type = "post_download"
    enabled = True

    def run_post_download(self, all_vouchers_data: list, output_dir: str, context: dict) -> dict:
        total_vouchers = len(all_vouchers_data)
        mh_summary = {}
        total_gross_amount = 0.0
        missing_docs_count = 0
        
        # VLC Mapping Counters for Check 32 & Check 33
        check32_labour_vouchers = []
        check33_aapda_vouchers = []

        rows = []

        for v in all_vouchers_data:
            v_no = str(v.get("voucher_no", ""))
            mh = str(v.get("mh", "Unknown")).strip()
            amt_str = str(v.get("amount", "0")).replace(",", "")
            try:
                amt = float(amt_str)
            except ValueError:
                amt = 0.0

            total_gross_amount += amt
            mh_summary[mh] = mh_summary.get(mh, 0) + 1

            # Check 32 (FVC Labour Payments) hook
            # Note per user rules: POL data lacks Detail_Head field and labour narration keywords; VLC data mapping enriches this.
            if "2245" in mh or "labour" in str(v.get("narration", "")).lower() or "mazdoor" in str(v.get("narration", "")).lower():
                check32_labour_vouchers.append(v_no)

            # Check 33 (MH 2245 Aapda Payments) hook
            # Note per user rules: POL data lacks scheme head codes; VLC data mapping provides scheme-wise & detail-wise classification.
            if mh == "2245":
                check33_aapda_vouchers.append(v_no)

            folder = v.get("folder_path", "")
            has_files = os.path.exists(folder) and len(os.listdir(folder)) > 0 if folder else False
            if not has_files:
                missing_docs_count += 1

            rows.append({
                "Voucher_No": v_no,
                "Treasury": v.get("treasury", ""),
                "Major_Head": mh,
                "Amount": amt,
                "DDO_Code": v.get("ddo", ""),
                "Has_Downloaded_Files": "YES" if has_files else "NO",
                "Check_32_Labour_Candidate": "YES" if v_no in check32_labour_vouchers else "NO",
                "Check_33_MH2245_Aapda": "YES" if v_no in check33_aapda_vouchers else "NO"
            })

        msg = (f"Batch Audit Complete: {total_vouchers} vouchers analyzed. "
               f"Total Claim: ₹{total_gross_amount:,.2f}. "
               f"Missing Attachments: {missing_docs_count}. "
               f"Check 32 (Labour): {len(check32_labour_vouchers)} candidates, "
               f"Check 33 (MH 2245): {len(check33_aapda_vouchers)} candidates.")

        return {
            "status": "COMPLETED",
            "message": msg,
            "rows": rows,
            "summary_stats": {
                "total_vouchers": total_vouchers,
                "total_gross_amount": total_gross_amount,
                "missing_docs_count": missing_docs_count,
                "check32_candidates": len(check32_labour_vouchers),
                "check33_candidates": len(check33_aapda_vouchers),
                "mh_distribution": mh_summary
            }
        }
