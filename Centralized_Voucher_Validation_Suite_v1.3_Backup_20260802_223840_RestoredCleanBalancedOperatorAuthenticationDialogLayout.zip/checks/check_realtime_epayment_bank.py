import os
import glob
from checks.base_check import BaseValidationCheck
from parsers.party_details_parser import parse_party_details_pdf


class EPaymentBankCheck(BaseValidationCheck):
    check_id = "check_realtime_epayment_bank"
    name = "E-Payment Bank Account Verification Check"
    description = "Verifies each party has non-empty account_no, ifsc_code, party_name for e-payment."
    check_type = "realtime"
    enabled = True

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        try:
            party_pdf = os.path.join(download_folder, "Party_Details.pdf")
            if not os.path.exists(party_pdf):
                party_pdfs = glob.glob(os.path.join(download_folder, "bill_party_*.pdf"))
                if party_pdfs:
                    party_pdf = party_pdfs[0]
                else:
                    return {"status": "SKIPPED", "message": "No party details PDF found", "details": {}}

            parsed = parse_party_details_pdf(party_pdf)
            parties = parsed.parties  # list of dicts

            if not parties:
                return {"status": "SKIPPED", "message": "No parties parsed from PDF", "details": {"bill_ref": parsed.bill_ref_no}}

            all_complete = True
            missing_details = []

            for party in parties:
                acc_no = str(party.get("account_no", "")).strip()
                ifsc = str(party.get("ifsc_code", "")).strip()
                name = str(party.get("party_name", "")).strip()

                if not acc_no or not ifsc or not name:
                    all_complete = False
                    if not acc_no and not ifsc and not name:
                        return {"status": "FAIL", "message": "Critical bank details missing for e-payment", "details": {"party": party}}
                    missing_details.append({"party_name": name, "missing_account": not acc_no, "missing_ifsc": not ifsc})

            if all_complete:
                return {"status": "PASS", "message": "All parties have complete bank details", "details": {"parties_count": len(parties)}}
            else:
                return {"status": "WARNING", "message": "Some parties missing partial bank details", "details": {"missing_details": missing_details}}

        except Exception as e:
            return {"status": "FAIL", "message": "Error during check: %s" % str(e), "details": {}}
