import time
# checks/check_realtime_duplicate_amount.py
# Realtime Duplicate Amount & Attachment Check Plugin

import os
from checks.base_check import BaseValidationCheck
from automation.duplicate_detector import catalog_voucher_attachments

class CheckRealtimeDuplicateAmount(BaseValidationCheck):
    check_id = "check_realtime_duplicate_amount"
    name = "Duplicate Amount & Attachment Check"
    description = "Real-time verification of voucher amount & attachment hashes (MD5) to detect double payments."
    check_type = "realtime"
    enabled = True

    def __init__(self):
        self.seen_vouchers = []  # list of {meta, attachments}

    def run_realtime(self, voucher_data: dict, download_folder: str, context: dict) -> dict:
        voucher_no = str(voucher_data.get("voucher_no", "")).strip()
        amount = str(voucher_data.get("amount", "")).strip()
        
        if not download_folder or not os.path.exists(download_folder):
            return {
                "status": "PASS",
                "message": "No download folder available for attachment cataloging.",
                "details": {}
            }

        # Catalog attachments for current voucher
        attachments = catalog_voucher_attachments(download_folder, voucher_data)
        
        matches = []
        for prev in self.seen_vouchers:
            prev_meta = prev["meta"]
            prev_att = prev["attachments"]
            
            # Check matching amount
            if prev_meta.get("amount") == amount and amount:
                # Compare attachment MD5 hashes
                matching_files = []
                for cur_a in attachments:
                    for prev_a in prev_att:
                        if cur_a.md5 and cur_a.md5 == prev_a.md5:
                            matching_files.append({
                                "file_cur": cur_a.filename,
                                "file_prev": prev_a.filename,
                                "md5": cur_a.md5
                            })

                if matching_files:
                    matches.append({
                        "prev_voucher": prev_meta.get("voucher_no"),
                        "prev_treasury": prev_meta.get("treasury"),
                        "matching_files": matching_files
                    })

        # Save to seen list
        self.seen_vouchers.append({
            "meta": voucher_data,
            "attachments": attachments
        })

        if matches:
            prev_vchs = ", ".join([m['prev_voucher'] for m in matches])
            return {
                "status": "SUSPICIOUS",
                "message": f"Potential Duplicate Payment! Shares identical attachment MD5 hash with Voucher(s): {prev_vchs}",
                "details": {"matches": matches}
            }

        return {
            "status": "PASS",
            "message": f"No duplicate attachment matches detected across {len(self.seen_vouchers)} processed vouchers.",
            "details": {"attachments_count": len(attachments)}
        }
