"""checkable_combo.py - PySide6 Checkable Multi-Select ComboBox for Centralized Voucher Validation Suite.

Allows selecting multiple items (such as Treasuries) with checkboxes, 'Select All',
'Ok', and 'Cancel' controls inside the dropdown view.
"""

from PySide6.QtWidgets import QComboBox, QWidget, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt, QEvent
from PySide6.QtGui import QFont


class CheckableComboBox(QComboBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.view().installEventFilter(self)
        self.view().viewport().installEventFilter(self)
        self._block_signals = False
        self.model().dataChanged.connect(self.on_data_changed)
        self._changed = False
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        
        font = QFont("Segoe UI", 10)
        self.setFont(font)
        self.lineEdit().setFont(font)
        self.lineEdit().installEventFilter(self)
        
        # OK and Cancel buttons in the popup view
        self.button_widget = QWidget(self.view())
        btn_layout = QHBoxLayout(self.button_widget)
        btn_layout.setContentsMargins(6, 4, 6, 4)
        btn_layout.setSpacing(6)
        
        self.btn_ok = QPushButton("OK", self.button_widget)
        self.btn_ok.setFixedHeight(24)
        self.btn_ok.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        self.btn_ok.clicked.connect(self.on_ok_clicked)
        
        self.btn_cancel = QPushButton("Cancel", self.button_widget)
        self.btn_cancel.setFixedHeight(24)
        self.btn_cancel.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        self.btn_cancel.clicked.connect(self.on_cancel_clicked)
        
        btn_layout.addWidget(self.btn_ok)
        btn_layout.addWidget(self.btn_cancel)
        
        self.button_widget.setStyleSheet("""
            QWidget {
                background-color: #1a222d;
                border-top: 1px solid #2a3444;
            }
            QPushButton {
                background-color: #0d9488;
                color: white;
                border: 1px solid #14b8a6;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #14b8a6;
            }
            QPushButton:pressed {
                background-color: #0f766e;
            }
        """)
        self.button_widget.hide()
        self.update_display_text()

    def addItem(self, text, data=None):
        super().addItem(text, data)
        item = self.model().item(self.count() - 1)
        if item:
            item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            item.setCheckState(Qt.Unchecked)

    def addItems(self, texts):
        for text in texts:
            self.addItem(text)

    def eventFilter(self, widget, event):
        if widget == self.lineEdit():
            if event.type() == QEvent.MouseButtonPress:
                return True
            elif event.type() == QEvent.MouseButtonRelease:
                if not self.view().isVisible():
                    self.showPopup()
                else:
                    self.hidePopup()
                return True
        elif widget == self.view():
            if event.type() in [QEvent.Resize, QEvent.Show]:
                if hasattr(self, 'button_widget') and self.button_widget:
                    view_width = self.view().width()
                    view_height = self.view().height()
                    btn_height = 32
                    self.view().setViewportMargins(0, 0, 0, btn_height)
                    self.button_widget.setGeometry(0, view_height - btn_height, view_width, btn_height)
                    self.button_widget.raise_()
        elif widget == self.view().viewport():
            if event.type() == QEvent.MouseButtonPress:
                self._changed = True
            elif event.type() == QEvent.MouseButtonRelease:
                index = self.view().indexAt(event.pos())
                item = self.model().itemFromIndex(index)
                if item:
                    new_state = Qt.Unchecked if item.checkState() == Qt.Checked else Qt.Checked
                    item.setCheckState(new_state)
                return True
        return super().eventFilter(widget, event)

    def showPopup(self):
        super().showPopup()
        if hasattr(self, 'button_widget') and self.button_widget:
            self.button_widget.show()
            self.button_widget.raise_()

    def hidePopup(self):
        super().hidePopup()
        if hasattr(self, 'button_widget') and self.button_widget:
            self.button_widget.hide()

    def on_ok_clicked(self):
        self.update_display_text()
        self.hidePopup()

    def on_cancel_clicked(self):
        self._block_signals = True
        try:
            for i in range(self.count()):
                item = self.model().item(i)
                if item:
                    item.setCheckState(Qt.Unchecked)
        finally:
            self._block_signals = False
        self.update_display_text()
        self.hidePopup()

    def on_data_changed(self, topLeft, bottomRight, roles):
        if self._block_signals:
            return
        
        if Qt.CheckStateRole in roles or not roles:
            self._block_signals = True
            try:
                changed_row = topLeft.row()
                if changed_row == 0 and self.itemText(0) == "Select All":
                    state = self.model().item(0).checkState()
                    for i in range(1, self.count()):
                        item = self.model().item(i)
                        if item:
                            item.setCheckState(state)
                    self._block_signals = False
                    self.update_display_text()
                    self.hidePopup()
                    return
                else:
                    if self.itemText(0) == "Select All":
                        select_all_item = self.model().item(0)
                        if select_all_item:
                            all_checked = True
                            for i in range(1, self.count()):
                                item = self.model().item(i)
                                if item and item.checkState() == Qt.Unchecked:
                                    all_checked = False
                                    break
                            select_all_item.setCheckState(Qt.Checked if all_checked else Qt.Unchecked)
            finally:
                self._block_signals = False
            
            self.update_display_text()

    def update_display_text(self):
        checked = []
        start_idx = 1 if (self.count() > 0 and self.itemText(0) == "Select All") else 0
        for i in range(start_idx, self.count()):
            item = self.model().item(i)
            if item and item.checkState() == Qt.Checked:
                checked.append(item.text())
                
        if self.count() > 0 and self.itemText(0) == "Select All" and self.model().item(0).checkState() == Qt.Checked:
            self.setEditText("Select All")
        elif not checked:
            self.setEditText("Select Treasury")
        elif len(checked) <= 3:
            self.setEditText(", ".join(checked))
        else:
            self.setEditText(f"{len(checked)} Treasuries Selected")

    def checkedItems(self):
        items = []
        start_idx = 1 if (self.count() > 0 and self.itemText(0) == "Select All") else 0
        for i in range(start_idx, self.count()):
            item = self.model().item(i)
            if item and item.checkState() == Qt.Checked:
                data_val = item.data(Qt.UserRole)
                items.append(data_val if data_val else item.text())
        return items
