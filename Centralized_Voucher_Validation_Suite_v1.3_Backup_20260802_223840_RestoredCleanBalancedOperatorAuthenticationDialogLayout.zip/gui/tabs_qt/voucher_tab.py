from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QFrame,
    QPushButton, QLabel, QCheckBox, QLineEdit)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from gui.toggle_switch import ToggleSwitch

def build_voucher_tab(app, tab):
    """Build the Voucher tab - exact 1:1 clone of CTk version."""
    layout = QVBoxLayout(tab)
    layout.setContentsMargins(10, 5, 10, 5)

    # Info label
    app.lbl_voucher_info = QLabel(
        "📥 Voucher Downloader (Chromium Engine)\n"
        "Extracts Show MPTC PDF, Party Details PDF, Attachments & optional Paybill Excel reports.")
    app.lbl_voucher_info.setFont(QFont("Segoe UI", 11))
    # Make italic via font
    font = app.lbl_voucher_info.font()
    font.setItalic(True)
    app.lbl_voucher_info.setFont(font)
    app.lbl_voucher_info.setAlignment(Qt.AlignCenter)
    app.lbl_voucher_info.setWordWrap(True)
    app.lbl_voucher_info.setProperty("cssClass", "muted")
    layout.addWidget(app.lbl_voucher_info)

    # File selection card (Clean 2-Column Grid Layout)
    app.voucher_file_box = QFrame()
    app.voucher_file_box.setProperty("cssClass", "card")
    file_layout = QVBoxLayout(app.voucher_file_box)
    file_layout.setContentsMargins(16, 12, 16, 12)
    file_layout.setSpacing(10)

    card_header = QLabel("📁 VOUCHER LIST & COMPAY CLASSIFICATION DATASET")
    card_header.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
    card_header.setStyleSheet("color: #38bdf8; font-weight: 700; letter-spacing: 0.5px;")
    file_layout.addWidget(card_header)

    # 2-Column Grid Row
    from PySide6.QtWidgets import QGridLayout
    pickers_grid = QGridLayout()
    pickers_grid.setSpacing(10)

    # Left Column: Voucher Excel (Required - Primary Step 1)
    col_left = QVBoxLayout()
    col_left.setSpacing(6)
    app.btn_voucher_excel = QPushButton("STEP 1: 📂 Browse Voucher Excel (Required)")
    app.btn_voucher_excel.setFixedHeight(48)
    app.btn_voucher_excel.setCursor(Qt.PointingHandCursor)
    app.btn_voucher_excel.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
    app.btn_voucher_excel.setStyleSheet("""
        QPushButton {
            background-color: #1e293b;
            color: #00c9a7;
            border: 2px solid #00c9a7;
            border-radius: 10px;
            font-weight: 800;
            padding: 8px 16px;
        }
        QPushButton:hover {
            background-color: rgba(0, 201, 167, 0.15);
            border: 2px solid #00e5bf;
            color: #00e5bf;
        }
    """)
    app.btn_voucher_excel.clicked.connect(lambda: app.pick_excel_file("voucher"))
    col_left.addWidget(app.btn_voucher_excel)

    app.lbl_voucher_excel = QLabel("⚠️ STEP 1: Please select a Voucher List Excel file")
    app.lbl_voucher_excel.setStyleSheet("color: #f59e0b; font-size: 11px; font-weight: 700; background-color: rgba(245, 158, 11, 0.1); padding: 4px 8px; border-radius: 6px;")
    app.lbl_voucher_excel.setAlignment(Qt.AlignCenter)
    col_left.addWidget(app.lbl_voucher_excel)
    pickers_grid.addLayout(col_left, 0, 0)

    # Right Column: COMPAY / VLC CSV (Optional - Step 2)
    col_right = QVBoxLayout()
    col_right.setSpacing(6)
    app.btn_vlc_compay_opt = QPushButton("STEP 2: 🔗 Browse COMPAY / VLC CSV (Optional)")
    app.btn_vlc_compay_opt.setFixedHeight(48)
    app.btn_vlc_compay_opt.setCursor(Qt.PointingHandCursor)
    app.btn_vlc_compay_opt.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
    app.btn_vlc_compay_opt.setStyleSheet("""
        QPushButton {
            background-color: #1e293b;
            color: #3b82f6;
            border: 1.5px solid #334155;
            border-radius: 10px;
            font-weight: 800;
            padding: 8px 16px;
        }
        QPushButton:hover {
            background-color: rgba(59, 130, 246, 0.15);
            border: 1.5px solid #60a5fa;
            color: #60a5fa;
        }
    """)
    app.btn_vlc_compay_opt.clicked.connect(lambda: app.pick_vlc_compay_file())
    col_right.addWidget(app.btn_vlc_compay_opt)

    app.lbl_vlc_compay_opt = QLabel("ℹ️ STEP 2: Optional COMPAY CSV for advanced VLC audit")
    app.lbl_vlc_compay_opt.setStyleSheet("color: #94a3b8; font-size: 11px; font-weight: 600; background-color: rgba(148, 163, 184, 0.1); padding: 4px 8px; border-radius: 6px;")
    app.lbl_vlc_compay_opt.setAlignment(Qt.AlignCenter)
    col_right.addWidget(app.lbl_vlc_compay_opt)
    pickers_grid.addLayout(col_right, 0, 1)

    file_layout.addLayout(pickers_grid)

    # Bottom Toolbar: Execute Linking Button (Full Width)
    app.btn_execute_vlc_link = QPushButton("⚡ Execute VLC-COMPAY Linking Now")
    app.btn_execute_vlc_link.setProperty("cssClass", "primary")
    app.btn_execute_vlc_link.setFixedHeight(34)
    app.btn_execute_vlc_link.clicked.connect(lambda: app.execute_vlc_linking_interactive())
    file_layout.addWidget(app.btn_execute_vlc_link)

    layout.addWidget(app.voucher_file_box)

    # Batch folder row
    batch_frame = QFrame()
    batch_layout = QHBoxLayout(batch_frame)
    batch_layout.setContentsMargins(0, 0, 0, 0)

    lbl_batch = QLabel("Batch Folder Name (Optional):")
    lbl_batch.setFont(QFont("Segoe UI", 11))
    batch_layout.addWidget(lbl_batch)

    app.entry_voucher_batch_folder = QLineEdit()
    app.entry_voucher_batch_folder.setPlaceholderText("e.g., MH_2235_Run1")
    app.entry_voucher_batch_folder.setFixedHeight(30)
    if hasattr(app, 'var_batch_subfolder'):
        app.var_batch_subfolder.bind_to_widget(app.entry_voucher_batch_folder)
    batch_layout.addWidget(app.entry_voucher_batch_folder, 1)

    btn_batch_browse = QPushButton("Browse...")
    btn_batch_browse.setProperty("cssClass", "outline")
    btn_batch_browse.setFixedSize(85, 30)
    btn_batch_browse.clicked.connect(app.browse_batch_subfolder)
    batch_layout.addWidget(btn_batch_browse)

    layout.addWidget(batch_frame)

    # Action buttons
    btn_frame = QFrame()
    btn_layout = QHBoxLayout(btn_frame)
    btn_layout.setContentsMargins(0, 0, 0, 0)

    app.btn_voucher_start = QPushButton("▶ Start Validation")
    app.btn_voucher_start.setFixedHeight(44)
    app.btn_voucher_start.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
    app.btn_voucher_start.setCursor(Qt.PointingHandCursor)
    app.btn_voucher_start.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00c9a7, stop:1 #008060);
            color: #0f172a;
            border: none;
            border-radius: 10px;
            font-weight: 800;
            font-size: 13px;
            letter-spacing: 0.5px;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00e5bf, stop:1 #00c9a7);
        }
    """)
    app.btn_voucher_start.clicked.connect(lambda: app.start_thread("voucher", run_failed=False))
    btn_layout.addWidget(app.btn_voucher_start)

    app.btn_voucher_retry = QPushButton("🔁 Retry Failed Only")
    app.btn_voucher_retry.setProperty("cssClass", "secondary")
    app.btn_voucher_retry.setFixedHeight(30)
    app.btn_voucher_retry.clicked.connect(lambda: app.start_thread("voucher", run_failed=True))
    btn_layout.addWidget(app.btn_voucher_retry)

    app.btn_voucher_open_folder = QPushButton("📂 Open Downloads Folder")
    app.btn_voucher_open_folder.setProperty("cssClass", "outline")
    app.btn_voucher_open_folder.setFixedHeight(30)
    app.btn_voucher_open_folder.clicked.connect(lambda: app.open_downloads_folder())
    btn_layout.addWidget(app.btn_voucher_open_folder)

    app.btn_voucher_stop = QPushButton("🛑 Stop Safely")
    app.btn_voucher_stop.setProperty("cssClass", "danger")
    app.btn_voucher_stop.setFixedHeight(30)
    app.btn_voucher_stop.clicked.connect(app.request_stop)
    btn_layout.addWidget(app.btn_voucher_stop)

    layout.addWidget(btn_frame)
