def hide_process_window(pid):
    """Hide top-level window for a PID on Windows to remove Taskbar icon completely."""
    if sys.platform != "win32" or not pid:
        return
    try:
        import ctypes
        user32 = ctypes.windll.user32
        
        def EnumWindowsProc(hwnd, lParam):
            process_id = ctypes.c_ulong()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
            if process_id.value == pid:
                user32.ShowWindow(hwnd, 0)  # 0 = SW_HIDE
            return True

        WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
        user32.EnumWindows(WNDENUMPROC(EnumWindowsProc), 0)
    except Exception:
        pass

def kill_process_tree(pid):
    """Forcefully terminates a process and all its child subprocesses on Windows."""
    if not pid:
        return
    if sys.platform == "win32":
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=0x08000000
            )
        except Exception:
            pass
    else:
        try:
            os.kill(int(pid), 9)
        except Exception:
            pass

import os
import sys
import re
import time
import socket
import urllib.request
import urllib.parse
import subprocess
import shutil
import base64
import ctypes
import ctypes.wintypes
from playwright.sync_api import sync_playwright

if sys.platform == "win32":
    import win32gui
    import win32con
    import win32process
    
    TH32CS_SNAPPROCESS = 0x00000002
    
    class PROCESSENTRY32(ctypes.Structure):
        _fields_ = [
            ("pe_size", ctypes.wintypes.DWORD),
            ("cntUsage", ctypes.wintypes.DWORD),
            ("th32ProcessID", ctypes.wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.c_void_p),
            ("th32ModuleID", ctypes.wintypes.DWORD),
            ("cntThreads", ctypes.wintypes.DWORD),
            ("th32ParentProcessID", ctypes.wintypes.DWORD),
            ("pcPriClassBase", ctypes.wintypes.LONG),
            ("dwFlags", ctypes.wintypes.DWORD),
            ("szExeFile", ctypes.c_char * 260)
        ]

    def get_parent_pid(pid):
        pe = PROCESSENTRY32()
        pe.pe_size = ctypes.sizeof(pe)
        kernel32 = ctypes.windll.kernel32
        hSnapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        if hSnapshot == -1:
            return None
        try:
            if kernel32.Process32First(hSnapshot, ctypes.byref(pe)):
                while True:
                    if pe.th32ProcessID == pid:
                        return pe.th32ParentProcessID
                    if not kernel32.Process32Next(hSnapshot, ctypes.byref(pe)):
                        break
        finally:
            kernel32.CloseHandle(hSnapshot)
        return None

    def is_descendant(pid, ancestor_pid):
        curr = pid
        visited = set()
        for _ in range(10): # Limit ancestry depth to 10
            if curr in visited or curr == 0:
                break
            visited.add(curr)
            ppid = get_parent_pid(curr)
            if ppid == ancestor_pid:
                return True
            curr = ppid
        return False
else:
    def is_descendant(pid, ancestor_pid):
        return False

def _apply_stealth_mode_if_enabled(self):
    if not hasattr(self, "var_stealth") or not self.var_stealth.get() or sys.platform != "win32":
        return
    self.set_browser_visibility(False)


def toggle_browser_visibility(self):
    if not self.playwright:
        self.log("⚠️ Playwright driver not active. Start task first.")
        return
        
    driver_pid = None
    try:
        driver_pid = self.playwright._impl_obj._connection._transport._proc.pid
    except Exception:
        pass

    action_text = "showing" if self.browser_hidden else "hiding"
    cmd_show = win32con.SW_SHOW if self.browser_hidden else win32con.SW_HIDE

    try:
        def window_enum_callback(hwnd, _lParam):
            _, win_pid = win32process.GetWindowThreadProcessId(hwnd)
            title = win32gui.GetWindowText(hwnd).lower()
            
            # Check either PID descendant (precise) or fallback to window title
            match = False
            if driver_pid and is_descendant(win_pid, driver_pid):
                match = True
            elif any(x in title for x in ["firefox", "chromium", "ifms", "chrome", "edge"]):
                # Title matches only if direct PID check failed
                if not driver_pid:
                    match = True
                    
            if match:
                win32gui.ShowWindow(hwnd, cmd_show)
            return True
            
        win32gui.EnumWindows(window_enum_callback, None)
        self.browser_hidden = not self.browser_hidden
        self.log(f"🕵️ Browser visibility toggle: {action_text} browser window.")
    except Exception as e:
        self.log(f"⚠️ Failed to toggle browser visibility: {e}")

def set_browser_visibility(self, visible):
    if sys.platform != "win32":
        return
        
    driver_pid = None
    try:
        if hasattr(self, "playwright") and self.playwright:
            driver_pid = self.playwright._impl_obj._connection._transport._proc.pid
    except Exception:
        pass

    import win32gui
    import win32con
    import win32process
    
    cmd_show = win32con.SW_SHOW if visible else win32con.SW_HIDE
    target_titles = ["ifms", "chrome", "chromium", "firefox", "edge", "about:blank", "untitled", "paymentorderlist"]
    
    try:
        def window_enum_callback(hwnd, _lParam):
            title = win32gui.GetWindowText(hwnd).lower()
            _, win_pid = win32process.GetWindowThreadProcessId(hwnd)
            
            match = False
            if driver_pid and (win_pid == driver_pid or is_descendant(win_pid, driver_pid)):
                match = True
            elif any(x in title for x in target_titles):
                if "centralized" not in title and "validation" not in title and "suite" not in title and "ag(" not in title:
                    match = True
                    
            if match:
                win32gui.ShowWindow(hwnd, cmd_show)
            return True
            
        win32gui.EnumWindows(window_enum_callback, None)
        self.browser_hidden = not visible
    except Exception as e:
        self.log(f"⚠️ Failed to set browser visibility: {e}")


def find_browser_in_registry(browser_name):
    if sys.platform != "win32":
        return None
    import winreg
    sub_key = r"Software\Microsoft\Windows\CurrentVersion\App Paths\\" + ("chrome.exe" if "chrome" in browser_name or "chromium" in browser_name else "firefox.exe")
    for hkey in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
        try:
            key = winreg.OpenKey(hkey, sub_key)
            val, _ = winreg.QueryValue(key, None)
            winreg.CloseKey(key)
            if val and os.path.exists(val):
                return val
        except Exception:
            pass
    return None

def resolve_browser_path(self, browser_name):
    import json
    config_path = os.path.join(self.base_path, "config.json")
    custom_key = "custom_chrome_path" if "chrome" in browser_name or "chromium" in browser_name else "custom_firefox_path"
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                custom_path = cfg.get(custom_key)
                if custom_path and os.path.exists(custom_path):
                    return custom_path
        except Exception:
            pass

    # Playwright cannot launch/control standard system Firefox installations
    # because they lack Juggler protocol support. Only fall back to system
    # installations or prompt manual location for Chrome/Chromium.
    if "chrome" in browser_name or "chromium" in browser_name:
        reg_path = find_browser_in_registry(browser_name)
        if reg_path:
            return reg_path

        typical_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
        ]

        for path in typical_paths:
            if os.path.exists(path):
                return path

        # If Chrome still not found, prompt user via popup dialog
        self.log(f"⚠️ Browser {browser_name} not found in system paths. Requesting manual locator...")
        selected_path = None
        import queue
        q = queue.Queue()
        
        def ask_user():
            from PySide6.QtWidgets import QMessageBox, QFileDialog
            title = f"Locate {browser_name.capitalize()} Executable File"
            msg = f"Centralized Voucher Validation Suite could not automatically locate {browser_name.capitalize()}.\n\nDo you want to manually locate the executable file?"
            if QMessageBox.question(self, "Browser Missing", msg, QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes:
                path, _ = QFileDialog.getOpenFileName(self, title, "", "Executable files (*.exe);;All files (*.*)")
                q.put(path if path else None)
            else:
                q.put(None)
                
        if hasattr(self, "safe_after"):
            self.safe_after(0, ask_user)
        else:
            try:
                from PySide6.QtCore import QMetaObject, Qt, Q_ARG
                QMetaObject.invokeMethod(self, "_ask_user_gui", Qt.QueuedConnection)
            except Exception:
                pass
        try:
            selected_path = q.get(timeout=60)
        except queue.Empty:
            pass

        if selected_path and os.path.exists(selected_path):
            try:
                cfg = {}
                if os.path.exists(config_path):
                    with open(config_path, "r", encoding="utf-8") as f:
                        cfg = json.load(f)
                cfg[custom_key] = selected_path
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump(cfg, f, indent=4)
            except Exception:
                pass
            return selected_path

    return None

def _launch_browser(self, browser_name, **kwargs):
    """
    Launches Playwright browser with robust fallback to system-wide default path
    and auto-installation if the local/offline executable is missing or fails to launch.
    """
    max_retries = 3
    if not getattr(self, "playwright", None):
        self.log("🔄 Playwright driver not active. Initializing new driver instance...")
        from playwright.sync_api import sync_playwright
        self.playwright = sync_playwright().start()
        
    launcher = getattr(self.playwright, browser_name)
    err_msg = ""

    # Check if we should resolve browser path
    if "executable_path" not in kwargs:
        # Step 1: Check system-installed browser first (Chrome/Chromium)
        resolved = resolve_browser_path(self, browser_name)
        if resolved:
            self.log(f"🌐 Launching browser ({browser_name.capitalize()}) at: {resolved}")
            system_kwargs = kwargs.copy()
            system_kwargs["executable_path"] = resolved
            if "chrome" in browser_name or "chromium" in browser_name:
                system_kwargs["channel"] = "chrome"
            for attempt in range(1, max_retries + 1):
                try:
                    return launcher.launch(**system_kwargs)
                except Exception as e:
                    err_msg = str(e)
                    if attempt == max_retries:
                        self.log(f"⚠️ System-installed browser launch failed ({err_msg.splitlines()[0][:60]}). Trying bundled browser...")
                        break
                    time.sleep(1.0)

        # Step 2: Try dedicated Playwright browser (under PLAYWRIGHT_BROWSERS_PATH)
        self.log(f"🌐 Attempting to launch dedicated Playwright browser ({browser_name.capitalize()})...")
        for attempt in range(1, max_retries + 1):
            try:
                return launcher.launch(**kwargs)
            except Exception as e:
                err_msg = str(e)
                if attempt == max_retries:
                    self.log(f"⚠️ Dedicated Playwright browser launch failed: {err_msg.splitlines()[0][:60]}")
                    break
                time.sleep(1.0)
    else:
        # If executable_path was explicitly passed, use it directly
        for attempt in range(1, max_retries + 1):
            try:
                return launcher.launch(**kwargs)
            except Exception as e:
                err_msg = str(e)
                if attempt == max_retries:
                    self.log(f"⚠️ Explicit browser launch failed: {err_msg.splitlines()[0][:100]}")
                    break
                self.log(f"⚠️ Explicit browser launch attempt {attempt} failed. Retrying in 1.5s...")
                time.sleep(1.5)

    # Step 3: Fallback system-wide (remove PLAYWRIGHT_BROWSERS_PATH environment variable)
    if "PLAYWRIGHT_BROWSERS_PATH" in os.environ:
        self.log("🔄 Dedicated local browser path failed. Removing PLAYWRIGHT_BROWSERS_PATH and retrying system-wide...")
        old_path = os.environ.pop("PLAYWRIGHT_BROWSERS_PATH", None)
        try:
            self.playwright.stop()
        except Exception:
            pass
        try:
            self.playwright = sync_playwright().start()
            launcher2 = getattr(self.playwright, browser_name)
            
            for attempt in range(1, max_retries + 1):
                try:
                    return launcher2.launch(**kwargs)
                except Exception as e2:
                    err_msg = str(e2)
                    if attempt == max_retries:
                        self.log(f"⚠️ System-wide browser launch also failed after {max_retries} attempts: {err_msg.splitlines()[0][:100]}")
                        raise e2
                    self.log(f"⚠️ System-wide browser launch attempt {attempt} failed. Retrying in 1.5s...")
                    time.sleep(1.5)
        except Exception as e2:
            # Restore path for other components
            if old_path:
                os.environ["PLAYWRIGHT_BROWSERS_PATH"] = old_path
                try: self.playwright.stop()
                except: pass
                try: self.playwright = sync_playwright().start()
                except: pass

        # Step 4: Try automatic browser installation
        is_path_issue = "executable" in err_msg.lower() or "exist" in err_msg.lower() or "find" in err_msg.lower()
        if is_path_issue:
            self.log("📥 Browser binaries appear to be missing. Attempting automatic online installation...")
            try:
                import shutil
                from playwright._impl._driver import compute_driver_executable, get_driver_env
                driver_executable, driver_cli = compute_driver_executable()
                
                env = get_driver_env()
                local_install = False
                if "PLAYWRIGHT_BROWSERS_PATH" in os.environ:
                    env["PLAYWRIGHT_BROWSERS_PATH"] = os.environ["PLAYWRIGHT_BROWSERS_PATH"]
                    local_install = True
                
                # Clean up local path if it is invalid
                if local_install and "PLAYWRIGHT_BROWSERS_PATH" in os.environ:
                    local_path = os.environ["PLAYWRIGHT_BROWSERS_PATH"]
                    if os.path.isdir(local_path):
                        for item in os.listdir(local_path):
                            if item.lower().startswith(browser_name.lower() + "-"):
                                item_path = os.path.join(local_path, item)
                                self.log(f"🧹 Removing incomplete/invalid local browser directory: {item_path}")
                                shutil.rmtree(item_path, ignore_errors=True)
                
                self.log(f"⏳ Downloading and installing Playwright {browser_name} (please wait, internet required)...")
                res = subprocess.run([driver_executable, driver_cli, "install", browser_name], env=env, capture_output=True, text=True)
                if res.returncode == 0:
                    self.log("Peeking new install... Retrying launch...")
                    try: self.playwright.stop()
                    except: pass
                    try:
                        self.playwright = sync_playwright().start()
                        launcher3 = getattr(self.playwright, browser_name)
                        return launcher3.launch(**kwargs)
                    except Exception as launch_err:
                        self.log(f"❌ Failed to launch browser even after local installation: {launch_err}")
                else:
                    self.log(f"❌ Playwright local install returned exit code {res.returncode}. Stderr: {res.stderr.strip()[:150]}")
                    
                    if local_install:
                        self.log("🔄 Retrying installation in system-wide mode...")
                        if "PLAYWRIGHT_BROWSERS_PATH" in env:
                            del env["PLAYWRIGHT_BROWSERS_PATH"]
                        
                        default_path = os.path.expandvars(r"%USERPROFILE%\AppData\Local\ms-playwright")
                        if os.path.isdir(default_path):
                            for item in os.listdir(default_path):
                                if item.lower().startswith(browser_name.lower() + "-"):
                                    item_path = os.path.join(default_path, item)
                                    self.log(f"🧹 Removing incomplete/invalid system-wide browser directory: {item_path}")
                                    shutil.rmtree(item_path, ignore_errors=True)
                                    
                        res2 = subprocess.run([driver_executable, driver_cli, "install", browser_name], env=env, capture_output=True, text=True)
                        if res2.returncode == 0:
                            self.log("✅ Playwright system-wide browser installed successfully! Retrying launch...")
                            try: self.playwright.stop()
                            except: pass
                            try:
                                self.playwright = sync_playwright().start()
                                launcher4 = getattr(self.playwright, browser_name)
                                return launcher4.launch(**kwargs)
                            except Exception as e3:
                                self.log(f"❌ Failed to launch browser even after system-wide installation: {e3}")
                        else:
                            self.log(f"❌ Playwright system-wide install returned exit code {res2.returncode}. Stderr: {res2.stderr.strip()[:150]}")
            except Exception as ex:
                self.log(f"❌ Automatic browser downloader crashed: {ex}")
                
    raise Exception("Failed to launch Playwright browser. Please verify installation.")

def _launch_browser_with_failover(self, use_chrome):
    browser_name = "chromium" if use_chrome else "firefox"
    # Determine headless status based on stealth mode toggle
    stealth_active = getattr(self, "var_stealth", None) and self.var_stealth.get()
    headless_run = True if stealth_active else False
    
    # Launch parameters
    kwargs = {"headless": headless_run}
    if not use_chrome:
        kwargs["firefox_user_prefs"] = {
            "network.trr.mode": 5,
            "network.dns.disableIPv6": True,
            "widget.windows.window_occlusion_tracking.enabled": False,
            "dom.min_background_timeout_value": 10000,
            "privacy.reduceTimerPrecision": False,
            "network.proxy.type": 5,
            "network.proxy.no_proxies_on": "localhost, 127.0.0.1, .mptreasury.gov.in, mptreasury.gov.in"
        }
    if use_chrome:
        if kwargs.get("headless", False):
            kwargs["args"] = [
                "--headless=new",
                "--disable-gpu",
                "--no-sandbox",
                "--disable-backgrounding-occluded-windows",
                "--disable-background-timer-throttling",
                "--disable-renderer-backgrounding",
                "--disable-background-networking",
                "--window-position=-2400,-2400",
                "--window-size=10,10", "--disable-gpu", "--disable-software-rasterizer", "--log-level=3", "--silent", "--no-first-run"
            ]
        else:
            kwargs["args"] = [
                "--start-maximized",
                "--disable-backgrounding-occluded-windows",
                "--disable-background-timer-throttling",
                "--disable-renderer-backgrounding",
                "--disable-background-networking"
            ]
# Prefer bundled Playwright Chromium from pw-browsers
        
        # Check if we should allocate a remote debugging port for CDP isolation
        is_parallel = getattr(self, "var_parallel", None) and self.var_parallel.get()
        workers_count = getattr(self, "var_parallel_workers", None) and self.var_parallel_workers.get() or 1
        if is_parallel and workers_count > 1:
            try:
                import socket
                s = socket.socket()
                s.bind(('', 0))
                port = s.getsockname()[1]
                s.close()
                kwargs["args"].append(f"--remote-debugging-port={port}")
                self.cdp_port = port
                self.log(f"🌐 Scheduled remote debugging port {port} for CDP isolation.")
            except Exception as pe:
                self.log(f"⚠️ Failed to allocate remote debugging port: {pe}")
                    
    browser = self._launch_browser(browser_name, **kwargs)
    
    # If remote debugging port was set, fetch the webSocketDebuggerUrl
    if use_chrome and hasattr(self, "cdp_port") and self.cdp_port:
        import urllib.request
        import json
        time.sleep(2)
        for _ in range(10):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{self.cdp_port}/json/version", timeout=2) as conn:
                    data = json.loads(conn.read().decode('utf-8'))
                    self.cdp_url = data.get("webSocketDebuggerUrl")
                    if self.cdp_url:
                        self.log(f"🌐 Remote browser debugging attached (Port {self.cdp_port}).")
                        break
            except Exception:
                time.sleep(1)
                
    return browser, browser_name

def _cleanup_browser_session(self):
    # Terminate background CDP browser process tree if active
    if hasattr(self, "cdp_browser_process") and self.cdp_browser_process:
        try:
            proc_pid = self.cdp_browser_process.pid
            kill_process_tree(proc_pid)
        except Exception:
            pass
        self.cdp_browser_process = None
        
    if hasattr(self, "cdp_temp_dir") and self.cdp_temp_dir:
        try:
            import shutil
            shutil.rmtree(self.cdp_temp_dir, ignore_errors=True)
        except Exception:
            pass
        self.cdp_temp_dir = None

    if hasattr(self, "cdp_url"):
        self.cdp_url = None
    if hasattr(self, "cdp_port"):
        self.cdp_port = None

    try:
        if self.browser_page:
            try: self.browser_page.close()
            except: pass
            self.browser_page = None
            
        if self.browser_context:
            try: self.browser_context.close()
            except: pass
            self.browser_context = None
            
        if self.browser:
            try: self.browser.close()
            except: pass
            self.browser = None
            
        if self.playwright:
            try:
                d_pid = getattr(self.playwright._impl_obj._connection._transport._proc, 'pid', None)
                self.playwright.stop()
                if d_pid:
                    kill_process_tree(d_pid)
            except Exception:
                pass
            self.playwright = None
    except Exception:
        pass
    self.browser_hidden = False

def safe_logout_and_close(self, page=None, silent=False):
    try:
        # 1. Send silent HTTP logout on direct session
        if hasattr(self, "http_session") and self.http_session:
            try:
                self.http_session.get("https://ifmisprod.mptreasury.gov.in/IFMS/ifms.htm?actionFlag=logout", timeout=2, verify=False)
            except Exception: pass
            self.http_session = None

        # 2. Clear saved session state file
        try:
            user_dir = getattr(self, "user_dir", "")
            if user_dir:
                state_file = os.path.join(user_dir, "browser_state.json")
                if os.path.exists(state_file):
                    os.remove(state_file)
        except Exception: pass

        # 3. Non-blocking JS fetch logout if page is alive
        if page:
            try:
                if not page.is_closed():
                    page.evaluate("fetch('ifms.htm?actionFlag=logout').catch(() => {})")
                    time.sleep(0.3)
            except Exception: pass
    except Exception as ex:
        self.log(f"⚠️ Exception during session cleanup: {ex}")
    finally:
        self._cleanup_browser_session()
        self.stop_requested = False

        if hasattr(self, "stop_event") and self.stop_event:
            self.stop_event.clear()

        if not silent:
            self.log("✅ Portal session terminated successfully. Offline mode restored.", tag="success")
        self.update_browser_status("⚪ Session: Offline / Terminated. Ready for login.", bg_color="#374151", text_color="#9ca3af")

        # Reset UI task state if method exists
        if hasattr(self, "set_ui_task_running"):
            try: self.set_ui_task_running(False)
            except Exception: pass

def manual_portal_logout(self):
    self.log("🔓 Terminating portal session manually and closing browser context...")
    self.stop_requested = True
    if hasattr(self, "stop_event") and self.stop_event:
        self.stop_event.set()

    import threading
    t = threading.Thread(target=self.safe_logout_and_close, args=(getattr(self, "browser_page", None),), daemon=True)
    t.start()

def launch_web_portal(self):
    if not getattr(self, "api_port", None):
        self.log("⚠️ Web server is not running.")
        return
    import webbrowser
    # Launch dashboard URL with injected session security token
    url = f"http://127.0.0.1:{self.api_port}/?token={self.api_token}"
    self.log(f"🌐 Launching reporting dashboard: {url}")
    webbrowser.open(url)

def launch_ti_studio(self):
    import os
    import subprocess
    import sys
    from PySide6.QtWidgets import QMessageBox

    if getattr(sys, 'frozen', False):
        target_exe = sys.executable
        self.log(f"🚀 Launching TI Studio from combined executable: {target_exe} --ti-studio")
        subprocess.Popen([target_exe, "--ti-studio"])
    else:
        compiler_kit_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        target_script = os.path.join(compiler_kit_root, "TI Studio Pro", "app.py")
        if os.path.exists(target_script):
            self.log(f"🚀 Launching TI Studio from script: {sys.executable} \"{target_script}\"")
            subprocess.Popen([sys.executable, target_script], creationflags=0x08000000 if sys.platform == "win32" else 0)
        else:
            self.log("❌ Could not locate TI Studio script.")
            QMessageBox.critical(self, "Error", f"TI Studio script not found at:\n{target_script}")

def launch_epay_verifier(self):
    import os
    import subprocess
    import sys
    from PySide6.QtWidgets import QMessageBox

    if getattr(sys, 'frozen', False):
        target_exe = sys.executable
        self.log(f"🚀 Launching ePay Verifier from combined executable: {target_exe} --epay-verifier")
        subprocess.Popen([target_exe, "--epay-verifier"], creationflags=0x08000000 if sys.platform == "win32" else 0)
    else:
        compiler_kit_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        target_script = os.path.join(compiler_kit_root, "TI Studio Pro", "epay_verifier.py")
        if os.path.exists(target_script):
            self.log(f"🚀 Launching ePay Verifier from script: {sys.executable} \"{target_script}\"")
            subprocess.Popen([sys.executable, target_script], creationflags=0x08000000 if sys.platform == "win32" else 0)
        else:
            self.log("❌ Could not locate ePay Verifier script.")
            QMessageBox.critical(self, "Error", f"ePay Verifier script not found at:\n{target_script}")

def run_scraper_via_api(self, mode, username, password, config_params):
    self.log(f"🌐 Scraper scheduled via Local Web API | Mode: {mode.upper()}")
    
    # Apply API-received config settings dynamically
    if "download_dir" in config_params:
        self.var_download_dir.set(config_params["download_dir"])
    if "stealth_mode" in config_params:
        self.var_stealth.set(config_params["stealth_mode"])
    if "direct_dashboard" in config_params:
        self.var_direct_dashboard.set(config_params["direct_dashboard"])
    if "auto_solve_captcha" in config_params:
        self.var_auto_solve_captcha.set(config_params["auto_solve_captcha"])
        
    self.entry_user.delete(0, 'end')
    self.entry_user.insert(0, username)
    self.entry_pass.delete(0, 'end')
    self.entry_pass.insert(0, password)
    
    # Start thread
    self.start_thread(mode, run_failed=False)

def update_browser_status(self, message, bg_color="#0d1117", text_color="#00c9a7"):
    try:
        if self.browser_page and not self.browser_page.is_closed():
            js_code = f"""
            (function() {{
                let div = document.getElementById('ifmis-suite-status-banner');
                if (!div) {{
                    div = document.createElement('div');
                    div.id = 'ifmis-suite-status-banner';
                    div.style.position = 'fixed';
                    div.style.top = '0';
                    div.style.left = '0';
                    div.style.width = '100%';
                    div.style.backgroundColor = '{bg_color}';
                    div.style.color = '{text_color}';
                    div.style.padding = '12px';
                    div.style.textAlign = 'center';
                    div.style.fontFamily = 'Segoe UI, Arial, sans-serif';
                    div.style.fontSize = '14px';
                    div.style.fontWeight = 'bold';
                    div.style.zIndex = '999999';
                    div.style.boxShadow = '0 2px 10px rgba(0,0,0,0.5)';
                    div.style.borderBottom = '2px solid #00c9a7';
                    document.body.appendChild(div);
                    document.body.style.marginTop = '50px';
                }}
                div.innerHTML = `{message}`;
                div.style.backgroundColor = '{bg_color}';
                div.style.color = '{text_color}';
            }})();
            """
            self.browser_page.evaluate(js_code)
    except Exception:
        pass

def launch_shared_cdp_browser(self, use_chrome):
    """
    Launches a headless Chromium browser instance with remote debugging enabled,
    and returns the websocket debugging URL (CDP URL) for workers to connect to.
    """
    import subprocess
    import socket
    import tempfile
    import urllib.request
    import json
    import time
    import sys
    import os
    
    # 1. Find a free local port
    s = socket.socket()
    s.bind(('', 0))
    port = s.getsockname()[1]
    s.close()
    
    self.log(f"🌐 Launching background shared Chromium CDP browser on port {port}...")
    
    # Locate Chrome executable path
    chrome_path = None
    if sys.platform == "win32":
        chrome_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
        ]
        for p in chrome_paths:
            if os.path.exists(p):
                chrome_path = p
                break
    
    if not chrome_path:
        chrome_path = "chrome" # Assumes it's in PATH
        
    temp_dir = tempfile.mkdtemp(prefix="ifmis_cdp_")
    
    args = [
        chrome_path,
        "--headless=new",
        "--no-startup-window",
        "--silent-launch",
        f"--remote-debugging-port={port}",
        f"--user-data-dir={temp_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-gpu",
        "--disable-software-rasterizer",
        "--disable-extensions",
        "--mute-audio",
        "--log-level=3",
        "--window-position=-9999,-9999",
        "--window-size=1,1"
    ]
    
    try:
        # Start the chrome process
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, creationflags=0x08000000 if sys.platform == "win32" else 0)
        self.cdp_browser_process = proc
        self.cdp_temp_dir = temp_dir

        # Instantly hide window handle before it can paint on screen
        if proc and proc.pid:
            hide_process_window(proc.pid)

        # Wait up to 10 seconds for CDP endpoint to become ready
        time.sleep(2)
        
        for _ in range(10):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=2) as conn:
                    data = json.loads(conn.read().decode('utf-8'))
                    cdp_url = data.get("webSocketDebuggerUrl")
                    if cdp_url:
                        if proc and proc.pid: hide_process_window(proc.pid)
                        self.log(f"✅ Shared CDP Browser running at: {cdp_url}")
                        return cdp_url
            except Exception:
                time.sleep(1)
        
    except Exception as ex:
        self.log(f"⚠️ Failed to launch shared CDP browser: {ex}. Falling back to spawning normal contexts.")
    
    return None

def _get_valid_storage_state(self, state_file_path):
    """
    Validates that the browser_state.json is a valid JSON file and not stale.
    If it is corrupted, invalid, or empty, deletes it to prevent Playwright launch crashes.
    Returns the path if valid, or None if invalid/deleted/stale.
    """
    import os
    import time
    import json
    
    if not os.path.exists(state_file_path):
        return None
        
    # Check if size is too small to contain valid JSON
    if os.path.getsize(state_file_path) < 10:
        self.log("⚠️ Deleting empty or too small browser_state.json...")
        try:
            os.remove(state_file_path)
        except Exception:
            pass
        return None

    # Validate JSON content
    try:
        with open(state_file_path, "r", encoding="utf-8") as f:
            json.load(f)
    except Exception as e:
        self.log(f"⚠️ Deleting corrupted browser_state.json (failed to parse: {e})...")
        try:
            os.remove(state_file_path)
        except Exception:
            pass
        return None

    # Check for stale age (15 minutes / 900 seconds)
    try:
        file_age = time.time() - os.path.getmtime(state_file_path)
        if file_age > 900:
            self.log(f"🧹 Stale browser session detected (modified {int(file_age/60)}m ago). Clearing browser_state.json...")
            try:
                os.remove(state_file_path)
            except Exception:
                pass
            return None
    except Exception:
        pass

    return state_file_path

def bring_browser_to_front(self):
    if sys.platform != "win32":
        return
    driver_pid = None
    try:
        if self.playwright:
            driver_pid = self.playwright._impl_obj._connection._transport._proc.pid
    except Exception:
        pass
        
    try:
        import win32gui
        import win32con
        import win32process
        
        def enum_windows_callback(hwnd, _lParam):
            if win32gui.IsWindowVisible(hwnd):
                _, win_pid = win32process.GetWindowThreadProcessId(hwnd)
                title = win32gui.GetWindowText(hwnd).lower()
                
                match = False
                if driver_pid and (is_descendant(win_pid, driver_pid) or win_pid == driver_pid):
                    match = True
                elif any(x in title for x in ["firefox", "chromium", "ifms", "chrome", "edge"]):
                    if not driver_pid:
                        match = True
                        
                if match:
                    win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
                    win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                    # Use SetWindowPos to force top level z-ordering
                    win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 0, 0, 0, 0, win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                    win32gui.SetWindowPos(hwnd, win32con.HWND_NOTOPMOST, 0, 0, 0, 0, win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                    try:
                        win32gui.SetForegroundWindow(hwnd)
                    except Exception:
                        pass
            return True
        win32gui.EnumWindows(enum_windows_callback, None)
    except Exception as e:
        self.log(f"⚠️ Failed to bring browser to front: {e}")

def get_stealth_context_args(self, base_args=None):
    if base_args is None:
        base_args = {}
    import random
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ]
    VIEWPORTS = [
        {"width": 1920, "height": 1080},
        {"width": 1366, "height": 768},
        {"width": 1440, "height": 900},
        {"width": 1536, "height": 864},
        {"width": 1280, "height": 720}
    ]
    
    # Check if user has enabled stealth mode checkbox
    is_stealth = False
    if hasattr(self, "var_stealth") and self.var_stealth.get():
        is_stealth = True
        
    if is_stealth:
        base_args["user_agent"] = random.choice(USER_AGENTS)
        base_args["viewport"] = random.choice(VIEWPORTS)
    else:
        if "user_agent" not in base_args or not base_args["user_agent"]:
            base_args["user_agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            
    base_args["accept_downloads"] = True
    return base_args

def apply_webdriver_mask(page):
    try:
        page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    except Exception:
        pass
