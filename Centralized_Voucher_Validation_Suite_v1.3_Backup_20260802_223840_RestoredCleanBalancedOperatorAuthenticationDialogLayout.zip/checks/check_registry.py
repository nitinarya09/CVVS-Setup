import time
# checks/check_registry.py
# Plugin Registry & Report Generator for Centralized Voucher Validation Suite

import os
import sys
import importlib
import inspect
import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from checks.base_check import BaseValidationCheck


class CheckRegistry:
    """
    Manages discovery, execution, dynamic toggling of validation checks,
    and consolidation of report outputs (Excel + HTML summary dashboard).
    """

    def __init__(self, checks_dir=None, logger=None):
        if checks_dir is None:
            checks_dir = os.path.dirname(os.path.abspath(__file__))
        self.checks_dir = checks_dir
        self.logger = logger or (lambda msg, level="info": print(f"[{level.upper()}] {msg}"))
        self.registered_checks = {}  # check_id -> BaseValidationCheck instance
        self.realtime_results = []   # List of per-voucher realtime check result dicts
        self.post_results = {}       # check_id -> post download result dict
        
        self.reload_checks()

    def log(self, msg, level="info"):
        if self.logger:
            self.logger(msg, level)

    def reload_checks(self):
        """Dynamically scan checks/ directory and load all python check modules."""
        self.registered_checks.clear()
        
        if not os.path.exists(self.checks_dir):
            os.makedirs(self.checks_dir, exist_ok=True)
            return

        # Ensure parent of checks_dir is in sys.path
        parent_dir = os.path.dirname(self.checks_dir)
        if parent_dir not in sys.path:
            sys.path.insert(0, parent_dir)

        for filename in os.listdir(self.checks_dir):
            if not filename.endswith(".py"):
                continue
            if filename in ("__init__.py", "base_check.py", "check_registry.py"):
                continue

            module_name = f"checks.{filename[:-3]}"
            try:
                if module_name in sys.modules:
                    module = importlib.reload(sys.modules[module_name])
                else:
                    module = importlib.import_module(module_name)

                # Search for BaseValidationCheck subclasses in the module
                for name, obj in inspect.getmembers(module, inspect.isclass):
                    if issubclass(obj, BaseValidationCheck) and obj is not BaseValidationCheck:
                        instance = obj()
                        self.registered_checks[instance.check_id] = instance
                        self.log(f"Registered Check: '{instance.name}' ({instance.check_id}) [{instance.check_type.upper()}]")

            except Exception as e:
                self.log(f"⚠️ Error loading check script '{filename}': {e}", "warning")

    def get_all_checks(self):
        """Return list of all registered check instances."""
        return list(self.registered_checks.values())

    def get_realtime_checks(self):
        """Return enabled realtime check instances."""
        return [c for c in self.registered_checks.values() if c.check_type == "realtime" and c.enabled]

    def get_post_download_checks(self):
        """Return enabled post-download check instances."""
        return [c for c in self.registered_checks.values() if c.check_type == "post_download" and c.enabled]

    def set_check_enabled(self, check_id: str, enabled: bool):
        """Enable or disable a specific check by ID."""
        if check_id in self.registered_checks:
            self.registered_checks[check_id].enabled = enabled

    def run_realtime_checks(self, voucher_data: dict, download_folder: str, context: dict = None) -> list:
        """Run all enabled realtime checks for a single downloaded voucher."""
        if context is None:
            context = {}

        results = []
        enabled_realtime = self.get_realtime_checks()

        for check in enabled_realtime:
            try:
                res = check.run_realtime(voucher_data, download_folder, context)
                res_entry = {
                    "check_id": check.check_id,
                    "check_name": check.name,
                    "voucher_no": voucher_data.get("voucher_no", ""),
                    "treasury": voucher_data.get("treasury", ""),
                    "mh": voucher_data.get("mh", ""),
                    "amount": voucher_data.get("amount", ""),
                    "ddo": voucher_data.get("ddo", ""),
                    "status": res.get("status", "UNKNOWN"),
                    "message": res.get("message", ""),
                    "details": res.get("details", {}),
                    "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                results.append(res_entry)
                self.realtime_results.append(res_entry)

                status_val = res.get("status", "UNKNOWN")
                if status_val in ("WARNING", "FAIL", "SUSPICIOUS", "MISMATCH"):
                    # High-value claims are recorded silently in reports/tables without flooding console logs
                    if check.check_id not in ("check_realtime_sample_custom", "check_realtime_high_value"):
                        self.log(f"⚠️ [{check.name}] Voucher #{voucher_data.get('voucher_no')}: {res.get('message')}", "warning")

            except Exception as e:
                self.log(f"❌ Exception in realtime check '{check.name}': {e}", "error")
                results.append({
                    "check_id": check.check_id,
                    "check_name": check.name,
                    "voucher_no": voucher_data.get("voucher_no", ""),
                    "status": "ERROR",
                    "message": str(e),
                    "details": {}
                })

        return results

    def run_post_download_checks(self, all_vouchers_data: list, output_dir: str, context: dict = None) -> dict:
        """Run all enabled post-download checks after batch download finishes."""
        if context is None:
            context = {}

        self.post_results.clear()
        enabled_post = self.get_post_download_checks()

        for check in enabled_post:
            try:
                self.log(f"⏳ Running Post-Download Check: '{check.name}'...")
                res = check.run_post_download(all_vouchers_data, output_dir, context)
                self.post_results[check.check_id] = {
                    "check_id": check.check_id,
                    "check_name": check.name,
                    "status": res.get("status", "COMPLETED"),
                    "message": res.get("message", ""),
                    "rows": res.get("rows", []),
                    "summary_stats": res.get("summary_stats", {})
                }
                self.log(f"✅ [{check.name}] {res.get('message', 'Completed')}")
            except Exception as e:
                self.log(f"❌ Exception in post-download check '{check.name}': {e}", "error")
                self.post_results[check.check_id] = {
                    "check_id": check.check_id,
                    "check_name": check.name,
                    "status": "ERROR",
                    "message": str(e),
                    "rows": [],
                    "summary_stats": {}
                }

        # Generate Consolidated Excel Report & HTML Dashboard
        excel_path, html_path = self.generate_consolidated_reports(all_vouchers_data, output_dir)
        return {
            "excel_path": excel_path,
            "html_path": html_path,
            "post_results": self.post_results
        }

    def generate_consolidated_reports(self, all_vouchers_data: list, output_dir: str) -> tuple:
        """Generates Single Consolidated Excel Report + HTML Summary Dashboard."""
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        excel_path = os.path.join(output_dir, f"Centralized_Validation_Report_{timestamp}.xlsx")
        html_path = os.path.join(output_dir, f"Centralized_Validation_Dashboard_{timestamp}.html")

        # ── 1. Create Consolidated Excel Report ────────────────────────
        wb = openpyxl.Workbook()
        
        # Styles
        title_font = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
        header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
        sub_header_font = Font(name="Segoe UI", size=11, bold=True, color="1F2937")
        bold_font = Font(name="Segoe UI", size=10, bold=True)
        regular_font = Font(name="Segoe UI", size=10)
        
        navy_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
        header_fill = PatternFill(start_color="2563EB", end_color="2563EB", fill_type="solid")
        pass_fill = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
        warn_fill = PatternFill(start_color="FEF08A", end_color="FEF08A", fill_type="solid")
        fail_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
        
        thin_border = Border(
            left=Side(style='thin', color='CBD5E1'),
            right=Side(style='thin', color='CBD5E1'),
            top=Side(style='thin', color='CBD5E1'),
            bottom=Side(style='thin', color='CBD5E1')
        )

        # Sheet 1: Executive Summary
        ws_sum = wb.active
        ws_sum.title = "Executive Summary"
        ws_sum.views.sheetView[0].showGridLines = True

        ws_sum.merge_cells("A1:G2")
        title_cell = ws_sum["A1"]
        title_cell.value = "CENTRALIZED VOUCHER VALIDATION SUITE — EXECUTIVE AUDIT REPORT"
        title_cell.font = title_font
        title_cell.fill = navy_fill
        title_cell.alignment = Alignment(horizontal="center", vertical="center")

        unique_vouchers = set(r.get("voucher_no") for r in self.realtime_results if r.get("voucher_no"))
        vouchers_processed_count = len(all_vouchers_data) if (all_vouchers_data and len(all_vouchers_data) > 0) else len(unique_vouchers)

        ws_sum.append([])
        ws_sum.append(["Generated On:", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
        ws_sum.append(["Total Vouchers Downloaded:", vouchers_processed_count])
        ws_sum.append(["Total Real-time Validations Executed:", len(self.realtime_results)])
        ws_sum.append(["Total Checks Configured:", len(self.registered_checks)])
        ws_sum.append([])

        # Table of Registered Checks & Execution Status
        headers_checks = ["Check ID", "Check Name", "Type", "Status", "Description"]
        ws_sum.append(headers_checks)
        for col_num in range(1, len(headers_checks) + 1):
            c = ws_sum.cell(row=ws_sum.max_row, column=col_num)
            c.font = header_font
            c.fill = header_fill
            c.alignment = Alignment(horizontal="center")

        for chk in self.registered_checks.values():
            status_text = "ENABLED" if chk.enabled else "DISABLED"
            ws_sum.append([chk.check_id, chk.name, chk.check_type.upper(), status_text, chk.description])
            row_idx = ws_sum.max_row
            for col_idx in range(1, 6):
                cell = ws_sum.cell(row=row_idx, column=col_idx)
                cell.font = regular_font
                cell.border = thin_border

        # Sheet 2: Realtime Check Findings
        ws_rt = wb.create_sheet(title="Realtime Check Results")
        ws_rt.views.sheetView[0].showGridLines = True
        
        rt_headers = ["S.No", "Voucher No", "Treasury", "Major Head", "Amount", "DDO Code", "Check Name", "Status", "Message", "Timestamp"]
        ws_rt.append(rt_headers)
        for col_num in range(1, len(rt_headers) + 1):
            c = ws_rt.cell(row=1, column=col_num)
            c.font = header_font
            c.fill = header_fill
            c.alignment = Alignment(horizontal="center")

        for idx, r in enumerate(self.realtime_results, 1):
            st = str(r.get("status", "")).upper()
            row_vals = [
                idx, r.get("voucher_no"), r.get("treasury"), r.get("mh"),
                r.get("amount"), r.get("ddo"), r.get("check_name"), st,
                r.get("message"), r.get("timestamp")
            ]
            ws_rt.append(row_vals)
            row_idx = ws_rt.max_row
            for c_idx in range(1, len(row_vals) + 1):
                cell = ws_rt.cell(row=row_idx, column=c_idx)
                cell.font = regular_font
                cell.border = thin_border
                if c_idx == 8:  # Status column fill
                    if st in ("PASS", "MATCHED"): cell.fill = pass_fill
                    elif st in ("WARNING", "SUSPICIOUS", "MISMATCH"): cell.fill = warn_fill
                    elif st in ("FAIL", "ERROR"): cell.fill = fail_fill

        # Sheet 3... Post-Download Check Findings
        for chk_id, post_res in self.post_results.items():
            sheet_title = f"Post_{chk_id[:20]}"
            ws_p = wb.create_sheet(title=sheet_title)
            ws_p.views.sheetView[0].showGridLines = True
            
            rows = post_res.get("rows", [])
            if rows and isinstance(rows[0], dict):
                p_headers = list(rows[0].keys())
                ws_p.append(p_headers)
                for col_num in range(1, len(p_headers) + 1):
                    c = ws_p.cell(row=1, column=col_num)
                    c.font = header_font
                    c.fill = header_fill

                for rdict in rows:
                    r_vals = [rdict.get(k, "") for k in p_headers]
                    ws_p.append(r_vals)
                    row_idx = ws_p.max_row
                    for c_idx in range(1, len(r_vals) + 1):
                        cell = ws_p.cell(row=row_idx, column=c_idx)
                        cell.font = regular_font
                        cell.border = thin_border
            else:
                ws_p.append(["Status", post_res.get("status")])
                ws_p.append(["Message", post_res.get("message")])

        # Auto-adjust column widths
        for ws in wb.worksheets:
            for col in ws.columns:
                max_len = 0
                col_letter = get_column_letter(col[0].column)
                for cell in col:
                    if cell.value is not None:
                        # Avoid multiline cell string blowup
                        val_str = str(cell.value).split("\n")[0]
                        max_len = max(max_len, len(val_str))
                ws.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 50)

        wb.save(excel_path)
        self.log(f"📊 Consolidated Excel Report generated: {excel_path}")

        # ── 2. Create Interactive HTML Dashboard Summary ──────────────
        total_rt = len(self.realtime_results)
        flag_statuses = {"WARNING", "FAIL", "SUSPICIOUS", "MISMATCH", "ERROR"}
        flagged_results = [r for r in self.realtime_results if str(r.get("status", "")).upper() in flag_statuses]
        flagged_rt = len(flagged_results)
        passed_rt = total_rt - flagged_rt
        pass_rate = round((passed_rt / total_rt * 100), 2) if total_rt > 0 else 0

        # Data aggregation
        from collections import defaultdict
        check_flags = defaultdict(int)
        treasury_flags = defaultdict(int)
        voucher_flags = defaultdict(int)
        voucher_info = {}
        check_grouped_flags = defaultdict(list)

        for r in flagged_results:
            cname = r.get("check_name", "Unknown")
            treas = r.get("treasury", "Unknown")
            vno = r.get("voucher_no", "Unknown")
            
            check_flags[cname] += 1
            treasury_flags[treas] += 1
            voucher_flags[vno] += 1
            if vno not in voucher_info:
                voucher_info[vno] = {"treasury": treas, "mh": r.get("mh", ""), "amount": r.get("amount", "")}
            check_grouped_flags[cname].append(r)

        top_checks = sorted(check_flags.items(), key=lambda x: x[1], reverse=True)
        max_check_flag = top_checks[0][1] if top_checks else 1
        top_treasuries = sorted(treasury_flags.items(), key=lambda x: x[1], reverse=True)
        top_vouchers = sorted(voucher_flags.items(), key=lambda x: x[1], reverse=True)[:20]

        check_stats = defaultdict(lambda: {"total": 0, "flagged": 0})
        mh_stats = defaultdict(float)
        treasury_stats = defaultdict(lambda: {"total": 0, "flagged": 0})

        for r in self.realtime_results:
            cname = r.get("check_name", "Unknown")
            treas = r.get("treasury", "Unknown")
            mh = r.get("mh", "Unknown")
            is_flagged = str(r.get("status", "")).upper() in flag_statuses
            
            check_stats[cname]["total"] += 1
            treasury_stats[treas]["total"] += 1
            if is_flagged:
                check_stats[cname]["flagged"] += 1
                treasury_stats[treas]["flagged"] += 1
                
            amt_str = str(r.get("amount", "0")).replace(",", "")
            try:
                amt = float(amt_str)
            except:
                amt = 0.0
            mh_stats[mh] += amt

        # Build HTML
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centralized Voucher Validation Dashboard</title>
    <style>
        :root {{
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --accent: #38bdf8;
            --pass: #22c55e;
            --warn: #eab308;
            --fail: #ef4444;
            --border: #334155;
        }}
        body {{ font-family: 'Segoe UI', system-ui, sans-serif; background-color: var(--bg-color); color: var(--text-main); margin: 0; padding: 20px; }}
        .header {{ text-align: center; margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 10px; }}
        .header h1 {{ color: var(--accent); margin: 0; font-size: 24px; }}
        
        .tabs {{ display: flex; gap: 5px; margin-bottom: 20px; border-bottom: 1px solid var(--border); overflow-x: auto; }}
        .tab-btn {{ background: var(--card-bg); color: var(--text-muted); border: 1px solid var(--border); border-bottom: none; padding: 12px 20px; cursor: pointer; border-radius: 8px 8px 0 0; font-weight: bold; white-space: nowrap; }}
        .tab-btn.active {{ color: var(--text-main); background: var(--accent); border-color: var(--accent); }}
        .tab-content {{ display: none; }}
        .tab-content.active {{ display: block; }}
        
        .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 20px; }}
        .kpi-card {{ background: var(--card-bg); border: 1px solid var(--border); padding: 15px; border-radius: 8px; text-align: center; }}
        .kpi-val {{ font-size: 28px; font-weight: bold; margin-top: 8px; }}
        .kpi-val.pass {{ color: var(--pass); }}
        .kpi-val.warn {{ color: var(--warn); }}
        .kpi-val.accent {{ color: var(--accent); }}
        
        .grid-2 {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; }}
        .card {{ background: var(--card-bg); border: 1px solid var(--border); border-radius: 8px; padding: 15px; margin-bottom: 20px; overflow-x: auto; }}
        .card h3 {{ margin-top: 0; color: var(--accent); border-bottom: 1px solid var(--border); padding-bottom: 8px; }}
        
        table {{ width: 100%; border-collapse: collapse; text-align: left; }}
        th, td {{ padding: 10px; border-bottom: 1px solid var(--border); font-size: 13px; }}
        th {{ background: #0284c7; color: white; cursor: pointer; position: sticky; top: 0; }}
        tr:hover {{ background: #334155; }}
        
        .bar-wrap {{ background: var(--bg-color); border-radius: 4px; overflow: hidden; height: 16px; width: 100%; min-width: 100px; }}
        .bar-fill {{ background: var(--warn); height: 100%; }}
        
        details {{ margin-bottom: 10px; background: var(--card-bg); border: 1px solid var(--border); border-radius: 6px; }}
        summary {{ padding: 12px; cursor: pointer; font-weight: bold; color: var(--accent); outline: none; }}
        details > div {{ padding: 10px; border-top: 1px solid var(--border); overflow-x: auto; }}
        
        .badge {{ padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; display: inline-block; }}
        .badge-pass {{ background: rgba(34,197,94,0.1); color: #4ade80; border: 1px solid #22c55e; }}
        .badge-warn {{ background: rgba(234,179,8,0.1); color: #fde047; border: 1px solid #eab308; }}
        .badge-fail {{ background: rgba(239,68,68,0.1); color: #fca5a5; border: 1px solid #ef4444; }}
        
        .search-box {{ width: 100%; padding: 12px; margin-bottom: 15px; background: var(--bg-color); color: var(--text-main); border: 1px solid var(--border); border-radius: 4px; box-sizing: border-box; }}
        
        @media print {{
            body {{ background: white; color: black; padding: 0; }}
            .tabs, .search-box {{ display: none; }}
            .tab-content {{ display: block !important; page-break-after: always; margin-bottom: 40px; }}
            .card, details, .kpi-card {{ background: white; border: 1px solid #ccc; color: black; }}
            th {{ background: #eee !important; color: black !important; }}
            .bar-wrap {{ border: 1px solid #ccc; background: #f0f0f0; }}
            .bar-fill {{ background: #666; }}
            :root {{ --text-main: black; --text-muted: #333; --accent: black; --card-bg: white; --bg-color: white; --border: #ccc; --pass: black; --warn: black; }}
            h1, h3, summary {{ color: black !important; }}
            .badge {{ border: 1px solid black; color: black; background: transparent; }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Centralized Voucher Validation Dashboard</h1>
        <p>Generated: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
    </div>

    <div class="tabs">
        <button class="tab-btn active" onclick="openTab(event, 'tab-overview')">🏠 Overview</button>
        <button class="tab-btn" onclick="openTab(event, 'tab-flags')">⚠️ Flagged Findings</button>
        <button class="tab-btn" onclick="openTab(event, 'tab-all')">📋 All Results</button>
        <button class="tab-btn" onclick="openTab(event, 'tab-analytics')">📊 Analytics</button>
        <button class="tab-btn" onclick="openTab(event, 'tab-post')">📝 Post-Download Checks</button>
    </div>

    <!-- TAB 1: OVERVIEW -->
    <div id="tab-overview" class="tab-content active">
        <div class="kpi-grid">
            <div class="kpi-card">
                <div>Total Vouchers</div>
                <div class="kpi-val accent">{vouchers_processed_count}</div>
            </div>
            <div class="kpi-card">
                <div>Checks Executed</div>
                <div class="kpi-val accent">{total_rt}</div>
            </div>
            <div class="kpi-card">
                <div>Passed</div>
                <div class="kpi-val pass">{passed_rt}</div>
            </div>
            <div class="kpi-card">
                <div>Flagged</div>
                <div class="kpi-val warn">{flagged_rt}</div>
            </div>
            <div class="kpi-card">
                <div>Pass Rate</div>
                <div class="kpi-val pass">{pass_rate}%</div>
            </div>
        </div>
        
        <div class="grid-2">
            <div class="card">
                <h3>Most Flagging Checks</h3>
                <table>
                    <thead><tr><th>Check Name</th><th>Flags</th><th>Chart</th></tr></thead>
                    <tbody>
"""
        for cname, count in top_checks:
            pct = (count / max_check_flag * 100) if max_check_flag > 0 else 0
            html_content += f"""<tr><td>{cname}</td><td>{count}</td><td><div class="bar-wrap"><div class="bar-fill" style="width:{pct}%"></div></div></td></tr>"""
            
        html_content += """
                    </tbody>
                </table>
            </div>
            <div class="card">
                <h3>Flags by Treasury</h3>
                <table>
                    <thead><tr><th>Treasury</th><th>Flags</th></tr></thead>
                    <tbody>
"""
        for treas, count in top_treasuries:
            html_content += f"""<tr><td>{treas}</td><td>{count}</td></tr>"""
            
        html_content += """
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="card">
            <h3>Top Flagged Vouchers</h3>
            <table>
                <thead><tr><th>Voucher No</th><th>Treasury</th><th>Major Head</th><th>Amount</th><th>Total Flags</th></tr></thead>
                <tbody>
"""
        for vno, count in top_vouchers:
            vi = voucher_info.get(vno, {})
            html_content += f"""<tr><td>{vno}</td><td>{vi.get('treasury','')}</td><td>{vi.get('mh','')}</td><td>{vi.get('amount','')}</td><td>{count}</td></tr>"""
            
        html_content += """
                </tbody>
            </table>
        </div>
    </div>

    <!-- TAB 2: FLAGGED FINDINGS -->
    <div id="tab-flags" class="tab-content">
        <h2>Flagged Findings grouped by Check</h2>
"""
        for cname, results in check_grouped_flags.items():
            html_content += f"""
        <details>
            <summary>{cname} ({len(results)} flags)</summary>
            <div>
                <table>
                    <thead><tr><th>Voucher No</th><th>Treasury</th><th>MH</th><th>Amount</th><th>Status</th><th>Message</th></tr></thead>
                    <tbody>
"""
            for r in results:
                st = str(r.get("status", "")).upper()
                bclass = "badge-fail" if st in ("FAIL","ERROR") else "badge-warn"
                html_content += f"""<tr><td>{r.get('voucher_no')}</td><td>{r.get('treasury')}</td><td>{r.get('mh')}</td><td>{r.get('amount')}</td><td><span class="badge {bclass}">{st}</span></td><td>{r.get('message')}</td></tr>"""
            html_content += """
                    </tbody>
                </table>
            </div>
        </details>
"""
        html_content += """
    </div>

    <!-- TAB 3: ALL RESULTS -->
    <div id="tab-all" class="tab-content">
        <input type="text" id="searchInput" class="search-box" placeholder="Search across all results..." onkeyup="filterTable()">
        <div class="card">
            <table id="allTable">
                <thead>
                    <tr>
                        <th onclick="sortTable(0)">Voucher No ⇕</th>
                        <th onclick="sortTable(1)">Treasury ⇕</th>
                        <th onclick="sortTable(2)">MH ⇕</th>
                        <th onclick="sortTable(3)">Amount ⇕</th>
                        <th onclick="sortTable(4)">Check Name ⇕</th>
                        <th onclick="sortTable(5)">Status ⇕</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
"""
        for r in self.realtime_results:
            st = str(r.get("status", "")).upper()
            bclass = "badge-pass" if st in ("PASS", "MATCHED") else ("badge-warn" if st in ("WARNING", "SUSPICIOUS", "MISMATCH") else "badge-fail")
            html_content += f"""<tr><td>{r.get('voucher_no')}</td><td>{r.get('treasury')}</td><td>{r.get('mh')}</td><td>{r.get('amount')}</td><td>{r.get('check_name')}</td><td><span class="badge {bclass}">{st}</span></td><td>{r.get('message')}</td></tr>"""

        html_content += """
                </tbody>
            </table>
        </div>
    </div>

    <!-- TAB 4: ANALYTICS -->
    <div id="tab-analytics" class="tab-content">
        <div class="card">
            <h3>Check-wise Summary</h3>
            <table>
                <thead><tr><th>Check Name</th><th>Total Run</th><th>Passed</th><th>Flagged</th><th>Flag Rate %</th></tr></thead>
                <tbody>
"""
        for cname, stat in check_stats.items():
            passed = stat["total"] - stat["flagged"]
            rate = round((stat["flagged"] / stat["total"] * 100), 2) if stat["total"] > 0 else 0
            html_content += f"""<tr><td>{cname}</td><td>{stat['total']}</td><td>{passed}</td><td>{stat['flagged']}</td><td>{rate}%</td></tr>"""
            
        html_content += """
                </tbody>
            </table>
        </div>
        <div class="grid-2">
            <div class="card">
                <h3>Amount by Major Head</h3>
                <table>
                    <thead><tr><th>Major Head</th><th>Total Amount</th></tr></thead>
                    <tbody>
"""
        for mh, amt in mh_stats.items():
            html_content += f"""<tr><td>{mh}</td><td>₹ {amt:,.2f}</td></tr>"""
            
        html_content += """
                    </tbody>
                </table>
            </div>
            <div class="card">
                <h3>Treasury-wise Summary</h3>
                <table>
                    <thead><tr><th>Treasury</th><th>Total Checked</th><th>Flagged</th></tr></thead>
                    <tbody>
"""
        for treas, stat in treasury_stats.items():
            html_content += f"""<tr><td>{treas}</td><td>{stat['total']}</td><td>{stat['flagged']}</td></tr>"""
            
        html_content += """
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- TAB 5: POST-DOWNLOAD CHECKS -->
    <div id="tab-post" class="tab-content">
"""
        if not self.post_results:
            html_content += "<p>No post-download check results available.</p>"
        else:
            for chk_id, post_res in self.post_results.items():
                html_content += f"""
        <div class="card">
            <h3>{post_res.get("check_name", chk_id)}</h3>
            <p>Status: <strong>{post_res.get("status")}</strong> | Message: {post_res.get("message")}</p>
"""
                rows = post_res.get("rows", [])
                if rows and isinstance(rows[0], dict):
                    headers = list(rows[0].keys())
                    html_content += "<table><thead><tr>"
                    for h in headers: html_content += f"<th>{h}</th>"
                    html_content += "</tr></thead><tbody>"
                    for row in rows:
                        html_content += "<tr>"
                        for h in headers: html_content += f"<td>{row.get(h, '')}</td>"
                        html_content += "</tr>"
                    html_content += "</tbody></table>"
                html_content += "</div>"
                
        html_content += """
    </div>

    <script>
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            tablinks = document.getElementsByClassName("tab-btn");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
        }

        function filterTable() {
            var input, filter, table, tr, td, i, j, txtValue;
            input = document.getElementById("searchInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("allTable");
            tr = table.getElementsByTagName("tr");
            for (i = 1; i < tr.length; i++) {
                tr[i].style.display = "none";
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                    if (td[j]) {
                        txtValue = td[j].textContent || td[j].innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                            break;
                        }
                    }
                }
            }
        }

        function sortTable(n) {
            var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
            table = document.getElementById("allTable");
            switching = true;
            dir = "asc"; 
            while (switching) {
                switching = false;
                rows = table.rows;
                for (i = 1; i < (rows.length - 1); i++) {
                    shouldSwitch = false;
                    x = rows[i].getElementsByTagName("TD")[n];
                    y = rows[i + 1].getElementsByTagName("TD")[n];
                    var xContent = x.innerHTML.toLowerCase().replace(/<[^>]*>?/gm, '');
                    var yContent = y.innerHTML.toLowerCase().replace(/<[^>]*>?/gm, '');
                    
                    if (dir == "asc") {
                        if (xContent > yContent) { shouldSwitch = true; break; }
                    } else if (dir == "desc") {
                        if (xContent < yContent) { shouldSwitch = true; break; }
                    }
                }
                if (shouldSwitch) {
                    rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                    switching = true;
                    switchcount ++; 
                } else {
                    if (switchcount == 0 && dir == "asc") {
                        dir = "desc";
                        switching = true;
                    }
                }
            }
        }
    </script>
</body>
</html>
"""
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html_content)

        self.log(f"🌐 HTML Summary Dashboard generated: {html_path}")
        return excel_path, html_path
