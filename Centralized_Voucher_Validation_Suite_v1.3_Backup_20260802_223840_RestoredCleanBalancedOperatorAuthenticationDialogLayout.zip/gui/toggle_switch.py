"""
toggle_switch.py - Custom painted toggle-switch widget for Centralized Voucher Validation Suite.

Renders a pill-shaped track with a sliding circular knob using QPainter,
bypassing all QSS limitations.  Drop-in replacement for QCheckBox where
a toggle appearance is desired.

Usage
-----
    from gui.toggle_switch import ToggleSwitch

    sw = ToggleSwitch("Enable Feature", parent)
    sw.setChecked(True)

    # For warning-coloured toggles:
    sw = ToggleSwitch("Dry Run", parent, variant="warning")

Theme colours are picked up automatically from the QApplication via
``update_theme_colors()``.  Call that method on every toggle after a
theme change, or use the convenience ``update_all_toggles(parent)``
helper to walk the widget tree.
"""

from PySide6.QtWidgets import QCheckBox, QApplication
from PySide6.QtCore import Qt, QRect, QRectF, QPropertyAnimation, Property, QEasingCurve
from PySide6.QtGui import QPainter, QColor, QFont, QPen, QBrush


class ToggleSwitch(QCheckBox):
    """A modern pill-shaped toggle switch.

    Parameters
    ----------
    text : str
        Label shown beside the switch.
    parent : QWidget, optional
    variant : ``'normal'`` | ``'warning'``
        Colour variant.  ``'warning'`` uses an amber/orange track when ON.
    """

    # Default colours (overridden at runtime by theme)
    _track_on_color = QColor("#2ecc71")       # green
    _track_off_color = QColor("#555555")      # grey
    _knob_color = QColor("#ffffff")           # white
    _border_color = QColor("#444444")
    _warn_on_color = QColor("#e67e22")        # amber for warning variant

    # Dimensions
    _track_w = 44
    _track_h = 22
    _knob_margin = 3
    _track_radius = 11  # half of track_h for pill shape

    def __init__(self, text="", parent=None, variant="normal"):
        super().__init__(text, parent)
        self._variant = variant
        self._knob_x = self._knob_margin  # animated property
        self._animation = QPropertyAnimation(self, b"knob_position", self)
        self._animation.setDuration(150)
        self._animation.setEasingCurve(QEasingCurve.InOutCubic)

        # Hide the default QCheckBox indicator — we paint everything ourselves
        self.setStyleSheet(
            "QCheckBox::indicator { width: 0px; height: 0px; border: none; image: none; }"
            " QCheckBox { background: transparent; spacing: 0px; }"
        )

        # Connect toggled signal to animate
        self.toggled.connect(self._on_toggled)

        # Initialise from current state
        if self.isChecked():
            self._knob_x = self._knob_x_on

        # Pick up theme colours immediately
        self._apply_theme_from_app()

    # ── Animated knob position property ───────────────────────────────────

    def _get_knob_position(self):
        return self._knob_x

    def _set_knob_position(self, val):
        self._knob_x = val
        self.update()

    knob_position = Property(float, _get_knob_position, _set_knob_position)

    @property
    def _knob_diameter(self):
        return self._track_h - 2 * self._knob_margin

    @property
    def _knob_x_off(self):
        return self._knob_margin

    @property
    def _knob_x_on(self):
        return self._track_w - self._knob_diameter - self._knob_margin

    # ── Theme integration ─────────────────────────────────────────────────

    def _apply_theme_from_app(self):
        """Read theme colours from the QApplication's main window (IFMISSuiteQt)."""
        try:
            app = QApplication.instance()
            if app is None:
                return
            # The main window is the IFMISSuiteQt instance
            for w in app.topLevelWidgets():
                if hasattr(w, "get_theme_color"):
                    self._track_on_color = QColor(w.get_theme_color("BTN_PRIMARY_BG"))
                    self._warn_on_color = QColor(w.get_theme_color("BTN_WARNING_BG"))
                    self._border_color = QColor(w.get_theme_color("BORDER_COLOR"))
                    # Off track: slightly lighter than border
                    off_color = QColor(w.get_theme_color("BORDER_COLOR"))
                    off_color = off_color.lighter(130)
                    self._track_off_color = off_color
                    break
        except Exception:
            pass

    def update_theme_colors(self):
        """Public method — call after theme changes."""
        self._apply_theme_from_app()
        self.update()

    # ── Event handling ────────────────────────────────────────────────────

    def _on_toggled(self, checked):
        self._animation.stop()
        self._animation.setStartValue(self._knob_x)
        self._animation.setEndValue(self._knob_x_on if checked else self._knob_x_off)
        self._animation.start()

    def setChecked(self, checked):
        """Override to snap knob position when set programmatically."""
        super().setChecked(checked)
        self._knob_x = self._knob_x_on if checked else self._knob_x_off
        self.update()

    # ── Size hint ─────────────────────────────────────────────────────────

    def sizeHint(self):
        base = super().sizeHint()
        # Ensure enough width for track + spacing + text
        extra_w = self._track_w + 8  # track + gap
        h = max(base.height(), self._track_h + 4)
        return base.__class__(base.width() + extra_w, h)

    def minimumSizeHint(self):
        return self.sizeHint()

    # ── Painting ──────────────────────────────────────────────────────────

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # ── Track ─────────────────────────────────────────────
        checked = self.isChecked()
        if checked:
            track_color = (self._warn_on_color if self._variant == "warning"
                           else self._track_on_color)
        else:
            track_color = self._track_off_color

        track_rect = QRectF(0, (self.height() - self._track_h) / 2,
                            self._track_w, self._track_h)

        # Track border
        border_pen = QPen(self._border_color if not checked else track_color.darker(120), 1.0)
        painter.setPen(border_pen)
        painter.setBrush(QBrush(track_color))
        painter.drawRoundedRect(track_rect, self._track_radius, self._track_radius)

        # ── Knob (white circle) ───────────────────────────────
        knob_d = self._knob_diameter
        knob_y = (self.height() - knob_d) / 2
        knob_rect = QRectF(self._knob_x, knob_y, knob_d, knob_d)

        # Subtle shadow ring
        shadow_pen = QPen(QColor(0, 0, 0, 40), 1.0)
        painter.setPen(shadow_pen)
        painter.setBrush(QBrush(self._knob_color))
        painter.drawEllipse(knob_rect)

        # ── Label text ────────────────────────────────────────
        painter.setPen(QPen(self.palette().text().color()))
        text_rect = self.rect().adjusted(self._track_w + 8, 0, 0, 0)
        painter.setFont(self.font())
        painter.drawText(text_rect, Qt.AlignLeft | Qt.AlignVCenter, self.text())

        painter.end()

    # ── Click handling — make the whole widget clickable ──────────────────

    def hitButton(self, pos):
        return self.rect().contains(pos)


# ── Convenience helpers ──────────────────────────────────────────────────

def update_all_toggles(parent):
    """Walk *parent*'s widget tree and call ``update_theme_colors()``
    on every ``ToggleSwitch`` found."""
    for child in parent.findChildren(ToggleSwitch):
        child.update_theme_colors()
