; Inno Setup Script for Centralized Voucher Validation Suite - Browser Binaries Package
; Packs only Playwright browser binaries to keep application patches lightweight.

#define MyAppName "Centralized Voucher Validation Suite Browsers"
#define MyAppVersion "2.3"
#define MyAppPublisher "Administrator"

[Setup]
AppId={{5D875BC7-27C8-4228-AFED-2A3C2B68DC98}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} v{#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\Centralized Voucher Validation Suite
UsePreviousAppDir=yes
CreateAppDir=yes
DisableProgramGroupPage=yes
DisableDirPage=yes
DisableReadyPage=yes
DisableFinishedPage=no
OutputDir=output
OutputBaseFilename=IFMIS_365_Browsers_Setup
PrivilegesRequired=lowest
CloseApplications=force
RestartApplications=no
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
DisableWelcomePage=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Files]
Source: "pw-browsers\*"; DestDir: "{app}\pw-browsers"; Flags: ignoreversion recursesubdirs createallsubdirs

[Code]
function InitializeSetup(): Boolean;
var
  ResultCode: Integer;
begin
  Result := True;
  // Terminate any running instances of Centralized Voucher Validation Suite to prevent file lock issues
  Exec('taskkill.exe', '/f /im ifmis_365_suite.exe', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
end;