# backup.py
# Backup Generator for Centralized Voucher Validation Suite v1.3 (Option A: Includes pw-browsers)

import os
import sys
import shutil
import zipfile
import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(BASE_DIR)

# Exclude temporary build outputs, PyInstaller executables, browser binaries, and runtime downloads
EXCLUDE_DIRS = {"build", "dist", "output", "__pycache__", ".git", ".backups", "node_modules", "pw-browsers", "downloads", "USER_DATA", "venv", ".pytest_cache"}
EXCLUDE_EXTS = {".exe", ".zip", ".7z", ".tmp", ".log"}

def create_clean_zip_backup(description=""):
    """Create a lightweight timestamped source code + assets zip backup (~10MB)."""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    desc_suffix = f"_{description.strip().replace(' ', '_')}" if description else ""
    zip_name = f"Centralized_Voucher_Validation_Suite_v1.3_Backup_{timestamp}{desc_suffix}.zip"
    zip_path = os.path.join(PARENT_DIR, zip_name)

    print(f"Generating lightweight zip backup: {zip_name}")
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(BASE_DIR):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in EXCLUDE_EXTS:
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, BASE_DIR)
                zf.write(full_path, rel_path)

    size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"Backup Complete! File: {zip_name} | Size: {size_mb:.2f} MB")
    return zip_path

def create_clean_folder_backup():
    """Create a clean folder backup containing source code and browser binaries."""
    backup_folder_path = os.path.join(PARENT_DIR, "Backup V 1.3")
    print(f"Generating folder backup: {backup_folder_path}")
    if os.path.exists(backup_folder_path):
        shutil.rmtree(backup_folder_path)

    def _copy_clean(src, dst):
        os.makedirs(dst, exist_ok=True)
        for item in os.listdir(src):
            if item in EXCLUDE_DIRS:
                continue
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                _copy_clean(s, d)
            else:
                ext = os.path.splitext(item)[1].lower()
                if ext not in EXCLUDE_EXTS:
                    shutil.copy2(s, d)

    _copy_clean(BASE_DIR, backup_folder_path)
    print("Folder Backup Complete!")

if __name__ == "__main__":
    desc = sys.argv[1] if len(sys.argv) > 1 else ""
    create_clean_zip_backup(desc)
    create_clean_folder_backup()




